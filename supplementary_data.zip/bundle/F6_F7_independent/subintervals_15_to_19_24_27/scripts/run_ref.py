#!/usr/bin/python3
"""Run the referee's checker on the act1_test certificates.  Usage: run_ref.py mgf|t1 [names...]"""
import sys, os, json, glob, time, math
from fractions import Fraction as Fr
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import ref_boxcheck as R

LEANP = '/Users/kvallier/Desktop/Erdos 993/ProofRuns/2026-09-28_analytic_large_n/LEAN'
ACT = LEANP + '/certfree/act1_test/outputs/stage2'
OUT = LEANP + '/certfree/referee_act1_test/outputs'
D65 = Fr(6, 5)


def mgf_jobs():
    jobs = []
    P = R.piece(15)
    jobs.append(('R15_existing_lean', 15, R.lean_mbox_strip(15), Fr(7) / (2 * P['qhi']), P['m44']))
    for p in (16, 17, 18, 19):
        P = R.piece(p)
        bxs = [R.json_mbox(f) for f in sorted(glob.glob(ACT + '/mgf_D65/strip_%d/box_*.json' % p))]
        jobs.append(('R%d_new' % p, p, bxs, Fr(7) / (2 * P['qhi']), P['m44']))
    for p in (16, 18):
        P = R.piece(p)
        bxs = [R.json_mbox(f) for f in sorted(glob.glob(ACT + '/mgf_ext_D65/strip_%d/box_*.json' % p))]
        jobs.append(('ext%d_[m44,m45]' % p, p, bxs, P['m44'], P['m45']))
    for p in (24, 27):
        P = R.piece(p)
        bxs = [R.json_mbox(f) for f in sorted(glob.glob(LEANP + '/atlas_mgf/rung_25/strip_%d/box_*.json' % p))]
        jobs.append(('R%d_rung25' % p, p, bxs, Fr(8) / (2 * P['qhi']), P['m44']))
    return jobs


def t1_boxes(folder):
    out = []
    for f in sorted(glob.glob(folder + '/box_*.json')):
        r = json.load(open(f)); d = r['dual']
        b = dict(ql=Fr(r['q'][0]), qh=Fr(r['q'][1]), ml=Fr(r['m'][0]), mh=Fr(r['m'][1]), eta=Fr(d['mu']), xi=Fr(d['c']),
                 alpha=Fr(d['alpha']), beta=Fr(d['beta']), gamma=Fr(d['gamma']), z=[Fr(x) for x in d['z']], src=f,
                 box_D=Fr(r['D']), box_theta=Fr(r['theta']))
        b['m0'] = (b['ml'] + b['mh']) / 2
        b['Mstar'] = math.ceil(b['ml'])
        # least valid cutoff (own search): V = vmin N >= 25 and (T)
        vmin = min(b['ql'] * (1 - b['ql']), b['qh'] * (1 - b['qh']))
        N = math.ceil(Fr(25) / vmin)
        while True:
            V = vmin * N; x = N - b['m0']
            psi = b['alpha'] + b['beta'] * x - b['gamma'] * x * x
            if V >= 25 and psi <= -(1 / (20 * V) + 1 / (V * V)) - b['xi'] ** 2 / (4 * b['eta']) and b['beta'] - 2 * b['gamma'] * x <= 0:
                break
            N += 1
            assert N < 2000
        b['N'] = N
        out.append(b)
    return out


def t1_jobs():
    return [('LT15_new', 15, t1_boxes(ACT + '/t1_D65/band_13_22-25_89-100')),
            ('LT17_new', 17, t1_boxes(ACT + '/t1_D65/band_13_91-100_23-25'))]


def main():
    mode = sys.argv[1]; names = sys.argv[2:]
    res = {}
    if mode == 'mgf':
        for name, p, bxs, mlo, mhi in mgf_jobs():
            if names and name not in names:
                continue
            P = R.piece(p); t0 = time.time()
            stats = dict(evals=0, skipped=0, enumerated=0)
            per = []; allok = True
            for k, bx in enumerate(bxs):
                r = R.check_mgf_box(bx, P['theta'], D65, P['rates'], stats)
                r['box'] = k; r['src'] = os.path.basename(bx['src']) if '/' in bx['src'] else bx['src']
                if 'box_D' in bx:
                    r['box_params_match'] = (bx['box_theta'] == P['theta'] and bx['box_D'] == D65 and
                                             [e for _, e in bx['box_tilts']] == P['rates'] and
                                             [t for t, _ in bx['box_tilts']] == R.TAUS)
                per.append(r); allok &= r['ok']
            cov, why = R.covers(bxs, P['qlo'], P['qhi'], mlo, mhi)
            # rectangle inside the piece? boxes may exceed it; that is harmless
            res[name] = dict(piece=p, theta=str(P['theta']), D='6/5', rates=[str(x) for x in P['rates']],
                             rect=[str(P['qlo']), str(P['qhi']), str(mlo), str(mhi)], boxes=len(bxs), all_boxes_pass=allok,
                             cover=cov, cover_why=why, min_mg=min(r.get('mg', 0) for r in per),
                             min_F=min((r['least_F'] for r in per if r.get('least_F')), default=None),
                             params_match=all(r.get('box_params_match', True) for r in per),
                             fails=[(r['box'], r['why']) for r in per if not r['ok']], stats=stats, sec=round(time.time() - t0, 1))
            print(name, json.dumps({k: v for k, v in res[name].items() if k not in ('rates',)}), flush=True)
    else:
        for name, p, bxs in t1_jobs():
            if names and name not in names:
                continue
            P = R.piece(p); t0 = time.time()
            stats = dict(evals=0, skipped=0, enumerated=0)
            per = []; allok = True
            for k, bx in enumerate(bxs):
                lam_bar = bx['qh'] / (1 - bx['qh'])
                r = R.check_t1_box(bx, P['theta'], D65, P['rates'], lam_bar, stats)
                r['box'] = k; r['src'] = os.path.basename(bx['src']); r['N'] = bx['N']
                r['box_params_match'] = (bx['box_theta'] == P['theta'] and bx['box_D'] == D65)
                per.append(r); allok &= r['ok']
                if not r['ok']:
                    print('  FAIL', name, k, r['why'], flush=True)
            # boxes meeting the strip only (as the producer's cover); cover test on the whole set
            cov, why = R.covers(bxs, P['qlo'], P['qhi'], P['m44'], P['m45'])
            res[name] = dict(piece=p, theta=str(P['theta']), D='6/5', rates=[str(x) for x in P['rates']],
                             rect=[str(P['qlo']), str(P['qhi']), str(P['m44']), str(P['m45'])], boxes=len(bxs),
                             all_boxes_pass=allok, cover=cov, cover_why=why, min_mg=min(r.get('mg', 0) for r in per),
                             min_F=min((r['least_F'] for r in per if r.get('least_F')), default=None),
                             params_match=all(r['box_params_match'] for r in per), N_range=[min(b['N'] for b in bxs), max(b['N'] for b in bxs)],
                             fails=[(r['box'], r['why']) for r in per if not r['ok']], stats=stats, sec=round(time.time() - t0, 1))
            print(name, json.dumps({k: v for k, v in res[name].items() if k not in ('rates',)}), flush=True)
    tag = mode + ('_' + '_'.join(names) if names else '')
    json.dump(res, open(os.path.join(OUT, 'ref_%s.json' % tag), 'w'), indent=1, default=str)


if __name__ == '__main__':
    main()
