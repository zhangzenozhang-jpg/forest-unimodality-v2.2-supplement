#!/usr/bin/python3
"""Referee's exact recheck of the obstruction mixtures of act1_test (Proposition act1:prop:fail and the bracket
witnesses).  Exact rational arithmetic for every moment, the binomial kernels and the cdf; the exponentials
e^{-l mu} are enclosed in arb balls (200 bits) and every inequality involving them must hold for the whole ball.
Parameters (theta, rates, edges, floors) come from the Lean data (ref_boxcheck.piece), not from the witness files."""
import sys, os, json, math
from fractions import Fraction as Fr
from flint import arb, fmpq, ctx
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import ref_boxcheck as R

ctx.prec = 200
W = '/Users/kvallier/Desktop/Erdos 993/ProofRuns/2026-09-28_analytic_large_n/LEAN/certfree/act1_test/outputs/stage2'
TAUS = R.TAUS


def b(M, j, q):
    if j < 0 or j > M:
        return Fr(0)
    return math.comb(M, j) * q ** j * (1 - q) ** (M - j)


def check(path, p, kind, D, where):
    w = json.load(open(path))
    P = R.piece(p)
    lam = Fr(w['lam']); q = lam / (1 + lam); mu = Fr(w['mu'])
    theta = P['theta']; rates = P['rates']
    atoms = [(int(a['M']), int(a['j']), Fr(a['w'])) for a in w['atoms']]
    out = dict(file=os.path.basename(path), piece=p, kind=kind, D=str(D), lam=str(lam), mu=str(mu), states=len(atoms))
    out['file_params_match'] = (Fr(w['theta']) == theta and Fr(w['D']) == D and [Fr(x) for x in w['rates']] == rates
                                and Fr(w['q']) == q)
    # point location
    if where == 'm21':
        out['point_is_corner'] = (lam == P['lamhi'] and mu == Fr(7) / (2 * P['qhi']))
    else:
        out['point_is_corner'] = (lam == P['lamhi'] and mu == P['m44'] and P['m44'] < P['m45'])
    c = {}
    c['nonneg'] = all(x >= 0 for _, _, x in atoms)
    c['M_nat'] = all(M >= 0 for M, _, _ in atoms)
    c['mass_one'] = sum(x for _, _, x in atoms) == 1
    EM = sum(x * M for M, _, x in atoms)
    c['mean_mu'] = EM == mu
    Ed = sum(x * (j - q * M) for M, j, x in atoms)
    c['E_delta_0'] = Ed == 0
    Ed2 = sum(x * (j - q * M) ** 2 for M, j, x in atoms)
    budget = theta * q * (1 - q) * mu
    c['E_delta2_lt_budget'] = Ed2 < budget
    out['E_delta2_ratio'] = float(Ed2 / (q * (1 - q) * mu))
    Var = sum(x * (M - mu) ** 2 for M, _, x in atoms)
    c['Var_le_Dmu'] = Var <= D * mu
    out['Var_over_mu'] = float(Var / mu)
    out['Var_minus_Dmu'] = float(Var - D * mu)
    EfL = sum(x * ((1 - q) * b(M, j, q) - q * b(M, j - 1, q)) for M, j, x in atoms)
    EfR = sum(x * (q * b(M, j, q) - (1 - q) * b(M, j + 1, q)) for M, j, x in atoms)
    out['E_fL'] = float(EfL); out['E_fR'] = float(EfR)
    if kind == 'mgf':
        c['valley_L'] = EfL <= 0
        c['valley_R'] = EfR <= 0
        lap = []
        for t, l in zip(TAUS, rates):
            s = 1 - q + q * t
            Es = sum(x * s ** M for M, _, x in atoms)
            e = (-R.A(l * mu)).exp()
            ok = bool((e - R.A(Es)) >= 0)
            lap.append(ok)
            out.setdefault('laplace_rel_slack', []).append(float(((e - R.A(Es)) / e).mid()))
        c['laplace_all'] = all(lap)
    else:
        Ek = EfL / q + EfR / (1 - q)
        c['E_kappa_le_0'] = Ek <= 0
        out['E_kappa'] = float(Ek)
        M1 = math.ceil(mu) + 1
        out['M1'] = M1
        cdf_ok = True; worst = None
        for Mp in range(M1):
            F = sum(x for M, _, x in atoms if M <= Mp)
            if F > 1:
                cdf_ok = False
            for t, l in zip(TAUS, rates):
                T = (-R.A(l * mu)).exp() * R.A(((1 + lam) / (1 + lam * t)) ** Mp)
                if not bool((T - R.A(F)) >= 0):
                    cdf_ok = False
                rel = float(((T - R.A(F)) / T).mid())
                if worst is None or rel < worst[0]:
                    worst = (rel, Mp, str(t))
        c['cdf_le_T44_below_M1'] = cdf_ok
        out['cdf_worst_rel_slack'] = worst
    out['checks'] = c
    out['ok'] = all(c.values()) and out['point_is_corner']
    return out


JOBS = [
    ('witness/witness_R24_D65.json', 24, 'mgf', Fr(6, 5), 'm21'),
    ('witness/witness_R27_D65.json', 27, 'mgf', Fr(6, 5), 'm21'),
    ('t1_lp/witness_P16_D65_kappa.json', 16, 't1', Fr(6, 5), 'm44'),
    ('t1_lp/witness_P18_D65_kappa.json', 18, 't1', Fr(6, 5), 'm44'),
    ('witness/witness_R24_D11o10.json', 24, 'mgf', Fr(11, 10), 'm21'),
    ('witness/witness_R24_D109o100.json', 24, 'mgf', Fr(109, 100), 'm21'),
    ('witness/witness_R27_D47o40.json', 27, 'mgf', Fr(47, 40), 'm21'),
    ('t1_lp/witness_P16_D119o100_kappa.json', 16, 't1', Fr(119, 100), 'm44'),
    ('t1_lp/witness_P18_D119o100_kappa.json', 18, 't1', Fr(119, 100), 'm44'),
]

if __name__ == '__main__':
    res = []
    for f, p, kind, D, where in JOBS:
        r = check(os.path.join(W, f), p, kind, D, where)
        res.append(r)
        print(json.dumps(r), flush=True)
    json.dump(res, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'outputs', 'ref_mixtures.json'), 'w'),
              indent=1)
