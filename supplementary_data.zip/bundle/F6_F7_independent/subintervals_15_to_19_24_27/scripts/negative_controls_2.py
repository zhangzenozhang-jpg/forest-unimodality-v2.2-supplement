#!/usr/bin/python3
import sys, os, json
from fractions import Fraction as Fr
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import ref_boxcheck as R, run_ref as RR
def st(): return dict(evals=0, skipped=0, enumerated=0)
out = []
jobs = {j[0]: j for j in RR.mgf_jobs()}
name, p, bxs, mlo, mhi = jobs['R24_rung25']; P = R.piece(p)
out.append(('MGF R24_rung25 D=6/5+1/100: boxes failing', sum(not R.check_mgf_box(bx, P['theta'], Fr(6,5)+Fr(1,100), P['rates'], st())['ok'] for bx in bxs), len(bxs)))
t1 = {j[0]: j for j in RR.t1_jobs()}
name, p, bxs = t1['LT15_new']; P = R.piece(p)
res = []
for bx in bxs[:12]:
    lb = bx['qh'] / (1 - bx['qh'])
    b = dict(bx); b['alpha'] = bx['alpha'] + Fr(1, 10**4)
    r = R.check_t1_box(b, P['theta'], Fr(6,5), P['rates'], lb, st()); res.append(r['why'][:20])
out.append(('t1 LT15 first 12 boxes alpha+1e-4: reasons', res))
for o in out: print(o)
json.dump(out, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'outputs', 'negative_controls_2.json'), 'w'), indent=1)
