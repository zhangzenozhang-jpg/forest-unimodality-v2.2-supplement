#!/usr/bin/python3
"""Controls: the existing Lean rung-21 boxes of strips 16-19, 24, 27 at the certified caps (must pass) and at 6/5
(the author's Stage 1 says they fail (Mg) on some boxes)."""
import sys, os, json
from fractions import Fraction as Fr
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import ref_boxcheck as R
CERT = {15: Fr(11, 10), 16: Fr(11, 10), 17: Fr(11, 10), 18: Fr(11, 10), 19: Fr(11, 10), 24: Fr(21, 20), 27: Fr(23, 20)}
out = {}
for p in (16, 17, 18, 19, 24, 27):
    P = R.piece(p); bxs = R.lean_mbox_strip(p)
    row = {}
    for Dname, D in (('cert', CERT[p]), ('6/5', Fr(6, 5))):
        stats = dict(evals=0, skipped=0, enumerated=0)
        fails = []; mgs = []
        for k, bx in enumerate(bxs):
            r = R.check_mgf_box(bx, P['theta'], D, P['rates'], stats) if Dname == 'cert' or True else None
            if not r['ok']:
                fails.append((k, r['why']))
            mgs.append(r.get('mg', float('nan')))
        cov, _ = R.covers(bxs, P['qlo'], P['qhi'], Fr(7) / (2 * P['qhi']), P['m44'])
        row[Dname] = dict(boxes=len(bxs), fails=len(fails), fail_list=fails[:12], min_mg=min(mgs), cover=cov)
    out[p] = row
    print(p, json.dumps(row), flush=True)
json.dump(out, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'outputs', 'controls_mgf.json'), 'w'), indent=1, default=str)
