#!/usr/bin/python3
"""DIAGNOSTIC (floating point): the referee's own moment LP for the largest cap D* at a point (q, mu):
D* = (min E M^2 - mu^2)/mu over probability mixtures on states (M, j) satisfying every other hypothesis of the
criterion (MGF: valley E fL <= 0, E fR <= 0 and the five Laplace constraints; lower-tail: E kappa <= 0 and the cdf
bounds P(M <= M') <= T44 for M' <= ceil(mu)).  Below D* no mixture exists (necessary for a certificate to exist);
the box/point certificate existence is then the LP dual (strong duality of the finite LP)."""
import sys, os, json, math
import numpy as np
from scipy.optimize import linprog
from scipy.stats import binom
from fractions import Fraction as Fr
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import ref_boxcheck as R
TAUS = [0, 0.05, 0.1, 0.2, 0.3]

def dstar(p, lam, mu, kind, Mmax=70):
    P = R.piece(p); lam = float(lam); mu = float(mu); q = lam / (1 + lam)
    th = float(P['theta']); rates = [float(x) for x in P['rates']]
    states = [(M, j) for M in range(Mmax + 1) for j in range(-3, M + 4)]
    Ms = np.array([s[0] for s in states], float); js = np.array([s[1] for s in states], float)
    def b(M, j):
        return binom.pmf(j, M, q) if 0 <= j <= M else 0.0
    fL = np.array([(1 - q) * b(M, j) - q * b(M, j - 1) for M, j in states])
    fR = np.array([q * b(M, j) - (1 - q) * b(M, j + 1) for M, j in states])
    d = js - q * Ms
    A_eq = [np.ones(len(states)), Ms, d]; b_eq = [1, mu, 0]
    A_ub = [d * d]; b_ub = [th * q * (1 - q) * mu]
    if kind == 'mgf':
        A_ub += [fL, fR]; b_ub += [0, 0]
        for t, l in zip(TAUS, rates):
            A_ub.append((1 - q + q * t) ** Ms); b_ub.append(math.exp(-l * mu))
    else:
        A_ub.append(fL / q + fR / (1 - q)); b_ub.append(0)
        for Mp in range(math.ceil(mu) + 1):
            T = min([1.0] + [math.exp(-l * mu) * ((1 + lam) / (1 + lam * t)) ** Mp for t, l in zip(TAUS, rates)])
            A_ub.append((Ms <= Mp).astype(float)); b_ub.append(T)
    res = linprog(Ms * Ms, A_ub=np.array(A_ub), b_ub=b_ub, A_eq=np.array(A_eq), b_eq=b_eq, bounds=(0, None), method='highs')
    if res.status == 2:
        return float('inf')
    return (res.fun - mu * mu) / mu

out = {}
pts = {'a_R24_corner': (24, Fr(103, 100), Fr(1421, 206), 'mgf'), 'b_R27_corner': (27, Fr(107, 100), Fr(1449, 214), 'mgf'),
       'c_P16_corner': (16, Fr(91, 100), Fr(1146, 91), 't1'), 'd_P18_corner': (18, Fr(93, 100), Fr(386, 31), 't1')}
for k, (p, lam, mu, kind) in pts.items():
    out[k] = dstar(p, lam, mu, kind); print(k, out[k], flush=True)
# a coarse grid over R24 and R27 (rung 21) and over the rung-25 rectangles
for p, kind in ((24, 'mgf'), (27, 'mgf')):
    P = R.piece(p)
    grid = []
    for a in range(3):
        lam = P['lamlo'] + (P['lamhi'] - P['lamlo']) * Fr(a, 2)
        qhi = P['qhi']
        for mu in [Fr(7) / (2 * qhi), Fr(15, 2) / (2 * qhi), Fr(8) / (2 * qhi), Fr(9) / (2 * qhi), Fr(11) / (2 * qhi), P['m44']]:
            grid.append((float(lam), float(mu), dstar(p, lam, mu, kind)))
    out['grid_%d' % p] = grid
    for g in grid: print(p, g, flush=True)
json.dump(out, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'outputs', 'ref_dstar_lp.json'), 'w'), indent=1)
