#!/usr/bin/python3
"""Negative controls of the referee's checker: perturbations that must be rejected."""
import sys, os, json, glob
from fractions import Fraction as Fr
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import ref_boxcheck as R, run_ref as RR
out = []
jobs = {j[0]: j for j in RR.mgf_jobs()}
def st(): return dict(evals=0, skipped=0, enumerated=0)
# 1. MGF: alpha + 1e-9 on every box of R27_rung25 -> some (F) or (T) failure expected (tight atom 1e-12)
name, p, bxs, mlo, mhi = jobs['R27_rung25']; P = R.piece(p)
fails = 0
for bx in bxs:
    b = dict(bx); b['alpha'] = bx['alpha'] + Fr(1, 10**9)
    r = R.check_mgf_box(b, P['theta'], Fr(6, 5), P['rates'], st())
    fails += (not r['ok']) and r['why'].startswith('F')
out.append(('MGF R27_rung25 alpha+1e-9: boxes failing (F)', fails, len(bxs)))
# 2. MGF: D raised to 6/5 + 1/1000 on R24_rung25 -> (Mg) fails on the box of least margin
name, p, bxs, mlo, mhi = jobs['R24_rung25']; P = R.piece(p)
fails = sum(not R.check_mgf_box(bx, P['theta'], Fr(6, 5) + Fr(1, 1000), P['rates'], st())['ok'] for bx in bxs)
out.append(('MGF R24_rung25 D=6/5+1/1000: boxes failing', fails, len(bxs)))
# 3. MGF cover: drop one box of R16_new -> cover must fail
name, p, bxs, mlo, mhi = jobs['R16_new']; P = R.piece(p)
out.append(('cover R16_new minus box 0', R.covers(bxs[1:], P['qlo'], P['qhi'], mlo, mhi)[0], 'expect False'))
# 4. t1: alpha + 1e-7 on LT15 boxes -> (F) failures expected; D + 1/1000 -> Mg failures
t1 = {j[0]: j for j in RR.t1_jobs()}
name, p, bxs = t1['LT15_new']; P = R.piece(p)
fF = 0; fM = 0
for bx in bxs[:20]:
    lb = bx['qh'] / (1 - bx['qh'])
    b = dict(bx); b['alpha'] = bx['alpha'] + Fr(1, 10**7)
    r = R.check_t1_box(b, P['theta'], Fr(6, 5), P['rates'], lb, st()); fF += (not r['ok'])
    r = R.check_t1_box(bx, P['theta'], Fr(6, 5) + Fr(1, 1000), P['rates'], lb, st()); fM += (not r['ok'])
out.append(('t1 LT15 first 20 boxes alpha+1e-7: failing', fF, 20))
out.append(('t1 LT15 first 20 boxes D=6/5+1/1000: failing', fM, 20))
# 5. t1 with the tail base lowered to the box's lower q (lam_bar = ql/(1-ql)) must still pass or fail only in Mg (info)
for o in out: print(o)
json.dump(out, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'outputs', 'negative_controls.json'), 'w'), indent=1)
