#!/usr/bin/python3
"""Referee's own box checker for certfree/act1_test (written 1 Oct 2026 from part2_body.tex Sec. p2:sec:atlas and
appendix_C_inputs.tex Sec. apC:sec:mgfbox / apC:sec:t1box; no code reused from the author's scripts).

What is checked, per box, is the STATEMENT a passing box must imply (Theorems apC:thm:mgfbox, apC:thm:t1box):
  (S)  signs;  (T) the elementary tail for fibres M >= N (MGF: kernel >= -max(wL,wR); lower-tail: the paper's
       Fourier kernel floor 1/(20 V)+1/V^2 at V = v_min N >= 25, taken from Lemma apC:lem:fourier as proved);
  (F)  for every fibre M < N and EVERY atom j: rhs(M) <= kappa2(M,j;q) + xi*delta + eta*delta^2 for all q in [ql,qh].
       Outside atoms (j<=-2, j>=M+2): exact rational half-line minima.  Atoms -1..M+1: an exact rational skip
       (kappa2 >= -max(wL,wR) plus the exact minimum of the quadratic over the delta-interval), else an arb ball
       evaluation (python-flint, 200 bits, outward rounding) of kappa2 = B(q) K(q) over the q-interval, with
       bisection of the q-interval (depth <= 60).  This is NOT the paper's Taylor test; it is an independent
       sufficient test of the same pointwise inequality.
  (Mg) exact rational, with e^{-x} <= 1/sum_{i<=60} x^i/i! (x >= 0).
Parameters (theta, D, rates, edges, floors) are read from the Lean data modules (READ ONLY), not from the boxes.
"""
import sys, os, re, json, glob, time, math
from fractions import Fraction as Fr
from flint import arb, fmpq, ctx

ctx.prec = 200
LEAN = '/Users/kvallier/Desktop/Erdos993-Lean-FiberFloor/Erdos993Lean/Analytic'
TAUS = [Fr(0), Fr(1, 20), Fr(1, 10), Fr(1, 5), Fr(3, 10)]


def fq(x):
    x = Fr(x)
    return fmpq(x.numerator, x.denominator)


def A(x):
    return arb(fq(x))


# ------------------------------------------------------------------ Lean data (parsed directly)
def lean_lists(path):
    s = open(path).read()
    out = {}
    for m in re.finditer(r'def (\w+)\s*:\s*List\s*\(?(List\s+)?(\w+)\)?\s*:=\s*(\[.*?\])\s*\n\s*\n', s, re.S):
        name, nested, typ, body = m.group(1), m.group(2), m.group(3), m.group(4)
        if typ == 'Nat':
            out[name] = [int(t) for t in re.findall(r'\d+', body)]
        elif nested:
            rows = re.findall(r'\[([^\[\]]*)\]', body)
            out[name] = [[Fr(int(a), int(b)) for a, b in re.findall(r'R \((-?\d+)\) (\d+)', r)] for r in rows]
        else:
            out[name] = [Fr(int(a), int(b)) for a, b in re.findall(r'R \((-?\d+)\) (\d+)', body)]
    return out


N44 = lean_lists(os.path.join(LEAN, 'N44/Data/Params.lean'))
N45 = lean_lists(os.path.join(LEAN, 'N45/Data/Params.lean'))
assert len(N44['pieceLo']) == 55 and len(N44['rates44']) == 55 and all(len(r) == 5 for r in N44['rates44'])
assert len(N45['mmin45']) == 46


def qof(lam):
    return lam / (1 + lam)


def piece(p):
    lo, hi = N44['pieceLo'][p], N44['pieceHi'][p]
    return dict(p=p, lamlo=lo, lamhi=hi, qlo=qof(lo), qhi=qof(hi), theta=N44['theta44'][p], D44=N44['D44'][p],
                rates=N44['rates44'][p], m44=N44['mmin44'][p], m45=N45['mmin45'][N44['pieceUp'][p]],
                k44=N44['kmin44'][p])


def lean_mbox_strip(p):
    """The existing rung-21 boxes of strip p, parsed from MGF/Data/R21Sxx.lean (MBox field order of MGF/Checker.lean)."""
    s = open(os.path.join(LEAN, 'MGF/Data/R21S%02d.lean' % p)).read()
    boxes = []
    for m in re.finditer(r'def boxR21S\d+_\d+ : MBox :=\s*⟨(.*?)⟩', s, re.S):
        body = m.group(1)
        zpart = re.search(r'\[(.*?)\]', body).group(1)
        z = [Fr(int(a), int(b)) for a, b in re.findall(r'R \((-?\d+)\) (\d+)', zpart)]
        head = body[:body.index('[')]
        vals = [Fr(int(a), int(b)) for a, b in re.findall(r'R \((-?\d+)\) (\d+)', head)]
        N = int(re.search(r'\]\s*,\s*(\d+)\s*$', body.strip()).group(1))
        ql, qh, ml, mh, m0, nu, c, al, be, ga, a, b = vals
        boxes.append(dict(ql=ql, qh=qh, ml=ml, mh=mh, m0=m0, eta=nu, xi=c, alpha=al, beta=be, gamma=ga, wL=a, wR=b,
                          z=z, N=N, src='lean R21S%02d' % p))
    return boxes


def json_mbox(path):
    r = json.load(open(path))
    d = r['dual']
    return dict(ql=Fr(r['q'][0]), qh=Fr(r['q'][1]), ml=Fr(r['m'][0]), mh=Fr(r['m'][1]), m0=Fr(r['m0']),
                eta=Fr(d['nu']), xi=Fr(d['c']), alpha=Fr(d['alpha']), beta=Fr(d['beta']), gamma=Fr(d['gamma']),
                wL=Fr(d['a']), wR=Fr(d['b']), z=[Fr(x) for x in d['z']], N=int(r['cutoff']), src=path,
                box_theta=Fr(r['theta']), box_D=Fr(r['D']), box_tilts=[(Fr(t), Fr(e)) for t, e in r['tilts']])


# ------------------------------------------------------------------ helpers
def quad_min(eta, xi, lo, hi):
    """exact min of eta d^2 + xi d over d in [lo, hi] (lo may be None = -inf, hi None = +inf); eta > 0"""
    ds = -xi / (2 * eta)
    if lo is not None and ds < lo:
        d = lo
    elif hi is not None and ds > hi:
        d = hi
    else:
        d = ds
    return eta * d * d + xi * d


def exp_neg_upper(x):
    """exact rational upper bound of e^{-x}, x >= 0: 1/sum_{i<=60} x^i/i!"""
    assert x >= 0
    s = Fr(0); t = Fr(1)
    for i in range(61):
        s += t
        t = t * x / (i + 1)
    return 1 / s


def vmax(ql, qh):
    if ql <= Fr(1, 2) <= qh:
        return Fr(1, 4)
    return max(ql * (1 - ql), qh * (1 - qh))


def kappa_ball(M, j, Q, wL, wR):
    """ball enclosing kappa2(M,j;q) for q in the ball Q (0<q<1)"""
    if j == -1:
        return -A(wR) * (1 - Q) ** M
    if j == M + 1:
        return -A(wL) * Q ** M
    kL = Fr(M + 1 - 2 * j, M - j + 1)
    kR = Fr(2 * j + 1 - M, j + 1)
    B = A(math.comb(M, j)) * Q ** (j - 1) * (1 - Q) ** (M - j - 1)
    K = A(wL * kL) * (1 - Q) ** 2 + A(wR * kR) * Q ** 2
    return B * K


def atom_ok(M, j, a, b, bx, rhs, wL, wR, depth, stats):
    """rhs <= kappa2 + xi d + eta d^2 for all q in [a,b], d = j - qM"""
    qm = quad_min(bx['eta'], bx['xi'], j - b * M, j - a * M)
    Q = A(a).union(A(b))
    val = kappa_ball(M, j, Q, wL, wR) + A(qm) - A(rhs)
    stats['evals'] += 1
    if val >= 0:
        return True, val.lower()
    if depth >= 60:
        return False, val.lower()
    mid = (a + b) / 2
    ok1, s1 = atom_ok(M, j, a, mid, bx, rhs, wL, wR, depth + 1, stats)
    if not ok1:
        return False, s1
    ok2, s2 = atom_ok(M, j, mid, b, bx, rhs, wL, wR, depth + 1, stats)
    return ok2, (s1 if s1 < s2 else s2)


def check_F(bx, rhs_of, wL, wR, floor_skip, stats):
    """(F): every fibre M < N, every atom j.  floor_skip: a valid lower bound -c of kappa2 (c >= 0) for the exact skip."""
    eta, xi = bx['eta'], bx['xi']
    ql, qh, N = bx['ql'], bx['qh'], bx['N']
    least = None
    for M in range(N):
        rhs = rhs_of(M)
        # outside atoms (kappa2 = 0)
        if rhs > quad_min(eta, xi, None, -2 - ql * M):
            return False, 'F outside left M=%d' % M, None
        if rhs > quad_min(eta, xi, M + 2 - qh * M, None):
            return False, 'F outside right M=%d' % M, None
        for j in range(-1, M + 2):
            qmin = quad_min(eta, xi, j - qh * M, j - ql * M)
            if rhs <= qmin - floor_skip:
                stats['skipped'] += 1
                continue
            stats['enumerated'] += 1
            ok, s = atom_ok(M, j, ql, qh, bx, rhs, wL, wR, 0, stats)
            if not ok:
                return False, 'F atom M=%d j=%d (ball lower %s)' % (M, j, s), None
            sf = float(s.mid())
            if least is None or sf < least[0]:
                least = (sf, M, j)
    return True, 'ok', least


# ------------------------------------------------------------------ MGF box test
def check_mgf_box(bx, theta, D, rates, stats):
    eta, xi, al, be, ga, wL, wR, z, N, m0 = (bx[k] for k in ('eta', 'xi', 'alpha', 'beta', 'gamma', 'wL', 'wR', 'z', 'N', 'm0'))
    ql, qh, ml, mh = bx['ql'], bx['qh'], bx['ml'], bx['mh']
    # (S)
    if not (0 < ql < qh < 1 and eta > 0 and ga >= 0 and wL >= 0 and wR >= 0 and all(x >= 0 for x in z) and 0 < ml <= mh
            and len(z) == 5):
        return dict(ok=False, why='S')
    psi = lambda M: al + be * (M - m0) - ga * (M - m0) ** 2
    Bk = max(wL, wR)
    # (T)
    if not (psi(N) <= -Bk - xi * xi / (4 * eta) and be - 2 * ga * (N - m0) <= 0):
        return dict(ok=False, why='T')
    # (Mg)
    ehat = [exp_neg_upper(l * ml) for l in rates]
    mg = (al + min(be * (ml - m0), be * (mh - m0)) - ga * (D * mh + max((ml - m0) ** 2, (mh - m0) ** 2))
          - eta * theta * vmax(ql, qh) * mh - sum(zr * e for zr, e in zip(z, ehat)))
    if not mg > 0:
        return dict(ok=False, why='Mg', mg=float(mg))
    # (F)
    s = [1 - qh + qh * t for t in TAUS]
    cache = {}

    def rhs_of(M):
        return psi(M) - sum(zr * sr ** M for zr, sr in zip(z, s))
    okF, why, least = check_F(bx, rhs_of, wL, wR, Bk, stats)
    return dict(ok=okF, why=why, mg=float(mg), mg_rel=float(mg / al) if al else None, least_F=least)


# ------------------------------------------------------------------ lower-tail box test
def check_t1_box(bx, theta, D, rates, lam_bar, stats):
    eta, xi, al, be, ga, z, N, m0, Mstar = (bx[k] for k in ('eta', 'xi', 'alpha', 'beta', 'gamma', 'z', 'N', 'm0', 'Mstar'))
    ql, qh, ml, mh = bx['ql'], bx['qh'], bx['ml'], bx['mh']
    if not (0 < ql < qh < 1 and eta > 0 and ga > 0 and all(x >= 0 for x in z) and 0 < ml <= mh and Mstar < ml + 1
            and lam_bar >= 0):
        return dict(ok=False, why='S')
    psi = lambda M: al + be * (M - m0) - ga * (M - m0) ** 2
    vmin = min(ql * (1 - ql), qh * (1 - qh))
    V = vmin * N
    if not (V >= 25 and psi(N) <= -(1 / (20 * V) + 1 / (V * V)) - xi * xi / (4 * eta) and be - 2 * ga * (N - m0) <= 0):
        return dict(ok=False, why='T')
    # (Mg): T-hat'_{M'} = min(1, min_r ehat_r ((1+lb)/(1+lb tau_r))^{M'}) for M' <= M*, else 1
    ehat = [exp_neg_upper(l * ml) for l in rates]
    tail = Fr(0)
    for Mp, zM in enumerate(z):
        if zM == 0:
            continue
        if Mp <= Mstar:
            T = min([Fr(1)] + [e * ((1 + lam_bar) / (1 + lam_bar * t)) ** Mp for e, t in zip(ehat, TAUS)])
        else:
            T = Fr(1)
        tail += zM * T
    mg = (al + min(be * (ml - m0), be * (mh - m0)) - ga * (D * mh + max((ml - m0) ** 2, (mh - m0) ** 2))
          - eta * theta * vmax(ql, qh) * mh - tail)
    if not mg > 0:
        return dict(ok=False, why='Mg', mg=float(mg))
    suffix = [Fr(0)] * (len(z) + 1)
    for i in range(len(z) - 1, -1, -1):
        suffix[i] = suffix[i + 1] + z[i]

    def rhs_of(M):
        return psi(M) - (suffix[M] if M < len(z) else 0)
    okF, why, least = check_F(bx, rhs_of, Fr(1), Fr(1), Fr(1), stats)
    return dict(ok=okF, why=why, mg=float(mg), mg_rel=float(mg / al) if al else None, least_F=least)


# ------------------------------------------------------------------ cover test (own sweep)
def covers(boxes, qlo, qhi, mlo, mhi):
    """True iff the union of the closed boxes contains [qlo,qhi] x [mlo,mhi]: elementary q-cells from all box edges,
    and on each cell the m-intervals of the boxes containing it must cover [mlo,mhi]."""
    edges = sorted(set([qlo, qhi] + [b['ql'] for b in boxes] + [b['qh'] for b in boxes]))
    edges = [e for e in edges if qlo <= e <= qhi]
    for a, b in zip(edges, edges[1:]):
        iv = sorted((bx['ml'], bx['mh']) for bx in boxes if bx['ql'] <= a and b <= bx['qh'])
        reach = mlo
        if not iv or iv[0][0] > mlo:
            return False, ('gap at', float(a), float(b), float(mlo))
        for l, h in iv:
            if l > reach:
                break
            reach = max(reach, h)
        if reach < mhi:
            return False, ('gap at', float(a), float(b), float(reach))
    # also the degenerate case qlo == qhi not used here
    return True, None
