#!/bin/bash
# Referee: run ref_mgf_check.py on all 55 strips [m_*, 50] and the 3 toML strips. One process, nice -n 10.
cd "$(dirname "$0")"
R=../one_criterion_test/outputs/stage2/mgf_one
OUT=out_strips.jsonl
: > $OUT
echo "start $(date)" > run_strips.log
for i in $(seq 0 54); do
  if [ $i -ge 21 ] && [ $i -le 23 ]; then root=$R/band14_to50; else root=$R/to50; fi
  nice -n 10 python3 ref_mgf_check.py strip $root $i >> $OUT 2>> run_strips.log
done
for i in 2 47 54; do
  echo "toML $i" >> run_strips.log
  nice -n 10 python3 ref_mgf_check.py strip $R/toML $i >> out_toML.jsonl 2>> run_strips.log
done
echo "done $(date)" >> run_strips.log
