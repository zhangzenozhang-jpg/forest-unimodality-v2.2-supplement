#!/bin/bash
# Rerun of both main checks with the final ref_mgf_check.py (the floor_scope option added at 13:56 does not change the
# default path). Two processes at most, nice -n 10.
cd "$(dirname "$0")"
R=../one_criterion_test/outputs/stage2/mgf_one
echo "rerun start $(date)" > rerun_final.log
( for i in $(seq 0 54); do
    if [ $i -ge 21 ] && [ $i -le 23 ]; then root=$R/band14_to50; else root=$R/to50; fi
    nice -n 10 python3 ref_mgf_check.py strip $root $i
  done > out_strips_final.jsonl 2>> rerun_final.log; echo "strips done $(date)" >> rerun_final.log ) &
nice -n 10 python3 ref_convert_check.py 0 1 > out_convert_final.jsonl 2>> rerun_final.log
echo "convert done $(date)" >> rerun_final.log
wait
echo "rerun done $(date)" >> rerun_final.log
