"""Referee check of claim (iii) / Proposition oc:prop:floor(c): convert every lower-tail box of the 31 coverings of
[50, 400] (Table 4 of v2.0) to an MGF box as the proposition says, and run the referee's own exact MGF box test
(ref_mgf_check.mgf_box_test) in 'floor' mode (Proposition (b)) with wL = wR = 1.

Conversion (lower-tail box with tail base lb, prices zT[M'] attached to P(M <= M'), index M*):
  sbar_r = (1 + lb tau_r)/(1 + lb);  eT_r = 1/sum_{i<120} (ell_r m_l)^i/i!;
  for M' <= M*: That_{M'} = min(1, min_r eT_r sbar_r^{-M'}); if That_{M'} < 1, r(M') = argmin and
      z_r += zT[M'] sbar_r^{-M'}; otherwise zT[M'] goes to C0;  for M' > M*: zT[M'] goes to C0;
  alpha' = alpha - C0.
Data: the 25 coverings compiled in Lean (U01..U24, U26) parsed by this file's own parser from the Lean data modules
(/Users/kvallier/Desktop/Erdos993-Lean-FiberFloor, read only); the 6 coverings outside Lean (U25, U27, U28 lo/hi,
U29, U30 at the hand caps) from upper_d_test/outputs/stage2/final_lower_tail_coverings.json.
Caps: theta and D of the covering (Lean's bandAt for the Lean coverings; the JSON for the hand coverings); rates: the
band's rates of v2.0 Table apA:tab:rates (compared with the data).
Usage: python3 ref_convert_check.py <shard> <nshards>   -> JSON lines on stdout
"""
import sys, json, re, time
from pathlib import Path
from gmpy2 import mpq
from ref_mgf_check import Box, mgf_box_test, parse_v20, exp_lower_recip, Q, TAUS

LEAN = Path('/Users/kvallier/Desktop/Erdos993-Lean-FiberFloor/Erdos993Lean/Analytic/Atlas')
HAND = Path('/Users/kvallier/Desktop/Erdos 993/ProofRuns/2026-09-28_analytic_large_n/LEAN/certfree/upper_d_test/outputs/stage2/final_lower_tail_coverings.json')

RTOK = re.compile(r'R \((-?\d+)\) (\d+)')


def parse_lean_U(k):
    t = (LEAN / 'Data' / ('U%02d.lean' % k)).read_text()
    boxes = []
    for m in re.finditer(r'def boxU%02d_(\d+) : Box :=\n(.*?)⟩' % k, t, re.S):
        body = m.group(2)
        lb = body.index('['); rb = body.index(']')
        head = [mpq(int(a), int(b)) for a, b in RTOK.findall(body[:lb])]
        z = [mpq(int(a), int(b)) for a, b in RTOK.findall(body[lb:rb])]
        tail = [int(x) for x in re.findall(r'\d+', body[rb + 1:])]
        assert len(head) == 10 and len(tail) == 2, (k, m.group(1), len(head), tail)
        ql, qh, ml, mh, m0, eta, xi, alpha, beta, gamma = head
        boxes.append(dict(ql=ql, qh=qh, ml=ml, mh=mh, m0=m0, eta=eta, xi=xi, alpha=alpha, beta=beta, gamma=gamma,
                          z=z, N=tail[0], Mstar=tail[1], name='U%02d#%s' % (k, m.group(1))))
    sl = re.search(r'def slabsU%02d : List Slab := \[(.*?)\n\]' % k, t, re.S).group(1)
    slabs = []
    for mm in re.finditer(r'⟨R \((-?\d+)\) (\d+), R \((-?\d+)\) (\d+), \[([0-9, ]*)\]⟩', sl):
        slabs.append(dict(lo=mpq(int(mm.group(1)), int(mm.group(2))), hi=mpq(int(mm.group(3)), int(mm.group(4))),
                          chain=[int(x) for x in mm.group(5).split(',')]))
    return boxes, slabs


def lean_band_params():
    """bandAt i: D, theta, ell, lamLo, lamHi from the Lean Atlas band table (own parser)."""
    out = {}
    import pickle  # only for the cross-check below; primary source is the Lean text
    return out


def convert(b, lb, ell):
    sbar = [(1 + lb * t) / (1 + lb) for t in TAUS]
    eT = [exp_lower_recip(l * b['ml'], 120) for l in ell]
    z = [mpq(0)] * 5
    C0 = mpq(0)
    n_moved = 0
    for Mp, zt in enumerate(b['z']):
        if zt == 0:
            continue
        if zt < 0:
            raise ValueError('negative tail price')
        if Mp > b['Mstar']:
            C0 += zt; n_moved += 1
            continue
        vals = [eT[r] / sbar[r] ** Mp for r in range(5)]
        v = min(vals)
        if v >= 1:
            C0 += zt; n_moved += 1
            continue
        r = vals.index(v)
        z[r] += zt / sbar[r] ** Mp
    return Box(b['ql'], b['qh'], b['ml'], b['mh'], b['m0'], b['eta'], b['xi'], b['alpha'] - C0, b['beta'], b['gamma'],
               mpq(1), mpq(1), z, b['N']), C0, n_moved


def lowertail_margin(b, lb, ell, theta, D):
    """(Mg) of the lower-tail band test (v2.0 Section 5.2), for comparison."""
    ql, qh, ml, mh, m0 = b['ql'], b['qh'], b['ml'], b['mh'], b['m0']
    sbar = [(1 + lb * t) / (1 + lb) for t in TAUS]
    eT = [exp_lower_recip(l * ml, 120) for l in ell]
    vmax = mpq(1, 4) if ql <= mpq(1, 2) <= qh else max(ql * (1 - ql), qh * (1 - qh))
    tot = mpq(0)
    for Mp, zt in enumerate(b['z']):
        if zt == 0:
            continue
        Tp = mpq(1) if Mp > b['Mstar'] else min(mpq(1), min(eT[r] / sbar[r] ** Mp for r in range(5)))
        tot += zt * Tp
    return (b['alpha'] + min(b['beta'] * (ml - m0), b['beta'] * (mh - m0))
            - b['gamma'] * (D * mh + max((ml - m0) ** 2, (mh - m0) ** 2)) - b['eta'] * theta * vmax * mh - tot)


def all_coverings():
    bands, pieces = parse_v20()
    import pickle
    covs = pickle.load(open('/Users/kvallier/Desktop/Erdos 993/ProofRuns/2026-09-28_analytic_large_n/LEAN/certfree/upper_d_test/outputs/stage1/coverings.pkl', 'rb'))
    pk = {c['name']: c for c in covs}
    out = []
    for k in list(range(1, 25)) + [26]:
        boxes, slabs = parse_lean_U(k)
        c = pk['Atlas/U%02d' % k]
        band = c['band']
        i = k - 1
        assert band['lamHi'] == c['tail'][1]
        lam = (mpq(band['lamLo']), mpq(band['lamHi']))
        assert lam == bands[i]['lam'], (k, lam, bands[i]['lam'])
        ell_lean = [mpq(x) for x in band['ell']]
        out.append(dict(name='U%02d' % k, band=i, lam=lam, lb=lam[1], theta=mpq(band['theta']), D=mpq(band['D']),
                        ell=bands[i]['ell'], ell_data=ell_lean, boxes=boxes, slabs=slabs, mrange=(mpq(50), mpq(400)),
                        n_boxes_pickle=len(c['boxes'])))
    hj = json.loads(HAND.read_text())
    for c in hj['coverings']:
        if not c['covering'].startswith('Atlas/U'):
            continue
        lam = (Q(c['lam'][0]), Q(c['lam'][1]))
        bi = [i for i, b in bands.items() if b['lam'][0] <= lam[0] and lam[1] <= b['lam'][1]]
        assert len(bi) == 1, (c['covering'], bi)
        i = bi[0]
        boxes = []
        for j, b in enumerate(c['boxes']):
            boxes.append(dict(ql=Q(b['q'][0]), qh=Q(b['q'][1]), ml=Q(b['m'][0]), mh=Q(b['m'][1]), m0=Q(b['m0']),
                              eta=Q(b['eta']), xi=Q(b['xi']), alpha=Q(b['alpha']), beta=Q(b['beta']), gamma=Q(b['gamma']),
                              z=[Q(x) for x in b['z']], N=int(b['N']), Mstar=int(b['Mstar']), name='%s#%d' % (c['covering'], j)))
        assert c['tail'][0] == 'const'
        slabs = [dict(lo=Q(s['lo']), hi=Q(s['hi']), chain=s['chain']) for s in c['slabs']]
        out.append(dict(name=c['covering'], band=i, lam=lam, lb=Q(c['tail'][1]), theta=Q(c['theta']), D=Q(c['D']),
                        ell=bands[i]['ell'], ell_data=[Q(x) for x in c['rates']], boxes=boxes, slabs=slabs,
                        mrange=(Q(c['m'][0]), Q(c['m'][1])), n_boxes_pickle=None))
    return out, bands, pieces


def cover_check(cov):
    """own cover check of [q(lam_lo), q(lam_hi)] x [50, 400] from the boxes alone"""
    lam0, lam1 = cov['lam']
    q_lo, q_hi = lam0 / (1 + lam0), lam1 / (1 + lam1)
    m_lo, m_hi = cov['mrange']
    bx = cov['boxes']
    pts = sorted(set([q_lo, q_hi] + [b['ql'] for b in bx if q_lo < b['ql'] < q_hi] + [b['qh'] for b in bx if q_lo < b['qh'] < q_hi]))
    fails = []
    for a, b in zip(pts, pts[1:]):
        ivs = sorted((x['ml'], x['mh']) for x in bx if x['ql'] <= a and b <= x['qh'])
        tip = m_lo
        for lo, hi in ivs:
            if lo <= tip:
                tip = max(tip, hi)
        if tip < m_hi:
            fails.append('q-cell [%s,%s] up to m=%s' % (a, b, tip))
    return fails, q_lo, q_hi


if __name__ == '__main__':
    shard, nsh = int(sys.argv[1]), int(sys.argv[2])
    only_cover = len(sys.argv) > 3 and sys.argv[3] == 'cover'
    covs, bands, pieces = all_coverings()
    if only_cover:
        tot = 0
        for c in covs:
            f, ql, qh = cover_check(c)
            lbq = c['lb'] / (1 + c['lb'])
            bad_qh = [b['name'] for b in c['boxes'] if b['qh'] > lbq]
            bad_q = [b['name'] for b in c['boxes'] if b['ql'] > qh or b['qh'] < ql]
            tot += len(c['boxes'])
            print(json.dumps(dict(cov=c['name'], band=c['band'], n=len(c['boxes']), n_pickle=c['n_boxes_pickle'],
                                  cover_fails=f, qh_above_tailbase=bad_qh, theta=str(c['theta']), D=str(c['D']),
                                  lb=str(c['lb']), ell_match=(c['ell'] == c['ell_data']), mrange=[str(x) for x in c['mrange']])))
        print(json.dumps(dict(total_entries=tot, coverings=len(covs))))
        sys.exit(0)
    jobs = [(c, b) for c in covs for b in c['boxes']]
    for idx, (c, b) in enumerate(jobs):
        if idx % nsh != shard:
            continue
        t0 = time.time()
        mb, C0, nm = convert(b, c['lb'], c['ell'])
        ltm = lowertail_margin(b, c['lb'], c['ell'], c['theta'], c['D'])
        r = mgf_box_test(mb, c['theta'], c['D'], c['ell'], 'floor')
        print(json.dumps(dict(idx=idx, cov=c['name'], box=b['name'], N=b['N'], ok=r['ok'], fails=r['fails'][:3],
                              mgf_margin=r['margin'], lt_margin=float(ltm), margin_ge=(r['margin'] is not None and r['margin'] >= float(ltm)),
                              C0=float(C0), moved=nm, atoms=r.get('atoms'), min_slack=r.get('min_slack'),
                              sec=round(time.time() - t0, 1))), flush=True)
