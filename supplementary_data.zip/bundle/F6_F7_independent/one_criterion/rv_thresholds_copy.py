# rv_thresholds.py -- referee's own verifier of the thresholds of large_mean_section.tex (Section "Application to
# forests"), written from the text only. Interval arithmetic: mpmath.iv (outward rounding), prec 120 bits.
# Inputs, read from the SOURCE sections (not from the large_mean scripts):
#   theta: o2/o2_section.tex, Table o2:tab:bands (31 intervals, gamma-1), hard-coded below;
#   D:     multiplier_curve/curve_section.tex, Table mc:tab:curve (lo, mid, u1..u4), hard-coded below;
#   ell:   tail_var/outputs/tail_kappa.json (kappa per piece; rate = q(lo)*kappa, Theorem tv:thm:tail).
# Modes:  (1) certify the authors' per-atom design data (rho,u0,mL) read from large_mean/outputs/thresholds.json
#             (claimed data only; no code imported);
#         (2) own search: least integer m per atom over rho in Table lm:tab:env and u0 = rho*v_min*m (the largest
#             admissible u0), requiring u0 >= 11/2, r*m >= 3/2 and Psi_atom(m) > 0.
import json, math, sys
from fractions import Fraction as Fr
from mpmath import iv, mp
iv.prec = 120
BASE = "/Users/kvallier/Desktop/Erdos 993/ProofRuns/2026-09-28_analytic_large_n/LEAN/certfree/"

def I(x):
    if isinstance(x, Fr):
        return iv.mpf(x.numerator) / iv.mpf(x.denominator)
    return iv.mpf(x)

THETA_TAB = [  # (a, b, gamma) from o2 Table o2:tab:bands
 ("1/3","37/100","44/25"),("37/100","2/5","87/50"),("2/5","11/25","87/50"),("11/25","47/100","43/25"),
 ("47/100","51/100","43/25"),("51/100","11/20","43/25"),("11/20","29/50","17/10"),("29/50","3/5","169/100"),
 ("3/5","16/25","171/100"),("16/25","17/25","17/10"),("17/25","18/25","17/10"),("18/25","77/100","171/100"),
 ("77/100","81/100","17/10"),("81/100","43/50","171/100"),("43/50","9/10","17/10"),("9/10","19/20","171/100"),
 ("19/20","1","43/25"),("1","21/20","43/25"),("21/20","11/10","173/100"),("11/10","23/20","173/100"),
 ("23/20","121/100","7/4"),("121/100","63/50","7/4"),("63/50","33/25","89/50"),("33/25","69/50","179/100"),
 ("69/50","143/100","9/5"),("143/100","3/2","37/20"),("3/2","39/25","189/100"),("39/25","8/5","19/10"),
 ("8/5","9/5","209/100"),("9/5","21/10","117/50"),("21/10","7/3","63/25")]
THETA_TAB = [(Fr(a), Fr(b), Fr(g) - 1) for a, b, g in THETA_TAB]
D_TAB = [(Fr(1,3),Fr(11,20),Fr(6,5)),(Fr(11,20),Fr(263,200),Fr(6,5)),(Fr(263,200),Fr(3,2),Fr(7,5)),
         (Fr(3,2),Fr(7,4),Fr(8,5)),(Fr(7,4),Fr(2),Fr(9,5)),(Fr(2),Fr(7,3),Fr(21,10))]
kap = json.load(open(BASE + "tail_var/outputs/tail_kappa.json"))["pieces"]
PIECES = []
for p in kap:
    lo, hi, k = Fr(p["lo"]), Fr(p["hi"]), Fr(p["kappa"])
    rate = lo / (1 + lo) * k
    assert rate == Fr(p["rate"]), p
    PIECES.append((lo, hi, rate))
assert len(PIECES) == 55 and PIECES[0][0] == Fr(1,3) and PIECES[-1][1] == Fr(7,3)
for i in range(54): assert PIECES[i][1] == PIECES[i+1][0]
for i in range(30): assert THETA_TAB[i][1] == THETA_TAB[i+1][0]
pts = sorted(set([a for a,_,_ in THETA_TAB] + [THETA_TAB[-1][1]] + [a for a,_,_ in PIECES] + [PIECES[-1][1]]
                 + [a for a,_,_ in D_TAB] + [D_TAB[-1][1]]))
ATOMS = list(zip(pts[:-1], pts[1:]))

def lookup(tab, a, b):
    hits = [row[2] for row in tab if row[0] <= a and b <= row[1]]
    assert len(hits) == 1, (a, b, hits)
    return hits[0]

GAMMA_E = {Fr(1,4):Fr(10), Fr(3,10):Fr(17,2), Fr(1,3):Fr(15,2), Fr(7,20):Fr(29,4), Fr(2,5):Fr(13,2), Fr(1,2):Fr(11,2)}
PI = iv.pi
SQPI = iv.sqrt(PI)
aG = iv.exp(I(Fr(-1,2))) / iv.sqrt(2 * PI)

def Gam(p, rho):
    R = I(rho); P = I(p)
    return (iv.exp(-P * iv.log(R)) - 1 + P * (R - 1)) / (1 - R) ** 2

def kfun(rho):
    R = I(rho)
    return (R * iv.log(R) - R + 1) / (1 - R) ** 2

def fourier_consts(u0):
    U = I(u0)
    c0 = I(Fr(43,96)) * (1 - 1 / (4 * U))
    a1 = 1 / (12 * PI * c0 ** 2)
    a2 = 15 * iv.exp(I(Fr(-5,2)) * iv.log(c0)) / (768 * SQPI)
    a3 = 1 / (6 * PI * c0 ** 3)
    a4 = 75 * iv.exp(I(Fr(-7,2)) * iv.log(c0)) / (1536 * SQPI) + 15 * iv.exp(I(Fr(-5,2)) * iv.log(c0)) / (384 * SQPI)
    e1 = iv.exp(-I(Fr(4596,10000)) * U); e2 = iv.exp(-U / 2)
    Km = a2 + iv.exp(I(Fr(3,2)) * iv.log(U)) * (I(Fr(6817,10000)) * e1 + e2 / (PI * U))
    Kc = a4 + iv.exp(I(Fr(5,2)) * iv.log(U)) * (I(Fr(6268,10000)) * e1 + (1 + 1 / U) * e2 / (PI * U))
    return a1, a2, a3, a4, Km, Kc

def psi_atom(a, b, theta, D, ell, rho, u0, m):
    """Returns (ok_range, ok_rate, Psi_atom interval, parts). Everything from the text of Section 'Uniform margin'."""
    qa, qb = a / (1 + a), b / (1 + b)
    v = lambda q: q * (1 - q)
    vmin = min(v(qa), v(qb))
    vmax = Fr(1,4) if qa <= Fr(1,2) <= qb else max(v(qa), v(qb))
    dmax = max(abs(1 - 2*qa), abs(1 - 2*qb))
    dmin = Fr(0) if qa <= Fr(1,2) <= qb else min(abs(1 - 2*qa), abs(1 - 2*qb))
    ok_range = (rho * vmin * m >= u0) and (u0 >= Fr(11,2))
    r = I(ell) - I(rho) * iv.log(1 + I(b))
    ok_rate = (r * m).a >= 1.5
    a1, a2, a3, a4, Km, Kc = fourier_consts(u0)
    GE = I(GAMMA_E[rho]); G1, G32, G2, G52 = Gam(1, rho), Gam(Fr(3,2), rho), Gam(2, rho), Gam(Fr(5,2), rho)
    kk = kfun(rho)
    TH = I(theta); eps = I(D) / m
    H = iv.exp(-TH / 2) / iv.sqrt(2 * PI)
    Cb = H * I(max(Fr(3,2), 1 + theta / 2))
    slo = iv.sqrt(I(vmin) * m)
    PsiC = aG * (1 - TH - GE * eps) - a3 * I(dmax) / slo * (1 + G2 * eps) - Kc / slo ** 2 * (1 + G52 * eps)
    tail = iv.exp(I(Fr(3,2)) * iv.log(I(vmax) * m)) * iv.exp(-r * m)
    beta = H * (1 - I(Fr(3,2)) * kk * eps) - a1 * I(dmax) / slo * (1 + G1 * eps) - Km / slo ** 2 * (1 + G32 * eps)
    massUB = tail * I(dmax) ** 2 * Cb / (I(vmin) * slo)
    massexpr = I(dmin) ** 2 * m * beta - massUB
    mass = massexpr if massexpr.a > 0 else iv.mpf(0)
    Psi = PsiC - tail + mass
    return ok_range, ok_rate, Psi, dict(PsiC=PsiC, tail=tail, mass=mass, r=r, Kc=Kc, Km=Km, a4=a4, beta=beta)

def psi_float(a, b, theta, D, ell, rho, u0, m):
    """Floating-point mirror of psi_atom, used only to locate the candidate m of the own search."""
    qa, qb = float(a / (1 + a)), float(b / (1 + b))
    v = lambda q: q * (1 - q)
    vmin = min(v(qa), v(qb)); vmax = 0.25 if qa <= 0.5 <= qb else max(v(qa), v(qb))
    dmax = max(abs(1 - 2*qa), abs(1 - 2*qb)); dmin = 0.0 if qa <= 0.5 <= qb else min(abs(1 - 2*qa), abs(1 - 2*qb))
    rho_f, u0f, th, Df = float(rho), float(u0), float(theta), float(D)
    r = float(ell) - rho_f * math.log(1 + float(b))
    if r <= 0: return -1e9, r
    c0 = 43/96 * (1 - 1/(4*u0f))
    a1 = 1/(12*math.pi*c0**2); a2 = 15*c0**-2.5/(768*math.sqrt(math.pi)); a3 = 1/(6*math.pi*c0**3)
    a4 = 75*c0**-3.5/(1536*math.sqrt(math.pi)) + 15*c0**-2.5/(384*math.sqrt(math.pi))
    Km = a2 + u0f**1.5*(0.6817*math.exp(-0.4596*u0f) + math.exp(-u0f/2)/(math.pi*u0f))
    Kc = a4 + u0f**2.5*(0.6268*math.exp(-0.4596*u0f) + (1+1/u0f)*math.exp(-u0f/2)/(math.pi*u0f))
    G = lambda p: (rho_f**-p - 1 + p*(rho_f - 1))/(1 - rho_f)**2
    kk = (rho_f*math.log(rho_f) - rho_f + 1)/(1 - rho_f)**2
    ag = math.exp(-0.5)/math.sqrt(2*math.pi); H = math.exp(-th/2)/math.sqrt(2*math.pi); Cb = H*max(1.5, 1 + th/2)
    eps = Df/m; slo = math.sqrt(vmin*m)
    PsiC = ag*(1 - th - float(GAMMA_E[rho])*eps) - a3*dmax/slo*(1 + G(2)*eps) - Kc/slo**2*(1 + G(2.5)*eps)
    tail = (vmax*m)**1.5*math.exp(-r*m)
    beta = H*(1 - 1.5*kk*eps) - a1*dmax/slo*(1 + G(1)*eps) - Km/slo**2*(1 + G(1.5)*eps)
    mass = max(dmin**2*m*beta - tail*dmax**2*Cb/(vmin*slo), 0.0)
    return PsiC - tail + mass, r

def nL_of(b, mL):
    qb = b / (1 + b)
    return 4 * math.ceil(2 * qb * mL) - 7   # exact: Fraction ceil

if __name__ == "__main__":
    print("atoms:", len(ATOMS))
    claimed = json.load(open(BASE + "large_mean/outputs/thresholds.json"))
    catoms = claimed["atoms"]
    assert len(catoms) == len(ATOMS)
    out = []
    band_rows = {}
    allok = True
    for i, (a, b) in enumerate(ATOMS):
        th = lookup(THETA_TAB, a, b); D = lookup(D_TAB, a, b); ell = lookup(PIECES, a, b)
        c = catoms[i]
        assert (Fr(c["lo"]), Fr(c["hi"])) == (a, b), (i, c["lo"], c["hi"], a, b)
        same_inputs = (Fr(c["theta"]) == th and Fr(c["D"]) == D and Fr(c["ell"]) == ell)
        rho, u0, mL = Fr(c["rho"]), Fr(c["u0"]).limit_denominator(1000), int(c["mL"])
        okR, okr, Psi, parts = psi_atom(a, b, th, D, ell, rho, u0, mL)
        cert = okR and okr and Psi.a > 0
        # also: fails at mL-1 with the same design? (information only)
        okR1, okr1, Psi1, _ = psi_atom(a, b, th, D, ell, rho, u0, mL - 1)
        cert_prev = okR1 and okr1 and Psi1.a > 0
        # own search: float screen, then interval confirmation
        best = None
        qa_, qb_ = a / (1 + a), b / (1 + b)
        vmin_ = min(qa_*(1-qa_), qb_*(1-qb_))
        for rho2 in sorted(GAMMA_E):
            m0 = max(20, math.ceil(Fr(11,2) / (rho2 * vmin_)))
            m = m0
            while m < 2000 and (best is None or m < best[0]):
                u02 = rho2 * vmin_ * m
                P, rr = psi_float(a, b, th, D, ell, rho2, u02, m)
                if rr <= 0: break
                if P > 0 and rr * m >= 1.5:
                    o1, o2, Pi, _ = psi_atom(a, b, th, D, ell, rho2, u02, m)
                    if o1 and o2 and Pi.a > 0:
                        best = (m, rho2, u02); break
                m += 1
        nLc = nL_of(b, mL); nLo = nL_of(b, best[0])
        allok &= cert and same_inputs and nLc == int(c["nL"])
        out.append(dict(atom=i, lo=str(a), hi=str(b), theta=str(th), D=str(D), ell=str(ell), inputs_match=same_inputs,
                        claimed=dict(rho=str(rho), u0=str(u0), mL=mL, nL=int(c["nL"])),
                        certified=cert, Psi_lower=float(Psi.a), Psi_upper=float(Psi.b), nL_recomputed=nLc,
                        certified_at_mL_minus_1_same_design=cert_prev,
                        own_min=dict(mL=best[0], rho=str(best[1]), u0=float(best[2]), nL=nLo),
                        r=float(parts["r"].a), PsiC=float(parts["PsiC"].a), tail=float(parts["tail"].b),
                        mass=float(parts["mass"].a), Kc=float(parts["Kc"].b)))
        print(f"{i:2d} [{str(a):>7},{str(b):>7}] th={float(th):.2f} D={str(D):>5} ell={float(ell):.4f} "
              f"rho={str(rho):>4} u0={float(u0):5.2f} mL={mL:4d} nL={nLc:4d}/{int(c['nL']):4d} cert={cert} "
              f"Psi>={float(Psi.a):.5f} prev={cert_prev} | own: mL={best[0]} rho={best[1]} nL={nLo}")
    # band maxima over the 31 theta intervals
    print("\nband maxima (theta intervals):")
    bands = []
    for (a, b, th) in THETA_TAB:
        rows = [o for o in out if a <= Fr(o["lo"]) and Fr(o["hi"]) <= b]
        mLmax = max(o["claimed"]["mL"] for o in rows); nLmax = max(o["nL_recomputed"] for o in rows)
        own_mL = max(o["own_min"]["mL"] for o in rows); own_nL = max(o["own_min"]["nL"] for o in rows)
        bands.append(dict(lo=str(a), hi=str(b), theta=str(th), atoms=len(rows), mL=mLmax, nL=nLmax, own_mL=own_mL, own_nL=own_nL))
        print(f"[{str(a):>7},{str(b):>7}] atoms={len(rows)} theta={float(th):.2f} mL={mLmax} nL={nLmax}  own: mL={own_mL} nL={own_nL}")
    print("overall nL (claimed designs):", max(bnd["nL"] for bnd in bands), " own search:", max(bnd["own_nL"] for bnd in bands))
    print("ALL CLAIMED ATOMS CERTIFIED AND CONSISTENT:", allok)
    json.dump(dict(atoms=out, bands=bands), open(BASE + "referee_large_mean/rv_thresholds.json", "w"), indent=1)
