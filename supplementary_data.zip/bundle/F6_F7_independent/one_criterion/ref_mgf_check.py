"""Referee's own exact checker of the MGF box test of v2.0 Section 5.1 (for_tong/TWIN_v2.0/s5_part_a.tex),
written from the paper text (not from the author's replay_mgf.py / indep_mgf_check.py).

Exact rational arithmetic throughout (gmpy2.mpq / mpz); no floating point enters any decision.
Parameters theta(iota), D(iota), ell_r(iota) are parsed from v2.0's Appendix A tables (apx_tables.tex);
the boxes' declared parameters are only compared, never used.

Modes:
  plain : the MGF box test exactly as in Section 5.1 (floor max(wL,wR) everywhere).
  floor : the variant of Proposition oc:prop:floor(b): for v_min*M >= 25 the floor max(wL,wR) is replaced by
          min(max(wL,wR), wmin*(1/(20V)+1/V^2)) with V = v_min*M (only wL = wR is supported, which is all (c) needs),
          in (T) and in lev (whole-fiber test, range-end certificates and the per-atom skip).
Usage:
  python3 ref_mgf_check.py strip <root_dir> <iota>          -> JSON line on stdout
"""
import sys, json, re, time
from pathlib import Path
from gmpy2 import mpq, mpz, isqrt


def ifloor(x):
    x = mpq(x)
    return int(x.numerator // x.denominator)


def iceil(x):
    x = mpq(x)
    return -int((-x.numerator) // x.denominator)


V20 = Path('/Users/kvallier/Desktop/Erdos 993/ProofRuns/2026-09-28_analytic_large_n/LEAN/for_tong/TWIN_v2.0/apx_tables.tex')
TAUS = [mpq(0), mpq(1, 20), mpq(1, 10), mpq(1, 5), mpq(3, 10)]


def Q(s):
    s = str(s).strip().replace('$', '').replace('\\,', '')
    if '/' in s:
        a, b = s.split('/')
        return mpq(int(a), int(b))
    return mpq(int(s))


def parse_v20():
    t = V20.read_text()
    # rates table
    i = t.index('label{apA:tab:rates}')
    rates_block = t[t.rfind('\\begin{tabular}', 0, i):i]
    bands = {}
    for m in re.finditer(r'^(\d+) & \$\[([^,]+),\\,([^\]]+)\]\$ & \$([^$]+)\$ & \$([^$]+)\$ & \$([^$]+)\$ & \$([^$]+)\$ & \$([^$]+)\$ \\\\', rates_block, re.M):
        bands[int(m.group(1))] = dict(lam=(Q(m.group(2)), Q(m.group(3))), ell=[Q(m.group(k)) for k in range(4, 9)])
    assert len(bands) == 30, len(bands)
    i = t.index('label{apA:tab:pieces}')
    pb = t[t.rfind('\\begin{tabular}', 0, i):i]
    pieces = {}
    for m in re.finditer(r'^(\d+) & (\d+) & \$\[([^,]+),\\,([^\]]+)\]\$ & \$([^$]+)\$ & \$([^$]+)\$ & \$([^$]+)\$ & \$([^$]+)\$ & \$([^$]+)\$ & (\d+) & (\d+) &', pb, re.M):
        io = int(m.group(1)); band = int(m.group(2))
        ell = list(bands[band]['ell']); ell[0] = Q(m.group(7))
        pieces[io] = dict(band=band, lam=(Q(m.group(3)), Q(m.group(4))), theta=Q(m.group(5)), D=Q(m.group(6)),
                          ell=ell, m25=Q(m.group(8)), mstar=Q(m.group(9)), boxes=int(m.group(10)), slabs=int(m.group(11)))
    assert len(pieces) == 55, len(pieces)
    return bands, pieces


def ceil_sqrt_q(v):
    """least integer k >= 0 with k^2 >= v (v rational >= 0)"""
    v = mpq(v)
    c = iceil(v)
    k = int(isqrt(c))
    while k * k < v:
        k += 1
    while k > 0 and (k - 1) * (k - 1) >= v:
        k -= 1
    return k


def qmin_on(eta, xi, lo, hi):
    """min of eta d^2 + xi d over d in [lo, hi] (lo <= hi; None = infinite end)"""
    v = -xi / (2 * eta)
    if lo is not None and v < lo:
        x = lo
    elif hi is not None and v > hi:
        x = hi
    else:
        x = v
    return eta * x * x + xi * x


def exp_lower_recip(x, terms):
    """1 / sum_{i < terms} x^i / i!  (an upper bound of e^{-x} for x >= 0)"""
    s = mpq(1); t = mpq(1)
    for i in range(1, terms):
        t = t * x / i
        s += t
    return 1 / s


class Box:
    def __init__(self, ql, qh, ml, mh, m0, eta, xi, alpha, beta, gamma, wL, wR, z, N):
        self.ql, self.qh, self.ml, self.mh, self.m0 = ql, qh, ml, mh, m0
        self.eta, self.xi, self.alpha, self.beta, self.gamma = eta, xi, alpha, beta, gamma
        self.wL, self.wR, self.z, self.N = wL, wR, z, int(N)


def box_from_json(d):
    du = d['dual']
    return Box(Q(d['q'][0]), Q(d['q'][1]), Q(d['m'][0]), Q(d['m'][1]), Q(d['m0']), Q(du['nu']), Q(du['c']),
               Q(du['alpha']), Q(du['beta']), Q(du['gamma']), Q(du['a']), Q(du['b']), [Q(x) for x in du['z']],
               d['cutoff'])


def mgf_box_test(bx, theta, D, ell, mode='plain', stop_after=5, floor_scope='all'):
    """The MGF box test of v2.0 Section 5.1. Returns dict(pass, margin, fails, atoms, min_slack)."""
    fails = []
    ql, qh, ml, mh, m0 = bx.ql, bx.qh, bx.ml, bx.mh, bx.m0
    eta, xi, alpha, beta, gamma, wL, wR, z, N = bx.eta, bx.xi, bx.alpha, bx.beta, bx.gamma, bx.wL, bx.wR, bx.z, bx.N
    # (S)
    if not (0 < ql < qh < 1 and eta > 0 and gamma >= 0 and wL >= 0 and wR >= 0 and all(x >= 0 for x in z)
            and 0 < ml <= mh and len(z) == len(ell) == 5):
        return dict(ok=False, fails=['(S)'], margin=None)
    if not (theta >= 0 and D >= 0 and all(e >= 0 for e in ell)):
        return dict(ok=False, fails=['params not sane'], margin=None)
    W = max(wL, wR)
    wmin = min(wL, wR)
    vmin = min(ql * (1 - ql), qh * (1 - qh))
    if mode == 'floor':
        assert wL == wR, 'floor mode implemented for wL = wR only'

    def floor_at(M):
        if mode == 'floor' and vmin * M >= 25:
            V = vmin * M
            return min(W, wmin * (1 / (20 * V) + 1 / (V * V)))
        return W

    def psi0(M):
        x = mpq(M) - m0
        return alpha + beta * x - gamma * x * x

    xi2 = xi * xi / (4 * eta)
    # (T)
    if not (psi0(N) <= -floor_at(N) - xi2 and beta - 2 * gamma * (N - m0) <= 0):
        fails.append('(T) at N=%d' % N)
    # (Mg)
    ehat = [exp_lower_recip(l * ml, 121) for l in ell]           # 1/sum_{i<=120}
    vmax = mpq(1, 4) if ql <= mpq(1, 2) <= qh else max(ql * (1 - ql), qh * (1 - qh))
    margin = (alpha + min(beta * (ml - m0), beta * (mh - m0)) - gamma * (D * mh + max((ml - m0) ** 2, (mh - m0) ** 2))
              - eta * theta * vmax * mh - sum((zr * e for zr, e in zip(z, ehat)), mpq(0)))
    if not margin > 0:
        fails.append('(Mg) margin %.3e' % float(margin))
    # (F)
    q0 = (ql + qh) / 2
    dq = (qh - ql) / 2
    s_r = [1 - qh + qh * t for t in TAUS]
    dstar = -xi / (2 * eta)
    qs = {'l': ql, '0': q0, 'h': qh}
    num = {k: int(v.numerator) for k, v in qs.items()}
    den = {k: int(v.denominator) for k, v in qs.items()}
    rows = {k: [mpz(1)] for k in qs}           # den^M * bin_M(j; q)
    denM = {k: mpz(1) for k in qs}
    pascal = [mpz(1)]
    spow = [mpq(1)] * 5
    atoms = 0
    min_slack = None
    vq = {k: v * (1 - v) for k, v in qs.items()}
    for M in range(N):
        rhs = psi0(M) - sum((zr * sp for zr, sp in zip(z, spow)), mpq(0))
        # (i) half-lines where the kernel vanishes
        if not (rhs <= qmin_on(eta, xi, None, -2 - ql * M) and rhs <= qmin_on(eta, xi, M + 2 - qh * M, None)):
            fails.append('half-line M=%d' % M)
        F_M = floor_at(M)
        lev = rhs + F_M + xi2
        if lev > 0 and floor_scope == 'wholefiber':
            lev = rhs + W + xi2      # variant: floor only in the whole-fiber test; range ends and skip use max(wL,wR)
        if lev > 0:
            rbox = ceil_sqrt_q(lev / eta) + 1
            jlo = max(-1, ifloor(ql * M + dstar) - rbox)
            jhi = min(M + 1, iceil(qh * M + dstar) + rbox)
            if jlo > -1:
                Dm = ql * M + dstar - (jlo - 1)
                if not (Dm >= 0 and eta * Dm * Dm >= lev):
                    jlo = -1
            if jhi < M + 1:
                Dp = (jhi + 1) - qh * M - dstar
                if not (Dp >= 0 and eta * Dp * Dp >= lev):
                    jhi = M + 1
            for j in range(jlo, jhi + 1):
                atoms += 1
                lo_d, hi_d = j - qh * M, j - ql * M
                # skip
                if dstar < lo_d:
                    dist = lo_d - dstar
                elif dstar > hi_d:
                    dist = dstar - hi_d
                else:
                    dist = mpq(0)
                if eta * dist * dist >= lev:
                    continue
                d0 = j - q0 * M
                Qd = qmin_on(eta, xi, lo_d, hi_d)
                if j == -1:
                    k0 = -wR * (1 - q0) ** M
                    K1 = wR * M * (1 - ql) ** (M - 1) if M >= 1 else mpq(0)
                    K2 = wR * M * (M - 1) * (1 - ql) ** (M - 2) if M >= 2 else mpq(0)
                    k0p = wR * M * (1 - q0) ** (M - 1) if M >= 1 else mpq(0)
                elif j == M + 1:
                    k0 = -wL * q0 ** M
                    K1 = wL * M * qh ** (M - 1) if M >= 1 else mpq(0)
                    K2 = wL * M * (M - 1) * qh ** (M - 2) if M >= 2 else mpq(0)
                    k0p = -wL * M * q0 ** (M - 1) if M >= 1 else mpq(0)
                else:
                    A = wL * mpq(M + 1 - 2 * j, M - j + 1)
                    Bc = wR * mpq(2 * j + 1 - M, j + 1)
                    Bv = {k: mpq(rows[k][j], denM[k]) / vq[k] for k in qs}
                    Kf = lambda x: A * (1 - x) ** 2 + Bc * x * x
                    Kp = lambda x: -2 * A * (1 - x) + 2 * Bc * x
                    Bmax = max(Bv['l'], Bv['h'])
                    if M != 2:
                        qc = mpq(j - 1, M - 2)
                        if ql < qc < qh:
                            Bc_val = pascal[j] * qc ** (j - 1) * (1 - qc) ** (M - j - 1)
                            Bmax = max(Bmax, Bc_val)
                    pts = [ql, qh]
                    if A + Bc != 0:
                        vtx = A / (A + Bc)
                        if ql < vtx < qh:
                            pts.append(vtx)
                    Kmax = max(abs(Kf(x)) for x in pts)
                    Kpmax = max(abs(Kp(ql)), abs(Kp(qh)))
                    Lmax = max(abs(mpq(j - 1) / u - mpq(M - j - 1) / (1 - v)) for u in (ql, qh) for v in (ql, qh))
                    Lpmax = abs(mpq(j - 1)) / (ql * ql) + abs(mpq(M - j - 1)) / ((1 - qh) * (1 - qh))
                    Kpp = abs(2 * (A + Bc))
                    K1 = Bmax * (Kpmax + Lmax * Kmax)
                    K2 = Bmax * (Kpp + 2 * Lmax * Kpmax + (Lmax * Lmax + Lpmax) * Kmax)
                    k0 = Bv['0'] * Kf(q0)
                    L0 = mpq(j - 1) / q0 - mpq(M - j - 1) / (1 - q0)
                    k0p = Bv['0'] * (Kp(q0) + L0 * Kf(q0))
                s1 = k0 - dq * K1 + Qd - rhs
                if s1 >= 0:
                    sl = s1
                else:
                    kt = k0 + xi * d0 + eta * d0 * d0
                    ktp = k0p - M * (xi + 2 * eta * d0)
                    s2 = kt - dq * abs(ktp) - dq * dq * (K2 + 2 * eta * M * M) / 2 - rhs
                    sl = max(s1, s2)
                if min_slack is None or sl < min_slack[0]:
                    min_slack = (sl, M, j)
                if sl < 0:
                    fails.append('atom (%d,%d) slack %.3e' % (M, j, float(sl)))
                    if len(fails) >= stop_after:
                        return dict(ok=False, fails=fails, margin=float(margin), atoms=atoms)
        # advance rows to M+1
        for k in qs:
            p = num[k]; r = den[k]; s = r - p
            old = rows[k]
            new = [s * old[0]] + [s * old[i] + p * old[i - 1] for i in range(1, len(old))] + [p * old[-1]]
            rows[k] = new
            denM[k] = denM[k] * r
        pascal = [mpz(1)] + [pascal[i] + pascal[i - 1] for i in range(1, len(pascal))] + [mpz(1)]
        spow = [sp * s for sp, s in zip(spow, s_r)]
    return dict(ok=not fails, fails=fails, margin=float(margin), margin_exact_positive=bool(margin > 0), atoms=atoms,
                min_slack=(float(min_slack[0]), min_slack[1], min_slack[2]) if min_slack else None)


def check_strip(root, iota):
    bands, pieces = parse_v20()
    P = pieces[iota]
    folder = Path(root) / ('strip_%02d' % iota)
    files = sorted(folder.glob('box_*.json'))
    res = []
    declared_diff = []
    t0 = time.time()
    boxes = []
    for f in files:
        d = json.loads(f.read_text())
        bx = box_from_json(d)
        boxes.append(bx)
        if Q(d['theta']) != P['theta'] or Q(d['D']) != P['D'] or [Q(e) for _, e in d['tilts']] != P['ell'] \
                or [Q(t) for t, _ in d['tilts']] != TAUS:
            declared_diff.append(f.name)
        r = mgf_box_test(bx, P['theta'], P['D'], P['ell'], 'plain')
        r['file'] = f.name
        r['N'] = bx.N
        res.append(r)
    # own cover check (from the boxes alone, ignoring COVER.json): every q in [q_lo, q_hi], every m in [m_*, 50]
    lam0, lam1 = P['lam']
    q_lo, q_hi = lam0 / (1 + lam0), lam1 / (1 + lam1)
    m_lo, m_hi = P['mstar'], mpq(50)
    cover_fails = []
    pts = sorted(set([q_lo, q_hi] + [b.ql for b in boxes if q_lo < b.ql < q_hi] + [b.qh for b in boxes if q_lo < b.qh < q_hi]))
    for a, b in zip(pts, pts[1:]):
        # boxes whose closed q-range contains [a, b]
        ivs = sorted((bx.ml, bx.mh) for bx in boxes if bx.ql <= a and b <= bx.qh)
        tip = m_lo
        ok = False
        for lo, hi in ivs:
            if lo <= tip:
                tip = max(tip, hi)
        if tip < m_hi:
            cover_fails.append('q-cell [%s,%s] covered only up to m=%s' % (a, b, tip))
    # the q-cells must include the end points: the closed boxes are closed sets, so cells cover all q in [q_lo,q_hi]
    out = dict(iota=iota, root=str(root), n_boxes=len(files), m_star=str(m_lo), q=[str(q_lo), str(q_hi)],
               all_boxes_pass=all(r['ok'] for r in res), cover_ok=not cover_fails, cover_fails=cover_fails,
               declared_param_diff=declared_diff, min_margin=min(r['margin'] for r in res if r['margin'] is not None),
               boxes=res, seconds=round(time.time() - t0, 1))
    return out


if __name__ == '__main__':
    if sys.argv[1] == 'strip':
        out = check_strip(sys.argv[2], int(sys.argv[3]))
        print(json.dumps(out, default=str), flush=True)
