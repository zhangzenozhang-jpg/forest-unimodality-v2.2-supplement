"""Second-program check of the claimed m_L(iota) (one_criterion_test outputs/stage2/largemean_route.json): evaluate the
uniform margin Psi_atom of the large-mean section with the large-mean REFEREE's own verifier (rv_thresholds_copy.py, a
byte copy of certfree/referee_large_mean/rv_thresholds.py; mpmath.iv, 120 bits) at the route's inputs of v2.0 Appendix A
(theta(iota), D(iota), ell_0(iota), endpoints), with the claimed design (cut, V_*) at m_L, and also at m_L - 1."""
import json
from fractions import Fraction as Fr
import rv_thresholds_copy as RV
from ref_mgf_check import parse_v20
bands, pieces = parse_v20()
cl = json.load(open('../one_criterion_test/outputs/stage2/largemean_route.json'))
allok = True; rows = []
for r in cl:
    i = r['iota']; P = pieces[i]
    a, b = Fr(str(P['lam'][0])), Fr(str(P['lam'][1]))
    th, D, ell = Fr(str(P['theta'])), Fr(str(P['D'])), Fr(str(P['ell'][0]))
    same = (Fr(r['theta']) == th and Fr(r['D']) == D and Fr(r['ell0']) == ell and [Fr(x) for x in r['lam']] == [a, b])
    rho = Fr(r['cut']); u0 = Fr(r['V_star']).limit_denominator(1000); m = int(r['mL'])
    okR, okr, Psi, parts = RV.psi_atom(a, b, th, D, ell, rho, u0, m)
    cert = bool(okR and okr and Psi.a > 0)
    okR1, okr1, Psi1, _ = RV.psi_atom(a, b, th, D, ell, rho, u0, m - 1)
    allok &= cert and same
    rows.append(dict(iota=i, mL=m, inputs_match=same, certified=cert, Psi_lower=float(Psi.a), at_mL_minus_1=bool(okR1 and okr1 and Psi1.a > 0)))
    print(i, m, same, cert, float(Psi.a), bool(okR1 and okr1 and Psi1.a > 0))
print('ALL', allok, 'min mL', min(r['mL'] for r in rows), 'max mL', max(r['mL'] for r in rows))
json.dump(rows, open('out_mL_check.json', 'w'), indent=1)
