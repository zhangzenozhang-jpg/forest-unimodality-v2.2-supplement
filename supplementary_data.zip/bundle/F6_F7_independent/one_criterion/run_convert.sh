#!/bin/bash
cd "$(dirname "$0")"
s=$1
echo "shard $s start $(date)" >> run_convert.log
nice -n 10 python3 ref_convert_check.py $s 2 > out_convert_$s.jsonl 2>> run_convert.log
echo "shard $s done $(date)" >> run_convert.log
