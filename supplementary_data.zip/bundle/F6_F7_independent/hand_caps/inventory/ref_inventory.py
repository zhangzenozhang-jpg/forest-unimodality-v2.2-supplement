#!/usr/bin/env python3
"""Referee's independent inventory of the variance-cover cells by activity (lambda) range.

Reads ONLY the Lean data/compute modules of the repository (read only):
  /Users/kvallier/Desktop/Erdos993-Lean-FiberFloor  (commit aa8ba75)
and recomputes, for every trie leaf (cell) of the four certified variance coverings, its exact
lambda-range [a, b] (fixed point, units 2^-64), then classifies each cell against the hand cap
D_hat and the N44 sub-interval ends (Erdos993Lean/Analytic/N44/Data/Params.lean).

Lean semantics reproduced (all from the repository, see the report):
  * one = 2^64                                    TailCert/Compute/Ival.lean:37
  * fdiv a b = a / b  (Int.ediv = floor for b>0)  TailCert/Compute/Ival.lean:46
  * cdiv a b = -((-a) / b)  (= ceil for b>0)      TailCert/Compute/Ival.lean:49
  * ofRat q = <fdiv (num*one) den, cdiv (num*one) den>   Ival.lean:63
  * rootCell lo hi = <(ofRat lo).lo, (ofRat hi).hi, 0, 6*one, 0, one>  Reserve/Cert/Compute/Cell.lean:242
  * midI a b = (a + b) / 2  (floor)               Reserve/Cert/Compute/Cell.lean:206
  * lowHalf/highHalf axis 0 = lambda; any other char splits T ('1') or r (else)  Cell.lean:209-218
  * walk: preorder, 'L' leaf, else split axis ch.toNat-48, low half first   Cell.lean:231-239
  * rootU = rootCell (8/5) (7/3)                  Reserve/UpperCert/Compute/Cell.lean:252
  * piece sub-boxes: the theorem statements in Reserve/UpperCert/Checks/PieceK.lean
Written independently by the referee; no author script is imported or read.
"""
import hashlib
import json
import os
import re
import sys
import time
from fractions import Fraction as F

REPO = "/Users/kvallier/Desktop/Erdos993-Lean-FiberFloor"
OUT = os.path.dirname(os.path.abspath(__file__))
ONE = 1 << 64
WALK_FUEL = 100  # Cell.lean:245


def rd(rel):
    with open(os.path.join(REPO, rel), "r", encoding="utf-8") as fh:
        return fh.read()


# ---------------------------------------------------------------- Lean string literal parsing
def lean_string_def(text, name):
    """Return the value of `def name : String := "..."` (Lean 4 string gaps handled)."""
    m = re.search(r"def\s+" + re.escape(name) + r"\s*:\s*String\s*:=\s*\"", text)
    if not m:
        raise ValueError("definition %s not found" % name)
    i = m.end()
    out = []
    n = len(text)
    while True:
        if i >= n:
            raise ValueError("unterminated string literal in %s" % name)
        c = text[i]
        if c == '"':
            break
        if c == "\\":
            nxt = text[i + 1]
            if nxt == "\n":  # string gap: backslash-newline then whitespace is skipped
                i += 2
                while i < n and text[i] in " \t\r\n":
                    i += 1
                continue
            raise ValueError("unexpected escape \\%r in %s" % (nxt, name))
        out.append(c)
        i += 1
    return "".join(out)


def doc_claims(text):
    """Claimed character count and SHA-256 from the module docstring."""
    m = re.search(r"([0-9]+) characters, SHA-256 of the string\s*`([0-9a-f]{64})`", text)
    return (int(m.group(1)), m.group(2)) if m else (None, None)


# ---------------------------------------------------------------- Lean arithmetic (exact)
def lean_ediv(a, b):
    """Int.ediv (Euclidean); for b > 0 equals floor division."""
    assert b > 0
    return a // b  # Python floor division == Euclidean division for positive divisor


def ofRat(q):
    q = F(q)
    num, den = q.numerator, q.denominator  # Lean Rat is normalized the same way
    lo = lean_ediv(num * ONE, den)
    hi = -lean_ediv(-num * ONE, den)
    return lo, hi


def rootCell_lambda(lo, hi):
    return ofRat(lo)[0], ofRat(hi)[1]


def midI(a, b):
    return lean_ediv(a + b, 2)


# ---------------------------------------------------------------- the walk (iterative)
def walk_leaves(s, root_ab, sink):
    """Preorder walk of trie string s from a cell whose lambda range is root_ab.
    Calls sink(a, b) for every leaf.  Returns dict with end position, leaf count, max depth,
    and whether the walk would run out of fuel (depth >= WALK_FUEL)."""
    stack = []  # pending high halves: (a, b, depth)
    a, b = root_ab
    depth = 0
    i = 0
    n = len(s)
    leaves = 0
    maxd = 0
    splits = {"0": 0, "1": 0, "2": 0}
    while True:
        if i >= n:
            raise ValueError("trie string exhausted before the tree closed (pos %d)" % i)
        ch = s[i]
        i += 1
        if depth > maxd:
            maxd = depth
        if ch == "L":
            sink(a, b)
            leaves += 1
            if not stack:
                break
            a, b, depth = stack.pop()
        elif ch == "0":
            m = midI(a, b)
            stack.append((m, b, depth + 1))
            b = m
            depth += 1
            splits["0"] += 1
        elif ch in "12":
            stack.append((a, b, depth + 1))
            depth += 1
            splits[ch] += 1
        else:
            raise ValueError("unexpected trie character %r at %d" % (ch, i - 1))
    return {"end_pos": i, "len": n, "consumed_all": i == n, "leaves": leaves,
            "max_depth": maxd, "fuel_ok": maxd <= WALK_FUEL - 1, "splits": splits}


# ---------------------------------------------------------------- sub-box expressions of pieces
def apply_box_expr(expr, root_ab):
    """Evaluate e.g. 'lowHalf (lowHalf (highHalf rootU 0) 1) 2' on the lambda range only."""
    expr = " ".join(expr.split())
    toks = re.findall(r"lowHalf|highHalf|rootU|\(|\)|[0-9]+", expr)
    pos = [0]

    def parse():
        t = toks[pos[0]]
        if t == "(":
            pos[0] += 1
            v = parse()
            assert toks[pos[0]] == ")"
            pos[0] += 1
            return v
        if t == "rootU":
            pos[0] += 1
            return root_ab
        if t in ("lowHalf", "highHalf"):
            pos[0] += 1
            c = parse()
            ax = int(toks[pos[0]])
            pos[0] += 1
            a, b = c
            if ax != 0:
                return c
            m = midI(a, b)
            return (a, m) if t == "lowHalf" else (m, b)
        raise ValueError("bad token %r" % t)

    v = parse()
    assert pos[0] == len(toks), (expr, toks, pos[0])
    return v


# ---------------------------------------------------------------- classification
_SCALED = {}


def cmp_fp(x, q):
    """sign(x/2^64 - q) exactly (x an integer fixed-point value)."""
    t = _SCALED.get(q)
    if t is None:
        qs = q * ONE  # exact rational q * 2^64
        if qs.denominator == 1:
            t = (True, qs.numerator)
        else:
            t = (False, qs.numerator // qs.denominator)  # floor
        _SCALED[q] = t
    exact, v = t
    if exact:
        return (x > v) - (x < v)
    return 1 if x > v else -1  # x integer, q*2^64 not an integer: never equal


def cmp_fp_slow(x, q):
    d = x * q.denominator - q.numerator * ONE
    return (d > 0) - (d < 0)


HAND_BREAKS = [F(263, 200), F(3, 2), F(7, 4), F(2)]
HAND_VALS = [F(6, 5), F(7, 5), F(8, 5), F(9, 5), F(21, 10)]
HAND_DOMAIN = (F(1, 3), F(7, 3))


def Dhat_at_fp(x):
    """D_hat at x/2^64 (pieces closed on the right)."""
    for brk, val in zip(HAND_BREAKS, HAND_VALS):
        if cmp_fp(x, brk) <= 0:
            return val
    return HAND_VALS[-1]


def parse_rat_list(text, name):
    m = re.search(r"def\s+" + name + r"\s*:\s*List Rat\s*:=\s*\[(.*?)\]", text, re.S)
    items = re.findall(r"R\s*\((-?[0-9]+)\)\s*([0-9]+)", m.group(1))
    return [F(int(n), int(d)) for n, d in items]


def main():
    t0 = time.time()
    log = []

    def say(msg):
        print(msg)
        log.append(msg)
        sys.stdout.flush()

    say("ref_inventory.py start %s" % time.strftime("%Y-%m-%d %H:%M:%S %Z"))
    head = os.popen("git -C '%s' rev-parse HEAD" % REPO).read().strip()
    say("repo HEAD %s" % head)

    # sub-interval ends from Params.lean
    ptxt = rd("Erdos993Lean/Analytic/N44/Data/Params.lean")
    plo = parse_rat_list(ptxt, "pieceLo")
    phi = parse_rat_list(ptxt, "pieceHi")
    assert len(plo) == 55 and len(phi) == 55, (len(plo), len(phi))
    for k in range(54):
        assert phi[k] == plo[k + 1], k
    pieces = {k: (plo[k], phi[k]) for k in range(38, 55)}
    say("pieces 38..54: " + ", ".join("%d:[%s,%s]" % (k, v[0], v[1]) for k, v in pieces.items()))

    # split points: piece ends 38..54 plus the hand-cap breakpoints
    pts = sorted(set([plo[k] for k in range(38, 55)] + [phi[54]] + HAND_BREAKS))
    say("split points: " + ", ".join(str(p) for p in pts))

    def label_of_gap(lo_pt, hi_pt):
        # name gaps by the N44 piece they lie in, 38 split at 263/200 into 38a/38b
        for k in range(38, 55):
            if plo[k] <= lo_pt and hi_pt <= phi[k]:
                if k == 38:
                    return "38a" if hi_pt <= F(263, 200) else "38b"
                return str(k)
        return "[%s,%s]" % (lo_pt, hi_pt)

    coverings = []

    # ---- three checkBand coverings
    specs = [
        ("R2", "Erdos993Lean/Analytic/Ladder/O1/TrieR2.lean", "trieR2", F(13, 10), F(7, 5), F(13, 10),
         "Erdos993Lean/Analytic/Ladder/O1/BoxR2.lean"),
        ("Trie3", "Erdos993Lean/Analytic/Reserve/Cert/Compute/Trie3.lean", "trie3", F(13, 10), F(8, 5), F(7, 5),
         "Erdos993Lean/Analytic/Reserve/Cert/Checks/Box3.lean"),
        ("R1", "Erdos993Lean/Analytic/Ladder/O1/TrieR1.lean", "trieR1", F(8, 5), F(33, 20), F(7, 5),
         "Erdos993Lean/Analytic/Ladder/O1/BoxR1.lean"),
    ]
    for name, rel, dname, lo, hi, cap, boxrel in specs:
        # confirm the band parameters from the theorem statement
        btxt = rd(boxrel)
        m = re.search(r"theorem\s+\w+\s*:\s*checkBand\s*\(([^)]*)\)\s*\(([^)]*)\)\s*\(([^)]*)\)\s*\(([^)]*)\)\s*(\d+)\s+"
                      + dname + r"\s*=\s*true", btxt)
        blo, bhi, bD = F(m.group(1)), F(m.group(2)), F(m.group(3))
        assert (blo, bhi, bD) == (lo, hi, cap), (name, blo, bhi, bD)
        coverings.append({"name": name, "lo": lo, "hi": hi, "cap": cap,
                          "parts": [(rel, dname, None)], "box_theorem": boxrel})

    # ---- the upper covering: nine pieces, sub-boxes from the check theorems
    up_parts = []
    for k in range(9):
        ctxt = rd("Erdos993Lean/Analytic/Reserve/UpperCert/Checks/Piece%d.lean" % k)
        m = re.search(r"theorem\s+piece_%d\s*:\s*checkAt\s*(.*?)\s*piece%d\s*=\s*true" % (k, k), ctxt, re.S)
        up_parts.append(("Erdos993Lean/Analytic/Reserve/UpperCert/Compute/Piece%d.lean" % k, "piece%d" % k,
                         m.group(1).strip()))
    coverings.append({"name": "Upper", "lo": F(8, 5), "hi": F(7, 3), "cap": F(8, 5), "parts": up_parts,
                      "box_theorem": "Erdos993Lean/Analytic/Reserve/UpperCert/Checks/Piece*.lean"})

    # skeleton cross-check from Main.lean
    mtxt = rd("Erdos993Lean/Analytic/Reserve/UpperCert/Main.lean")
    sk = re.search(r"skeleton\s*`([012P]+)`", mtxt).group(1)
    say("upper skeleton (Main.lean): %s" % sk)

    results = {"repo": REPO, "head": head, "one": "2^64", "pieces_38_54": {k: [str(v[0]), str(v[1])] for k, v in pieces.items()},
               "split_points": [str(p) for p in pts], "coverings": {}}

    all_endpoint_hits = {}

    for cov in coverings:
        name, lo, hi, cap = cov["name"], cov["lo"], cov["hi"], cov["cap"]
        root = rootCell_lambda(lo, hi)
        say("")
        say("=== %s: lambda in [%s, %s], cap D = %s; root lambda fixed point [%d, %d]" % (name, lo, hi, cap, root[0], root[1]))
        say("    root lo = floor(%s*2^64) (exact? %s), root hi = ceil(%s*2^64) (exact? %s)" % (
            lo, (lo * ONE).denominator == 1, hi, (hi * ONE).denominator == 1))
        interior = [p for p in pts if lo < p < hi]
        gaps = []
        edges = [lo] + interior + [hi]
        for g in range(len(edges) - 1):
            gaps.append(label_of_gap(edges[g], edges[g + 1]))
        say("    interior split points: " + ", ".join(str(p) for p in interior))
        say("    gaps: " + ", ".join(gaps))

        st = {"cells": 0, "removable": 0, "to_test": 0,
              "inside": {g: {"cells": 0, "removable": 0, "to_test": 0} for g in gaps},
              "straddlers": {"cells": 0, "removable": 0, "to_test": 0, "by_point": {}},
              "spill_below_lo": 0, "spill_above_hi": 0, "endpoint_hits": {},
              "min_a": None, "max_b": None, "below_Dhat_domain": 0, "above_Dhat_domain": 0}

        def sink(a, b, st=st, interior=interior, gaps=gaps, cap=cap, lo=lo, hi=hi):
            st["cells"] += 1
            if st["min_a"] is None or a < st["min_a"]:
                st["min_a"] = a
            if st["max_b"] is None or b > st["max_b"]:
                st["max_b"] = b
            # removability: sup of D_hat over [a, b] = D_hat(b) (nondecreasing, right-closed pieces)
            if cmp_fp(b, HAND_DOMAIN[1]) > 0:
                st["above_Dhat_domain"] += 1
            if cmp_fp(a, HAND_DOMAIN[0]) < 0:
                st["below_Dhat_domain"] += 1
            rem = Dhat_at_fp(b) <= cap
            key = "removable" if rem else "to_test"
            st[key] += 1
            if cmp_fp(a, lo) < 0:
                st["spill_below_lo"] += 1
            if cmp_fp(b, hi) > 0:
                st["spill_above_hi"] += 1
            # endpoint exactly on any split point (incl. covering ends)
            for p in pts:
                for which, x in (("a", a), ("b", b)):
                    if cmp_fp(x, p) == 0:
                        kk = "%s=%s" % (which, p)
                        st["endpoint_hits"][kk] = st["endpoint_hits"].get(kk, 0) + 1
            crossed = [p for p in interior if cmp_fp(a, p) < 0 < cmp_fp(b, p)]
            if crossed:
                s2 = st["straddlers"]
                s2["cells"] += 1
                s2[key] += 1
                ck = "+".join(str(p) for p in crossed)
                bp = s2["by_point"].setdefault(ck, {"cells": 0, "removable": 0, "to_test": 0})
                bp["cells"] += 1
                bp[key] += 1
            else:
                gi = sum(1 for p in interior if cmp_fp(a, p) >= 0)
                # sanity: b lies at or below the next edge
                if gi < len(interior):
                    assert cmp_fp(b, interior[gi]) <= 0
                g = st["inside"][gaps[gi]]
                g["cells"] += 1
                g[key] += 1

        parts_info = []
        for rel, dname, boxexpr in cov["parts"]:
            txt = rd(rel)
            s = lean_string_def(txt, dname)
            nclaim, shaclaim = doc_claims(txt)
            sha = hashlib.sha256(s.encode("ascii")).hexdigest()
            chars = set(s)
            sub = root if boxexpr is None else apply_box_expr(boxexpr, root)
            before = st["cells"]
            w = walk_leaves(s, sub, sink)
            info = {"file": rel, "def": dname, "sub_box_expr": boxexpr, "sub_box_lambda_fp": [sub[0], sub[1]],
                    "sub_box_lambda_float": [sub[0] / ONE, sub[1] / ONE],
                    "chars": len(s), "chars_claimed": nclaim, "sha256": sha, "sha256_claimed": shaclaim,
                    "sha_match": sha == shaclaim, "charset": "".join(sorted(chars)),
                    "leaves": w["leaves"], "count_L": s.count("L"), "consumed_all": w["consumed_all"],
                    "max_depth": w["max_depth"], "fuel_ok": w["fuel_ok"], "splits": w["splits"]}
            mleaves = re.search(r"([0-9]+) leaves\.", txt) or re.search(r"([0-9]+) cells over", txt)
            info["leaves_claimed_doc"] = int(mleaves.group(1)) if mleaves else None
            parts_info.append(info)
            say("    %s: chars %d (doc %s), sha %s, leaves %d (doc %s), L-count %d, consumed all %s, max depth %d, sub-box lambda [%.12f, %.12f]" % (
                dname, len(s), nclaim, "MATCH" if sha == shaclaim else "MISMATCH", w["leaves"], info["leaves_claimed_doc"],
                s.count("L"), w["consumed_all"], w["max_depth"], sub[0] / ONE, sub[1] / ONE))
            assert st["cells"] - before == w["leaves"]
        st["parts"] = parts_info
        for k, v in st["endpoint_hits"].items():
            all_endpoint_hits["%s:%s" % (name, k)] = v
        say("    cells %d; removable %d; to test %d" % (st["cells"], st["removable"], st["to_test"]))
        for g in gaps:
            d = st["inside"][g]
            say("      inside %-4s: %7d  (removable %d, to test %d)" % (g, d["cells"], d["removable"], d["to_test"]))
        s2 = st["straddlers"]
        say("      straddlers : %7d  (removable %d, to test %d)" % (s2["cells"], s2["removable"], s2["to_test"]))
        for ck, v in sorted(s2["by_point"].items()):
            say("         crossing %s: %d (removable %d, to test %d)" % (ck, v["cells"], v["removable"], v["to_test"]))
        say("      spill below lo %d, spill above hi %d; min a = %.15f, max b = %.15f" % (
            st["spill_below_lo"], st["spill_above_hi"], st["min_a"] / ONE, st["max_b"] / ONE))
        say("      endpoint hits on split points: %s" % (st["endpoint_hits"] or "none"))
        st["root_lambda_fp"] = [root[0], root[1]]
        st["lo"], st["hi"], st["cap"] = str(lo), str(hi), str(cap)
        st["min_a"] = str(st["min_a"])
        st["max_b"] = str(st["max_b"])
        results["coverings"][name] = st

    # skeleton cross-check: walking the skeleton with pieces substituted reproduces the piece sub-boxes
    root = rootCell_lambda(F(8, 5), F(7, 3))
    skel_boxes = []
    stack = []
    a, b = root
    i = 0
    while True:
        ch = sk[i]
        i += 1
        if ch == "P":
            skel_boxes.append((a, b))
            if not stack:
                break
            a, b = stack.pop()
        elif ch == "0":
            m = midI(a, b)
            stack.append((m, b))
            b = m
        else:
            stack.append((a, b))
    up_boxes = [tuple(p["sub_box_lambda_fp"]) for p in results["coverings"]["Upper"]["parts"]]
    skel_ok = (skel_boxes == up_boxes) and i == len(sk)
    say("")
    say("skeleton cross-check (pieces' lambda sub-boxes == skeleton order): %s" % skel_ok)
    results["skeleton"] = sk
    results["skeleton_matches_piece_theorems_lambda"] = skel_ok

    # ---- compare with the claim
    claim = {
        "R2": {"cells": 71868, "removable": 8432, "to_test": 63436,
               "inside": {"38a": 8432, "38b": 23239, "39": 37679}, "straddlers": 2518},
        "Trie3": {"cells": 107872, "removable": 60386, "to_test": 47486,
                  "inside": {"38a": 2475, "38b": 7159, "39": 11640, "40": 5041, "41": 6666, "42": 16456, "43": 43994},
                  "straddlers": 14441},
        "R1": {"cells": 85150, "removable": 0, "to_test": 85150, "inside": {"44": 85150}, "straddlers": 0},
        "Upper": {"cells": 670014, "removable": 113428, "to_test": 556586,
                  "inside": {"44": 35843, "45": 34096, "46": 35525, "47": 31941, "48": 34392, "49": 35840,
                             "50": 34648, "51": 32224, "52": 37637, "53": 187017, "54": 126610},
                  "straddlers": 44241},
    }
    mism = []
    for name, c in claim.items():
        st = results["coverings"][name]
        for k in ("cells", "removable", "to_test"):
            if st[k] != c[k]:
                mism.append("%s %s: computed %d vs claim %d" % (name, k, st[k], c[k]))
        for g, v in c["inside"].items():
            got = st["inside"].get(g, {"cells": None})["cells"]
            if got != v:
                mism.append("%s inside %s: computed %s vs claim %d" % (name, g, got, v))
        extra = [g for g in st["inside"] if g not in c["inside"] and st["inside"][g]["cells"]]
        for g in extra:
            mism.append("%s inside %s: computed %d, not in the claim's table" % (name, g, st["inside"][g]["cells"]))
        if st["straddlers"]["cells"] != c["straddlers"]:
            mism.append("%s straddlers: computed %d vs claim %d" % (name, st["straddlers"]["cells"], c["straddlers"]))
    tot = sum(results["coverings"][n]["cells"] for n in claim)
    rem = sum(results["coverings"][n]["removable"] for n in claim)
    tt = sum(results["coverings"][n]["to_test"] for n in claim)
    srem = sum(results["coverings"][n]["straddlers"]["removable"] for n in claim)
    stt = sum(results["coverings"][n]["straddlers"]["to_test"] for n in claim)
    t3_43_tt = results["coverings"]["Trie3"]["inside"]["43"]["to_test"]
    t3_other_tt = results["coverings"]["Trie3"]["to_test"] - t3_43_tt
    for lab, got, want in (("total cells", tot, 934904), ("total removable", rem, 182246), ("total to test", tt, 752658),
                           ("straddlers removable (all coverings)", srem, 18913),
                           ("straddlers to test (all coverings)", stt, 42287),
                           ("Trie3 to-test cells outside 43 (the '+3,492')", t3_other_tt, 3492)):
        if got != want:
            mism.append("%s: computed %d vs claim %d" % (lab, got, want))
        say("%-48s computed %8d   claim %8d   %s" % (lab, got, want, "OK" if got == want else "MISMATCH"))
    results["totals"] = {"cells": tot, "removable": rem, "to_test": tt, "straddlers_removable": srem,
                         "straddlers_to_test": stt, "trie3_to_test_outside_43": t3_other_tt}
    results["endpoint_hits_on_split_points"] = all_endpoint_hits
    results["mismatches"] = mism
    say("")
    say("MISMATCHES (%d):" % len(mism))
    for x in mism:
        say("  " + x)
    say("endpoint hits on split points (all coverings): %s" % (all_endpoint_hits or "none"))
    say("elapsed %.1f s; end %s" % (time.time() - t0, time.strftime("%Y-%m-%d %H:%M:%S %Z")))

    with open(os.path.join(OUT, "ref_inventory.json"), "w") as fh:
        json.dump(results, fh, indent=1, default=str)
    with open(os.path.join(OUT, "ref_inventory.log"), "w") as fh:
        fh.write("\n".join(log) + "\n")


if __name__ == "__main__":
    main()
