"""Referee's own box checker (referee_upper_d_test), written from the paper's statements:
part2_body.tex Sec. p2:sec:atlas (MGF box test), appendix_C_inputs.tex Sec. apC:sec:t1box (lower-tail box test).

Soundness target (what a pass proves), for every q in [ql,qh]:
  (F)  rhs(M) <= kappa2(M,j;q) + xi*delta + eta*delta^2   for all M < Mbar, all integers j  (delta = j - qM)
  (T)  the elementary tail (MGF: kappa2 >= -max(wL,wR); lower-tail: the paper's Fourier floor, Lemma apC:lem:fourier)
  (Mg) the margin, exactly as stated in the paper (exact rationals).
My (F) is a DIFFERENT sufficient test from the paper's Taylor test:
  * atoms j <= -2, j >= M+2 (kappa2 = 0): exact half-line minima of eta d^2 + xi d;
  * atoms with eta*dist(d*, [j-qh M, j-ql M])^2 >= lev, lev = rhs + W + xi^2/(4 eta): skipped (kappa2 >= -W),
    W = max(wL,wR) (MGF) or W = 1 (lower tail: kappa >= -(b(j-1)+b(j+1)) >= -1);
  * other atoms: kappa2 = B(q) K(q), B = C(M,j) q^(j-1) (1-q)^(M-j-1) > 0 enclosed exactly via the extremes of the
    exponent (endpoints and the critical point), K quadratic in q (exact extremes); lower bound
    lb(B K) + min_delta (eta d^2 + xi d) - rhs >= 0 certified in arb balls (200 bits), with q-bisection;
    j = -1 and j = M+1 exactly: kappa2 = -wR (1-q)^M >= -wR (1-ql)^M, kappa2 = -wL q^M >= -wL qh^M.
"""
from fractions import Fraction as F
import math
from flint import arb, fmpq, ctx

ctx.prec = 200
TILTS = [F(0), F(1, 20), F(1, 10), F(1, 5), F(3, 10)]

_LF = [arb(0)]


def logfact(n):
    while len(_LF) <= n:
        k = len(_LF)
        _LF.append(_LF[-1] + arb(k).log())
    return _LF[n]


def A(x):
    """exact Fraction -> arb ball"""
    return arb(fmpq(x.numerator, x.denominator))


_logcache = {}


def alog(x):
    v = _logcache.get(x)
    if v is None:
        v = A(x).log()
        if len(_logcache) > 200000:
            _logcache.clear()
        _logcache[x] = v
    return v


def quad_min(eta, xi, lo, hi):
    """exact min of eta d^2 + xi d on [lo, hi] (eta > 0)"""
    ds = -xi / (2 * eta)
    d = min(max(ds, lo), hi)
    return eta * d * d + xi * d


def halfline_min_le(eta, xi, a):
    """min over d <= a"""
    ds = -xi / (2 * eta)
    d = ds if ds <= a else a
    return eta * d * d + xi * d


def halfline_min_ge(eta, xi, b):
    ds = -xi / (2 * eta)
    d = ds if ds >= b else b
    return eta * d * d + xi * d


def atom_lb_ok(M, j, a, b, wL, wR, eta, xi, rhs, depth=0, maxdepth=14, stats=None):
    """certify  min_{q in [a,b]} kappa2(M,j;q) + xi d + eta d^2 >= rhs  (0 <= j <= M)."""
    if stats is not None:
        stats['evals'] += 1
    # K(q) = wL kL (1-q)^2 + wR kR q^2
    kL = F(M + 1 - 2 * j, M - j + 1)
    kR = F(2 * j + 1 - M, j + 1)
    c0 = wL * kL
    c2 = wL * kL + wR * kR
    c1 = -2 * wL * kL
    pts = [a, b]
    if c2 != 0:
        qv = -c1 / (2 * c2)
        if a < qv < b:
            pts.append(qv)
    Kvals = [c2 * q * q + c1 * q + c0 for q in pts]
    Kmin = min(Kvals)
    # exponent e(q) = Ae log q + Be log(1-q), Ae = j-1, Be = M-j-1
    Ae, Be = j - 1, M - j - 1
    epts = [a, b]
    if Ae * Be > 0:
        qs = F(Ae, Ae + Be)
        if a < qs < b:
            epts.append(qs)
    lc = logfact(M) - logfact(j) - logfact(M - j)
    evals = [lc + Ae * alog(q) + Be * alog(1 - q) for q in epts]
    if Kmin >= 0:
        # B >= exp(min exponent); the smallest certified lower end of the exponent balls
        lows = [e.lower() for e in evals]
        m = lows[0]
        for x in lows[1:]:
            if x < m:
                m = x
        Bbound = m.exp()
        BK = Bbound * A(Kmin)
    else:
        ups = [e.upper() for e in evals]
        m = ups[0]
        for x in ups[1:]:
            if x > m:
                m = x
        Bbound = m.exp()
        BK = Bbound * A(Kmin)
    Q = quad_min(eta, xi, j - b * M, j - a * M)
    val = BK + A(Q - rhs)
    if val >= 0:
        return True
    if depth >= maxdepth:
        return False
    mid = (a + b) / 2
    return (atom_lb_ok(M, j, a, mid, wL, wR, eta, xi, rhs, depth + 1, maxdepth, stats) and
            atom_lb_ok(M, j, mid, b, wL, wR, eta, xi, rhs, depth + 1, maxdepth, stats))


def fiber_ok(M, ql, qh, wL, wR, eta, xi, rhs, W, stats):
    """(F) for one fiber M: all integer atoms j, all q in [ql, qh]."""
    ds = -xi / (2 * eta)
    # half-lines j <= -2 and j >= M+2 (kappa2 = 0)
    if halfline_min_le(eta, xi, -2 - ql * M) < rhs:
        return False, ('halfline-', M)
    if halfline_min_ge(eta, xi, M + 2 - qh * M) < rhs:
        return False, ('halfline+', M)
    lev = rhs + W + xi * xi / (4 * eta)
    if lev <= 0:
        stats['fibers_lev'] += 1
        return True, None
    # candidate range with exact verification of the ends
    r = math.sqrt(float(lev / eta)) + 2.0
    jlo = max(-1, int(math.floor(float(ql * M + ds) - r)) - 1)
    jhi = min(M + 1, int(math.ceil(float(qh * M + ds) + r)) + 1)
    if jlo > -1:
        jL = jlo - 1
        dd = ds - (jL - ql * M)
        if not (dd >= 0 and eta * dd * dd >= lev):
            jlo = -1
    if jhi < M + 1:
        jR = jhi + 1
        dd = (jR - qh * M) - ds
        if not (dd >= 0 and eta * dd * dd >= lev):
            jhi = M + 1
    for j in range(jlo, jhi + 1):
        lo_d, hi_d = j - qh * M, j - ql * M
        if ds < lo_d:
            dist = lo_d - ds
        elif ds > hi_d:
            dist = ds - hi_d
        else:
            dist = F(0)
        if eta * dist * dist >= lev:
            stats['skip'] += 1
            continue
        stats['atoms'] += 1
        Qmin = quad_min(eta, xi, lo_d, hi_d)
        if j == -1:
            if -wR * (1 - ql) ** M + Qmin < rhs:
                return False, ('atom', M, j)
            continue
        if j == M + 1:
            if -wL * qh ** M + Qmin < rhs:
                return False, ('atom', M, j)
            continue
        if not atom_lb_ok(M, j, ql, qh, wL, wR, eta, xi, rhs, stats=stats):
            return False, ('atom', M, j)
    return True, None


def vmax(ql, qh):
    if ql <= F(1, 2) <= qh:
        return F(1, 4)
    return max(ql * (1 - ql), qh * (1 - qh))


def exp_partial(x, nterms):
    s = F(0)
    t = F(1)
    for i in range(nterms):
        if i > 0:
            t = t * x / i
        s += t
    return s


def mgf_box(bx, theta, D, rates, stats):
    """MGF box test. bx: dict with ql,qh,ml,mh,m0,eta,xi,alpha,beta,gamma,wL,wR,z(5),N. Returns (ok, margin, why)."""
    ql, qh, ml, mh, m0 = bx['ql'], bx['qh'], bx['ml'], bx['mh'], bx['m0']
    eta, xi, al, be, ga = bx['eta'], bx['xi'], bx['alpha'], bx['beta'], bx['gamma']
    wL, wR, z, N = bx['wL'], bx['wR'], bx['z'], bx['N']
    # (S)
    if not (0 < ql < qh < 1 and eta > 0 and ga >= 0 and wL >= 0 and wR >= 0 and all(x >= 0 for x in z)
            and 0 < ml <= mh and len(z) == 5):
        return False, None, 'S'
    W = max(wL, wR)
    psi = lambda M: al + be * (M - m0) - ga * (M - m0) ** 2
    # (T)
    if not (psi(N) <= -W - xi * xi / (4 * eta) and be - 2 * ga * (N - m0) <= 0):
        return False, None, 'T'
    # (Mg)
    eh = [1 / exp_partial(l * ml, 121) for l in rates]
    mg = (al + min(be * (ml - m0), be * (mh - m0)) - ga * (D * mh + max((ml - m0) ** 2, (mh - m0) ** 2))
          - eta * theta * vmax(ql, qh) * mh - sum(zr * e for zr, e in zip(z, eh)))
    if not mg > 0:
        return False, mg, 'Mg'
    # (F)
    s = [1 - qh + qh * t for t in TILTS]
    for M in range(N):
        rhs = psi(M) - sum(zr * sr ** M for zr, sr in zip(z, s))
        ok, why = fiber_ok(M, ql, qh, wL, wR, eta, xi, rhs, W, stats)
        if not ok:
            return False, mg, ('F', why)
    return True, mg, None


def t1_box(bx, theta, D, rates, lamBar, stats):
    """Lower-tail box test. bx: ql,qh,ml,mh,m0,eta,xi,alpha,beta,gamma,z(list over M'),N,Mstar."""
    ql, qh, ml, mh, m0 = bx['ql'], bx['qh'], bx['ml'], bx['mh'], bx['m0']
    eta, xi, al, be, ga = bx['eta'], bx['xi'], bx['alpha'], bx['beta'], bx['gamma']
    z, N, Ms = bx['z'], bx['N'], bx['Mstar']
    if not (0 < ql < qh < 1 and eta > 0 and ga > 0 and all(x >= 0 for x in z) and 0 < ml <= mh
            and Ms < ml + 1 and lamBar >= 0):
        return False, None, 'S'
    psi = lambda M: al + be * (M - m0) - ga * (M - m0) ** 2
    vmin = min(ql * (1 - ql), qh * (1 - qh))
    V = vmin * N
    if not (V >= 25 and psi(N) <= -(1 / (20 * V) + 1 / (V * V)) - xi * xi / (4 * eta)
            and be - 2 * ga * (N - m0) <= 0):
        return False, None, 'T'
    eT = [1 / exp_partial(l * ml, 120) for l in rates]
    ratio = [(1 + lamBar) / (1 + lamBar * t) for t in TILTS]
    cost = F(0)
    pw = [F(1)] * 5
    for Mp, zz in enumerate(z):
        if Mp > 0:
            pw = [p * r for p, r in zip(pw, ratio)]
        if zz == 0:
            continue
        if Mp <= Ms:
            Th = min([F(1)] + [e * p for e, p in zip(eT, pw)])
        else:
            Th = F(1)
        cost += zz * Th
    mg = (al + min(be * (ml - m0), be * (mh - m0)) - ga * (D * mh + max((ml - m0) ** 2, (mh - m0) ** 2))
          - eta * theta * vmax(ql, qh) * mh - cost)
    if not mg > 0:
        return False, mg, 'Mg'
    # suffix sums of z
    suf = [F(0)] * (len(z) + 1)
    for i in range(len(z) - 1, -1, -1):
        suf[i] = suf[i + 1] + z[i]
    for M in range(N):
        rhs = psi(M) - (suf[M] if M < len(z) else 0)
        ok, why = fiber_ok(M, ql, qh, F(1), F(1), eta, xi, rhs, F(1), stats)
        if not ok:
            return False, mg, ('F', why)
    return True, mg, None


def cover_ok(boxes, Qlo, Qhi, mlo, mhi):
    """exact: the union of the closed boxes contains [Qlo,Qhi] x [mlo,mhi]."""
    cuts = sorted(set([Qlo, Qhi] + [b['ql'] for b in boxes if Qlo < b['ql'] < Qhi]
                      + [b['qh'] for b in boxes if Qlo < b['qh'] < Qhi]))
    for x0, x1 in zip(cuts, cuts[1:]):
        iv = sorted((b['ml'], b['mh']) for b in boxes if b['ql'] <= x0 and b['qh'] >= x1)
        reach = mlo
        for lo, hi in iv:
            if lo > reach:
                break
            if hi > reach:
                reach = hi
        if reach < mhi:
            return False, (x0, x1, reach)
    return True, None
