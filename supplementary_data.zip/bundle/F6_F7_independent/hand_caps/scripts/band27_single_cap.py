"""Band 27 ([19/10, 41/20]) straddles the hand-cap break at 2: do the final S28/L28/U28 coverings (passing Lean entries +
new boxes) also pass with ONE cap D = 21/10 for the whole band (the paper's band test carries one D per band)?"""
import json, glob, sys
from fractions import Fraction as F
import leandata as L, refbox as RB, run_t1 as RT
B = L.bands(); sf = L.strip_floor52(); b = B[27]; st = dict(evals=0, atoms=0, skip=0, fibers_lev=0); res = {}
for kind in ('S', 'L', 'U'):
    if kind == 'S':
        lean = L.boxes_atlas(f"{L.LEAN}/N52/Data/S28.lean"); new = [RT.author_box(p) for p in sorted(glob.glob(f"{RT.AUTH}/t1_hand/N52_S28/box_*.json"))]
        base = lambda x: x['qh'] / (1 - x['qh']); mlo, mhi = sf[27], b['mmin']
    elif kind == 'L':
        lean = L.boxes_atlas(f"{L.LEAN}/Atlas/Data/L28.lean"); new = [RT.author_box(p) for p in sorted(glob.glob(f"{RT.AUTH}/t1_hand_const/Atlas_L28/box_*.json"))]
        base = lambda x: b['hi']; mlo, mhi = b['mmin'], F(50)
    else:
        lean = L.boxes_atlas(f"{L.LEAN}/Atlas/Data/U28.lean"); new = [RT.author_box(p) for p in sorted(glob.glob(f"{RT.AUTH}/t1_hand_const/Atlas_U28/box_*.json"))]
        base = lambda x: b['hi']; mlo, mhi = F(50), F(400)
    keep = []; fail_new = []
    for k, x in enumerate(lean):
        if RB.t1_box(x, b['theta'], RT.dhat(x['qh'] / (1 - x['qh'])), b['ell'], base(x), st)[0]:
            keep.append(x)
    allb = keep + new
    fails = [x['name'] for x in allb if not RB.t1_box(x, b['theta'], F(21, 10), b['ell'], base(x), st)[0]]
    res[kind] = dict(final_entries=len(allb), fail_at_21_10=fails)
    print(kind, len(allb), 'fail at single cap 21/10:', len(fails), fails[:8], flush=True)
json.dump(res, open(sys.argv[1], 'w'), indent=1)
