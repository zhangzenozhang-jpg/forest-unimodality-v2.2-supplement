"""Referee's own parser of the Lean data modules (read only), commit aa8ba75 of Erdos993-Lean-FiberFloor."""
import re
from fractions import Fraction as F

LEAN = "/Users/kvallier/Desktop/Erdos993-Lean-FiberFloor/Erdos993Lean/Analytic"


TYPES = {}


def strip_comments(t):
    t = re.sub(r'/-.*?-/', ' ', t, flags=re.S)
    t = re.sub(r'--[^\n]*', ' ', t)
    return t


TOK = re.compile(r'R \((-?\d+)\) (\d+)|mkRat (-?\d+) (\d+)|\[|\]|⟨|⟩|(?<![\w.])(\d+)(?![\w.])')


def tokens(s):
    out = []
    for m in TOK.finditer(s):
        if m.group(1) is not None:
            out.append(F(int(m.group(1)), int(m.group(2))))
        elif m.group(3) is not None:
            out.append(F(int(m.group(3)), int(m.group(4))))
        elif m.group(5) is not None:
            out.append(int(m.group(5)))
        else:
            out.append(m.group(0))
    return out


def nest(toks):
    """turn bracket tokens into nested python lists"""
    stack = [[]]
    for t in toks:
        if t in ('[', '⟨'):
            stack.append([])
        elif t in (']', '⟩'):
            x = stack.pop()
            stack[-1].append(x)
        else:
            stack[-1].append(t)
    return stack[0]


def defs(path):
    t = strip_comments(open(path, encoding='utf-8').read())
    parts = re.split(r'\n(?:@\[[^\]]*\]\s*)?(?:private\s+)?def\s+', '\n' + t)
    out = {}
    for p in parts[1:]:
        name = p.split()[0]
        head = p.split(':=', 1)[0] if ':=' in p else ''
        body = p.split(':=', 1)[1] if ':=' in p else ''
        out[name] = body
        TYPES[name] = head
    return out


def deflist(path, name):
    d = defs(path)
    return nest(tokens(d[name]))[0]


def boxes_atlas(path):
    """Atlas Box: <ql, qh, ml, mh, m0, mu, c, alpha, beta, gamma, [z], N, cm>"""
    d = defs(path)
    out = []
    for name, body in d.items():
        if not (name.startswith('box') and re.search(r':\s*Box\s*$', TYPES[name].strip() + ' ')):
            continue
        v = nest(tokens(body))[0]
        ql, qh, ml, mh, m0, mu, c, al, be, ga, z, N, cm = v
        out.append(dict(name=name, ql=ql, qh=qh, ml=ml, mh=mh, m0=m0, eta=mu, xi=c, alpha=al, beta=be, gamma=ga,
                        z=list(z), N=N, Mstar=cm))
    return out


def boxes_mgf(path):
    """MGF MBox: <ql, qh, ml, mh, m0, nu, c, alpha, beta, gamma, a, b, [z], N>"""
    d = defs(path)
    out = []
    for name, body in d.items():
        if not (name.startswith('box') and re.search(r':\s*MBox\s*$', TYPES[name].strip() + ' ')):
            continue
        v = nest(tokens(body))[0]
        ql, qh, ml, mh, m0, nu, c, al, be, ga, a, b, z, N = v
        out.append(dict(name=name, ql=ql, qh=qh, ml=ml, mh=mh, m0=m0, eta=nu, xi=c, alpha=al, beta=be, gamma=ga,
                        wL=a, wR=b, z=list(z), N=N))
    return out


def bands():
    v = deflist(f"{LEAN}/Atlas/Params.lean", 'bandParams')
    out = []
    for b in v:
        D, th, ell, lo, hi, mmin = b
        out.append(dict(D=D, theta=th, ell=list(ell), lo=lo, hi=hi, mmin=mmin))
    return out


def n44():
    p = f"{LEAN}/N44/Data/Params.lean"
    keys = ['pieceLo', 'pieceHi', 'pieceParent', 'pieceUp', 'rates44', 'theta44', 'D44', 'kmin44', 'mmin44', 'newEll']
    return {k: deflist(p, k) for k in keys}


def n45():
    p = f"{LEAN}/N45/Data/Params.lean"
    d = defs(p)
    return {k: nest(tokens(d[k]))[0] for k in d if k in ('pieceLo', 'pieceHi', 'theta45', 'D45', 'mmin45', 'pieceUp')}


def n48():
    p = f"{LEAN}/N48/Data/Params.lean"
    d = defs(p)
    return {k: nest(tokens(d[k]))[0] for k in d if isinstance(d[k], str) and d[k].strip().startswith('[')}


def strip_floor52():
    return deflist(f"{LEAN}/N52/Data/Params.lean", 'stripFloor')


def mmin21():
    return deflist(f"{LEAN}/MGF/N21/Data.lean", 'mmin21')
