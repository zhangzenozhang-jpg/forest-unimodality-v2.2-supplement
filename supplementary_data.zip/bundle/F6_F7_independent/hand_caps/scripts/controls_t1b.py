"""Extra negative control: raising alpha makes (F) harder; find the boxes of new S30 / new L30 that reject alpha + 1e-3."""
import json, glob, sys
from fractions import Fraction as F
import leandata as L, refbox as RB, run_t1 as RT
B = L.bands(); st = dict(evals=0, atoms=0, skip=0, fibers_lev=0); res = {}
for cov, i, base in (('t1_hand/N52_S30', 29, None), ('t1_hand_const/Atlas_L30', 29, 'band')):
    b = B[i]
    new = [RT.author_box(p) for p in sorted(glob.glob(f"{RT.AUTH}/{cov}/box_*.json"))]
    out = []
    for x in new:
        y = dict(x); y['alpha'] += F(1, 1000)
        lb = b['hi'] if base else y['qh'] / (1 - y['qh'])
        r = RB.t1_box(y, b['theta'], F(21, 10), b['ell'], lb, st)
        out.append(str(r[2]) if not r[0] else 'pass')
    res[cov] = out; print(cov, out, flush=True)
json.dump(res, open(sys.argv[1], 'w'), indent=1)
