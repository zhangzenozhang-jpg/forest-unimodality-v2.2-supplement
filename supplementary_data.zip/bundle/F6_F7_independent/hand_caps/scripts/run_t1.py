"""Referee recheck of the lower-tail coverings the changed route uses above m_52 on the bands where the hand cap exceeds
the coarse cap (bands 24, 26, 27, 28, 29; Lean files S/L/U 25, 27..30): every Lean entry at the hand cap, every new
box of the author (t1_hand/N52_* and t1_hand_const/Atlas_*), and the exact cover of (passing Lean entries + new boxes).
theta, rates, edges, floors from the Lean data (my parser); D = hand cap sup over each box; tail base: q_h/(1-q_h) in
the strips (N52), the band's top activity in the coarse coverings (Atlas L, U), as in the paper's family table."""
import json, glob, sys, time
from math import ceil
from fractions import Fraction as F
import leandata as L
import refbox as RB

AUTH = ("/Users/kvallier/Desktop/Erdos 993/ProofRuns/2026-09-28_analytic_large_n/LEAN/certfree/upper_d_test/"
        "outputs/stage2")


def qof(l):
    return l / (1 + l)


def dhat(lam):
    if lam <= F(263, 200): return F(6, 5)
    if lam <= F(3, 2): return F(7, 5)
    if lam <= F(7, 4): return F(8, 5)
    if lam <= F(2): return F(9, 5)
    if lam <= F(7, 3): return F(21, 10)
    raise ValueError(lam)


B = L.bands()
sf = L.strip_floor52()


def least_cutoff(b):
    ql, qh = b['ql'], b['qh']
    v = min(ql * (1 - ql), qh * (1 - qh))
    N = int(ceil(F(25) / v))
    for _ in range(100000):
        V = v * N
        x = N - b['m0']
        psi = b['alpha'] + b['beta'] * x - b['gamma'] * x * x
        if V >= 25 and psi <= -(1 / (20 * V) + 1 / (V * V)) - b['xi'] ** 2 / (4 * b['eta']) and \
                b['beta'] - 2 * b['gamma'] * x <= 0:
            return N
        N += 1
    return None


def author_box(path):
    r = json.load(open(path))
    d = r['dual']
    b = dict(name=path.split('/')[-2] + '/' + path.split('/')[-1], ql=F(r['q'][0]), qh=F(r['q'][1]), ml=F(r['m'][0]),
             mh=F(r['m'][1]), eta=F(d['mu']), xi=F(d['c']), alpha=F(d['alpha']), beta=F(d['beta']),
             gamma=F(d['gamma']), z=[F(x) for x in d['z']])
    b['m0'] = (b['ml'] + b['mh']) / 2
    b['Mstar'] = int(ceil(b['ml']))
    b['N'] = least_cutoff(b)
    b['N_json'] = r.get('cutoff')
    return b


def run_cov(i, kind):
    band = B[i]
    fileidx = i + 1
    if kind == 'S':
        lean = L.boxes_atlas(f"{L.LEAN}/N52/Data/S{fileidx:02d}.lean")
        new = [author_box(p) for p in sorted(glob.glob(f"{AUTH}/t1_hand/N52_S{fileidx:02d}/box_*.json"))]
        mlo, mhi = sf[i], band['mmin']
        base = lambda b: b['qh'] / (1 - b['qh'])
    elif kind == 'L':
        lean = L.boxes_atlas(f"{L.LEAN}/Atlas/Data/L{fileidx:02d}.lean")
        new = [author_box(p) for p in sorted(glob.glob(f"{AUTH}/t1_hand_const/Atlas_L{fileidx:02d}/box_*.json"))]
        mlo, mhi = band['mmin'], F(50)
        base = lambda b: band['hi']
    else:
        lean = L.boxes_atlas(f"{L.LEAN}/Atlas/Data/U{fileidx:02d}.lean")
        new = [author_box(p) for p in sorted(glob.glob(f"{AUTH}/t1_hand_const/Atlas_U{fileidx:02d}/box_*.json"))]
        mlo, mhi = F(50), F(400)
        base = lambda b: band['hi']
    res = dict(cov=f"{kind}{fileidx:02d}", band=i, lam=[str(band['lo']), str(band['hi'])], theta=str(band['theta']),
               rect=[str(mlo), str(mhi)], lean_entries=len(lean), new_boxes=len(new), lean_fail=[], new_fail=[])
    t0 = time.time()
    stats = dict(evals=0, atoms=0, skip=0, fibers_lev=0)
    keep = []
    mg_lean, mg_new = [], []
    for k, b in enumerate(lean):
        D = dhat(b['qh'] / (1 - b['qh']))
        ok, mg, why = RB.t1_box(b, band['theta'], D, band['ell'], base(b), stats)
        if ok:
            keep.append(b)
            mg_lean.append(float(mg))
        else:
            res['lean_fail'].append([k, b['name'], str(why), float(mg) if mg is not None else None, str(D)])
    for b in new:
        D = dhat(b['qh'] / (1 - b['qh']))
        if b['N'] is None:
            res['new_fail'].append([b['name'], 'no cutoff'])
            continue
        ok, mg, why = RB.t1_box(b, band['theta'], D, band['ell'], base(b), stats)
        if ok:
            mg_new.append(float(mg))
        else:
            res['new_fail'].append([b['name'], str(why), float(mg) if mg is not None else None, str(D)])
    cok, cwhy = RB.cover_ok(keep + [b for b in new], qof(band['lo']), qof(band['hi']), mlo, mhi)
    res['cover_final'] = cok
    res['cover_why'] = str(cwhy)
    res['lean_pass'] = len(keep)
    res['min_margin_lean_pass'] = min(mg_lean) if mg_lean else None
    res['min_margin_new'] = min(mg_new) if mg_new else None
    res['stats'] = stats
    res['sec'] = round(time.time() - t0, 1)
    res['PASS'] = cok and not res['new_fail']
    print(json.dumps(res), flush=True)
    return res


if __name__ == '__main__':
    which = sys.argv[1]          # 'S', 'L' or 'U'
    OUT = sys.argv[2]
    out = [run_cov(i, which) for i in (24, 26, 27, 28, 29)]
    json.dump(out, open(OUT, 'w'), indent=1, default=str)
    print('DONE', flush=True)
