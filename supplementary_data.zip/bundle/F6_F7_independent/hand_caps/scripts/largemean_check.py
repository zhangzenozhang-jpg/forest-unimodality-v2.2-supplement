"""Referee recompute of the two final bounds of the large-mean theorem (appendix_C_inputs.tex, proof of
Theorem apC:thm:largemean) with eps = D/mu_M, for the paper's D <= 8/5 (control) and D <= 21/10."""
from fractions import Fraction as F
def bounds(eps):
    aG_lo, aG_hi = F(6, 25), F(1, 4)
    # central: 3/8<=q<=8/13, theta<=7/10, |1-2q|<=1/4, sigma>=8, sigma^2>=75, 2e^{-mu/30}sigma^3<=1/250
    c = aG_lo * (1 - F(7, 10) - 20 * eps) - F(2, 3) * F(1, 4) * (1 + 15 * eps) / 8 - (1 + 30 * eps) / 75 - F(1, 250)
    assert 1 - F(7, 10) - 20 * eps >= 0
    # outer: theta<=1, |1-2q|<=1/2: a_G(1-theta-20eps) >= -(1/4)(20 eps) when theta = 1 (worst case in theta, see below)
    o = (-aG_hi * 20 * eps - F(2, 3) * F(1, 2) * (1 + 15 * eps) / 8 - (1 + 30 * eps) / 75 - F(1, 250)
         + F(9, 1600) * 75 * (1 - 4 * eps - F(2, 3)))
    assert 1 - 4 * eps - F(2, 3) >= 0
    return c, o
for D in (F(8, 5), F(21, 10)):
    eps = D / 400
    c, o = bounds(eps)
    print('D =', D, 'eps =', eps, 'central =', c, float(c), 'outer =', o, float(o))
# the outer expression is affine in theta with coefficient -a_G - (9/1600)*(2/3)*sigma^2 < 0, so theta = 1 is the worst
# case: check the theta-dependence sign used: a_G(1-theta-20eps) + (9/1600) sigma^2 (1-4eps-2theta/3)
print('largest D for which both stay positive (scan):')
lo, hi = F(8, 5), F(10)
for _ in range(60):
    mid = (lo + hi) / 2
    c, o = None, None
    try:
        c, o = bounds(mid / 400)
        ok = c > 0 and o > 0
    except AssertionError:
        ok = False
    lo, hi = (mid, hi) if ok else (lo, mid)
print(float(lo))
