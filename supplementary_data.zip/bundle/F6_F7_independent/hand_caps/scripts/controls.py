"""Controls for the referee's MGF checker: Stage-1 reproduction (existing Lean lists at the hand caps), positive
controls (existing Lean lists at their Lean caps D21tab), negative controls (perturbed data must be rejected)."""
import json, glob, sys
from fractions import Fraction as F
import leandata as L
import refbox as RB
import run_mgf as RM   # reuses only helpers; run_mgf's main block is guarded below

P, m21, sf = RM.P, RM.m21, RM.sf
D21 = lambda i: F(21, 20) if i == 24 else (F(23, 20) if i == 27 else P['D44'][i])
res = {}
st = dict(evals=0, atoms=0, skip=0, fibers_lev=0)
# Stage-1 reproduction: existing Lean lists at the hand caps (expect R_38, R_43, R_48, R_53 to fail)
for i in (38, 43, 48, 53):
    ex = L.boxes_mgf(f"{L.LEAN}/MGF/Data/R21S{i:02d}.lean")
    fails = []
    for k, b in enumerate(ex):
        ok, mg, why = RB.mgf_box(b, P['theta44'][i], RM.dhat_box(b), P['rates44'][i], st)
        if not ok:
            fails.append([k, str(why), float(mg) if mg is not None else None])
    res[f'stage1_R{i}_hand'] = dict(boxes=len(ex), fails=fails)
    print(i, 'hand', len(ex), fails, flush=True)
# positive controls: all existing Lean lists 38..54 at the Lean caps
for i in range(38, 55):
    ex = L.boxes_mgf(f"{L.LEAN}/MGF/Data/R21S{i:02d}.lean")
    fails = []
    mgs = []
    for k, b in enumerate(ex):
        ok, mg, why = RB.mgf_box(b, P['theta44'][i], D21(i), P['rates44'][i], st)
        mgs.append(float(mg) if mg is not None else -1)
        if not ok:
            fails.append([k, str(why)])
    cov = RB.cover_ok(ex, RM.qof(P['pieceLo'][i]), RM.qof(P['pieceHi'][i]), m21[i], P['mmin44'][i])[0]
    res[f'pos_R{i}_lean_caps'] = dict(boxes=len(ex), fails=fails, cover=cov, min_margin=min(mgs))
    print(i, 'lean caps', D21(i), len(ex), fails, cov, min(mgs), flush=True)
# negative controls
AUTH = RM.AUTH
bs = [RM.author_box(p) for p in sorted(glob.glob(f"{AUTH}/full/strip_38/box_*.json"))]
nf = sum(1 for b in bs if not RB.mgf_box(b, P['theta44'][38], F(7, 5) + F(1, 20), P['rates44'][38], st)[0])
res['neg_R38_D+1/20'] = nf
print('neg D+1/20 on new R38: fails', nf, 'of', len(bs), flush=True)
b0 = dict(bs[0]); b0['alpha'] = b0['alpha'] - F(1, 1000)
r0 = RB.mgf_box(b0, P['theta44'][38], F(7, 5), P['rates44'][38], st)
res['neg_R38_box0_alpha-1e-3'] = str(r0[2])
print('neg alpha-1e-3:', r0[0], r0[2], flush=True)
b1 = dict(bs[0]); b1['xi'] = b1['xi'] + F(1, 100)
r1 = RB.mgf_box(b1, P['theta44'][38], F(7, 5), P['rates44'][38], st)
res['neg_R38_box0_xi+1e-2'] = [r1[0], str(r1[2])]
print('neg xi+1e-2:', r1[0], r1[2], flush=True)
cov = RB.cover_ok(bs[1:], RM.qof(P['pieceLo'][38]), RM.qof(P['pieceHi'][38]), m21[38], sf[22])
res['neg_R38_drop_box0_cover'] = cov[0]
print('neg drop box 0 cover:', cov, flush=True)
json.dump(res, open(sys.argv[1], 'w'), indent=1, default=str)
print('DONE')
