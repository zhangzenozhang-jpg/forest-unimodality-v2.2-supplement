"""Which order-44/45/48 lower-tail coverings on [13/10,7/3] are still used after route change (i), and is each one's
cap at least the hand cap (sup over the activities where it is used)?"""
from fractions import Fraction as F
import leandata as L
import os
def dhat(lam):
    if lam <= F(263, 200): return F(6, 5)
    if lam <= F(3, 2): return F(7, 5)
    if lam <= F(7, 4): return F(8, 5)
    if lam <= F(2): return F(9, 5)
    return F(21, 10)
def hsup(lo, hi):   # sup over [lo,hi] of the left-closed step function = value at hi
    return dhat(hi)
P44 = L.n44()
d45 = L.defs(f"{L.LEAN}/N45/Data/Params.lean"); P45 = {k: L.nest(L.tokens(d45[k]))[0] for k in ('pieceLo','pieceHi','pieceParent','D45','mmin45','theta45')}
d48 = L.defs(f"{L.LEAN}/N48/Data/Params.lean"); P48 = {k: L.nest(L.tokens(d48[k]))[0] for k in ('pieceLo','pieceHi','pieceParent','mmin48')}
B = L.bands()
changed = {38, 39, 43, 44, 47, 48, 49, 50, 51, 52, 53, 54}
print('order 44 (subintervals 38..54):')
for i in range(38, 55):
    lo, hi = P44['pieceLo'][i], P44['pieceHi'][i]
    f = f"{L.LEAN}/N44/Data/P{i:02d}.lean"
    up = P44['pieceUp'][i]
    exists = os.path.exists(f)
    print(f"  {i} [{lo},{hi}] D44={P44['D44'][i]} hand={hsup(lo,hi)} m44={P44['mmin44'][i]} m45(up {up})={P45['mmin45'][up]} file={exists} changed={i in changed}",
          'OK' if (i in changed or not exists or P44['D44'][i] >= hsup(lo, hi)) else 'CAP BELOW HAND')
print('order 45 pieces meeting [13/10,7/3]:')
for p in range(46):
    lo, hi = P45['pieceLo'][p], P45['pieceHi'][p]
    if hi <= F(13, 10): continue
    subs = [i for i in range(55) if P44['pieceLo'][i] >= lo and P44['pieceHi'][i] <= hi]
    used = [i for i in subs if i not in changed]
    exists = os.path.exists(f"{L.LEAN}/N45/Data/P{p:02d}.lean")
    need = max([hsup(P44['pieceLo'][i], P44['pieceHi'][i]) for i in used], default=None)
    print(f"  {p} [{lo},{hi}] D45={P45['D45'][p]} subs={subs} still used for={used} file={exists} need={need}",
          'OK' if (not used or not exists or P45['D45'][p] >= need) else 'CAP BELOW HAND')
print('order 48 pieces meeting [13/10,7/3]:')
for p in range(33):
    lo, hi = P48['pieceLo'][p], P48['pieceHi'][p]
    if hi <= F(13, 10): continue
    subs = [i for i in range(55) if P44['pieceLo'][i] >= lo and P44['pieceHi'][i] <= hi]
    used = [i for i in subs if i not in changed]
    D = B[P48['pieceParent'][p]]['D']
    exists = os.path.exists(f"{L.LEAN}/N48/Data/P{p:02d}.lean")
    need = max([hsup(P44['pieceLo'][i], P44['pieceHi'][i]) for i in used], default=None)
    print(f"  {p} [{lo},{hi}] D(parent band {P48['pieceParent'][p]})={D} subs={subs} still used for={used} file={exists} need={need}",
          'OK' if (not used or not exists or D >= need) else 'CAP BELOW HAND')
print('bands 22..29: coarse D vs hand sup; strip floor m52, m61:')
sf = L.strip_floor52()
for i in range(22, 30):
    b = B[i]
    print(f"  band {i} [{b['lo']},{b['hi']}] D={b['D']} theta={b['theta']} hand sup={hsup(b['lo'], b['hi'])} m52={sf[i]} ({float(sf[i]):.4f}) m61={b['mmin']} ({float(b['mmin']):.4f})",
          'recheck' if hsup(b['lo'], b['hi']) > b['D'] else 'same/stronger')
