"""Band 27 split at lambda = 2: the final S28/L28/U28 coverings (Lean entries passing at the hand caps + new boxes) give
two sub-band coverings, [19/10,2] at 9/5 (every box passes at its own cap >= 9/5, hence at 9/5) and [2,41/20] at 21/10
(only boxes with q_h > q(2), whose cap is 21/10). Cover check only (box tests done in run_t1.py)."""
import json, glob, sys
from fractions import Fraction as F
import leandata as L, refbox as RB, run_t1 as RT
B = L.bands(); sf = L.strip_floor52(); b = B[27]; st = dict(evals=0, atoms=0, skip=0, fibers_lev=0)
q2 = F(2, 3); res = {}
for kind in ('S', 'L', 'U'):
    if kind == 'S':
        lean = L.boxes_atlas(f"{L.LEAN}/N52/Data/S28.lean"); new = [RT.author_box(p) for p in sorted(glob.glob(f"{RT.AUTH}/t1_hand/N52_S28/box_*.json"))]
        base = lambda x: x['qh'] / (1 - x['qh']); mlo, mhi = sf[27], b['mmin']
    elif kind == 'L':
        lean = L.boxes_atlas(f"{L.LEAN}/Atlas/Data/L28.lean"); new = [RT.author_box(p) for p in sorted(glob.glob(f"{RT.AUTH}/t1_hand_const/Atlas_L28/box_*.json"))]
        base = lambda x: b['hi']; mlo, mhi = b['mmin'], F(50)
    else:
        lean = L.boxes_atlas(f"{L.LEAN}/Atlas/Data/U28.lean"); new = [RT.author_box(p) for p in sorted(glob.glob(f"{RT.AUTH}/t1_hand_const/Atlas_U28/box_*.json"))]
        base = lambda x: b['hi']; mlo, mhi = F(50), F(400)
    keep = [x for x in lean if RB.t1_box(x, b['theta'], RT.dhat(x['qh'] / (1 - x['qh'])), b['ell'], base(x), st)[0]]
    allb = keep + new
    lo_ok = RB.cover_ok(allb, b['lo'] / (1 + b['lo']), q2, mlo, mhi)
    up = [x for x in allb if x['qh'] > q2]
    up_ok = RB.cover_ok(up, q2, b['hi'] / (1 + b['hi']), mlo, mhi)
    res[kind] = dict(lower_19_10_to_2=lo_ok[0], upper_2_to_41_20=up_ok[0], n_upper=len(up), why=[str(lo_ok[1]), str(up_ok[1])])
    print(kind, res[kind], flush=True)
json.dump(res, open(sys.argv[1], 'w'), indent=1)
