"""Controls for the referee's lower-tail checker: positive (Lean entries at their Lean band caps), negative (perturbed)."""
import json, glob, sys
from fractions import Fraction as F
import leandata as L
import refbox as RB
B = L.bands(); sf = L.strip_floor52()
AUTH = ("/Users/kvallier/Desktop/Erdos 993/ProofRuns/2026-09-28_analytic_large_n/LEAN/certfree/upper_d_test/"
        "outputs/stage2")
sys.argv += []
import run_t1 as RT  # guarded below
st = dict(evals=0, atoms=0, skip=0, fibers_lev=0)
res = {}
# positive: Lean entries at the Lean band caps
for kind, i in (('S', 24), ('S', 29), ('L', 29), ('U', 24), ('U', 27)):
    b = B[i]
    if kind == 'S':
        lean = L.boxes_atlas(f"{L.LEAN}/N52/Data/S{i+1:02d}.lean"); base = lambda x: x['qh'] / (1 - x['qh']); mlo, mhi = sf[i], b['mmin']
    elif kind == 'L':
        lean = L.boxes_atlas(f"{L.LEAN}/Atlas/Data/L{i+1:02d}.lean"); base = lambda x: b['hi']; mlo, mhi = b['mmin'], F(50)
    else:
        lean = L.boxes_atlas(f"{L.LEAN}/Atlas/Data/U{i+1:02d}.lean"); base = lambda x: b['hi']; mlo, mhi = F(50), F(400)
    fails = [k for k, x in enumerate(lean) if not RB.t1_box(x, b['theta'], b['D'], b['ell'], base(x), st)[0]]
    cov = RB.cover_ok(lean, b['lo'] / (1 + b['lo']), b['hi'] / (1 + b['hi']), mlo, mhi)[0]
    res[f'pos_{kind}{i+1}_lean_caps'] = dict(entries=len(lean), fails=fails, cover=cov, D=str(b['D']))
    print('pos', kind, i + 1, len(lean), fails, cov, flush=True)
# negative: new S30 boxes with alpha - 1e-3; drop one; larger D
new = [RT.author_box(p) for p in sorted(glob.glob(f"{AUTH}/t1_hand/N52_S30/box_*.json"))]
b = B[29]
x = dict(new[0]); x['alpha'] -= F(1, 1000)
r = RB.t1_box(x, b['theta'], F(21, 10), b['ell'], x['qh'] / (1 - x['qh']), st)
res['neg_S30_new0_alpha-1e-3'] = [r[0], str(r[2])]; print('neg alpha', r[0], r[2], flush=True)
x = dict(new[0]); x['xi'] += F(1, 50)
r = RB.t1_box(x, b['theta'], F(21, 10), b['ell'], x['qh'] / (1 - x['qh']), st)
res['neg_S30_new0_xi+2e-2'] = [r[0], str(r[2])]; print('neg xi', r[0], r[2], flush=True)
nf = sum(1 for x in new if not RB.t1_box(x, b['theta'], F(21, 10) + F(1, 5), b['ell'], x['qh'] / (1 - x['qh']), st)[0])
res['neg_S30_D+1/5_fails'] = nf; print('neg D+1/5 fails', nf, 'of', len(new), flush=True)
nf = sum(1 for x in new if not RB.t1_box(x, b['theta'], F(21, 10), b['ell'], F(3), st)[0])
res['neg_S30_tailbase3_fails'] = nf; print('neg tail base 3 fails', nf, 'of', len(new), flush=True)
cov = RB.cover_ok(new[1:], b['lo'] / (1 + b['lo']), b['hi'] / (1 + b['hi']), sf[29], b['mmin'])
res['neg_S30_drop_box0_cover'] = cov[0]; print('neg drop cover', cov, flush=True)
json.dump(res, open(sys.argv[1], 'w'), indent=1, default=str)
print('DONE')
