"""Referee's exact recheck of the ten refuting mixtures (upper_d_test, Proposition ud:prop:fail).
From each witness file only (covering name, lambda, mu, atoms (M, j, w)) is read; theta, the five rates of the covering's
piece and the cap are re-derived here from the Lean data (my parser) and the hand-cap table; all conditions exact
(Fractions), the exponentials of T certified in arb balls (200 bits)."""
import json, glob, sys
from fractions import Fraction as F
from math import comb, ceil
from flint import arb, fmpq, ctx
import leandata as L

ctx.prec = 200
W = ("/Users/kvallier/Desktop/Erdos 993/ProofRuns/2026-09-28_analytic_large_n/LEAN/certfree/upper_d_test/"
     "outputs/stage2/witness")
TILTS = [F(0), F(1, 20), F(1, 10), F(1, 5), F(3, 10)]


def A(x):
    return arb(fmpq(x.numerator, x.denominator))


def dhat(lam):
    if lam <= F(263, 200): return F(6, 5)
    if lam <= F(3, 2): return F(7, 5)
    if lam <= F(7, 4): return F(8, 5)
    if lam <= F(2): return F(9, 5)
    return F(21, 10)


P44 = L.n44()
d45 = L.defs(f"{L.LEAN}/N45/Data/Params.lean")
P45 = {k: L.nest(L.tokens(d45[k]))[0] for k in ('pieceLo', 'pieceHi', 'pieceParent', 'rates45', 'theta45', 'D45')}
d48 = L.defs(f"{L.LEAN}/N48/Data/Params.lean")
P48 = {k: L.nest(L.tokens(d48[k]))[0] for k in ('pieceLo', 'pieceHi', 'pieceParent', 'rates48')}
B = L.bands()


def params(cov):
    order, p = cov.split('/')
    p = int(p[1:])
    if order == 'N44':
        return dict(lo=P44['pieceLo'][p], hi=P44['pieceHi'][p], theta=P44['theta44'][p], rates=P44['rates44'][p],
                    Dcert=P44['D44'][p])
    if order == 'N45':
        return dict(lo=P45['pieceLo'][p], hi=P45['pieceHi'][p], theta=P45['theta45'][p], rates=P45['rates45'][p],
                    Dcert=P45['D45'][p])
    if order == 'N48':
        b = B[P48['pieceParent'][p]]
        return dict(lo=P48['pieceLo'][p], hi=P48['pieceHi'][p], theta=b['theta'], rates=P48['rates48'][p],
                    Dcert=b['D'])
    raise ValueError(cov)


def bpmf(M, j, q):
    if j < 0 or j > M:
        return F(0)
    return comb(M, j) * q ** j * (1 - q) ** (M - j)


out = []
for path in sorted(glob.glob(f"{W}/witness_*.json")):
    w = json.load(open(path))
    cov = w['covering']
    pr = params(cov)
    lam = F(w['lam'])
    q = lam / (1 + lam)
    mu = F(w['mu'])
    atoms = [(int(a['M']), int(a['j']), F(a['w'])) for a in w['atoms']]
    # the cap of every box of this covering containing q(lam): sup of the hand cap over [lam, lam_h] for a box with
    # lam_h > lam unless lam is the piece's top
    Dbox = dhat(lam) if lam == pr['hi'] else dhat(lam + F(1, 10 ** 12))
    r = dict(file=path.split('/')[-1], cov=cov, lam=str(lam), piece=[str(pr['lo']), str(pr['hi'])],
             in_piece=pr['lo'] <= lam <= pr['hi'], mu=str(mu), theta=str(pr['theta']), D=str(Dbox),
             D_file=w['D'], theta_file=w['theta'], rates_match=[str(x) for x in pr['rates']] == w['rates'],
             states=len(atoms))
    ws = [x[2] for x in atoms]
    r['nonneg'] = all(x >= 0 for x in ws)
    r['mass_one'] = sum(ws) == 1
    EM = sum(wt * M for M, j, wt in atoms)
    r['mean_mu'] = EM == mu
    Ed = sum(wt * (j - q * M) for M, j, wt in atoms)
    r['mean_delta_zero'] = Ed == 0
    Ed2 = sum(wt * (j - q * M) ** 2 for M, j, wt in atoms)
    budget = pr['theta'] * q * (1 - q) * mu
    r['delta2_lt_budget'] = Ed2 < budget
    r['Ed2_ratio'] = float(Ed2 / (q * (1 - q) * mu))
    VarM = sum(wt * (M - mu) ** 2 for M, j, wt in atoms)
    r['var_le_Dmu'] = VarM <= Dbox * mu
    r['var_ratio'] = float(VarM / mu)
    # kernel kappa = fL/q + fR/(1-q)
    Ek = F(0); EfL = F(0); EfR = F(0)
    for M, j, wt in atoms:
        fL = (1 - q) * bpmf(M, j, q) - q * bpmf(M, j - 1, q)
        fR = q * bpmf(M, j, q) - (1 - q) * bpmf(M, j + 1, q)
        EfL += wt * fL; EfR += wt * fR
        Ek += wt * (fL / q + fR / (1 - q))
    r['E_kappa_le_0'] = Ek <= 0
    r['E_kappa'] = float(Ek)
    r['E_fL'] = float(EfL); r['E_fR'] = float(EfR)
    r['valley'] = EfL <= 0 and EfR <= 0
    # cdf bounds P(M <= M') <= T(M') for M' < M1 = ceil(mu)+1, T with the covering's five rates, tail base lam
    M1 = int(ceil(mu)) + 1
    okc = True; worst = None
    for Mp in range(M1):
        Pc = sum(wt for M, j, wt in atoms if M <= Mp)
        if Pc == 0:
            continue
        terms = [(-A(l * mu)).exp() * A(((1 + lam) / (1 + lam * t)) ** Mp) for l, t in zip(pr['rates'], TILTS)]
        ok_here = Pc <= 1 and all(A(Pc) <= tt for tt in terms)
        rel = min(float((tt - A(Pc)).mid() / tt.mid()) for tt in terms)
        if worst is None or rel < worst[1]:
            worst = (Mp, rel)
        okc = okc and ok_here
    r['cdf_le_T'] = okc
    r['cdf_worst_rel_slack'] = worst
    r['M1'] = M1
    lowmass = sum(wt for M, j, wt in atoms if M <= 6)
    r['mass_M_le_6'] = float(lowmass)
    E1q = sum(wt * (1 - q) ** M for M, j, wt in atoms)
    r['E(1-q)^M_over_exp(-l0 mu)'] = float((A(E1q) / (-A(pr['rates'][0] * mu)).exp()).mid())
    r['ALL'] = all([r['in_piece'], r['nonneg'], r['mass_one'], r['mean_mu'], r['mean_delta_zero'],
                    r['delta2_lt_budget'], r['var_le_Dmu'], r['E_kappa_le_0'], r['cdf_le_T']])
    print(json.dumps(r), flush=True)
    out.append(r)
json.dump(out, open(sys.argv[1], 'w'), indent=1)
print('ALL TEN:', len(out), all(x['ALL'] for x in out))
