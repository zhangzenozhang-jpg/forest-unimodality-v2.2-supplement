"""Referee recheck of every MGF certificate the changed route uses on the subintervals 38..54 at the hand caps.
theta, rates (tilts 0,1/20,1/10,1/5,3/10), edges, floors from the Lean data (my parser); D = hand cap sup over each box.
Author's new boxes: only (q, m, m0, dual, cutoff) are read from their JSON; their theta/D/rates fields are ignored."""
import json, glob, sys, time
from fractions import Fraction as F
import leandata as L
import refbox as RB

OUT = sys.argv[1] if len(sys.argv) > 1 and sys.argv[0].endswith('run_mgf.py') else 'out_mgf.json'
AUTH = ("/Users/kvallier/Desktop/Erdos 993/ProofRuns/2026-09-28_analytic_large_n/LEAN/certfree/upper_d_test/"
        "outputs/stage2/mgf_hand")


def qof(l):
    return l / (1 + l)


def dhat(lam):
    if lam <= F(263, 200): return F(6, 5)
    if lam <= F(3, 2): return F(7, 5)
    if lam <= F(7, 4): return F(8, 5)
    if lam <= F(2): return F(9, 5)
    if lam <= F(7, 3): return F(21, 10)
    raise ValueError(lam)


def dhat_box(b):
    return dhat(b['qh'] / (1 - b['qh']))


P = L.n44()
m21 = L.mmin21()
sf = L.strip_floor52()


def m21_paper(i):
    k = 7 if i <= 50 else 8
    return F(k) / (2 * qof(P['pieceHi'][i]))


def author_box(path):
    d = json.load(open(path))
    du = d['dual']
    fr = lambda s: F(s)
    return dict(name=path.split('/')[-2] + '/' + path.split('/')[-1], ql=fr(d['q'][0]), qh=fr(d['q'][1]),
                ml=fr(d['m'][0]), mh=fr(d['m'][1]), m0=fr(d['m0']), eta=fr(du['nu']), xi=fr(du['c']),
                alpha=fr(du['alpha']), beta=fr(du['beta']), gamma=fr(du['gamma']), wL=fr(du['a']), wR=fr(du['b']),
                z=[fr(x) for x in du['z']], N=int(d['cutoff']))


def check_list(i, boxes, mlo, mhi, label):
    th = P['theta44'][i]
    rates = P['rates44'][i]
    res = dict(label=label, piece=i, n=len(boxes), mlo=str(mlo), mhi=str(mhi), fails=[], margins=[])
    t0 = time.time()
    stats = dict(evals=0, atoms=0, skip=0, fibers_lev=0)
    for b in boxes:
        D = dhat_box(b)
        ok, mg, why = RB.mgf_box(b, th, D, rates, stats)
        res['margins'].append(float(mg) if mg is not None else None)
        if not ok:
            res['fails'].append([b['name'], str(why), float(mg) if mg is not None else None, str(D)])
    Qlo, Qhi = qof(P['pieceLo'][i]), qof(P['pieceHi'][i])
    cok, cwhy = RB.cover_ok(boxes, Qlo, Qhi, mlo, mhi)
    res['cover'] = cok
    res['cover_why'] = str(cwhy)
    res['min_margin'] = min(m for m in res['margins'] if m is not None) if any(
        m is not None for m in res['margins']) else None
    res['D_used'] = sorted(set(str(dhat_box(b)) for b in boxes))
    res['stats'] = stats
    res['sec'] = round(time.time() - t0, 1)
    res['PASS'] = cok and not res['fails']
    print(json.dumps({k: v for k, v in res.items() if k != 'margins'}), flush=True)
    return res


if __name__ == '__main__':
    out = {'m21_check': [], 'lists': []}
    for i in range(38, 55):
        out['m21_check'].append([i, str(m21[i]), str(m21_paper(i)), m21[i] == m21_paper(i)])
    print('m21 agree:', all(x[3] for x in out['m21_check']), flush=True)

    # 1. new full lists 38, 43, 48, 53 over [m21, m52(band)]
    for i in (38, 43, 48, 53):
        bs = [author_box(p) for p in sorted(glob.glob(f"{AUTH}/full/strip_{i}/box_*.json"))]
        band = P['pieceParent'][i]
        out['lists'].append(check_list(i, bs, m21[i], sf[band], f'new full list R_{i} to m52'))
    # 2. existing Lean lists + 3. extension boxes
    for i in (39, 44, 47, 49, 50, 51, 52, 54):
        ex = L.boxes_mgf(f"{L.LEAN}/MGF/Data/R21S{i:02d}.lean")
        out['lists'].append(check_list(i, ex, m21[i], P['mmin44'][i], f'existing Lean R21S{i} to m44'))
        ext = [author_box(p) for p in sorted(glob.glob(f"{AUTH}/ext/strip_{i}/box_*.json"))]
        band = P['pieceParent'][i]
        out['lists'].append(check_list(i, ext, P['mmin44'][i], sf[band], f'extension {i}: m44 to m52'))
        out['lists'].append(dict(label=f'union cover {i} [m21,m52]', piece=i,
                                 cover=RB.cover_ok(ex + ext, qof(P['pieceLo'][i]), qof(P['pieceHi'][i]), m21[i],
                                                   sf[band])[0]))
    # 4. controls: existing failing lists at the hand cap must FAIL; at certified D21 they must PASS
    json.dump(out, open(OUT, 'w'), indent=1, default=str)
    print('DONE', flush=True)
