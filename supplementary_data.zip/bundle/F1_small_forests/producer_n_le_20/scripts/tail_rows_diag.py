#!/usr/bin/env python3
"""DIAGNOSTIC (float LP): do the paper's prefix and tail inequalities (Proposition prefix/tail (a),(b)), added as linear
rows on the inventory, simplify the certificates of the eight remaining triples?  Report LP value with families:
S only, S+tail, S+prefix+tail, and all basic rows."""
import math
import numpy as np
from scipy.optimize import linprog
import lp_core as L
C = lambda n, k: math.comb(n, k) if n >= 0 and 0 <= k <= n else 0
def bcoef(n, a):
    c = n-a; d = a-c
    return [sum(C(c, j)*2**j*C(d, s-j) for j in range(0, c+1)) for s in range(0, n+2)]
def extra_rows(n, a, k, kinds):
    S = L.states(n, a); out = []
    b = bcoef(n, a)
    icoef = lambda r: {s: C(s[1], r-s[0]) for s in S}
    if 'tail' in kinds:
        for s_ in (k, k+1, k+2):        # i_{s-1} b_s - i_s b_{s-1} >= 0
            v1, v0 = icoef(s_-1), icoef(s_)
            out.append(('tail_%d' % s_, 0, {s: b[s_]*v1[s]-b[s_-1]*v0[s] for s in S}))
    if 'prefix' in kinds:
        for kk in (k-2, k-1, k, k+1):   # (k+1) i_{k+1} - (n-3k) i_k >= 0
            if kk < 0: continue
            v1, v0 = icoef(kk+1), icoef(kk)
            out.append(('prefix_%d' % kk, 0, {s: (kk+1)*v1[s]-(n-3*kk)*v0[s] for s in S}))
    return out
def lpval(n, a, k, fams, kinds):
    S = L.states(n, a); idx = {s: i for i, s in enumerate(S)}; nv = len(S)+1
    rows = [r for r in L.row_data(n, a) if L.fam(r[0]) in fams] + extra_rows(n, a, k, kinds)
    A, bb = [], []
    for nm, u, v in rows:
        r = np.zeros(nv)
        for s, x in v.items(): r[idx[s]] = -float(x)
        sc = max(abs(r).max(), 1.0); A.append(r/sc); bb.append(float(u)/sc)
    dL = np.zeros(nv); dR = np.zeros(nv)
    for (y, m), i in idx.items():
        dL[i] = C(m, k-y)-C(m, k-1-y); dR[i] = C(m, k-y)-C(m, k+1-y)
    sc = max(abs(dL).max(), abs(dR).max(), 1.0); dL /= sc; dR /= sc; dL[-1] = dR[-1] = -1.0
    A += [dL, dR]; bb += [0.0, 0.0]
    Aeq = np.zeros((2, nv)); Aeq[0, idx[(0, a)]] = 1.0
    for (y, m), i in idx.items():
        if y == 1: Aeq[1, i] = 1.0
    cost = np.zeros(nv); cost[-1] = 1.0
    res = linprog(cost, A_ub=np.array(A), b_ub=np.array(bb), A_eq=Aeq, b_eq=[1.0, float(n-a)],
                  bounds=[(0, None)]*(nv-1)+[(None, None)], method='highs')
    return res.fun if res.status == 0 else None
eight = [(15,9,5),(17,11,6),(18,11,6),(19,10,6),(19,11,6),(19,13,7),(20,10,6),(20,13,7)]
ALL = ('edge_budget','matching_excess','subset_count','missing_edge_union','pair_extension')
for t in eight:
    r = {}
    r['S'] = lpval(*t, ('subset_count',), ())
    r['S+tail'] = lpval(*t, ('subset_count',), ('tail',))
    r['S+tail+prefix'] = lpval(*t, ('subset_count',), ('tail','prefix'))
    r['ES+tail'] = lpval(*t, ('subset_count','edge_budget'), ('tail',))
    r['all'] = lpval(*t, ALL, ())
    print(t, {k: (round(v, 4) if v is not None else None) for k, v in r.items()}, '(tau>0 = certified)')
