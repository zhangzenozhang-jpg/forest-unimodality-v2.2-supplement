#!/usr/bin/env python3
"""Lemma P's tangent certificate in the return's schema: the anchored line of Z is replaced, level by level, by the
supporting line of the lower convex hull of phi_h at the average excess allowed at e=0:
   t_1 = (a-1)/c ,  t_h = X_h(0)/C(c,h) = [(a-1)C(c-2,h-1) + d C(c-2,h-2)]/C(c,h)   (h>=2).
If t_h lies beyond the hull minimum, the line is the horizontal line at the minimum (q=0).
Prices then follow the same schema map as z_param_cert.z_prices with (p_h, q_h) := (intercept, -slope).
Verified exactly by the return's CHECKER (no rounding, no repair)."""
import sys, math, json
from fractions import Fraction as Q
import lp_core as L
from z_param_cert import f, C
def hull(pts):
    H = []
    for p in pts:
        while len(H) >= 2 and (H[-1][1]-H[-2][1])*(p[0]-H[-2][0]) >= (p[1]-H[-2][1])*(H[-1][0]-H[-2][0]):
            H.pop()
        H.append(p)
    return H
def tangent(H, t):
    """supporting line p - q x of the hull, valid for the running-min envelope at mean t: returns (p, q) with q>=0,
    and p - q x <= phi(x) for all hull x."""
    # minimum vertex
    imin = min(range(len(H)), key=lambda i: H[i][1])
    if t >= H[imin][0]:
        return H[imin][1], Q(0)
    for (x1, y1), (x2, y2) in zip(H, H[1:]):
        if x1 <= t <= x2:
            s = (y2-y1)/(x2-x1)       # negative on the decreasing part
            return y1 - s*x1, -s
    return H[0][1], Q(0)
def t_prices(al, n, a, k):
    c = n-a; d = a-c
    p, q = {}, {}
    for h in range(1, c+1):
        H = hull([(Q(x), Q(f(al, k, h, a-h-x))) for x in range(0, a-h+1)])
        t = Q(a-1, c) if h == 1 else Q((a-1)*C(c-2, h-1) + d*C(c-2, h-2), C(c, h))
        p[h], q[h] = tangent(H, t)
    T = sum(q[h]*C(c-2, h-1) for h in range(2, c+1))
    A = q[1] + T
    P2 = (p[2] if c >= 2 else 0) + sum(max(Q(0), p[h])*C(c-2, h-2) for h in range(3, c+1))
    rows = {}
    if A > 0: rows['edge_budget'] = A
    for h in range(2, c+1):
        if q[h] > 0: rows['matching_excess_%d' % h] = q[h]
    for h in range(3, c+1):
        if p[h] < 0: rows['subset_count_%d' % h] = -p[h]
        if p[h] > 0: rows['missing_edge_union_%d' % h] = p[h]
    if c >= 2 and A - P2 > 0: rows['subset_count_2'] = A - P2
    return rows
if __name__ == '__main__':
    import z_param_cert as Z
    NMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 26
    ALS = [Q(1, 2), Q(1, 3), Q(5, 12), Q(7, 12), Q(1, 4), Q(2, 3), Q(0), Q(1)] + [Q(i, 50) for i in range(51)]
    sr = lambda n, a, k: C(a, k)-C(a, k-1)-sum(C(n-a, h)*(C(2*(k-1-h), k-1-h)//(k-h)) for h in range(1, min(n-a, k-1)+1))
    tally = {'SR': 0, 'Z': 0, 'T': 0, 'none': []}
    certs = []
    for (n, a, k) in L.domain(NMAX):
        if sr(n, a, k) > 0: tally['SR'] += 1; continue
        done = None
        for kind, pf in (('Z', Z.z_prices), ('T', t_prices)):
            for al in ALS:
                try:
                    cert = L.exact_from(n, a, k, al, pf(al, n, a, k), den=None, repair=False)
                except AssertionError:
                    cert = None
                if cert is not None:
                    done = (kind, cert); break
            if done: break
        if done:
            tally[done[0]] += 1; done[1]['kind'] = done[0]; certs.append(done[1])
        else:
            tally['none'].append((n, a, k))
    json.dump(certs, open('../outputs/param_certs_n%d.json' % NMAX, 'w'), indent=0)
    print('n<=%d parametric certificates verified by the return CHECKER:' % NMAX, tally)
