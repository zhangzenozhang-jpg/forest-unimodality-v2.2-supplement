#!/usr/bin/env python3
"""Coverage of the two-tier scheme: Tier 1 = Lemma S_R (alpha=1, Catalan form) on 2k<=a-1;
Tier 2 = Lemma P at alpha=1/2 on 2k>=a.  Also Lemma P at alpha=1/2 on every triple.  Exact."""
import json, sys
from fractions import Fraction as Q
import level_lemma as P
from subset_lemma import PHI_R_cat
def window(n):
    for a in range((n+1)//2, n):
        for k in range((n+3)//4+1, min(a, (n+2*a+5)//6)):
            yield a, k
nmax = int(sys.argv[1])
res = []
for n in range(1, nmax+1):
    for a, k in window(n):
        r = {'n': n, 'a': a, 'k': k, 'tier1_region': 2*k <= a-1, 'SR': PHI_R_cat(n, a, k) > 0}
        v = P.phi_P(Q(1, 2), n, a, k)
        r['P_half'] = str(v); r['P_half_ok'] = v > 0
        res.append(r)
json.dump(res, open('../outputs/coverage_half_%d.json' % nmax, 'w'))
for lim in (20, 26, nmax):
    sub = [r for r in res if r['n'] <= lim]
    t1 = [r for r in sub if r['tier1_region']]
    t2 = [r for r in sub if not r['tier1_region']]
    print('n<=%d: triples %d | tier1 region %d, S_R holds on %d | tier2 region %d, P(1/2) holds on %d | P(1/2) on all: %d | scheme covers %d' % (
        lim, len(sub), len(t1), sum(r['SR'] for r in t1), len(t2), sum(r['P_half_ok'] for r in t2),
        sum(r['P_half_ok'] for r in sub), sum((r['SR'] if r['tier1_region'] else r['P_half_ok']) for r in sub)))
    print('   uncovered:', [(r['n'], r['a'], r['k']) for r in sub if not (r['SR'] if r['tier1_region'] else r['P_half_ok'])][:30])
