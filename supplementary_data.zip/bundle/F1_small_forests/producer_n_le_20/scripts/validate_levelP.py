#!/usr/bin/env python3
"""Soundness test of the IMPLEMENTATION of Lemma P and Lemma S on real forests (DIAGNOSTIC; the lemmas are proved
on paper).  For all forests with n <= NMAX and EVERY maximum-cardinality marking, and every k in 1..a-1 and alpha in a
small set, check  al(i_k-i_{k-1}) + (1-al)(i_k-i_{k+1}) >= PHI_P(al,n,a,k)  and  >= PHI_S(al)  exactly, and that
the forest's own (e, s) and level data satisfy the lemma's hypotheses."""
import sys, pathlib, itertools
from fractions import Fraction as Q
from collections import Counter
HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent.parent.parent / 'pro_six/return_binomial_fiber_20260929/independent'))
import recheck_fiber as rf
import level_lemma as P
import subset_lemma as S
NMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 11
ALS = [Q(1), Q(0), Q(1, 2), Q(1, 3), Q(3, 5)]
stats = Counter()
cache = {}
worst_gap = None
for n, G in rf.forests_upto(NMAX):
    poly = rf.indep_poly_dp(G)
    alpha = len(poly) - 1
    a = alpha
    if a == n or n == 0:
        continue
    allI = rf.independent_sets(G, sorted(G.nodes))
    for A in allI:
        if len(A) != alpha:
            continue
        A = frozenset(A)
        Cset = sorted(set(G.nodes) - A)
        c = len(Cset)
        # hypotheses: e <= c-1, s = D-c <= a-1-e, level-2 count, matching excess (from the return, rechecked here)
        e = sum(1 for u, v in G.edges if u in Cset and v in Cset)
        D = sum(1 for u, v in G.edges if (u in A) != (v in A))
        assert e <= c-1 and D - c <= a-1-e and D >= c
        stats['markings'] += 1
        for k in range(1, a):
            for al in ALS:
                key = (n, a, k, al)
                if key not in cache:
                    cache[key] = (P.phi_P(al, n, a, k), S.PHI(al, n, a, k))
                pP, pS = cache[key]
                lhs = al*(poly[k] - poly[k-1]) + (1-al)*(poly[k] - (poly[k+1] if k+1 < len(poly) else 0))
                stats['checks'] += 1
                if lhs < pP:
                    stats['P_VIOLATION'] += 1
                    print('P VIOLATION', n, a, k, al, lhs, pP, sorted(G.edges), sorted(A))
                if lhs < pS:
                    stats['S_VIOLATION'] += 1
                    print('S VIOLATION', n, a, k, al, lhs, pS)
                gap = lhs - pP
                if worst_gap is None or gap < worst_gap[0]:
                    worst_gap = (gap, n, a, k, str(al))
print(dict(stats), 'tightest P gap', worst_gap)
