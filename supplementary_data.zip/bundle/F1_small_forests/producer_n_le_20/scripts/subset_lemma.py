#!/usr/bin/env python3
"""Lemma S (subset-count lemma), exact integer/rational evaluation.  No LP.

For alpha in [0,1], k, a, c:   f_al(y,m) = C(m,k-y) - al*C(m,k-y-1) - (1-al)*C(m,k-y+1).
PHI(al) = f_al(0,a) + c*min_{0<=m<=a-1} f_al(1,m) + sum_{h=2}^{c} C(c,h)*min(0, min_{0<=m<=a-h} f_al(h,m)).
Lemma S: for every forest with alpha(F)=a, n=a+c:  al*(i_k-i_{k-1}) + (1-al)*(i_k-i_{k+1}) >= PHI(al).
Closed forms: rise (al=1):  PHI_R >= C(a,k)-C(a,k-1) - sum_{h=1}^{min(c,k-1)} C(c,h) Cat(k-1-h)      [CAT form]
              fall (al=0):  PHI_F  = C(a,k)-C(a,k+1) - sum_{h=1}^{c} C(c,h) max(0, C(a-h,k-h+1)-C(a-h,k-h)) [exact]
"""
import math, sys, json
from fractions import Fraction as Q
C = lambda n, k: math.comb(n, k) if n >= 0 and 0 <= k <= n else 0
def cat(j):
    return C(2*j, j)//(j+1) if j >= 0 else 0

def f(al, k, y, m):
    return C(m, k-y) - al*C(m, k-y-1) - (1-al)*C(m, k-y+1)

def PHI(al, n, a, k):
    c = n-a
    val = f(al, k, 0, a)
    if c >= 1:
        val += c*min(f(al, k, 1, m) for m in range(0, a))
    for h in range(2, c+1):
        val += C(c, h)*min(0, min(f(al, k, h, m) for m in range(0, a-h+1)))
    return val

def PHI_R_cat(n, a, k):
    c = n-a
    return C(a, k)-C(a, k-1) - sum(C(c, h)*cat(k-1-h) for h in range(1, min(c, k-1)+1))

def PHI_F_closed(n, a, k):
    c = n-a
    return C(a, k)-C(a, k+1) - sum(C(c, h)*max(0, C(a-h, k-h+1)-C(a-h, k-h)) for h in range(1, c+1))

def best_alpha(n, a, k):
    """PHI is concave piecewise-linear in al; maximize exactly over the breakpoints of its pieces.
    Every piece is linear, so the max over [0,1] is attained at 0, 1, or an intersection of two affine
    functions among {f_al(y,m)} (for the mins) -- we scan a fine rational grid plus endpoints and then
    refine by exact bisection on the concave function (sufficient for a proposal; final value exact)."""
    best = (PHI(Q(1), n, a, k), Q(1))
    for al in [Q(0), Q(1, 2), Q(1, 3), Q(2, 3), Q(1, 4), Q(3, 4)] + [Q(i, 24) for i in range(25)]:
        v = PHI(al, n, a, k)
        if v > best[0]:
            best = (v, al)
    # ternary search on concave function
    lo, hi = Q(0), Q(1)
    for _ in range(40):
        m1, m2 = lo + (hi-lo)/3, hi - (hi-lo)/3
        if PHI(m1, n, a, k) < PHI(m2, n, a, k):
            lo = m1
        else:
            hi = m2
    for al in (lo, hi, (lo+hi)/2):
        al2 = al.limit_denominator(1000)
        v = PHI(al2, n, a, k)
        if v > best[0]:
            best = (v, al2)
    return best

def window(n):
    for a in range((n+1)//2, n):
        for k in range((n+3)//4+1, min(a, (n+2*a+5)//6)):
            yield a, k

if __name__ == '__main__':
    nmax = int(sys.argv[1]) if len(sys.argv) > 1 else 26
    out = []
    for n in range(1, nmax+1):
        for a, k in window(n):
            rec = {'n': n, 'a': a, 'k': k, 'c': n-a, 'd': 2*a-n}
            rec['R_cat'] = PHI_R_cat(n, a, k) > 0
            rec['R'] = PHI(Q(1), n, a, k) > 0
            rec['F'] = PHI(Q(0), n, a, k) > 0
            assert (PHI(Q(0), n, a, k) == PHI_F_closed(n, a, k)), (n, a, k)
            assert PHI(Q(1), n, a, k) >= PHI_R_cat(n, a, k)
            v, al = best_alpha(n, a, k)
            rec['mix'] = v > 0
            rec['mix_alpha'] = str(al)
            rec['mix_value'] = str(v)
            out.append(rec)
    json.dump(out, open(sys.argv[2], 'w')) if len(sys.argv) > 2 else None
    from collections import Counter
    for lim in (20, 26, nmax):
        sub = [r for r in out if r['n'] <= lim]
        print('n<=%d: triples %d | R_cat %d | R %d | F %d | R or F %d | mix(best alpha) %d' % (
            lim, len(sub), sum(r['R_cat'] for r in sub), sum(r['R'] for r in sub), sum(r['F'] for r in sub),
            sum(r['R'] or r['F'] for r in sub), sum(r['mix'] for r in sub)))
