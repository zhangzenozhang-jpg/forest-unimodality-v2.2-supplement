#!/usr/bin/env python3
"""Region analysis for Lemma S_R (Catalan rise) and S_F (fall): exact integers.
PHI_R(a,c,k) = C(a,k)-C(a,k-1) - sum_{h=1}^{min(c,k-1)} C(c,h) Cat(k-1-h)
PHI_F(a,c,k) = C(a,k)-C(a,k+1) - sum_{h=1}^{min(c,k+1)} C(c,h) max(0, C(a-h,k-h+1)-C(a-h,k-h))"""
import math, json, sys
from subset_lemma import PHI_R_cat, PHI_F_closed, PHI, window, best_alpha
from fractions import Fraction as Q
C = lambda n, k: math.comb(n, k) if n >= 0 and 0 <= k <= n else 0
def phiR(a, c, k): return PHI_R_cat(a+c, a, k)
def phiF(a, c, k): return PHI_F_closed(a+c, a, k)
def _main():
    # minimal a for rise, for each (c,k): smallest a >= 2k-1 with phiR>0 (monotone in a for a >= 2k-3)
    print('a_min_R(c,k): smallest a with PHI_R(a,c,k)>0 (monotone in a once a>=2k-3; decreasing in c)')
    for k in range(3, 14):
        row = []
        for c in range(1, 14):
            a = max(2*k-3, 1)
            while phiR(a, c, k) <= 0 and a < 200: a += 1
            row.append(a)
        print('k=%2d' % k, ' '.join('%3d' % x for x in row))
    # check monotonicity claims on a big box
    bad = 0
    for k in range(2, 30):
        for c in range(1, 30):
            for a in range(max(2*k-3, 1), 90):
                if phiR(a+1, c, k) < phiR(a, c, k): bad += 1
                if phiR(a, c+1, k) > phiR(a, c, k): bad += 1
    print('monotonicity violations (a up / c down) in box:', bad)
    # n<=20 tiers
    tiers = {}
    for n in range(1, 21):
        for a, k in window(n):
            c = n-a
            if phiR(a, c, k) > 0: t = 'S_R'
            elif phiF(a, c, k) > 0: t = 'S_F'
            elif best_alpha(n, a, k)[0] > 0: t = 'S_mix'
            else: t = 'P'
            tiers[(n, a, k)] = t
    from collections import Counter
    print(Counter(tiers.values()))
    for key in sorted(tiers):
        if tiers[key] != 'S_R':
            n, a, k = key
            print(key, 'c=%d d=%d' % (n-a, 2*a-n), tiers[key], ' (k-a/2=%s)' % (Q(k)-Q(a, 2)))


if __name__ == "__main__":
    _main()
