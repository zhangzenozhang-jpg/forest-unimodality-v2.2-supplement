#!/usr/bin/env python3
"""Lemma S_R as ONE parametric certificate in the return's schema, checked by the return's own CHECKER:
   left=1, right=0, t[subset_count_h] = Cat_{k-1-h} (2<=h<=min(c,k-1)), z0 = C(a,k)-C(a,k-1), z1 = -Cat_{k-2},
   epsilon = PHI_R(a,c,k).  Run over every window triple n<=NMAX with PHI_R>0."""
import sys, math
import lp_core as L
C = math.comb
cat = lambda j: C(2*j, j)//(j+1)
NMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 26
ok = 0; tried = 0
for (n, a, k) in L.domain(NMAX):
    c = n-a
    phi = C(a, k)-C(a, k-1) - sum(C(c, h)*cat(k-1-h) for h in range(1, min(c, k-1)+1))
    if phi <= 0: continue
    tried += 1
    rows = {'subset_count_%d' % h: str(cat(k-1-h)) for h in range(2, min(c, k-1)+1)}
    cert = {'n': n, 'a': a, 'k': k, 'left': '1', 'right': '0', 'epsilon': str(phi), 'rows': rows,
            'equalities': [str(C(a, k)-C(a, k-1)), str(-cat(k-2) if k >= 2 else 0)]}
    L.CK.certificate_details(cert)   # raises AssertionError on any failure
    ok += 1
print('S_R parametric certificate verified by the return CHECKER at %d of %d triples with PHI_R>0 (n<=%d)' % (ok, tried, NMAX))
