import json, glob, pathlib
from collections import Counter, defaultdict
HERE = pathlib.Path(__file__).resolve().parent
recs = []
for f in sorted(glob.glob(str(HERE.parent/'outputs'/'family_necessity_*.jsonl'))):
    recs += [json.loads(l) for l in open(f)]
recs.sort(key=lambda r:(r['n'],r['a'],r['k']))
print(len(recs))
order = ['none','subset_count','edge_budget+subset_count','edge_budget+matching_excess+subset_count',
 'edge_budget+missing_edge_union+subset_count','edge_budget+pair_extension+subset_count',
 'edge_budget+matching_excess+missing_edge_union+subset_count','edge_budget+matching_excess+pair_extension+subset_count',
 'edge_budget+missing_edge_union+pair_extension+subset_count','matching_excess+missing_edge_union+pair_extension+subset_count',
 'edge_budget+matching_excess+subset_count+missing_edge_union+pair_extension']
short = {'none':'0','subset_count':'S','edge_budget+subset_count':'ES','edge_budget+matching_excess+subset_count':'EMS',
 'edge_budget+missing_edge_union+subset_count':'EUS','edge_budget+pair_extension+subset_count':'EPS',
 'edge_budget+matching_excess+missing_edge_union+subset_count':'EMUS','edge_budget+matching_excess+pair_extension+subset_count':'EMPS',
 'edge_budget+missing_edge_union+pair_extension+subset_count':'EUPS','matching_excess+missing_edge_union+pair_extension+subset_count':'MUPS',
 'edge_budget+matching_excess+subset_count+missing_edge_union+pair_extension':'ALL'}
tot = Counter(); totle20 = Counter()
side = Counter(); sidele20 = Counter()
for r in recs:
    for k,v in r['fams'].items():
        if v['exact']:
            tot[short[k]] += 1
            if r['n']<=20: totle20[short[k]] += 1
    s = ('R' if r['side']['rise']['exact'] else '-') + ('F' if r['side']['fall']['exact'] else '-')
    side[s] += 1
    if r['n']<=20: sidele20[s]+=1
print('exactly certified by family subset (all / n<=20):')
for k in [short[o] for o in order]:
    print('  %-5s %3d  %3d' % (k, tot[k], totle20[k]))
print('one-sided availability (R=rise-only cert exists, F=fall-only cert exists):', dict(side), 'n<=20:', dict(sidele20))
# minimal family label per triple: smallest in a chain order
chain = ['0','S','ES','EMS','EMUS','EMPS','EUS','EPS','EUPS','MUPS','ALL']
mins = Counter(); grid = defaultdict(dict)
for r in recs:
    ok = {short[k] for k,v in r['fams'].items() if v['exact']}
    lab = next((c for c in chain if c in ok), 'NONE')
    # which families are NECESSARY: missing from ALL-minus-one?  (use the 4-family tests)
    nec = []
    if 'EMUS' not in ok and 'EMPS' not in ok and 'EUPS' not in ok and 'MUPS' not in ok:
        pass
    if 'EUPS' not in ok and 'ALL' in ok: nec.append('M')
    if 'MUPS' not in ok and 'ALL' in ok: nec.append('E')
    s = ('R' if r['side']['rise']['exact'] else '-') + ('F' if r['side']['fall']['exact'] else '-')
    grid[(r['n'],r['a'])][r['k']] = lab + ('[' + ''.join(nec) + ']' if nec else '') + ':' + s
    mins[lab] += 1
print('first sufficient family set in chain order:', dict(mins))
for n in range(1,27):
    for a in range((n+1)//2, n):
        if grid[(n,a)]:
            print('n=%2d a=%2d c=%2d d=%2d :'%(n,a,n-a,2*a-n), '  '.join('k%d:%s'%(k,v) for k,v in sorted(grid[(n,a)].items())))
