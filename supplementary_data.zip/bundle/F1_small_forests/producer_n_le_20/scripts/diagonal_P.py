#!/usr/bin/env python3
"""DIAGNOSTIC scan (exact values at each point): Lemma P along tier-2 diagonals (fixed c, delta=2k-a), alpha grid i/24,
plus S_R. Question: does the level relaxation itself fail when a grows with c fixed?"""
import sys
from fractions import Fraction as Q
import verify_floor as V
ALS = [Q(i, 24) for i in range(25)]
cs = [int(x) for x in sys.argv[1].split(',')]
AMAX = int(sys.argv[2])
for c in cs:
    for delta in (0, 1):
        bad = []
        pts = 0
        for a in range(max(c, 2), AMAX+1):
            if (a+delta) % 2: continue
            k = (a+delta)//2; n = a+c
            if not ((n+3)//4 < k < min(a, (n+2*a+5)//6)): continue
            pts += 1
            best = max(V.phi_P(al, n, a, k) for al in ALS)
            if best <= 0: bad.append(a)
        print('c=%d delta=%d: %d window points up to a=%d; Lemma P fails at a=%s' % (c, delta, pts, AMAX, bad or 'none'), flush=True)
