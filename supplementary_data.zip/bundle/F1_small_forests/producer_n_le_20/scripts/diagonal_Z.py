#!/usr/bin/env python3
"""DIAGNOSTIC (exact values, but a scan, not a proof of the all-a statement): tier 2 along diagonals.
For fixed c and delta = 2k - a (tier 2 has delta >= 0), scan a and record whether Lemma Z with some alpha in
{1/3, 5/12, 1/2} is positive at (n,a,k) = (a+c, a, (a+delta)/2), restricted to window triples.
Question: is the good set an up-set in a (which would reduce tier 2 to one corner per (c, delta))?"""
import sys
from fractions import Fraction as Q
import verify_floor as V
ALS = [Q(1, 3), Q(5, 12), Q(1, 2)]
AMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 40
for c in range(1, 11):
    for delta in range(0, 4):
        row = []
        for a in range(max(c, 2), AMAX+1):
            if (a+delta) % 2: continue
            k = (a+delta)//2
            n = a+c
            if not ((n+3)//4 < k < min(a, (n+2*a+5)//6)): continue
            ok = any(V.phi_Z(al, n, a, k) > 0 for al in ALS)
            row.append((a, ok))
        if row:
            bad = [a for a, ok in row if not ok]
            upset = all(ok for a, ok in row if bad and a > max(bad)) if bad else True
            print('c=%2d delta=%d: window a in [%d,%d] (%d pts); Z fails at a=%s' % (
                c, delta, row[0][0], row[-1][0], len(row), bad if bad else 'none'), flush=True)
