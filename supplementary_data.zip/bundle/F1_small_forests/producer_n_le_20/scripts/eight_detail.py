#!/usr/bin/env python3
"""DIAGNOSTIC detail of Lemma Z on the eight triples left after the Catalan-Markov bound: for the working alpha, the
per-level anchor p_h, chord slope q_h, the x attaining q_h, x0 = h+1-delta, and the level functions."""
from fractions import Fraction as Q
import verify_floor as V
eight = [(15,9,5),(17,11,6),(18,11,6),(19,10,6),(19,11,6),(19,13,7),(20,10,6),(20,13,7)]
ALS = [Q(1,3), Q(5,12), Q(1,2), Q(1,4), Q(7,12), Q(2,3)]
for (n,a,k) in eight:
    c = n-a; delta = 2*k-a
    ok = [(al, V.phi_Z(al,n,a,k)) for al in ALS]
    ok = [(al,v) for al,v in ok if v > 0]
    print('(%d,%d,%d) c=%d d=%d delta=%d  Z>0 at alpha:' % (n,a,k,c,2*a-n,delta), [(str(al), float(v)) for al,v in ok])
    al = max(ok, key=lambda t: t[1])[0]
    for h in range(1, min(c, k+1)+1):
        p0 = V.f(al,k,h,a-h)
        phis = [V.f(al,k,h,a-h-x) for x in range(0, a-h+1)]
        best = (Q(0), 0)
        for x in range(1, a-h+1):
            r = Q(p0 - phis[x], x)
            if r > best[0]: best = (r, x)
        print('   h=%d x0=%d  phi(x)=%s  q=%s at x=%d' % (h, h+1-delta, [round(float(v),2) for v in phis[:10]], best[0], best[1]))
