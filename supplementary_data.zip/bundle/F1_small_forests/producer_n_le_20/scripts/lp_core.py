#!/usr/bin/env python3
"""Core: exact rows (formulas imported from the return's CHECKER.py), float dual LP to PROPOSE certificates
(scipy HiGHS), exact rationalize+repair+verify (Fractions; final check by CHECKER.certificate_details).
Nothing float is trusted: every certificate reported as valid passes the exact CHECKER routine."""
import json, math, pathlib, sys
from fractions import Fraction as Q
import numpy as np
from scipy.optimize import linprog, milp, LinearConstraint, Bounds

HERE = pathlib.Path(__file__).resolve().parent
RET = HERE.parent.parent.parent / 'pro_six/return_binomial_fiber_20260929/BINOMIAL_FIBER_COMPLETION'
sys.path.insert(0, str(RET))
import CHECKER as CK  # noqa: E402  (import has no side effects; main() is guarded)

choose = CK.choose
states = CK.states

def domain(bound=26):
    return CK.parameter_domain(bound)

def fam(name):
    head, _, tail = name.rpartition('_')
    return head if tail.isdigit() else name

def row_data(n, a, names=None):
    names = CK.all_row_names(n, a) if names is None else names
    S = states(n, a)
    return [(nm, CK.slack_constant(nm, n, a), {s: CK.slack_coefficient(nm, n, a, *s) for s in S}) for nm in names]

def dLdR(n, a, k):
    S = states(n, a)
    dL = {(y, m): choose(m, k-y) - choose(m, k-1-y) for (y, m) in S}
    dR = {(y, m): choose(m, k-y) - choose(m, k+1-y) for (y, m) in S}
    return dL, dR

def solve_dual(n, a, k, names=None, alpha_fixed=None, sparse=False, eps_frac=0.5, max_rows=None):
    """Float dual LP. Variables: alpha, t_r (r in names), z1.  Returns (eps, alpha, {name: t}) or None.
    sparse=True: MILP minimizing #rows subject to eps >= eps_frac * eps_max."""
    c = n - a
    S = states(n, a)
    rows = row_data(n, a, names)
    R = len(rows)
    dL, dR = dLdR(n, a, k)
    nv = 1 + R + 1
    A_ub, b_ub = [], []
    # constraints written as  A x <= b
    for s in S:
        y, m = s
        if y == 0:
            continue
        row = np.zeros(nv)
        # r(s) = alpha*(dL-dR) + dR - sum t v ; need r >= 0 (y>=2) or r - z1 >= 0 (y==1)
        row[0] = -(dL[s] - dR[s])
        for i, (nm, u, v) in enumerate(rows):
            row[1+i] = v[s]
        if y == 1:
            row[-1] = 1.0
        A_ub.append(row); b_ub.append(float(dR[s]))
    s0 = (0, a)
    obj = np.zeros(nv)   # maximize  alpha*(dL0-dR0) + dR0 - sum t (v(s0)+u) + c z1
    obj[0] = dL[s0] - dR[s0]
    for i, (nm, u, v) in enumerate(rows):
        obj[1+i] = -(v[s0] + u)
    obj[-1] = c
    const = dR[s0]
    bounds = [(0, 1)] + [(0, None)]*R + [(None, None)]
    if alpha_fixed is not None:
        bounds[0] = (alpha_fixed, alpha_fixed)
    A_ub = np.array(A_ub); b_ub = np.array(b_ub)
    res = linprog(-obj, A_ub=A_ub, b_ub=b_ub, bounds=bounds, method='highs')
    if res.status != 0:
        return None
    epsmax = -res.fun + const
    x = res.x
    if sparse and epsmax > 1e-6:
        integrality = np.array([0] + [0]*R + [0] + [1]*R)
        nv2 = nv + R
        big = 1e4
        cons = []
        A2 = np.zeros((A_ub.shape[0], nv2)); A2[:, :nv] = A_ub
        cons.append(LinearConstraint(A2, -np.inf, b_ub))
        o = np.zeros(nv2); o[:nv] = obj
        cons.append(LinearConstraint(o.reshape(1, -1), eps_frac*epsmax - const, np.inf))
        # t_r <= big*b_r
        Ab = np.zeros((R, nv2))
        for i in range(R):
            Ab[i, 1+i] = 1.0; Ab[i, nv+i] = -big
        cons.append(LinearConstraint(Ab, -np.inf, 0))
        cost = np.zeros(nv2); cost[nv:] = 1.0
        lb = [b[0] if b[0] is not None else -np.inf for b in bounds] + [0]*R
        ub = [b[1] if b[1] is not None else np.inf for b in bounds] + [1]*R
        r2 = milp(cost, constraints=cons, integrality=integrality, bounds=Bounds(lb, ub),
                  options={'time_limit': 20})
        if r2.x is not None:
            support = [rows[i][0] for i in range(R) if r2.x[nv+i] > 0.5]
            # re-solve LP on that support to maximize eps
            out = solve_dual(n, a, k, support, alpha_fixed=alpha_fixed)
            if out is not None:
                return out
    tp = {rows[i][0]: x[1+i] for i in range(R) if x[1+i] > 1e-12}
    return epsmax, x[0], tp

def exact_from(n, a, k, alpha, prices, den=None, repair=True):
    """Rationalize (alpha, prices), set z0/z1 optimally, repair y>=2 deficits with subset_count rows,
    return a CHECKER-format certificate dict if eps>0 (verified by CK.certificate_details), else None."""
    c = n - a
    rq = (lambda v: Q(v).limit_denominator(den)) if den else (lambda v: Q(v))
    al = min(max(rq(alpha), Q(0)), Q(1))
    t = {nm: rq(v) for nm, v in prices.items()}
    t = {nm: v for nm, v in t.items() if v > 0}
    dL, dR = dLdR(n, a, k)
    S = states(n, a)
    names = list(t)
    def resid(tt):
        rows = {nm: (CK.slack_constant(nm, n, a), None) for nm in tt}
        r = {}
        for s in S:
            val = al*dL[s] + (1-al)*dR[s] - sum(v*CK.slack_coefficient(nm, n, a, *s) for nm, v in tt.items())
            r[s] = val
        return r
    r = resid(t)
    if repair:
        for h in range(2, c+1):
            mn = min(r[s] for s in S if s[0] == h)
            if mn < 0:
                nm = 'subset_count_%d' % h
                t[nm] = t.get(nm, Q(0)) - mn
        r = resid(t)
    z0 = r[(0, a)]
    z1 = min(r[s] for s in S if s[0] == 1) if c >= 1 else Q(0)
    eps = z0 + c*z1 - sum(v*CK.slack_constant(nm, n, a) for nm, v in t.items())
    if eps <= 0 or any(r[s] < 0 for s in S if s[0] >= 2):
        return None
    cert = {'n': n, 'a': a, 'k': k, 'left': str(al), 'right': str(1-al), 'epsilon': str(eps),
            'rows': {nm: str(v) for nm, v in t.items()}, 'equalities': [str(z0), str(z1)]}
    CK.certificate_details(cert)   # raises on any failure
    return cert

def maxden(cert):
    vals = [cert['left'], cert['right'], cert['epsilon']] + list(cert['rows'].values()) + cert['equalities']
    return max(Q(v).denominator for v in vals)
