#!/usr/bin/env python3
"""(2) Fewest-row certificates in the return's schema (float MILP proposes a support; exact rationalization with
small denominators; exact verification by the return's CHECKER.certificate_details).  n <= NMAX.
Output: outputs/sparse_min_<part>.jsonl  (cert dicts are exact and CHECKER-verified)."""
import json, sys, pathlib
import lp_core as L
HERE = pathlib.Path(__file__).resolve().parent
part, nparts, nmax = int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3])
dom = [t for i, t in enumerate(L.domain(nmax)) if i % nparts == part]
with open(HERE.parent/'outputs'/('sparse_min_%d.jsonl' % part), 'w') as f:
    for (n, a, k) in dom:
        best = None
        for frac in (0.05, 0.3):
            out = L.solve_dual(n, a, k, None, sparse=True, eps_frac=frac)
            if out is None: continue
            for den in (1, 2, 3, 4, 6, 12, 60, 360, 2520, 10**5):
                try:
                    c = L.exact_from(n, a, k, out[1], out[2], den=den)
                except AssertionError:
                    c = None
                if c is not None:
                    key = (len(c['rows']), L.maxden(c))
                    if best is None or key < best[0]:
                        best = (key, c)
                    break
        rec = {'n': n, 'a': a, 'k': k, 'rows': best[0][0] if best else None, 'maxden': best[0][1] if best else None,
               'cert': best[1] if best else None}
        f.write(json.dumps(rec) + '\n'); f.flush()
