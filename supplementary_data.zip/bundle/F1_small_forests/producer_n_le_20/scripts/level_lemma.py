#!/usr/bin/env python3
"""Lemma P (level-by-level payment), exact rational evaluation.  No LP, no certificate table.

For a forest F, maximum independent A (|A|=a), C=V\\A (|C|=c), d=a-c, weights al, be=1-al:
  al(i_k-i_{k-1}) + be(i_k-i_{k+1}) = sum_J f(|J|, m(J)),   f(y,m)=C(m,k-y)-al C(m,k-y-1)-be C(m,k-y+1).
Integer parameters of the forest: e = e(F[C]) in [0, min(c-1, a-1)],  s = D - c in [0, a-1-e]  (D = #cross edges).
Level data (all PROVED rows of the return, plus e(F[C]) <= c-1 and integrality of e):
  singletons: c of them, excesses x_v = b_v - 1 >= 0, sum x_v = s <= a-1-e, contribution f(1, a-1-x_v);
  level h>=2: N_h sets, excess x_J = a-m(J)-h >= 0, sum x_J <= X_h := s C(c-2,h-1) + d C(c-2,h-2)
              (matching excess), N_2 = C(c,2)-e exactly, and for h>=3
              max(0, C(c,h) - e C(c-2,h-2)) <= N_h <= min(C(c,h), C(c-2,h-2)(C(c,2)-e)/C(h,2)).
PHI_P(e) = f(0,a) + Sing(c, a-1-e) + sum_h Lev_h(e) where each term is the exact minimum of the corresponding
fractional moment problem (at most two atoms).  PHI_P = min_e PHI_P(e) > 0 excludes the weak valley at k.
"""
import math, sys, json
from fractions import Fraction as Q
C = lambda n, k: math.comb(n, k) if n >= 0 and 0 <= k <= n else 0

def fval(al, k, y, m):
    return C(m, k-y) - al*C(m, k-y-1) - (1-al)*C(m, k-y+1)

def lower_hull(pts):
    """pts: list of (x, phi) with distinct increasing x. Returns lower convex hull vertices."""
    hull = []
    for p in pts:
        while len(hull) >= 2:
            (x1, y1), (x2, y2) = hull[-2], hull[-1]
            # remove middle if it is not strictly below the chord
            if (y2 - y1)*(p[0] - x1) >= (p[1] - y1)*(x2 - x1):
                hull.pop()
            else:
                break
        hull.append(p)
    return hull

def psi(hull, t):
    """min over probability measures on the points with mean excess <= t of E[phi] (t >= 0).
    = min_{t' <= t} envelope(t').  Envelope is convex; take its minimum over [x0, min(t, xmax)]."""
    if t < hull[0][0]:
        return None
    best = None
    for i, (x, y) in enumerate(hull):
        if x <= t:
            best = y if best is None else min(best, y)
    # interior point at t on a segment
    for (x1, y1), (x2, y2) in zip(hull, hull[1:]):
        if x1 <= t <= x2:
            yt = y1 + (y2 - y1)*(Q(t) - x1)/(x2 - x1)
            best = yt if best is None else min(best, yt)
    return best

def level_min(hull, K_lo, K_hi, X):
    """min over K in [K_lo, K_hi] (reals) and measures of total mass K, total excess <= X, of sum phi.
    K*psi(X/K) is convex piecewise linear in K with breakpoints K = X/x_i; K=0 gives 0."""
    cands = set([K_lo, K_hi])
    for (x, _) in hull:
        if x > 0:
            K = Q(X)/x
            if K_lo <= K <= K_hi:
                cands.add(K)
    best = None
    for K in cands:
        if K == 0:
            v = Q(0)
        else:
            p = psi(hull, Q(X)/K)
            if p is None:
                continue
            v = K*p
        best = v if best is None else min(best, v)
    return best

def phi_P(al, n, a, k, use_pair=True, use_union=True, use_matching=True, detail=False):
    c = n - a; d = a - c
    base = fval(al, k, 0, a)
    worst = None; worst_e = None; parts_w = None
    emax = min(c-1, a-1) if c >= 1 else 0
    hulls = {}
    for y in range(1, c+1):
        mmax = a - y
        pts = [(Q(x), Q(fval(al, k, y, mmax - x))) for x in range(0, mmax+1)]
        hulls[y] = lower_hull(pts)
    for e in range(0, emax+1):
        s = a - 1 - e
        parts = {}
        tot = Q(base)
        if c >= 1:
            v = Q(c)*psi(hulls[1], Q(s, c))
            parts[1] = v; tot += v
        for h in range(2, c+1):
            if h == 2:
                lo = hi = Q(C(c, 2) - e)
            else:
                lo = Q(max(0, C(c, h) - e*C(c-2, h-2))) if use_union else Q(0)
                hi = Q(C(c, h))
                if use_pair:
                    hi = min(hi, Q(C(c-2, h-2)*(C(c, 2)-e), C(h, 2)))
            X = s*C(c-2, h-1) + d*C(c-2, h-2) if use_matching else 10**12
            v = level_min(hulls[h], lo, hi, X)
            parts[h] = v; tot += v
        if worst is None or tot < worst:
            worst, worst_e, parts_w = tot, e, parts
    if detail:
        return worst, worst_e, parts_w
    return worst

ALPHAS = [Q(1), Q(0), Q(1, 2), Q(1, 3), Q(2, 3), Q(1, 4), Q(3, 4), Q(1, 5), Q(2, 5), Q(3, 5), Q(4, 5), Q(1, 6), Q(5, 6)]

def best(n, a, k, **kw):
    b = None
    for al in ALPHAS:
        v = phi_P(al, n, a, k, **kw)
        if b is None or v > b[0]:
            b = (v, al)
    return b

def window(n):
    for a in range((n+1)//2, n):
        for k in range((n+3)//4+1, min(a, (n+2*a+5)//6)):
            yield a, k

if __name__ == '__main__':
    lo, hi = int(sys.argv[1]), int(sys.argv[2])
    outp = sys.argv[3]
    with open(outp, 'w') as f:
        for n in range(lo, hi+1):
            for a, k in window(n):
                v, al = best(n, a, k)
                v1 = phi_P(Q(1), n, a, k); v0 = phi_P(Q(0), n, a, k)
                rec = {'n': n, 'a': a, 'k': k, 'P_best': str(v), 'alpha': str(al), 'ok': v > 0,
                       'P_rise': str(v1), 'P_fall': str(v0)}
                f.write(json.dumps(rec) + '\n'); f.flush()
