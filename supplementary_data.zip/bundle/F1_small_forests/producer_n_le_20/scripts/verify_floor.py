#!/usr/bin/env python3
"""Standalone exact verifier for the table-free small-forest floor (standard library only; Python 3.9+).

It evaluates three explicit lower bounds (REPORT.md, Lemmas S_R, Z, P) for the valley functional
      V_al(F,k) = al*(i_k - i_{k-1}) + (1-al)*(i_k - i_{k+1})
of every forest F with alpha(F)=a, n=a+c, at every window triple (n,a,k):
      ceil(n/4) < k < min(a, ceil((n+2a)/6)),  ceil(n/2) <= a <= n-1.
No certificate data is read: every number is recomputed from binomial coefficients.
Usage: python3 verify_floor.py [NMAX]   (default 20)."""
import math, sys
from fractions import Fraction as Q

def C(n, k):
    return math.comb(n, k) if n >= 0 and 0 <= k <= n else 0

def cat(j):
    return C(2*j, j)//(j+1)

def window(n):
    for a in range((n+1)//2, n):
        for k in range((n+3)//4+1, min(a, (n+2*a+5)//6)):
            yield a, k

def f(al, k, y, m):  # contribution of one fiber (y, m) to V_al
    return C(m, k-y) - al*C(m, k-y-1) - (1-al)*C(m, k-y+1)

# ---- Lemma S_R (alpha = 1): i_k - i_{k-1} >= C(a,k)-C(a,k-1) - sum_{h=1}^{min(c,k-1)} C(c,h) Cat(k-1-h)
def phi_R(a, c, k):
    return C(a, k)-C(a, k-1) - sum(C(c, h)*cat(k-1-h) for h in range(1, min(c, k-1)+1))

# ---- level data common to Lemmas Z and P
def level_bounds(c, h, e):
    """count bounds [lo, hi] for N_h given e = e(F[C]) (h >= 2)"""
    if h == 2:
        return Q(C(c, 2)-e), Q(C(c, 2)-e)
    lo = Q(max(0, C(c, h)-e*C(c-2, h-2)))
    hi = min(Q(C(c, h)), Q(C(c-2, h-2)*(C(c, 2)-e), C(h, 2)))
    return lo, hi

def excess_cap(a, c, h, e):
    """sum over independent h-sets J of (a - m(J) - h) <= (a-1-e) C(c-2,h-1) + d C(c-2,h-2)"""
    return (a-1-e)*C(c-2, h-1) + (2*a-(a+c))*C(c-2, h-2)

# ---- Lemma Z (anchored tangent lines)
def phi_Z(al, n, a, k):
    c = n-a
    p0, q = {}, {}
    for h in range(1, c+1):
        p0[h] = Q(f(al, k, h, a-h))
        q[h] = max([Q(0)] + [(p0[h]-f(al, k, h, a-h-x))/x for x in range(1, a-h+1)])
    worst = None
    for e in range(0, min(c-1, a-1)+1):
        tot = Q(f(al, k, 0, a)) + c*p0[1] - q[1]*(a-1-e)
        for h in range(2, c+1):
            lo, hi = level_bounds(c, h, e)
            tot += min(lo*p0[h], hi*p0[h]) - q[h]*excess_cap(a, c, h, e)
        worst = tot if worst is None else min(worst, tot)
    return worst

# ---- Lemma P (exact per-level moment minima: lower convex hulls)
def hull(pts):
    H = []
    for p in pts:
        while len(H) >= 2 and (H[-1][1]-H[-2][1])*(p[0]-H[-2][0]) >= (p[1]-H[-2][1])*(H[-1][0]-H[-2][0]):
            H.pop()
        H.append(p)
    return H

def psi(H, t):  # min of E[phi] over probability measures with mean excess <= t
    vals = [y for (x, y) in H if x <= t]
    for (x1, y1), (x2, y2) in zip(H, H[1:]):
        if x1 <= t <= x2:
            vals.append(y1 + (y2-y1)*(t-x1)/(x2-x1))
    return min(vals)

def level_min(H, lo, hi, X):
    cands = {lo, hi} | {Q(X)/x for (x, _) in H if x > 0 and lo <= Q(X)/x <= hi}
    return min((Q(0) if K == 0 else K*psi(H, Q(X)/K)) for K in cands)

def phi_P(al, n, a, k):
    c = n-a
    Hs = {h: hull([(Q(x), Q(f(al, k, h, a-h-x))) for x in range(0, a-h+1)]) for h in range(1, c+1)}
    worst = None
    for e in range(0, min(c-1, a-1)+1):
        tot = Q(f(al, k, 0, a)) + c*psi(Hs[1], Q(a-1-e, c))
        for h in range(2, c+1):
            lo, hi = level_bounds(c, h, e)
            tot += level_min(Hs[h], lo, hi, excess_cap(a, c, h, e))
        worst = tot if worst is None else min(worst, tot)
    return worst

def main():
    NMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 20
    ZGRID = [Q(1, 3), Q(5, 12), Q(1, 2), Q(1, 4), Q(7, 12), Q(2, 3), Q(0), Q(1)]
    PGRID = [Q(1, 2)] + [Q(i, 100) for i in range(0, 101)]
    tally = {'tier1_SR': 0, 'tier2_Z': 0, 'P': 0, 'OPEN': 0}
    lines = []
    for n in range(1, NMAX+1):
        for a, k in window(n):
            c = n-a
            if 2*k <= a-1 and phi_R(a, c, k) > 0:
                tally['tier1_SR'] += 1
                lines.append('%d %d %d  S_R  alpha=1  value=%d' % (n, a, k, phi_R(a, c, k)))
                continue
            done = False
            for al in ZGRID:
                v = phi_Z(al, n, a, k)
                if v > 0:
                    tally['tier2_Z'] += 1
                    lines.append('%d %d %d  Z    alpha=%s  value=%s' % (n, a, k, al, v))
                    done = True
                    break
            if done:
                continue
            for al in PGRID:
                v = phi_P(al, n, a, k)
                if v > 0:
                    tally['P'] += 1
                    lines.append('%d %d %d  P    alpha=%s  value=%s' % (n, a, k, al, v))
                    done = True
                    break
            if not done:
                tally['OPEN'] += 1
                lines.append('%d %d %d  OPEN' % (n, a, k))
    print('\n'.join(lines))
    print('SUMMARY n<=%d:' % NMAX, tally, 'total', sum(tally.values()))
    # tier-1 corner checks (monotonicity lemma): for each k, corner (2k+1, min(NMAX,4k-4)-(2k+1))
    for k in range(3, NMAX):
        c0 = min(NMAX, 4*k-4)-(2*k+1)
        if c0 >= 1:
            print('corner k=%d (a,c)=(%d,%d): Cat_{k+1}=%d  sum=%d  %s' % (
                k, 2*k+1, c0, C(2*k+1, k)-C(2*k+1, k-1), C(2*k+1, k)-C(2*k+1, k-1)-phi_R(2*k+1, c0, k),
                'OK' if phi_R(2*k+1, c0, k) > 0 else 'FAILS'))

if __name__ == '__main__':
    main()
