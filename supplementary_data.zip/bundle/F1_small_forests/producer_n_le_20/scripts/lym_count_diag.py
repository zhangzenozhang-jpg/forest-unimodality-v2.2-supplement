#!/usr/bin/env python3
"""DIAGNOSTIC (float LP, HiGHS): does the COUNT-LEVEL shadow (shadow (17) at s=0 only):
      (h+1) N_{h+1} <= (c-h) N_h      (1 <= h <= c-1)
added to the return's basic rows push the frontier past 26?  This row set keeps Lemma P's structure
(it couples only the per-level COUNTS K_h in a chain, not the excess distributions), so a positive answer
would give a candidate table-free extension "Lemma P + count chain".  Primal: min tau s.t. both valley sides <= tau."""
import sys, math
import numpy as np
from scipy.optimize import linprog
import lp_core as L
C = lambda n, k: math.comb(n, k) if n >= 0 and 0 <= k <= n else 0
def rows(n, a, lym=True):
    out = L.row_data(n, a)
    c = n-a
    if lym:
        S = L.states(n, a)
        for h in range(1, c):
            v = {s: ((c-h) if s[0] == h else 0) - ((h+1) if s[0] == h+1 else 0) for s in S}
            out.append(('lym0_%d' % h, 0, v))
    return out
def tau(n, a, k, lym=True):
    S = L.states(n, a); idx = {s: i for i, s in enumerate(S)}; nv = len(S)+1
    A, b = [], []
    for nm, u, v in rows(n, a, lym):
        r = np.zeros(nv)
        for s, x in v.items(): r[idx[s]] = -float(x)
        sc = max(abs(r).max(), 1.0); A.append(r/sc); b.append(float(u)/sc)
    dL = np.zeros(nv); dR = np.zeros(nv)
    for (y, m), i in idx.items():
        dL[i] = C(m, k-y)-C(m, k-1-y); dR[i] = C(m, k-y)-C(m, k+1-y)
    sc = max(abs(dL).max(), abs(dR).max(), 1.0); dL /= sc; dR /= sc; dL[-1] = dR[-1] = -1.0
    A += [dL, dR]; b += [0.0, 0.0]
    Aeq = np.zeros((2, nv)); Aeq[0, idx[(0, a)]] = 1.0
    for (y, m), i in idx.items():
        if y == 1: Aeq[1, i] = 1.0
    cost = np.zeros(nv); cost[-1] = 1.0
    res = linprog(cost, A_ub=np.array(A), b_ub=np.array(b), A_eq=Aeq, b_eq=[1.0, float(n-a)],
                  bounds=[(0, None)]*(nv-1)+[(None, None)], method='highs')
    return res.fun if res.status == 0 else None
lo, hi = int(sys.argv[1]), int(sys.argv[2])
for n in range(lo, hi+1):
    tot = 0; ok_b = 0; ok_l = 0; fails = []
    for a in range((n+1)//2, n):
        for k in range((n+3)//4+1, min(a, (n+2*a+5)//6)):
            tot += 1
            tb = tau(n, a, k, lym=False); tl = tau(n, a, k, lym=True)
            ok_b += (tb is not None and tb > 1e-9); ok_l += (tl is not None and tl > 1e-9)
            if not (tl is not None and tl > 1e-9): fails.append((a, k))
    print('n=%d: window %d | basic %d | basic+countLYM %d | fails(+LYM) %s' % (n, tot, ok_b, ok_l, fails[:12]), flush=True)
