#!/usr/bin/env python3
"""Lemma Z at alpha = 1/2 (and 5/12 where needed) on all 18 hard triples of the exact window (n<=20):
B_Z(e) for all e, e-minimizer, and whether B_Z(1) >= B_Z(0) (with convexity => min at e=0).  Exact."""
import json
from fractions import Fraction as Q
from tiers_v2 import Z_e, tiers
hard = sorted(t for t, tr in tiers.items() if tr in ('CM', 'Z'))
rows = []
for t in hard:
    n, a, k = t; c = n-a
    for al in (Q(1, 2), Q(5, 12)):
        vals = [Z_e(al, n, a, k, e)[0] for e in range(0, min(c-1, a-1)+1)]
        if min(vals) > 0:
            break
    ok0 = vals[0] > 0 and (len(vals) == 1 or vals[1] >= vals[0])
    rows.append({'t': t, 'alpha': str(al), 'B0': str(vals[0]), 'B1': str(vals[1]) if len(vals) > 1 else None,
                 'min': str(min(vals)), 'argmin': vals.index(min(vals)), 'e0_certifies': ok0})
    print(t, 'alpha=%s B(0)=%s B(1)=%s min=%s at e=%d  e=0 suffices by convexity: %s' % (
        al, vals[0], vals[1] if len(vals) > 1 else '-', min(vals), vals.index(min(vals)), ok0))
json.dump([{**r, 't': list(r['t'])} for r in rows], open('../outputs/z_half_all18.json', 'w'), indent=1)
print('all 18 certified with min at e=0 and B(1)>=B(0):', all(r['e0_certifies'] for r in rows))
