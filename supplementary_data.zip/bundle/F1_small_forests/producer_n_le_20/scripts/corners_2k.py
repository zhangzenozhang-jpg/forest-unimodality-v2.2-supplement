#!/usr/bin/env python3
"""Tier 2a corners (a = 2k, n <= 20): by monotonicity in c, S_R covers all window triples with a = 2k and c <= c1(k)
iff PHI_R(2k, c1(k), k) > 0;  C(2k,k)-C(2k,k-1) = Cat_k.  Lists c1(k) and the remaining a=2k triples."""
import math
C = math.comb
cat = lambda j: C(2*j, j)//(j+1)
def phiR(a, c, k): return C(a, k)-C(a, k-1)-sum(C(c, h)*cat(k-1-h) for h in range(1, min(c, k-1)+1))
def inwin(n, a, k): return (n+3)//4 < k < min(a, (n+2*a+5)//6) and (n+1)//2 <= a <= n-1
tot = 0
for k in range(3, 10):
    a = 2*k
    cs = [c for c in range(1, 21-a) if inwin(a+c, a, k)]
    good = [c for c in cs if phiR(a, c, k) > 0]
    if not cs: continue
    c1 = max(good) if good else 0
    assert good == [c for c in cs if c <= c1]
    tot += len(good)
    terms = ' + '.join('%d*%d' % (C(c1, h), cat(k-1-h)) for h in range(1, min(c1, k-1)+1))
    print('k=%d a=%d: window c in %s; S_R covers c<=%d; corner Cat_%d=%d > %s = %d ; left to Z: c in %s' % (
        k, a, cs, c1, k, cat(k), terms, cat(k)-phiR(a, c1, k), [c for c in cs if c > c1]))
print('a=2k triples covered by S_R (n<=20):', tot)
