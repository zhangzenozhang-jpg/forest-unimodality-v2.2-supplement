#!/usr/bin/env python3
"""DIAGNOSTIC: compare Lemma P(alpha=1/2) with the float LP optimum of the return's relaxation at alpha=1/2
(all five families).  Lemma P should be >= LP (it is the same relaxation decoupled by level, plus integrality of
e(F[C]) and e(F[C]) <= c-1).  Also record the worst e and whether e=0 is the minimizer."""
import json
from fractions import Fraction as Q
import lp_core as L
import level_lemma as P
from collections import Counter
def window(n):
    for a in range((n+1)//2, n):
        for k in range((n+3)//4+1, min(a, (n+2*a+5)//6)):
            yield a, k
worstE = Counter(); rows = []
for n in range(7, 21):
    for a, k in window(n):
        if 2*k <= a-1: continue
        v, e, parts = P.phi_P(Q(1, 2), n, a, k, detail=True)
        lp = L.solve_dual(n, a, k, None, alpha_fixed=0.5)
        worstE[e] += 1
        rows.append((n, a, k, float(v), lp[0] if lp else None, e))
        print(n, a, k, 'P(1/2)=%.3f' % float(v), 'LP(1/2)=%.3f' % (lp[0] if lp else float('nan')), 'worst e', e,
              'P>=LP-1e-6' if (lp is None or float(v) >= lp[0]-1e-6) else 'P<LP !!')
print('worst-e distribution (tier 2, n<=20, alpha=1/2):', dict(worstE))
