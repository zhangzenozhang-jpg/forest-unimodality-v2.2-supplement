#!/usr/bin/env python3
"""Catalan-Markov bound (closed form).  For alpha in [0,1], beta = 1-alpha, delta = 2k-a.
Per set J at level h (excess x = a-h-m(J)):
  rise part  g^R_h(x) = C(M,j)-C(M,j-1)  (M = a-h-x, j = k-h)  >=  Cat_{j-1} (h+1-delta-x)   for 1<=h<=k-1,
             = 1 for h = k, = 0 for h > k;
  fall part  g^F_h(x) = C(M,j)-C(M,j+1)  >= -D_F(h) := -max(0, C(a-h,j+1)-C(a-h,j))            (Lemma 2).
Level-h total >= max( kappa_h N_h - alpha Cat_{j-1} sum x ,  -(alpha Cat_{j-1} + beta D_F(h)) U_h )
  with kappa_h = alpha Cat_{j-1}(h+1-delta) - beta D_F(h), N_h in [L_h, U_h], sum x <= X_h (or a-1-e for h=1).
Empty fiber: alpha(C(a,k)-C(a,k-1)) + beta(C(a,k)-C(a,k+1)).   Minimize over integer e in [0, min(c-1,a-1)].
Exact rationals."""
import math, sys, json
from fractions import Fraction as Q
C = lambda n, k: math.comb(n, k) if n >= 0 and 0 <= k <= n else 0
def cat(j): return C(2*j, j)//(j+1) if j >= 0 else 0
def LU(c, h, e):
    if h == 1: return Q(c), Q(c)
    if h == 2: return Q(C(c, 2)-e), Q(C(c, 2)-e)
    lo = Q(max(0, C(c, h)-e*C(c-2, h-2)))
    hi = min(Q(C(c, h)), Q(C(c-2, h-2)*(C(c, 2)-e), C(h, 2)))
    return lo, hi
def Xcap(a, c, h, e):
    if h == 1: return Q(a-1-e)
    return Q((a-1-e)*C(c-2, h-1) + (2*a-(a+c))*C(c-2, h-2))
def B(al, n, a, k, e, detail=False, markov=True):
    be = 1-al; c = n-a; delta = 2*k-a
    tot = al*(C(a, k)-C(a, k-1)) + be*(C(a, k)-C(a, k+1))
    parts = {0: tot}
    for h in range(1, c+1):
        j = k-h
        DF = max(0, C(a-h, j+1)-C(a-h, j)) if h <= k+1 else 0
        lo, hi = LU(c, h, e)
        if h <= k-1:
            cr = cat(j-1)
            kap = al*cr*(h+1-delta) - be*DF
            mk = min(kap*lo, kap*hi) - al*cr*Xcap(a, c, h, e)
            worst = -(al*cr + be*DF)*hi
            v = max(mk, worst) if markov else worst
        elif h == k:
            kap = al - be*DF
            v = min(kap*lo, kap*hi)
        elif h == k+1:
            v = -be*hi
        else:
            v = Q(0)
        parts[h] = v; tot += v
    return (tot, parts) if detail else tot
def Phi(al, n, a, k, markov=True):
    c = n-a
    return min(B(al, n, a, k, e, markov=markov) for e in range(0, min(c-1, a-1)+1))
def hB(n, a):
    c = n-a; d = a-c
    b = [sum(C(c, j)*2**j*C(d, s-j) for j in range(0, c+1)) for s in range(0, a+1)]
    return b.index(max(b))
if __name__ == '__main__':
    NMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 20
    ALS = [Q(i, 12) for i in range(13)] + [Q(i, 20) for i in range(21)]
    ALS = sorted(set(ALS))
    res = []
    for n in range(1, NMAX+1):
        for a in range((n+1)//2, n):
            for k in range((n+3)//4+1, min(a, (n+2*a+5)//6)):
                if k >= hB(n, a): continue
                best = max(((Phi(al, n, a, k), al) for al in ALS), key=lambda t: t[0])
                res.append((n, a, k, 2*k-a, n-a, best[0] > 0, str(best[1]), str(best[0])))
    hard = [r for r in res if r[3] >= 0]
    print('exact window n<=%d: %d triples; Catalan-Markov covers %d; with 2k>=a: %d of %d' % (
        NMAX, len(res), sum(r[5] for r in res), sum(r[5] for r in hard), len(hard)))
    for r in hard:
        print('  (%d,%d,%d) delta=%d c=%d  CM ok=%s alpha=%s value=%s' % r)
