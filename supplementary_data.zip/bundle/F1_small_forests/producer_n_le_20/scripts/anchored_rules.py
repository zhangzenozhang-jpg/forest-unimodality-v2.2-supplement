#!/usr/bin/env python3
"""Which alpha in a grid make Lemma Z positive on tier 2 (n<=20), where the steepest chord q_h is attained,
and whether a simple alpha-rule works.  Exact."""
import math
from fractions import Fraction as Q
from anchored import phi_Z, fval, window, C
GRID = [Q(i, 12) for i in range(13)]
rules = {}
argx = {}
for n in range(1, 21):
    for a, k in window(n):
        if 2*k <= a-1: continue
        ok = [al for al in GRID if phi_Z(al, n, a, k) > 0]
        c = n-a
        rules[(n, a, k)] = ok
        print((n, a, k), 'c=%d d=%d 2k-a=%d' % (c, 2*a-n, 2*k-a), 'alpha ok (x/12):', [int(al*12) for al in ok])
# where is q_h attained at alpha = 1/2?  record x* / x_max
from collections import Counter
where = Counter()
for (n, a, k), ok in rules.items():
    al = Q(1, 2)
    for h in range(1, n-a+1):
        xm = a-h
        p0 = fval(al, k, h, a-h)
        best = (Q(0), 0)
        for x in range(1, xm+1):
            r = Q(p0 - fval(al, k, h, a-h-x), x)
            if r > best[0]: best = (r, x)
        where['x*=%s' % ('none(q=0)' if best[1] == 0 else ('xmax' if best[1] == xm else ('xmax-1' if best[1] == xm-1 else 'interior')))] += 1
print('attainment of steepest chord at alpha=1/2:', dict(where))
# simple rule candidates by 2k-a
for name, rule in [('al=1/2 if 2k-a<=1 else 1/3', lambda n, a, k: Q(1, 2) if 2*k-a <= 1 else Q(1, 3)),
                   ('al=(3-(2k-a))/6 ', lambda n, a, k: Q(3-(2*k-a), 6)),
                   ('al=1/2 if 2k=a; 1/3 if 2k=a+1; 1/4 if 2k=a+2', lambda n, a, k: {0: Q(1, 2), 1: Q(1, 3), 2: Q(1, 4)}.get(2*k-a, Q(1, 4)))]:
    good = sum(1 for (n, a, k) in rules if rule(n, a, k) in rules[(n, a, k)])
    print('rule', name, ':', good, '/', len(rules), ' fails:', [t for t in rules if rule(*t) not in rules[t]])
