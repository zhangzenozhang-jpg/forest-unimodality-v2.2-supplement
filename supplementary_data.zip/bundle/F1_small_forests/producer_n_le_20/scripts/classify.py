#!/usr/bin/env python3
"""Classify the 322 certificates of BINOMIAL_FIBER_COMPLETION by support pattern and region. DIAGNOSTIC tabulation."""
import json, math, pathlib, sys
from collections import Counter, defaultdict
from fractions import Fraction as Q
HERE = pathlib.Path(__file__).resolve().parent
SRC = HERE.parent.parent.parent / 'pro_six/return_binomial_fiber_20260929/BINOMIAL_FIBER_COMPLETION/CERTIFICATES.json'
certs = json.load(open(SRC))
def fam(name):
    return name.rsplit('_',1)[0] if name[-1].isdigit() else name
pat = defaultdict(list)
for c in certs:
    n,a,k = c['n'],c['a'],c['k']
    fams = tuple(sorted(set(fam(r) for r in c['rows'])))
    pat[fams].append(c)
print('distinct family-supports:', len(pat))
for fams, L in sorted(pat.items(), key=lambda t:-len(t[1])):
    cs = sorted(set(x['n']-x['a'] for x in L))
    sides = Counter((x['left'],x['right']) if (x['left'] in '01' ) else ('mix','mix') for x in L)
    print(len(L), fams, 'c in', cs, 'n range', min(x['n'] for x in L), max(x['n'] for x in L), 'sides', dict(sides))
# exact row supports with h relative to k and c
pat2 = defaultdict(list)
for c in certs:
    n,a,k = c['n'],c['a'],c['k']; cc = n-a
    key = tuple(sorted(c['rows']))
    pat2[key].append((n,a,k))
print('distinct exact supports:', len(pat2))
# region table: for each (n,a) list k and pattern code
codes = {}
for i,(fams,L) in enumerate(sorted(pat.items(), key=lambda t:-len(t[1]))):
    codes[fams] = chr(ord('A')+i)
    print(chr(ord('A')+i), fams)
grid = defaultdict(dict)
for c in certs:
    n,a,k = c['n'],c['a'],c['k']
    fams = tuple(sorted(set(fam(r) for r in c['rows'])))
    side = 'L' if c['right']=='0' else ('R' if c['left']=='0' else 'M')
    grid[(n,a)][k] = codes[fams]+side
for n in range(1,27):
    for a in range((n+1)//2, n):
        if grid[(n,a)]:
            print('n=%2d a=%2d c=%2d d=%2d :'%(n,a,n-a,2*a-n), ' '.join('k%d:%s'%(k,v) for k,v in sorted(grid[(n,a)].items())))
