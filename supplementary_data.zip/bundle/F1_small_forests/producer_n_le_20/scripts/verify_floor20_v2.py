#!/usr/bin/env python3
"""Exact verifier for the section floor20_section.tex (standard library only; Python 3.9+).

Checks, for every forest with n <= 20 vertices (through the parameters (n,a,k) only; no forest is enumerated):
 (W) the window: ceil(n/4) < k < h_B(n,a), h_B = first mode of (1+2x)^(n-a) (1+x)^(2a-n);
     the 130 triples of the certificate domain split into 30 with k >= h_B and the 100 window triples;
 (T1) window triples with 2k <= a-1: the 7 Catalan corner inequalities Cat_{k+1} > sum_h C(c0,h) Cat_{k-1-h};
 (T2) window triples with a = 2k and PHI_R > 0: the 5 corner inequalities Cat_k > sum_h C(c1,h) Cat_{k-1-h};
 (Z) the remaining 18 triples: the anchored bound with explicit level data (p_h, q_h) depending only on (a,k,alpha):
     the line condition phi_h(x) >= p_h - q_h x for all 0 <= x <= a-h, B(0) > 0 and B(1) >= B(0).
Also writes LaTeX table fragments to ../outputs/floor20_tables.tex.  Exit status 0 iff every check passes."""
import math, sys, os
from fractions import Fraction as Q

def C(n, k):
    return math.comb(n, k) if n >= 0 and 0 <= k <= n else 0

def cat(j):
    return C(2*j, j)//(j+1) if j >= 0 else 0

def hB(n, a):
    c, d = n-a, 2*a-n
    b = [sum(C(c, j)*2**j*C(d, s-j) for j in range(c+1)) for s in range(a+1)]
    return b.index(max(b))

def domain20():
    for n in range(1, 21):
        for a in range((n+1)//2, n):
            for k in range((n+3)//4+1, min(a, (n+2*a+5)//6)):
                yield n, a, k

def phiR(a, c, k):
    return C(a, k)-C(a, k-1) - sum(C(c, h)*cat(k-1-h) for h in range(1, min(c, k-1)+1))

def f(al, k, y, m):
    return C(m, k-y) - al*C(m, k-y-1) - (1-al)*C(m, k-y+1)

def level_data(al, a, k, hmax):
    """p_h = f(h, a-h), q_h = steepest chord slope from x = 0 (>= 0); both depend only on (a, k, alpha)."""
    p, q = {}, {}
    for h in range(1, hmax+1):
        p[h] = Q(f(al, k, h, a-h))
        q[h] = max([Q(0)] + [(p[h]-f(al, k, h, a-h-x))/x for x in range(1, a-h+1)])
        assert all(f(al, k, h, a-h-x) >= p[h]-q[h]*x for x in range(0, a-h+1))   # the line condition
    return p, q

def B(al, n, a, k, e, p, q):
    c, d = n-a, 2*a-n
    tot = Q(f(al, k, 0, a)) + c*p[1] - q[1]*(a-1-e)
    for h in range(2, c+1):
        if h == 2:
            lo = hi = Q(C(c, 2)-e)
        else:
            lo = Q(max(0, C(c, h)-e*C(c-2, h-2)))
            hi = min(Q(C(c, h)), Q(C(c-2, h-2)*(C(c, 2)-e), C(h, 2)))
        X = (a-1-e)*C(c-2, h-1) + d*C(c-2, h-2)
        tot += min(lo*p[h], hi*p[h]) - q[h]*X
    return tot

def tex_frac(v):
    v = Q(v)
    if v.denominator == 1:
        return '%d' % v.numerator
    s = '-' if v < 0 else ''
    return '%s%d/%d' % (s, abs(v.numerator), v.denominator)

def main():
    ok = True
    D = list(domain20())
    W = [t for t in D if t[2] < hB(t[0], t[1])]
    tail = [t for t in D if t not in W]
    print('domain n<=20: %d triples; window (k < h_B): %d; k >= h_B: %d' % (len(D), len(W), len(tail)))
    ok &= (len(D), len(W), len(tail)) == (130, 100, 30)
    T1 = [t for t in D if 2*t[2] <= t[1]-1]
    T2 = [t for t in D if t[1] == 2*t[2] and phiR(t[1], t[0]-t[1], t[2]) > 0]
    rest = [t for t in D if t not in T1 and t not in T2]
    tailset = [t for t in rest if t[2] >= hB(t[0], t[1])]
    R = [t for t in rest if t not in tailset]
    print('domain split: T1 %d, T2 %d, k>=h_B among the rest %d, remaining %d' % (len(T1), len(T2), len(tailset), len(R)))
    ok &= (len(T1), len(T2), len(tailset), len(R)) == (72, 24, 16, 18)
    ok &= all(t in W for t in R)
    tailrows = []
    for (n, a, k) in sorted(tailset):
        c, d = n-a, 2*a-n
        bk = sum(C(c, j)*2**j*C(d, k-j) for j in range(c+1))
        bk1 = sum(C(c, j)*2**j*C(d, k+1-j) for j in range(c+1))
        ok &= bk1 <= bk
        tailrows.append((n, a, k, c, d, bk, bk1))
        print('tail (%d,%d,%d): b_k=%d >= b_{k+1}=%d' % (n, a, k, bk, bk1))
    # T1 corners
    corners1 = []
    for k in range(3, 10):
        ts = [t for t in T1 if t[2] == k]
        if not ts: continue
        c0 = min(20, 4*k-4)-(2*k+1)
        assert all(t[1] >= 2*k+1 and t[0]-t[1] <= c0 for t in ts)
        lhs, rhs = cat(k+1), sum(C(c0, h)*cat(k-1-h) for h in range(1, min(c0, k-1)+1))
        assert lhs == C(2*k+1, k)-C(2*k+1, k-1)
        corners1.append((k, 2*k+1, c0, lhs, rhs)); ok &= lhs > rhs
    # T2 corners
    corners2 = []
    for k in range(3, 10):
        ts = [t for t in T2 if t[2] == k]
        if not ts: continue
        c1 = max(t[0]-t[1] for t in ts)
        lhs, rhs = cat(k), sum(C(c1, h)*cat(k-1-h) for h in range(1, min(c1, k-1)+1))
        assert lhs == C(2*k, k)-C(2*k, k-1)
        corners2.append((k, 2*k, c1, lhs, rhs)); ok &= lhs > rhs
    for x in corners1: print('T1 corner k=%d (a,c)=(%d,%d): %d > %d' % x)
    for x in corners2: print('T2 corner k=%d (a,c)=(%d,%d): %d > %d' % x)
    # Z
    rows = []; tables = {}
    for (n, a, k) in sorted(R):
        c = n-a
        for al in (Q(1, 2), Q(5, 12)):
            key = (a, k, al)
            if key not in tables:
                tables[key] = level_data(al, a, k, min(a-1, k+1))
            p, q = tables[key]
            pp = {h: (p[h] if h in p else Q(0)) for h in range(1, c+1)}
            qq = {h: (q[h] if h in q else Q(0)) for h in range(1, c+1)}
            b0, b1 = B(al, n, a, k, 0, pp, qq), B(al, n, a, k, 1, pp, qq)
            if b0 > 0 and b1 >= b0:
                rows.append((n, a, k, al, b0, b1)); break
        else:
            ok = False; print('FAILED', (n, a, k))
    for r in rows: print('Z (%d,%d,%d) alpha=%s  B(0)=%s  B(1)=%s' % r)
    ok &= len(rows) == 18
    # LaTeX fragments
    out = []
    out.append('% generated by scripts/verify_floor20_v2.py; do not edit by hand')
    out.append('\\newcommand{\\FloorCornersOne}{%')
    for (k, a0, c0, lhs, rhs) in corners1:
        out.append('%d & $(%d,%d)$ & %d & %d\\\\' % (k, a0, c0, lhs, rhs))
    out.append('}')
    out.append('\\newcommand{\\FloorCornersTwo}{%')
    for (k, a0, c1, lhs, rhs) in corners2:
        out.append('%d & $(%d,%d)$ & %d & %d\\\\' % (k, a0, c1, lhs, rhs))
    out.append('}')
    out.append('\\newcommand{\\FloorTwoList}{%')
    t2s = sorted(T2)
    out.append(',\\ '.join('$(%d,%d,%d)$' % t for t in t2s))
    out.append('}')
    out.append('\\newcommand{\\FloorOneCount}{%d}' % len(T1))
    ok &= all(2*t[2] >= t[1] for t in t2s + tailset + R) and len([t for t in D if 2*t[2] >= t[1]]) == 58
    out.append('\\newcommand{\\FloorTail}{%')
    for (n, a, k, c, d, bk, bk1) in tailrows:
        out.append('$(%d,%d,%d)$ & %d & %d & %d & %d\\\\' % (n, a, k, c, d, bk, bk1))
    out.append('}')
    out.append('\\newcommand{\\FloorLevelData}{%')
    used = sorted(set((r[1], r[2], r[3]) for r in rows), key=lambda t: (t[0], t[1], -t[2]))
    for (a, k, al) in used:
        p, q = tables[(a, k, al)]
        hs = sorted(p)
        out.append('$(%d,%d)$ & $%s$ & $%s$ & $%s$\\\\' % (a, k, tex_frac(al),
                   ',\\ '.join(tex_frac(p[h]) for h in hs), ',\\ '.join(tex_frac(q[h]) for h in hs)))
    out.append('}')
    psirows = set()
    for (a, k, al) in used:
        for h in range(1, min(a-1, k+1)+1):
            psirows.add((al, a-h, k-h))
    # closed forms for j <= 0 are checked here and stated in the text
    for (al, r, j) in psirows:
        vals = [f(al, j, 0, r-x) for x in range(0, r+1)]          # psi_{r,j}(x) = f_al(0, r-x) at rank j
        if j == -1:
            ok &= all(v == -(1-al) for v in vals)
        if j == 0:
            ok &= all(v == 1-(1-al)*(r-x) for x, v in enumerate(vals))
    for part, cond in (('One', lambda t: t[0] == Q(1, 2)), ('Two', lambda t: t[0] != Q(1, 2))):
        out.append('\\newcommand{\\FloorPsiRows%s}{%%' % part)
        for (al, r, j) in sorted([t for t in psirows if t[2] >= 1 and cond(t)], key=lambda t: (t[2], t[1])):
            vals = [f(al, j, 0, r-x) for x in range(0, r+1)]
            p0 = Q(vals[0])
            q0 = max([Q(0)] + [(p0-vals[x])/x for x in range(1, r+1)])
            ok &= all(vals[x] >= p0-q0*x for x in range(0, r+1))
            out.append('%d & %d & $%s$ & $%s$ & $%s$\\\\' % (r, j, tex_frac(p0), tex_frac(q0), ',\\ '.join(tex_frac(v) for v in vals)))
        out.append('}')
    # the functions g_j(M) = C(M,j) - al C(M,j-1) - (1-al) C(M,j+1), one row per (al, j >= 1)
    for part, al, Mmax in (('Half', Q(1, 2), 13), ('FiveTwelfths', Q(5, 12), 12)):
        js = sorted(set(t[2] for t in psirows if t[0] == al and t[2] >= 1))
        out.append('\\newcommand{\\FloorG%s}{%%' % part)
        for j in js:
            out.append('%d & %s\\\\' % (j, ' & '.join('$%s$' % tex_frac(f(al, j, 0, M)) for M in range(0, Mmax+1))))
        out.append('}')
    # p_h = g_{k-h}(a-h) and q_h = steepest chord from the right end, recomputed from g
    for (a, k, al) in used:
        p, q = tables[(a, k, al)]
        for h in p:
            r, j = a-h, k-h
            g = [f(al, j, 0, M) for M in range(0, r+1)]
            qq = max([Q(0)] + [Q(g[r]-g[M], r-M) for M in range(0, r)])
            ok &= (p[h], q[h]) == (Q(g[r]), qq)
    # consistency: level data of each (a,k,al) equal the psi data at (a-h, k-h)
    for (a, k, al) in used:
        p, q = tables[(a, k, al)]
        for h in p:
            r, j = a-h, k-h
            vals = [f(al, j, 0, r-x) for x in range(0, r+1)]
            p0 = Q(vals[0]); q0 = max([Q(0)] + [(p0-vals[x])/x for x in range(1, r+1)])
            ok &= (p[h], q[h]) == (p0, q0)
    out.append('\\newcommand{\\FloorZValues}{%')
    for (n, a, k, al, b0, b1) in rows:
        out.append('$(%d,%d,%d)$ & %d & %d & $%s$ & $%s$ & $%s$\\\\' % (n, a, k, n-a, 2*a-n, tex_frac(al), tex_frac(b0), tex_frac(b1)))
    out.append('}')
    # ---- additions after the referee report (30 Sep 2026): breakdown checks and re-laid-out tables ----
    a2k = [t for t in D if t[1] == 2*t[2]]
    ok &= len(a2k) == 32 and len([t for t in a2k if t in T2]) == 24 and len([t for t in a2k if t in R]) == 8
    ok &= all(t in R for t in a2k if t not in T2)
    classes = ((1, T1, '$2k\\le a-1$', 'Prop.~\\ref{fl:prop:class1}'),
               (2, T2, '$a=2k$, $\\Phi(a,c,k)>0$', 'Prop.~\\ref{fl:prop:class2}'),
               (3, tailset, 'Table~\\ref{fl:tab:tail}', 'Prop.~\\ref{fl:prop:class3}'),
               (4, R, 'Table~\\ref{fl:tab:values}', 'Prop.~\\ref{fl:prop:class4}'))
    brk = []
    for (name, S, cond, how) in classes:
        inW = len([t for t in S if t in W])
        brk.append((name, len(S), inW, len(S)-inW, len([t for t in S if t[1] == 2*t[2]]), cond, how))
    ok &= [b[1:5] for b in brk] == [(72, 72, 0, 0), (24, 10, 14, 24), (16, 0, 16, 0), (18, 18, 0, 8)]
    ok &= (sum(b[1] for b in brk), sum(b[2] for b in brk), sum(b[3] for b in brk), sum(b[4] for b in brk)) == (130, 100, 30, 32)
    print('breakdown (class, size, in window, outside window, with a=2k):', [b[:5] for b in brk])
    out.append('\\newcommand{\\FloorBreakdown}{%')
    for (name, size, inW, outW, n2k, cond, how) in brk:
        out.append('$\\mathcal P_%d$ & %s & %d & %d & %d & %d & %s\\\\' % (name, cond, size, n2k, inW, outW, how))
    out.append('\\midrule')
    out.append('total & & %d & %d & %d & %d & \\\\' % (sum(b[1] for b in brk), sum(b[4] for b in brk),
               sum(b[2] for b in brk), sum(b[3] for b in brk)))
    out.append('}')
    # g tables in two halves of M
    for part, al, Mmax in (('Half', Q(1, 2), 13), ('Five', Q(5, 12), 12)):
        js = sorted(set(t[2] for t in psirows if t[0] == al and t[2] >= 1))
        for half, Ms in (('Low', range(0, 7)), ('High', range(7, Mmax+1))):
            out.append('\\newcommand{\\FloorG%s%s}{%%' % (part, half))
            for j in js:
                cells = ['$%s$' % tex_frac(f(al, j, 0, M)) for M in Ms] + [''] * (7-len(Ms))
                out.append('%d & %s\\\\' % (j, ' & '.join(cells)))
            out.append('}')
    # level data: one line of p_h and one line of q_h per (a,k,omega), h = 1..8
    out.append('\\newcommand{\\FloorLevelPQ}{%')
    for (a, k, al) in used:
        p, q = tables[(a, k, al)]
        hs = sorted(p)
        pc = ['$%s$' % tex_frac(p[h]) for h in hs] + [''] * (8-len(hs))
        qc = ['$%s$' % tex_frac(q[h]) for h in hs] + [''] * (8-len(hs))
        out.append('$(%d,%d)$ & $%s$ & $p_h$ & %s\\\\' % (a, k, tex_frac(al), ' & '.join(pc)))
        out.append(' & & $q_h$ & %s\\\\[2pt]' % ' & '.join(qc))
    out.append('}')
    here = os.path.dirname(os.path.abspath(__file__))
    with open(os.path.join(here, '..', 'outputs', 'floor20_tables.tex'), 'w') as fh:
        fh.write('\n'.join(out) + '\n')
    print('ALL CHECKS PASS' if ok else 'SOME CHECK FAILED')
    sys.exit(0 if ok else 1)

if __name__ == '__main__':
    main()
