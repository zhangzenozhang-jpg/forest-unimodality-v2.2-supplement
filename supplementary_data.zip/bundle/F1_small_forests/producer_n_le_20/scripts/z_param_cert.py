#!/usr/bin/env python3
"""Lemma Z as a parametric certificate in the return's schema (explicit multipliers), checked by the return's CHECKER.
For alpha and (n,a,k):  p_h = f_al(h,a-h),  q_h = max(0, max_{1<=x<=a-h} (p_h - f_al(h,a-h-x))/x)   (h = 1..c)
  matching_excess_h : q_h                       (h >= 2)
  subset_count_h    : max(0,-p_h)               (h >= 3)
  missing_edge_union_h : max(0, p_h)            (h >= 3)
  edge_budget       : A = q_1 + sum_{h>=2} q_h C(c-2,h-1)
  subset_count_2    : max(0, A - P_2),  P_2 = p_2 + sum_{h>=3} max(0,p_h) C(c-2,h-2)
z0, z1 set optimally (exact); epsilon = Z(0) - C(c,2) max(0, P_2 - A).  No repair, no rounding."""
import sys, math, json
from fractions import Fraction as Q
import lp_core as L
C = lambda n, k: math.comb(n, k) if n >= 0 and 0 <= k <= n else 0
def f(al, k, y, m):
    return C(m, k-y) - al*C(m, k-y-1) - (1-al)*C(m, k-y+1)
def z_prices(al, n, a, k):
    c = n-a
    p, q = {}, {}
    for h in range(1, c+1):
        p[h] = Q(f(al, k, h, a-h))
        q[h] = max([Q(0)] + [(p[h]-f(al, k, h, a-h-x))/x for x in range(1, a-h+1)])
    T = sum(q[h]*C(c-2, h-1) for h in range(2, c+1))
    A = q[1] + T
    P2 = (p[2] if c >= 2 else 0) + sum(max(Q(0), p[h])*C(c-2, h-2) for h in range(3, c+1))
    rows = {}
    if A > 0: rows['edge_budget'] = A
    for h in range(2, c+1):
        if q[h] > 0: rows['matching_excess_%d' % h] = q[h]
    for h in range(3, c+1):
        if p[h] < 0: rows['subset_count_%d' % h] = -p[h]
        if p[h] > 0: rows['missing_edge_union_%d' % h] = p[h]
    if c >= 2 and A - P2 > 0: rows['subset_count_2'] = A - P2
    return rows
if __name__ == '__main__':
    NMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 20
    ALS = [Q(1, 3), Q(5, 12), Q(1, 2), Q(1, 4), Q(7, 12), Q(2, 3), Q(0), Q(1)]
    sr = lambda n, a, k: C(a, k)-C(a, k-1)-sum(C(n-a, h)*(C(2*(k-1-h), k-1-h)//(k-h)) for h in range(1, min(n-a, k-1)+1))
    res = {'SR_param': 0, 'Z_param': 0, 'none': []}
    out = []
    for (n, a, k) in L.domain(NMAX):
        if sr(n, a, k) > 0:
            res['SR_param'] += 1; continue
        got = None
        for al in ALS:
            rows = z_prices(al, n, a, k)
            try:
                cert = L.exact_from(n, a, k, al, rows, den=None, repair=False)
            except AssertionError:
                cert = None
            if cert is not None:
                got = cert; break
        if got:
            res['Z_param'] += 1
            out.append(got)
        else:
            res['none'].append((n, a, k))
    json.dump(out, open('../outputs/z_param_certs_n%d.json' % NMAX, 'w'), indent=0)
    print('n<=%d: S_R parametric cert %d; Z parametric cert (CHECKER-verified) %d; neither: %s' % (
        NMAX, res['SR_param'], res['Z_param'], res['none']))
