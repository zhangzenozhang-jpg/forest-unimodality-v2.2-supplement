#!/usr/bin/env python3
"""Tier 1 corner table (exact integers).  PHI_R(a,c,k) = C(a,k)-C(a,k-1) - sum_{h=1}^{min(c,k-1)} C(c,h) Cat(k-1-h).
Window + tier 1 (2k <= a-1) + n <= NB  ==>  a >= 2k+1 and c <= c0(k) := min(NB, 4k-4) - (2k+1).
By monotonicity (increasing in a for a >= 2k-3, decreasing in c) PHI_R(a,c,k) >= PHI_R(2k+1, c0(k), k)."""
import math, sys
C = lambda n, k: math.comb(n, k) if n >= 0 and 0 <= k <= n else 0
cat = lambda j: C(2*j, j)//(j+1)
def phiR(a, c, k):
    return C(a, k)-C(a, k-1) - sum(C(c, h)*cat(k-1-h) for h in range(1, min(c, k-1)+1))
for NB in (20, 26, 10**9):
    print('--- n <=', NB if NB < 10**9 else 'any')
    for k in range(3, 16):
        c0 = min(NB, 4*k-4) - (2*k+1)
        if c0 < 1:
            continue
        lhs = C(2*k+1, k)-C(2*k+1, k-1)
        rhs = lhs - phiR(2*k+1, c0, k)
        print('k=%2d corner (a,c)=(%2d,%2d): C(a,k)-C(a,k-1) = %d  vs  sum C(c,h)Cat(k-1-h) = %d  -> %s' % (
            k, 2*k+1, c0, lhs, rhs, 'OK' if lhs > rhs else 'FAILS'))
