#!/usr/bin/env python3
"""Mixed closed-form lines (DIAGNOSTIC search for a pattern; each bound found is exact and valid by the stated lemmas):
 rise part (1<=h<=k-1): segment line of g^R_h through (i,g(i)),(i+1,g(i+1)), 0<=i<=x0 (x0=h+1-delta>=1), or the
   Catalan line Cat_{j-1}(x0-x) if x0<=0;  [valid: convexity on 0..x0+1 and damage <= Cat_{j-1}]
 fall part: if g^F_h(0) <= 0: constant g^F_h(0); if g^F_h(0) > 0: either 0 (valid since g^F>=0 there) or the chord
   line g^F_h(0)(1 - x/(a-h)) [validity CHECKED numerically here per level; must be proved before use].
Level h = k: rise 1, fall g^F_k(0) (constant); h = k+1: fall -1.
Search: alpha in grid, per-level choice maximizing the level bound at the worst e (greedy per e)."""
import math, sys
from fractions import Fraction as Q
from catalan_markov import C, cat, LU, Xcap, hB
def gR(a, k, h, x):
    M = a-h-x; j = k-h
    return C(M, j)-C(M, j-1)
def gF(a, k, h, x):
    M = a-h-x; j = k-h
    return C(M, j)-C(M, j+1)
def fall_chord_valid(a, k, h):
    g0 = gF(a, k, h, 0)
    return all(Q(gF(a, k, h, x)) >= Q(g0)*(1-Q(x, a-h)) for x in range(0, a-h+1))
def level_opts(al, n, a, k, h):
    """list of (p, q) lines p - q x valid for phi_h = al gR + (1-al) gF on 0..a-h"""
    be = 1-al; delta = 2*k-a; j = k-h
    if h == k+1: return [(-be, Q(0))]
    if h > k+1: return [(Q(0), Q(0))]
    if h == k: return [(al + be*gF(a, k, h, 0), Q(0))]
    x0 = h+1-delta
    rl = []
    if x0 <= 0:
        rl.append((Q(cat(j-1))*x0, Q(cat(j-1))))
    else:
        for i in range(0, x0+1):
            g0, g1 = gR(a, k, h, i), gR(a, k, h, i+1)
            q = Q(g0-g1); rl.append((Q(g0)+q*i, q))
    f0 = gF(a, k, h, 0)
    fl = [(Q(min(0, f0)), Q(0))]
    if f0 > 0 and fall_chord_valid(a, k, h):
        fl.append((Q(f0), Q(f0, a-h)))
    return [(al*pr+be*pf, al*qr+be*qf) for (pr, qr) in rl for (pf, qf) in fl]
def Phi(al, n, a, k):
    c = n-a; worst = None
    opts = {h: level_opts(al, n, a, k, h) for h in range(1, c+1)}
    for e in range(0, min(c-1, a-1)+1):
        tot = al*(C(a, k)-C(a, k-1)) + (1-al)*(C(a, k)-C(a, k+1))
        for h in range(1, c+1):
            lo, hi = LU(c, h, e); X = Xcap(a, c, h, e)
            tot += max(min(p*lo, p*hi) - q*X for (p, q) in opts[h])
        worst = tot if worst is None else min(worst, tot)
    return worst
if __name__ == '__main__':
    ALS = sorted(set([Q(i, 12) for i in range(13)] + [Q(i, 20) for i in range(21)]))
    eight = [(15,9,5),(17,11,6),(18,11,6),(19,10,6),(19,11,6),(19,13,7),(20,10,6),(20,13,7)]
    for t in eight:
        b = max(((Phi(al, *t), al) for al in ALS), key=lambda u: u[0])
        print(t, 'ok' if b[0] > 0 else 'FAIL', 'alpha=%s value=%.3f' % (b[1], float(b[0])))
