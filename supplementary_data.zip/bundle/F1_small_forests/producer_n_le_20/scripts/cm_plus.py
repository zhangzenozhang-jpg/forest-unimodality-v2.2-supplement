#!/usr/bin/env python3
"""CM+ : closed-form tangent lines.  Rise part g^R_h(x) = C(M,j)-C(M,j-1) (M=a-h-x, j=k-h, 1<=h<=k-1) is convex on the
integers 0..x0+1 (x0 = h+1-delta), so every segment line through (i, g(i)), (i+1, g(i+1)), 0<=i<=x0, is a lower bound on
all 0<=x<=a-h (beyond x0+1 the line is <= -Cat_{j-1} <= g).  Fall part: g^F_h(x) >= min(0, g^F_h(0)).
Level bound: kappa N_h - alpha*q*sum(x), kappa = alpha*p + beta*min(0,g^F_h(0)), line alpha(p - q x).
Choice of i: RULE = segment containing the average excess t = X_h/U_h (clamped to [0,x0]); or BEST over i (DIAGNOSTIC).
Also keep the S-type fallback -(alpha*Cat + beta*D_F) U_h.  Exact rationals."""
import math, sys
from fractions import Fraction as Q
from catalan_markov import C, cat, LU, Xcap, hB
def gR(a, k, h, x):
    M = a-h-x; j = k-h
    return C(M, j)-C(M, j-1)
def gF0(a, k, h):
    j = k-h; M = a-h
    return C(M, j)-C(M, j+1)
def level(al, n, a, k, h, e, choice):
    be = 1-al; c = n-a; delta = 2*k-a; j = k-h
    lo, hi = LU(c, h, e); X = Xcap(a, c, h, e)
    fneg = min(0, gF0(a, k, h)) if h <= k+1 else 0
    if h >= k+1:
        return be*fneg*hi if h == k+1 else Q(0)
    if h == k:
        kap = al*1 + be*fneg
        return min(kap*lo, kap*hi)
    x0 = h+1-delta
    cr = cat(j-1)
    fallback = -(al*cr + be*max(0, -gF0(a, k, h)))*hi
    cands = []
    if x0 <= 0:
        segs = [(x0, Q(0), Q(cr))]            # line through (x0,0) slope -Cat
    else:
        segs = []
        for i in range(0, x0+1):
            g0, g1 = gR(a, k, h, i), gR(a, k, h, i+1)
            q = Q(g0-g1)                        # slope -q
            p = Q(g0) + q*i                     # line p - q x
            segs.append((i, p, q))
    if choice == 'rule' and x0 > 0:
        t = X/hi if hi > 0 else Q(0)
        i = min(max(int(t), 0), x0)
        segs = [s for s in segs if s[0] == i]
    for (i, p, q) in segs:
        if x0 <= 0:
            p = Q(cr)*x0; q = Q(cr)             # line cr*(x0 - x)
        kap = al*p + be*fneg
        cands.append(min(kap*lo, kap*hi) - al*q*X)
    return max(cands + [fallback])
def B(al, n, a, k, e, choice):
    be = 1-al; c = n-a
    tot = al*(C(a, k)-C(a, k-1)) + be*(C(a, k)-C(a, k+1))
    for h in range(1, c+1):
        tot += level(al, n, a, k, h, e, choice)
    return tot
def Phi(al, n, a, k, choice='best'):
    c = n-a
    return min(B(al, n, a, k, e, choice) for e in range(0, min(c-1, a-1)+1))
if __name__ == '__main__':
    ALS = sorted(set([Q(i, 12) for i in range(13)] + [Q(i, 20) for i in range(21)]))
    nine = [(15,9,5),(16,9,5),(17,11,6),(18,11,6),(19,10,6),(19,11,6),(19,13,7),(20,10,6),(20,13,7)]
    for choice in ('rule', 'best'):
        print('choice =', choice)
        for t in nine:
            b = max(((Phi(al, *t, choice=choice), al) for al in ALS), key=lambda u: u[0])
            print('  ', t, 'ok' if b[0] > 0 else 'FAIL', 'alpha=%s value=%s (%.2f)' % (b[1], b[0], float(b[0])))
