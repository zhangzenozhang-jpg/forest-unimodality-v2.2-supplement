#!/usr/bin/env python3
"""The paper's window uses the exact h_B(F) = first mode of (1+2x)^nu (1+x)^(n-2nu), and nu(F) = c = n-a for a maximum
independent set A of a forest (Lemma: a matching saturating C).  So h_B depends only on (n,a).  List the triples of the
n<=20 domain (which uses H(n,a) = ceil((n+2a)/6) >= h_B) that actually satisfy k < h_B(n,a)."""
import math
C = lambda n, k: math.comb(n, k) if n >= 0 and 0 <= k <= n else 0
def hB(n, a):
    c = n-a; d = a-c
    b = [sum(C(c, j)*2**j*C(d, s-j) for j in range(0, c+1)) for s in range(0, a+1)]
    return b.index(max(b))
def dom(nmax):
    for n in range(1, nmax+1):
        for a in range((n+1)//2, n):
            for k in range((n+3)//4+1, min(a, (n+2*a+5)//6)):
                yield n, a, k
tot = 0; inW = []; out = []
for (n, a, k) in dom(20):
    tot += 1
    (inW if k < hB(n, a) else out).append((n, a, k))
print('domain n<=20:', tot, '| with k < h_B(n,a) (the exact window):', len(inW), '| k >= h_B (tail settles):', len(out))
print('settled by the exact tail:', out)
tier2 = [(n, a, k) for (n, a, k) in inW if 2*k >= a]
print('exact-window triples with 2k >= a:', len(tier2))
# the 34 hard ones
hard = [(11,7,4),(12,7,4),(12,8,4),(13,9,5),(14,9,5),(15,8,5),(15,9,5),(15,10,5),(15,11,6),(16,8,5),(16,9,5),(16,10,5),
        (16,11,6),(17,10,6),(17,11,6),(17,12,6),(17,13,7),(18,10,6),(18,11,6),(18,12,6),(18,13,7),(19,10,6),(19,11,6),
        (19,12,6),(19,12,7),(19,13,7),(19,15,8),(20,10,6),(20,11,6),(20,12,6),(20,12,7),(20,13,7),(20,14,7),(20,15,8)]
hard_in = [t for t in hard if t[2] < hB(t[0], t[1])]
print('of the 34 hard triples, in the exact window:', len(hard_in), hard_in)
print('of the 34 hard triples, settled by the exact tail:', [t for t in hard if t not in hard_in])
for (n, a) in sorted(set((t[0], t[1]) for t in hard)):
    print('  (n,a)=(%d,%d) c=%d d=%d h_B=%d H=%d' % (n, a, n-a, 2*a-n, hB(n, a), (n+2*a+5)//6))
