#!/usr/bin/env python3
"""Details of Lemma P on the triples not covered by Lemma S (n<=20), plus fine-alpha rescue of (26,15,9).
Exact rationals throughout."""
import json, sys
from fractions import Fraction as Q
import level_lemma as P
from subset_lemma import PHI_R_cat, PHI_F_closed, best_alpha
from region_S import phiR
def window(n):
    for a in range((n+1)//2, n):
        for k in range((n+3)//4+1, min(a, (n+2*a+5)//6)):
            yield a, k
rows = []
for n in range(1, 21):
    for a, k in window(n):
        if PHI_R_cat(n, a, k) > 0: continue
        vals = {}
        for al in [Q(1,2), Q(1,3), Q(2,5), Q(3,5), Q(2,3), Q(1), Q(0)]:
            v, e, parts = P.phi_P(al, n, a, k, detail=True)
            vals[str(al)] = (v, e, parts)
        bestal = max(vals, key=lambda s: vals[s][0])
        v, e, parts = vals[bestal]
        half = vals['1/2'][0]
        rows.append({'n': n, 'a': a, 'k': k, 'c': n-a, 'd': 2*a-n, 'best_alpha': bestal, 'value': str(v),
                     'worst_e': e, 'parts': {h: str(x) for h, x in parts.items()}, 'value_at_half': str(half),
                     'half_ok': half > 0,
                     'S_F': PHI_F_closed(n, a, k) > 0})
        print(n, a, k, 'c=%d d=%d' % (n-a, 2*a-n), 'best al', bestal, 'val %.2f' % float(v), 'worst e', e,
              '| al=1/2: %.2f' % float(half), '| parts', {h: round(float(x), 1) for h, x in parts.items()})
json.dump(rows, open('../outputs/tierP_detail_n20.json', 'w'), indent=1)
print('all n<=20 non-S_R triples certified by Lemma P at alpha=1/2?', all(r['half_ok'] for r in rows), sum(r['half_ok'] for r in rows), len(rows))
# fine alpha at (26,15,9)
best = None
for i in range(0, 101):
    al = Q(i, 100)
    v = P.phi_P(al, 26, 15, 9)
    if best is None or v > best[0]: best = (v, al)
print('(26,15,9) best on 1/100 grid:', best, float(best[0]))
