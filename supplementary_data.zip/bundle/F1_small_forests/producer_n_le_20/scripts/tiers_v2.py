#!/usr/bin/env python3
"""Final tiering of the exact window for n <= 20 (k < h_B(n,a)); exact integers/rationals.
T1: 2k <= a-1 (Catalan corners); T2a: a = 2k and PHI_R > 0 (Catalan corners);
CM: Catalan-Markov bound (alpha = 1) > 0 ; Z: anchored lemma with alpha in {1/2, 5/12, 1/3, ...}.
Also reports, for CM and Z, the minimizing e and the convexity neighbours."""
import math, json
from fractions import Fraction as Q
import catalan_markov as CMm
import verify_floor as V
C = CMm.C; cat = CMm.cat; hB = CMm.hB
def window20():
    for n in range(1, 21):
        for a in range((n+1)//2, n):
            for k in range((n+3)//4+1, min(a, (n+2*a+5)//6)):
                if k < hB(n, a):
                    yield n, a, k
def phiR(a, c, k): return C(a, k)-C(a, k-1)-sum(C(c, h)*cat(k-1-h) for h in range(1, min(c, k-1)+1))
def Z_e(al, n, a, k, e):
    """Lemma Z value at a fixed e (same formula as verify_floor.phi_Z but per e)"""
    c = n-a
    p0, q = {}, {}
    for h in range(1, c+1):
        p0[h] = Q(V.f(al, k, h, a-h))
        q[h] = max([Q(0)] + [(p0[h]-V.f(al, k, h, a-h-x))/x for x in range(1, a-h+1)])
    tot = Q(V.f(al, k, 0, a)) + c*p0[1] - q[1]*(a-1-e)
    for h in range(2, c+1):
        lo, hi = V.level_bounds(c, h, e)
        tot += min(lo*p0[h], hi*p0[h]) - q[h]*V.excess_cap(a, c, h, e)
    return tot, p0, q
tiers = {}
for (n, a, k) in window20():
    c = n-a
    if 2*k <= a-1:
        tiers[(n, a, k)] = 'T1'
    elif a == 2*k and phiR(a, c, k) > 0:
        tiers[(n, a, k)] = 'T2a'
    elif CMm.Phi(Q(1), n, a, k) > 0:
        tiers[(n, a, k)] = 'CM'
    else:
        tiers[(n, a, k)] = 'Z'
from collections import Counter
print('exact window n<=20:', len(tiers), Counter(tiers.values()))
out = {}
for t, tier in sorted(tiers.items()):
    n, a, k = t; c = n-a
    if tier == 'CM':
        vals = [CMm.B(Q(1), n, a, k, e) for e in range(0, min(c-1, a-1)+1)]
        emin = min(range(len(vals)), key=lambda i: vals[i])
        print('CM', t, 'c=%d d=%d delta=%d' % (c, 2*a-n, 2*k-a), 'B(e)=', [str(v) for v in vals], 'min at e=%d' % emin)
        out[str(t)] = {'tier': 'CM', 'B_e': [str(v) for v in vals]}
    if tier == 'Z':
        best = None
        for al in [Q(1, 2), Q(5, 12), Q(1, 3), Q(7, 12), Q(1, 4), Q(2, 3)]:
            vals = [Z_e(al, n, a, k, e)[0] for e in range(0, min(c-1, a-1)+1)]
            if min(vals) > 0:
                best = (al, vals); break
        al, vals = best
        emin = min(range(len(vals)), key=lambda i: vals[i])
        _, p0, q = Z_e(al, n, a, k, 0)
        print('Z ', t, 'c=%d d=%d delta=%d alpha=%s' % (c, 2*a-n, 2*k-a, al), 'B(e)=', [str(v) for v in vals],
              'min at e=%d' % emin, '| p_h:', {h: str(v) for h, v in p0.items()}, 'q_h:', {h: str(v) for h, v in q.items()})
        out[str(t)] = {'tier': 'Z', 'alpha': str(al), 'B_e': [str(v) for v in vals],
                       'p': {h: str(v) for h, v in p0.items()}, 'q': {h: str(v) for h, v in q.items()}}
json.dump({'tiers': {str(t): v for t, v in tiers.items()}, 'detail': out}, open('../outputs/tiers_v2.json', 'w'), indent=1)
# T2a corners inside the exact window
for k in range(3, 10):
    cs = [n-a for (n, a, kk), tier in tiers.items() if kk == k and a == 2*k and tier == 'T2a']
    if cs: print('T2a k=%d: c in %s (max %d)' % (k, sorted(cs), max(cs)))
# T1 corners: per k, max c and min a
for k in range(3, 10):
    ts = [(n, a) for (n, a, kk), tier in tiers.items() if kk == k and tier == 'T1']
    if ts: print('T1 k=%d: %d triples, a>=%d, c<=%d' % (k, len(ts), min(a for n, a in ts), max(n-a for n, a in ts)))
