#!/usr/bin/env python3
"""For every triple in the n<=26 domain: which FAMILY subsets certify (float LP proposal, then EXACT verification of a
rationalized certificate), and whether one-sided (alpha=1: strict rise, alpha=0: strict fall) certificates exist.
Output: outputs/family_necessity.jsonl.  A 'yes' is PROVED only when 'exact' is true (the certificate passed CHECKER)."""
import json, sys, itertools, pathlib
import lp_core as L
HERE = pathlib.Path(__file__).resolve().parent
FAMS = ['edge_budget', 'matching_excess', 'subset_count', 'missing_edge_union', 'pair_extension']
SUBSETS = [(), ('subset_count',), ('edge_budget', 'subset_count'), ('edge_budget', 'matching_excess', 'subset_count'),
           ('edge_budget', 'missing_edge_union', 'subset_count'), ('edge_budget', 'pair_extension', 'subset_count'),
           ('edge_budget', 'matching_excess', 'missing_edge_union', 'subset_count'),
           ('edge_budget', 'matching_excess', 'pair_extension', 'subset_count'),
           ('edge_budget', 'missing_edge_union', 'pair_extension', 'subset_count'),
           ('matching_excess', 'missing_edge_union', 'pair_extension', 'subset_count'),
           tuple(FAMS)]
def names_for(n, a, fams):
    return [nm for nm in L.CK.all_row_names(n, a) if L.fam(nm) in fams]
def try_cert(n, a, k, names, alpha_fixed=None):
    out = L.solve_dual(n, a, k, names, alpha_fixed=alpha_fixed)
    if out is None or out[0] <= 1e-7:
        return {'lp_eps': None if out is None else out[0], 'exact': False}
    for den in (12, 60, 360, 2520, 10**6, None):
        try:
            c = L.exact_from(n, a, k, out[1], out[2], den=den)
        except AssertionError:
            c = None
        if c is not None:
            return {'lp_eps': out[0], 'exact': True, 'cert': c}
    return {'lp_eps': out[0], 'exact': False}
def main():
    part, nparts = int(sys.argv[1]), int(sys.argv[2])
    dom = [t for i, t in enumerate(L.domain(26)) if i % nparts == part]
    with open(HERE.parent / 'outputs' / ('family_necessity_%d.jsonl' % part), 'w') as f:
        for (n, a, k) in dom:
            rec = {'n': n, 'a': a, 'k': k, 'fams': {}, 'side': {}}
            for fs in SUBSETS:
                r = try_cert(n, a, k, names_for(n, a, fs))
                rec['fams']['+'.join(fs) or 'none'] = {'exact': r['exact'], 'lp_eps': r['lp_eps']}
            for side, af in (('rise', 1.0), ('fall', 0.0)):
                r = try_cert(n, a, k, names_for(n, a, FAMS), alpha_fixed=af)
                rec['side'][side] = {'exact': r['exact'], 'lp_eps': r['lp_eps']}
            f.write(json.dumps(rec) + '\n'); f.flush()
main()
