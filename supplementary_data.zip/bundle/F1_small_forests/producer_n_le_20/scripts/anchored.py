#!/usr/bin/env python3
"""Lemma Z (anchored tangent lines): a closed-form weakening of Lemma P.
phi_h(x) = f_al(h, a-h-x), x in [0, a-h];  q_h = max(0, max_{1<=x<=a-h} (phi_h(0)-phi_h(x))/x)  (steepest chord from 0).
Then phi_h(x) >= phi_h(0) - q_h x for all x, and
 al dL + be dR >= f(0,a) + c phi_1(0) - q_1 (a-1-e) + sum_{h>=2} [ min(L_h phi_h(0), U_h phi_h(0)) - q_h X_h(e) ],
 minimized over integer e in [0, min(c-1,a-1)].   Exact rationals."""
import math, sys, json
from fractions import Fraction as Q
C = lambda n, k: math.comb(n, k) if n >= 0 and 0 <= k <= n else 0
def fval(al, k, y, m):
    return C(m, k-y) - al*C(m, k-y-1) - (1-al)*C(m, k-y+1)
def phi_Z(al, n, a, k, detail=False):
    c = n-a; d = a-c
    ph0 = {}; q = {}
    for h in range(1, c+1):
        xm = a-h
        p0 = Q(fval(al, k, h, a-h))
        qq = Q(0)
        for x in range(1, xm+1):
            qq = max(qq, (p0 - fval(al, k, h, a-h-x))/x)
        ph0[h] = p0; q[h] = qq
    worst = None
    for e in range(0, (min(c-1, a-1) if c >= 1 else 0)+1):
        s = a-1-e
        tot = Q(fval(al, k, 0, a))
        if c >= 1:
            tot += c*ph0[1] - q[1]*s
        for h in range(2, c+1):
            if h == 2:
                lo = hi = Q(C(c, 2)-e)
            else:
                lo = Q(max(0, C(c, h)-e*C(c-2, h-2)))
                hi = min(Q(C(c, h)), Q(C(c-2, h-2)*(C(c, 2)-e), C(h, 2)))
            X = s*C(c-2, h-1) + d*C(c-2, h-2)
            tot += min(lo*ph0[h], hi*ph0[h]) - q[h]*X
        if worst is None or tot < worst[0]:
            worst = (tot, e)
    return (worst, ph0, q) if detail else worst[0]
def window(n):
    for a in range((n+1)//2, n):
        for k in range((n+3)//4+1, min(a, (n+2*a+5)//6)):
            yield a, k
if __name__ == '__main__':
    from subset_lemma import PHI_R_cat
    ALS = [Q(1, 2), Q(1), Q(0), Q(1, 3), Q(2, 3), Q(2, 5), Q(3, 5), Q(1, 4), Q(3, 4)]
    res = []
    for n in range(1, 27):
        for a, k in window(n):
            t1 = 2*k <= a-1
            vh = phi_Z(Q(1, 2), n, a, k)
            vb = max((phi_Z(al, n, a, k), al) for al in ALS)
            res.append((n, a, k, t1, PHI_R_cat(n, a, k) > 0, vh > 0, vb[0] > 0, str(vb[1])))
    for lim in (20, 26):
        sub = [r for r in res if r[0] <= lim]
        t2 = [r for r in sub if not r[3]]
        print('n<=%d tier2 %d: Z(1/2) ok %d, Z(best) ok %d; all triples: Z(best) %d/%d; S_R-or-Z(best) %d' % (
            lim, len(t2), sum(r[5] for r in t2), sum(r[6] for r in t2), sum(r[6] for r in sub), len(sub),
            sum((r[4] or r[6]) for r in sub)))
        print('  tier2 not covered by Z(best):', [(r[0], r[1], r[2]) for r in t2 if not r[6]])
    json.dump(res, open('../outputs/anchored_26.json', 'w'))
