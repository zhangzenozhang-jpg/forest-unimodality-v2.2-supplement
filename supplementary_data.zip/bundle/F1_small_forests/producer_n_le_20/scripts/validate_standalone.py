#!/usr/bin/env python3
"""DIAGNOSTIC soundness test of the standalone verifier's formulas on real forests: all forests n <= NMAX, every
maximum-cardinality marking, every 1 <= k <= a-1, alpha in a grid:  V_al(F,k) >= phi_Z, phi_P (and phi_R for al=1).
Also checks phi_Z <= phi_P (Z is a weakening of P)."""
import sys, pathlib
from fractions import Fraction as Q
from collections import Counter
HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent.parent.parent / 'pro_six/return_binomial_fiber_20260929/independent'))
import recheck_fiber as rf
import verify_floor as V
NMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 12
ALS = [Q(1), Q(0), Q(1, 2), Q(1, 3), Q(5, 12)]
stats = Counter(); cache = {}; tight = None
for n, G in rf.forests_upto(NMAX):
    poly = rf.indep_poly_dp(G); a = len(poly)-1
    if n == 0 or a == n: continue
    nmax_mark = sum(1 for S in rf.independent_sets(G, sorted(G.nodes)) if len(S) == a)
    stats['forests'] += 1; stats['markings'] += nmax_mark
    c = n - a
    for k in range(1, a):
        for al in ALS:
            key = (n, a, k, al)
            if key not in cache:
                z = V.phi_Z(al, n, a, k); p = V.phi_P(al, n, a, k)
                if z > p: stats['Z>P !!'] += 1
                cache[key] = (z, p, V.phi_R(a, c, k) if al == 1 else None)
            z, p, r = cache[key]
            nxt = poly[k+1] if k+1 < len(poly) else 0
            lhs = al*(poly[k]-poly[k-1]) + (1-al)*(poly[k]-nxt)
            stats['checks'] += nmax_mark
            if lhs < z: stats['Z_VIOLATION'] += 1; print('Z VIOL', n, a, k, al, lhs, z)
            if lhs < p: stats['P_VIOLATION'] += 1; print('P VIOL', n, a, k, al, lhs, p)
            if r is not None and lhs < r: stats['R_VIOLATION'] += 1; print('R VIOL', n, a, k, lhs, r)
            g = lhs - p
            if tight is None or g < tight[0]: tight = (g, n, a, k, str(al))
print(dict(stats), 'tightest P gap', tight)
