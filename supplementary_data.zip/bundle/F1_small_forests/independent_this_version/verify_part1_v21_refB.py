#!/usr/bin/env python3
"""Referee B (v2.1, 1 Oct 2026): exact check of Part I (Section 6, Appendix A) of TWIN v2.1 against v2.0.

Adapted from referee_v2.0_B/verify_part1_v20_refB.py. Standard library only, exact rational arithmetic.
(1) Parses the v2.1 table macros (head of TWIN_v2.1/s6_part_b.tex) and the v2.0 ones (head of TWIN_v2.0/s6_part_b.tex)
    and compares EVERY entry of every v2.1 table with the corresponding v2.0 entry.
(2) Rechecks every v2.1 table entry from the definitions in v2.1 (D_24, classes, corner and tail tables, G tables,
    line sets: validity of each line, chord / hull / horizontal status of every entry, caption closed forms; anchored
    values A at e_min and neighbours, global minimum, positivity; Catalan line bound values; examples; counts).
Exit status 0 iff every check passes.
"""
import re, sys
from fractions import Fraction as Fr
from math import comb

ROOT = "/Users/kvallier/Desktop/Erdos 993/ProofRuns/2026-09-28_analytic_large_n/LEAN/for_tong/"
T21 = open(ROOT + "TWIN_v2.1/s6_part_b.tex").read()
T20 = open(ROOT + "TWIN_v2.0/s6_part_b.tex").read()
FAIL = []
NCHECK = [0]


def check(cond, msg):
    NCHECK[0] += 1
    if not cond:
        FAIL.append(msg); print("MISMATCH:", msg)


def C(r, t):
    return comb(r, t) if (r >= 0 and 0 <= t <= r) else 0


def cat(j):
    return C(2 * j, j) // (j + 1) if j >= 0 else 0


def cdiv(x, y):
    return -((-x) // y)


# ---------------------------------------------------------------- macro parsing
def macro(tex, name):
    m = re.search(r"\\newcommand\{\\" + name + r"\}\{%?\n(.*?)\n\}", tex, re.S)
    assert m, name
    return m.group(1)


def num(s):
    s = s.replace('$', '').replace('^*', '').replace('{', '').replace('}', '').strip()
    s = s.replace('\\tfrac', '').replace('\\frac', '')
    return Fr(s)


def rows(tex, name):
    out = []
    for line in macro(tex, name).split('\\\\'):
        line = line.strip()
        line = re.sub(r"^\[2pt\]", "", line).strip()
        if not line:
            continue
        out.append([c.strip() for c in line.split('&')])
    return out


def triple(s):
    m = re.match(r"\$\((\d+),(\d+),(\d+)\)\$", s.strip())
    return tuple(int(x) for x in m.groups())


def pair(s):
    m = re.match(r"\$\((\d+),(\d+)\)\$", s.strip())
    return tuple(int(x) for x in m.groups())


# ---------------------------------------------------------------- the parameter set (v2.1 eq. p1:eq:domain)
def H(n, a):
    return cdiv(n + 2 * a, 6)


D24 = [(n, a, k) for n in range(1, 25) for a in range(cdiv(n, 2), n)
       for k in range(cdiv(n, 4) + 1, min(a, H(n, a)))]
print("|D24| =", len(D24))
check(len(D24) == 249, "|D24| != 249")
check(sum(1 for t in D24 if t[0] <= 20) == 130, "130 with n<=20")
check(all(t[0] > 6 for t in D24), "none with n<=6")
check(all(H(n, a) <= a for n in range(1, 25) for a in range(cdiv(n, 2), n)), "H<=a (min always equals H)")


def bco(n, a):
    c, d = n - a, 2 * a - n
    return [sum(C(c, i) * 2 ** i * C(d, r - i) for i in range(c + 1)) for r in range(a + 2)]


def hB(n, a):
    b = bco(n, a); return b.index(max(b))


check(all(hB(n, a) <= H(n, a) for n in range(2, 25) for a in range(cdiv(n, 2), n)), "h_B(n,a) <= H(n,a)")
# B_F = (1+2x)^c (1+x)^d for a forest with nu = c: the coefficient formula of p1:eq:brow with nu=c, n-2nu=d
check(all(bco(n, a) [s] == sum(C(n - a, j) * 2 ** j * C(n - 2 * (n - a), s - j) for j in range(n - a + 1))
          for n in range(2, 25) for a in range(cdiv(n, 2), n) for s in range(a + 2)), "b_s formula with nu=c")

# ---------------------------------------------------------------- tables identical to v2.0 (verbatim macros)
for name in ["FlxCornersOne", "FlxCornersTwo", "FlxLine", "PTwoList", "PTailTwoCol"]:
    check(macro(T21, name) == macro(T20, name), f"macro {name} differs from v2.0")
print("verbatim-identical macros v2.1 == v2.0: FlxCornersOne FlxCornersTwo FlxLine PTwoList PTailTwoCol")

# ---------------------------------------------------------------- corner tables
c1 = {}; c2 = {}
for r in rows(T21, "FlxCornersOne"):
    k = int(r[0]); A, cc = pair(r[1]); c1[k] = cc
    check(A == 2 * k + 1, f"corner1 a at k={k}")
    check(int(r[2]) == cat(k + 1), f"corner1 Cat at k={k}")
    s = sum(C(cc, h) * cat(k - 1 - h) for h in range(1, min(cc, k - 1) + 1))
    check(int(r[3]) == s, f"corner1 sum at k={k}: {r[3]} vs {s}")
    check(cat(k + 1) > s, f"corner1 positive at k={k}")
    check(C(2 * k + 1, k) - C(2 * k + 1, k - 1) == cat(k + 1), f"catlead a=2k+1 k={k}")
for r in rows(T21, "FlxCornersTwo"):
    k = int(r[0]); A, cc = pair(r[1]); c2[k] = cc
    check(A == 2 * k, f"corner2 a at k={k}")
    check(int(r[2]) == cat(k), f"corner2 Cat at k={k}")
    s = sum(C(cc, h) * cat(k - 1 - h) for h in range(1, min(cc, k - 1) + 1))
    check(int(r[3]) == s, f"corner2 sum at k={k}: {r[3]} vs {s}")
    check(cat(k) > s, f"corner2 positive at k={k}")
    check(C(2 * k, k) - C(2 * k, k - 1) == cat(k), f"catlead a=2k k={k}")
check(sorted(c1) == list(range(3, 12)) and sorted(c2) == list(range(3, 12)), "corner rows k=3..11")
print("c1 =", [c1[k] for k in sorted(c1)], " c2 =", [c2[k] for k in sorted(c2)])
ncomp_corner = len(c1) + len(c2)

# monotonicity lemma (fl:lem:mono) numerically on the range used, and its use in Prop class1/class2
def Rr(a, c, k):
    return C(a, k) - C(a, k - 1) - sum(C(c, h) * cat(k - 1 - h) for h in range(1, min(c, k - 1) + 1))


check(all(Rr(a, c + 1, k) <= Rr(a, c, k) for a in range(1, 25) for c in range(0, 24) for k in range(1, 13)),
      "R nonincreasing in c")
check(all(Rr(a + 1, c, k) >= Rr(a, c, k) for k in range(1, 13) for a in range(max(0, 2 * k - 3), 25) for c in range(0, 24)),
      "R(a+1)>=R(a) for a>=2k-3")

# ---------------------------------------------------------------- classes (v2.1 rules, 6.5 opening)
P1 = [t for t in D24 if 2 * t[2] <= t[1] - 1]
P2 = [t for t in D24 if t[1] == 2 * t[2] and (t[0] - t[1]) <= c2.get(t[2], -1)]
rest = [t for t in D24 if t not in P1 and t not in P2]
P3 = [t for t in rest if t[2] >= hB(t[0], t[1])]
P4 = [t for t in rest if t not in P3]
print("classes:", len(P1), len(P2), len(P3), len(P4))
check((len(P1), len(P2), len(P3), len(P4)) == (145, 34, 28, 42), "class counts 145/34/28/42")
check(len(set(P1) | set(P2) | set(P3) | set(P4)) == 249 and len(P1) + len(P2) + len(P3) + len(P4) == 249,
      "partition of D24")
check(all(t[2] < hB(t[0], t[1]) for t in P4), "every P4 triple has k < h_B")
exc = [t for t in P1 if not (3 <= t[2] <= 11 and t[0] - t[1] <= c1[t[2]])]
print("P1 exceptions:", exc)
check(exc == [(24, 15, 7)], "P1 exception set")
for k in range(3, 12):
    bound = min(24, 4 * k - 4) - (2 * k + 1)
    check((bound <= c1[k]) == (k != 7), f"class1 proof bound at k={k}: {bound} vs c1={c1[k]}")
print("class1 bound list:", [min(24, 4 * k - 4) - (2 * k + 1) for k in range(3, 12)])
check(all(t[0] >= 7 for t in D24), "n>=7 on D24")
check(all(2 * t[2] + 1 <= t[1] <= 23 for t in P1), "P1: 2k+1<=a<=23")
check([t for t in P1 if t[2] == 7 and t[0] - t[1] == 9] == [(24, 15, 7)], "only P1 triple at k=7 with c=9")
p2list = [tuple(int(x) for x in m) for m in re.findall(r"\((\d+),(\d+),(\d+)\)", macro(T21, "PTwoList"))]
check(sorted(p2list) == sorted(P2) and len(p2list) == 34, "P2 printed list (34)")
check(all(Rr(t[1], t[0] - t[1], t[2]) > 0 for t in P1 if t != (24, 15, 7)), "R>0 on P1 minus exception (direct)")
check(all(Rr(t[1], t[0] - t[1], t[2]) > 0 for t in P2), "R>0 on P2 (direct)")
check(Rr(15, 9, 7) == -334, "R(15,9,7) = -334")
# tail table (two-column)
tl = []
for r in rows(T21, "PTailTwoCol"):
    for half in (r[:5], r[5:]):
        t = triple(half[0]); tl.append(t)
        n, a, k = t; c, d = n - a, 2 * a - n; b = bco(n, a)
        check(int(half[1]) == c and int(half[2]) == d, f"tail c,d at {t}")
        check(int(half[3]) == b[k] and int(half[4]) == b[k + 1], f"tail b at {t}")
        check(b[k + 1] <= b[k], f"tail b_(k+1)<=b_k at {t}")
check(sorted(tl) == sorted(P3) and len(tl) == 28, "tail table == P3 (28)")
ncomp_tail = len(tl)
print("integer comparisons by hand: corners", ncomp_corner, "+ tail", ncomp_tail, "=", ncomp_corner + ncomp_tail)
check(ncomp_corner == 18 and ncomp_tail == 28, "18 + 28 = 46 comparisons")

# ---------------------------------------------------------------- G, anchored bound, Catalan line bound
def G(w, j, m):
    return C(m, j) - w * C(m, j - 1) - (1 - w) * C(m, j + 1)


def Nlo(c, h, e):
    if h == 2: return Fr(C(c, 2) - e)
    return Fr(max(0, C(c, h) - e * C(c - 2, h - 2)))


def Nhi(c, h, e):
    if h == 2: return Fr(C(c, 2) - e)
    return min(Fr(C(c, h)), Fr(C(c - 2, h - 2)) * (C(c, 2) - e) / C(h, 2))


def Bh(a, c, d, h, e):
    return (a - 1 - e) * C(c - 2, h - 1) + d * C(c - 2, h - 2)


def chord(w, a, k, h):
    j = k - h; M = a - h
    p = G(w, j, M)
    q = max([Fr(0)] + [(p - G(w, j, m)) / (M - m) for m in range(0, M)])
    return p, q


def anchored(w, n, a, k, e, lines):
    c, d = n - a, 2 * a - n
    val = G(w, k, a)                      # d_LR(0,a) = G_k(a)
    p1, q1 = lines(1)
    val += c * p1 - q1 * (a - 1 - e)
    for h in range(2, c + 1):
        p, q = lines(h)
        val += min(Nlo(c, h, e) * p, Nhi(c, h, e) * p) - q * Bh(a, c, d, h, e)
    return val


def B0(w, n, a, k, lines):                # fl:eq:B0
    c, d = n - a, 2 * a - n
    val = G(w, k, a) + sum(C(c, h) * lines(h)[0] for h in range(1, c + 1)) - lines(1)[1] * (a - 1)
    val -= sum(lines(h)[1] * ((a - 1) * C(c - 2, h - 1) + d * C(c - 2, h - 2)) for h in range(2, c + 1))
    return val


def Rstar(n, a, k, e):
    c, d = n - a, 2 * a - n
    val = Fr(C(a, k) - C(a, k - 1))
    for h in range(1, min(c, k - 1) + 1):
        if h == 1:
            Z = Fr((a - 2 * k + 2) * c - (a - 1 - e)); Nb = Fr(c)
        else:
            s = a - 2 * k + h + 1
            Z = min(s * Nlo(c, h, e), s * Nhi(c, h, e)) - Bh(a, c, d, h, e); Nb = Nhi(c, h, e)
        val += max(cat(k - h - 1) * max(-Nb, Z), cat(k - h) * Z)
    return val


# --- G tables v2.1 vs definition and vs v2.0
def gcells(tex, names, mstarts, ncols):
    out = {}
    for name, m0 in zip(names, mstarts):
        for r in rows(tex, name):
            j = int(r[0])
            for i, cell in enumerate(r[1:1 + ncols]):
                if cell.strip() == '':
                    continue
                out[(j, m0 + i)] = num(cell)
    return out


g21h = gcells(T21, ["GHalfA", "GHalfB"], [0, 9], 9)
g20h = gcells(T20, ["FlxGHalfA", "FlxGHalfB", "FlxGHalfC"], [0, 7, 14], 7)
g21f = gcells(T21, ["GFive"], [0], 13)
g20f = gcells(T20, ["FloorGFiveLow", "FloorGFiveHigh"], [0, 7], 7)
check(g21h == g20h, "G table w=1/2: v2.1 entries != v2.0 entries")
check(g21f == g20f, "G table w=5/12: v2.1 entries != v2.0 entries")
check(sorted(g21h) == [(j, m) for j in range(1, 9) for m in range(0, 18)], "G(1/2) covers j=1..8, m=0..17")
check(sorted(g21f) == [(j, m) for j in range(1, 7) for m in range(0, 13)], "G(5/12) covers j=1..6, m=0..12")
for (j, m), v in g21h.items():
    check(v == G(Fr(1, 2), j, m), f"G(1/2) j={j} m={m}")
for (j, m), v in g21f.items():
    check(v == G(Fr(5, 12), j, m), f"G(5/12) j={j} m={m}")
check(all(G(Fr(1, 2), j, m) == 2 * C(m, j) - Fr(1, 2) * C(m + 2, j + 1) for j in range(0, 12) for m in range(0, 30)),
      "Pascal form at w=1/2")
print("G tables: w=1/2", len(g21h), "entries, w=5/12", len(g21f), "entries; equal to v2.0 and to the definition")

# --- Catalan line bound (Prop flx:prop:line), table flx:tab:line
line_rows = rows(T21, "FlxLine"); line_tr = [triple(r[0]) for r in line_rows]
nvals_line = 0
for r in line_rows:
    t = triple(r[0]); n, a, k = t; c, d = n - a, 2 * a - n
    check(int(r[1]) == c and int(r[2]) == d and num(r[3]) == 2 * k - a, f"line c,d,2k-a at {t}")
    e0 = int(r[4]); v0 = num(r[5]); nb = [num(x) for x in r[6].split(',')]
    vals = {e: Rstar(n, a, k, e) for e in range(0, c)}
    check(vals[e0] == v0 and v0 > 0, f"R* at {t} e0={e0}: {v0} vs {vals[e0]}")
    neigh = [e for e in (e0 - 1, e0 + 1) if 0 <= e <= c - 1]
    check([vals[e] for e in neigh] == nb, f"R* neighbours at {t}")
    check(all(vals[e] >= v0 for e in neigh), f"R* local min at {t}")
    check(min(vals.values()) == v0, f"R* global min at {t}")
    check(k >= 2, f"k>=2 at {t}")
    nvals_line += 1 + len(neigh)
print("Catalan line bound: triples", len(line_rows), " values printed", nvals_line)
check(len(line_rows) == 8 and nvals_line == 21, "8 triples / 21 values of R*")
check(line_tr[0] == (24, 15, 7), "first row of line table is (24,15,7)")
check(sorted(line_tr[1:]) == sorted(t for t in line_tr[1:] if t in P4) and len(set(line_tr[1:])) == 7,
      "rows 2..8 of the line table are 7 triples of P4")
check(Rstar(22, 16, 8, 0) == 36 and Rstar(22, 16, 8, 1) == Fr(3518, 15), "Example flx:ex:catline 36, 3518/15")
check([Bh(16, 6, 10, h, 0) for h in range(2, 7)] == [70, 130, 120, 55, 10], "Example B_h(0) list")
check([(h + 1) * C(6, h) - Bh(16, 6, 10, h, 0) for h in range(2, 7)] == [-25, -50, -45, -19, -3], "Example second entries")
check([cat(j) for j in range(6, -1, -1)] == [132, 42, 14, 5, 2, 1, 1] and C(16, 8) - C(16, 7) == 1430 == cat(8),
      "Example Catalan numbers")
check(-42 * 15 - 14 * 20 - 5 * 15 - 2 * 6 - 1 == -998 and 132 * max(-6, 12 - 15) == -396 and Rr(16, 6, 8) == 1430 - 1790,
      "Example arithmetic")

# --- v2.1 line-set table (fl:tab:level): parse, compare with v2.0 (FloorLevelPQ + FlxLevel), recheck
def parse_sets_v21():
    fl = rows(T21, "PLineSets"); out = []
    i = 0
    while i < len(fl):
        rp, rq = fl[i], fl[i + 1]
        a, k = pair(rp[0]); w = num(rp[1])
        check('p^' in rp[2] and 'q^' in rq[2] and rq[0] == '' and rq[1] == '', f"line set row labels at {(a, k, w)}")
        ps = [x for x in rp[3:] if x.strip()]; qs = [x for x in rq[3:] if x.strip()]
        # the printed cells must be a prefix h=1..len (no holes)
        check(all(x.strip() for x in rp[3:3 + len(ps)]) and all(x.strip() for x in rq[3:3 + len(qs)]), f"holes at {(a, k, w)}")
        out.append(((a, k, w), [num(x) for x in ps], [num(x) for x in qs], ['^*' in x for x in ps], ['^*' in x for x in qs]))
        i += 2
    return out


sets21 = parse_sets_v21()
keys21 = [s[0] for s in sets21]
print("v2.1 line sets:", len(sets21), [(a, k, str(w)) for (a, k, w) in keys21])
check(len(sets21) == 15 and len(set(keys21)) == 15, "15 distinct line sets keyed by (a,k,w_L)")
check(keys21 == sorted(keys21, key=lambda x: (x[0], x[1], -x[2])) or True, "order (info)")
S21 = {s[0]: s for s in sets21}

# v2.0 chord table and v2.0 line sets
lv20 = rows(T20, "FloorLevelPQ"); chord20 = {}
i = 0
while i < len(lv20):
    rp, rq = lv20[i], lv20[i + 1]
    a, k = pair(rp[0]); w = num(rp[1])
    chord20[(a, k, w)] = ([num(x) for x in rp[3:] if x.strip()], [num(x) for x in rq[3:] if x.strip()],
                          ['^*' in x for x in rp[3:] if x.strip()])
    i += 2
fl20 = rows(T20, "FlxLevel"); set20 = {}
i = 0
while i < len(fl20):
    rp, rq = fl20[i], fl20[i + 1]
    sid = int(rp[0])
    m = re.match(r"\$\((\d+),(\d+)\)\$,\s*\$(\d+)/(\d+)\$", rp[1].strip())
    a, k = int(m.group(1)), int(m.group(2)); w = Fr(int(m.group(3)), int(m.group(4)))
    set20[sid] = ((a, k, w), [num(x) for x in rp[3:] if x.strip()], [num(x) for x in rq[3:] if x.strip()],
                  ['^*' in x for x in rp[3:] if x.strip()])
    i += 2
check(len(chord20) == 9 and len(set20) == 7, "v2.0: 9 chord rows, 7 line sets")
keys20 = set(chord20) | {v[0] for v in set20.values()}
check(keys20 == set(keys21), f"v2.1 set keys == union of v2.0 keys: {sorted(keys20 ^ set(keys21))}")
check(len(keys20) == 15, "v2.0 union has 15 keys ((13,7,1/2) shared)")
shared = set(chord20) & {v[0] for v in set20.values()}
print("keys in both v2.0 tables:", [(a, k, str(w)) for (a, k, w) in shared])
for key, (ps, qs, st) in chord20.items():
    (_, ps21, qs21, st21, sq21) = S21[key]
    check(ps21[:len(ps)] == ps and qs21[:len(qs)] == qs, f"v2.1 set {key} != v2.0 chord row")
    check(len(ps21) >= len(ps), f"v2.1 set {key} shorter than v2.0 chord row")
    check(not any(st21[:len(ps)]), f"v2.1 set {key}: star where v2.0 had a chord")
for sid, (key, ps, qs, st) in set20.items():
    (_, ps21, qs21, st21, sq21) = S21[key]
    check(ps21[:len(ps)] == ps and qs21[:len(qs)] == qs, f"v2.1 set {key} != v2.0 set {sid}")
    check(st21[:len(ps)] == st, f"v2.1 set {key}: stars differ from v2.0 set {sid}")
    extra = len(ps21) - len(ps)
    if extra:
        print(f"  v2.1 set {key} prints {extra} more levels than v2.0 set {sid} (from the v2.0 chord row)")
# exact list of differences in printed lengths
for key in keys21:
    _, ps21, qs21, st21, _ = S21[key]
    l20 = []
    if key in chord20: l20.append(("chord", len(chord20[key][0])))
    for sid, v in set20.items():
        if v[0] == key: l20.append((f"set{sid}", len(v[1])))
    print(f"  {key[0]:>2},{key[1]:>2},{str(key[2]):>5}: v2.1 prints h=1..{len(ps21)}; v2.0: {l20}")

# --- recheck every line set from the definitions
def hull_status(w, a, k, h, p, q):
    j = k - h; M = a - h
    pts = [(m, G(w, j, m)) for m in range(0, M + 1)]
    valid = all(Gm >= p - q * (M - m) for m, Gm in pts)
    touch = [m for m, Gm in pts if Gm == p - q * (M - m)]
    edge = len(touch) >= 2
    horiz = (q == 0 and min(Gm for _, Gm in pts) == p)
    return valid, edge, horiz


nonchord_sets = []
for key in keys21:
    (a, k, w), ps, qs, st, sq = S21[key]
    check(len(ps) == len(qs), f"set {key}: p and q rows of equal length")
    check(not any(sq), f"set {key}: an asterisk on a q entry")
    check(len(ps) in (k - 1, k + 1), f"set {key}: printed length {len(ps)} not k-1 or k+1")
    for h in range(1, len(ps) + 1):
        p, q = ps[h - 1], qs[h - 1]
        valid, edge, horiz = hull_status(w, a, k, h, p, q)
        check(valid and q >= 0, f"set {key} h={h}: line not valid (fl:eq:line) or q<0")
        pc, qc = chord(w, a, k, h)
        if st[h - 1]:
            check(h <= k - 1, f"set {key}: asterisk at h={h} >= k")
            check(edge or horiz, f"set {key} h={h}: starred line neither hull edge nor horizontal through lowest point")
            check(p < pc and q < qc, f"set {key} h={h}: starred line not below chord in p and q")
        else:
            check((p, q) == (pc, qc), f"set {key} h={h}: unstarred entry is not the chord")
    if any(st): nonchord_sets.append(key)
    for h in (k, k + 1):  # caption closed forms
        pc, qc = chord(w, a, k, h)
        cap = (1 - (1 - w) * (a - k), Fr(0)) if h == k else (-(1 - w), Fr(0))
        check((pc, qc) == cap, f"set {key}: caption closed form at h={h}")
        if len(ps) >= h:
            check((ps[h - 1], qs[h - 1]) == cap, f"set {key}: printed h={h} != caption closed form")
print("line sets with an asterisk:", nonchord_sets)


def line_of(key):
    (a, k, w), ps, qs, st, sq = S21[key]

    def L(h):
        if h <= len(ps): return ps[h - 1], qs[h - 1]
        if h == k: return 1 - (1 - w) * (a - k), Fr(0)
        if h == k + 1: return -(1 - w), Fr(0)
        if h >= k + 2: return Fr(0), Fr(0)
        raise ValueError(f"level h={h} of set {key} not defined by table or caption")
    return L


# --- values table (fl:tab:values) v2.1: parse the two-column rows
vrows = []
for r in rows(T21, "PValues"):
    check(len(r) == 14, f"values row has {len(r)} cells")
    for side, half in (("L", r[:7]), ("R", r[7:])):
        if not half[0].strip():
            continue
        vrows.append((side, half))
check(len(vrows) == 35, "35 rows in values table")
left = [triple(h[0]) for s, h in vrows if s == "L"]; right = [triple(h[0]) for s, h in vrows if s == "R"]
check(len(left) == 18 and all(t[0] <= 20 for t in left), "left column: 18 with n<=20")
check(len(right) == 17 and all(21 <= t[0] <= 24 for t in right), "right column: 17 with 21<=n<=24")
val_tr = left + right
check(len(set(val_tr)) == 35, "values table triples distinct")
check(sorted(val_tr + line_tr[1:]) == sorted(P4), "values table (35) + line rows 2..8 (7) == P4 (42)")
check(not set(val_tr) & set(line_tr), "values and line tables disjoint")

# compare with v2.0 tables
z20 = {triple(r[0]): r for r in rows(T20, "FloorZValues")}
an20 = {triple(r[0]): r for r in rows(T20, "FlxAnchored")}
check(set(left) == set(z20) and set(right) == set(an20), "v2.1 value triples == v2.0 FloorZValues / FlxAnchored")
setkey20 = {sid: v[0] for sid, v in set20.items()}
nvals_anch = 0; emin_nonzero = []
for side, hr in vrows:
    t = triple(hr[0]); n, a, k = t; c, d = n - a, 2 * a - n
    w = num(hr[3]); e0 = int(hr[4]); v0 = num(hr[5]); nb = [num(x) for x in hr[6].split(',')]
    check(int(hr[1]) == c and int(hr[2]) == d, f"values c,d at {t}")
    if t in z20:
        r0 = z20[t]
        check(num(r0[3]) == w and int(r0[1]) == c and int(r0[2]) == d, f"v2.0 Z row c,d,w at {t}")
        check(e0 == 0 and v0 == num(r0[4]) and nb == [num(r0[5])], f"v2.1 values at {t} differ from v2.0 Z row")
    else:
        r0 = an20[t]
        check(num(r0[3]) == w and int(r0[1]) == c and int(r0[2]) == d, f"v2.0 anchored row c,d,w at {t}")
        check(setkey20[int(r0[4])] == (a, k, w), f"v2.0 set number at {t} is keyed by (a,k,w)")
        check(e0 == int(r0[5]) and v0 == num(r0[6]) and nb == [num(x) for x in r0[7].split(',')],
              f"v2.1 values at {t} differ from v2.0 anchored row")
    key = (a, k, w)
    check(key in S21, f"no line set for {t} key {key}")
    check(a >= k + 2, f"a>=k+2 at {t}")
    L = line_of(key)
    hmax = min(c, a - 1, k + 1)
    check(hmax == min(c, k + 1), f"min(a-1,k+1)=k+1 at {t}")
    # table/caption must define every level h<=min(c,k+1)
    _, ps, qs, st, sq = S21[key]
    need = [h for h in range(1, hmax + 1) if h > len(ps) and h not in (k, k + 1)]
    check(not need, f"levels {need} of {t} not printed and not given by caption")
    vals = {e: anchored(w, n, a, k, e, L) for e in range(0, c)}
    check(vals[e0] == v0 and v0 > 0, f"A at {t}: {v0} vs {vals[e0]}")
    neigh = [e for e in (e0 - 1, e0 + 1) if 0 <= e <= c - 1]
    check([vals[e] for e in neigh] == nb, f"A neighbours at {t}: {nb} vs {[vals[e] for e in neigh]}")
    check(all(vals[e] >= v0 for e in neigh), f"A local min at {t}")
    check(min(vals.values()) == v0, f"A global min at {t}")
    check(B0(w, n, a, k, L) == vals[0], f"fl:eq:B0 == A(0) at {t}")
    nvals_anch += 1 + len(neigh)
    if e0: emin_nonzero.append((t, e0))
print("anchored values printed:", nvals_anch, "; triples with e_min>0:", emin_nonzero)
check(nvals_anch == 74, "74 anchored values")
used_keys = sorted({(triple(hr[0])[1], triple(hr[0])[2], num(hr[3])) for s, hr in vrows})
check(set(used_keys) == set(keys21), "every line set is used, and only these")
nine = sorted({(triple(hr[0])[1], triple(hr[0])[2], num(hr[3])) for s, hr in vrows if triple(hr[0])[0] <= 20})
printed_long = sorted(key for key in keys21 if len(S21[key][1]) == key[1] + 1)
print("sets used by n<=20:", len(nine), "; sets printed to h=k+1:", len(printed_long))
check(nine == printed_long and len(nine) == 9, "caption: the nine sets used by n<=20 are those printed at h=k,k+1")

# Example fl:ex:1284 and the 'chords alone do not suffice' sentence after Prop class4
check(anchored(Fr(1, 2), 12, 8, 4, 0, lambda h: chord(Fr(1, 2), 8, 4, h)) == Fr(105, 4), "Example (12,8,4) A(0)=105/4")
check(anchored(Fr(1, 2), 12, 8, 4, 1, lambda h: chord(Fr(1, 2), 8, 4, h)) == 28, "Example (12,8,4) A(1)=28")
check(G(Fr(1, 2), 4, 8) == 14 and [chord(Fr(1, 2), 8, 4, h) for h in (1, 2, 3, 4)] ==
      [(7, Fr(9, 4)), (2, Fr(1, 2)), (Fr(-1, 2), 0), (-1, 0)], "Example (12,8,4) chord numbers")
check((G(Fr(1, 2), 3, 7) - G(Fr(1, 2), 3, 5)) / 2 == Fr(9, 4) and (G(Fr(1, 2), 2, 6) - G(Fr(1, 2), 2, 2)) / 4 == Fr(1, 2),
      "Example (12,8,4) steepest chords")
grid = [Fr(i, 24) for i in range(25)]
for t in [(23, 14, 8), (24, 14, 8), (24, 15, 8), (24, 17, 9)]:
    n, a, k = t
    best = max(min(anchored(w, n, a, k, e, (lambda h, w=w: chord(w, a, k, h))) for e in range(0, n - a)) for w in grid)
    check(best <= 0, f"chords suffice at {t} for some w=i/24 (best {best})")

# ---------------------------------------------------------------- the counts of 6.5
by_hand = (len(P1) - 1) + len(P2) + len(P3)
print("settled by hand:", by_hand, "(P1 rising", len(P1) - 1, "+ P2", len(P2), "+ P3", len(P3), ")",
      "; Catalan line bound:", len(line_tr), "; anchored:", len(val_tr))
check(by_hand == 206 and len(line_tr) == 8 and len(val_tr) == 35 and by_hand + 8 + 35 == 249, "206 + 8 + 35 = 249")
check(len(P4) == 42 and len(line_tr) - 1 == 7, "P4 = 7 + 35")
print("values of R* + A:", nvals_line, "+", nvals_anch, "=", nvals_line + nvals_anch)

print()
print("CHECKS RUN:", NCHECK[0])
print("FAILURES:", len(FAIL))
print("RESULT:", "ALL CHECKS PASS" if not FAIL else "SOME CHECKS FAIL")
sys.exit(0 if not FAIL else 1)
