#!/usr/bin/env python3
"""Referee B (v2.0, 1 Oct 2026): independent exact check of Section 6 and Appendix B of TWIN v2.0.

Written from the statements of v2.0 (s6_part_a/b/c.tex, apx_p1_tables.tex) only. Standard library, exact arithmetic.
The v2.0 table macros (head of s6_part_b.tex) are parsed only to COMPARE them with values recomputed here.
Exit status 0 iff every check passes.
"""
import re, sys
from fractions import Fraction as Fr
from math import comb

BASE = "/Users/kvallier/Desktop/Erdos 993/ProofRuns/2026-09-28_analytic_large_n/LEAN/for_tong/TWIN_v2.0/"
TEX = open(BASE + "s6_part_b.tex").read()
FAIL = []

def check(cond, msg):
    if not cond:
        FAIL.append(msg); print("MISMATCH:", msg)

def C(r, t):
    return comb(r, t) if (r >= 0 and 0 <= t <= r) else 0

def cat(j):
    return C(2*j, j)//(j+1) if j >= 0 else 0

def cdiv(x, y):
    return -((-x)//y)

# ---------------------------------------------------------------- macros
def macro(name):
    m = re.search(r"\\newcommand\{\\" + name + r"\}\{%?\n(.*?)\n\}", TEX, re.S)
    assert m, name
    return m.group(1)

def num(s):
    s = s.replace('$', '').replace('^*', '').replace('{', '').replace('}', '').strip()
    s = s.replace('\\tfrac', '').replace('\\frac', '')
    return Fr(s)

def rows(name):
    out = []
    for line in macro(name).split('\\\\'):
        line = line.strip()
        line = re.sub(r"^\[2pt\]", "", line).strip()
        if not line:
            continue
        out.append([c.strip() for c in line.split('&')])
    return out

def triple(s):
    m = re.match(r"\$\((\d+),(\d+),(\d+)\)\$", s.strip())
    return tuple(int(x) for x in m.groups())

def pair(s):
    m = re.match(r"\$\((\d+),(\d+)\)\$", s.strip())
    return tuple(int(x) for x in m.groups())

# ---------------------------------------------------------------- the parameter set
def H(n, a):
    return cdiv(n + 2*a, 6)

D24 = [(n, a, k) for n in range(1, 25) for a in range(cdiv(n, 2), n)
       for k in range(cdiv(n, 4) + 1, min(a, H(n, a)))]
print("|D24| =", len(D24))
check(len(D24) == 249, "|D24| != 249")
per_n = {n: sum(1 for t in D24 if t[0] == n) for n in range(1, 25)}
printed = dict(zip(range(7, 25), [1, 2, 1, 2, 5, 7, 5, 7, 12, 15, 12, 15, 21, 25, 22, 26, 33, 38]))
for n in range(1, 25):
    check(per_n[n] == printed.get(n, 0), f"per-n count n={n}: {per_n[n]} vs {printed.get(n, 0)}")
check(sum(per_n[n] for n in range(1, 21)) == 130, "130 with n<=20")
check(all(per_n[n] == 0 for n in range(1, 7)), "none with n<=6")
check(all(H(n, a) <= a for n in range(1, 25) for a in range(cdiv(n, 2), n)), "H<=a")

def bco(n, a):
    c, d = n - a, 2*a - n
    return [sum(C(c, i) * 2**i * C(d, r - i) for i in range(c + 1)) for r in range(a + 2)]

def hB(n, a):
    b = bco(n, a); return b.index(max(b))

check(all(hB(n, a) <= H(n, a) for n in range(2, 25) for a in range(cdiv(n, 2), n)), "h_B <= H (Prop inputs(c))")

# ---------------------------------------------------------------- corner tables
c1 = {}; c2 = {}
for r in rows("FlxCornersOne"):
    k = int(r[0]); A, cc = pair(r[1]); c1[k] = cc
    check(A == 2*k + 1, f"corner1 a at k={k}")
    check(int(r[2]) == cat(k + 1), f"corner1 Cat at k={k}")
    s = sum(C(cc, h) * cat(k - 1 - h) for h in range(1, min(cc, k - 1) + 1))
    check(int(r[3]) == s, f"corner1 sum at k={k}: {r[3]} vs {s}")
    check(cat(k + 1) > s, f"corner1 positive at k={k}")
    check(C(2*k+1, k) - C(2*k+1, k-1) == cat(k+1), f"catlead a=2k+1 k={k}")
for r in rows("FlxCornersTwo"):
    k = int(r[0]); A, cc = pair(r[1]); c2[k] = cc
    check(A == 2*k, f"corner2 a at k={k}")
    check(int(r[2]) == cat(k), f"corner2 Cat at k={k}")
    s = sum(C(cc, h) * cat(k - 1 - h) for h in range(1, min(cc, k - 1) + 1))
    check(int(r[3]) == s, f"corner2 sum at k={k}: {r[3]} vs {s}")
    check(cat(k) > s, f"corner2 positive at k={k}")
    check(C(2*k, k) - C(2*k, k-1) == cat(k), f"catlead a=2k k={k}")
print("c1 =", [c1[k] for k in sorted(c1)], " c2 =", [c2[k] for k in sorted(c2)])
check(sorted(c1) == list(range(3, 12)) and sorted(c2) == list(range(3, 12)), "corner rows k=3..11")
# maximality (not needed for the proof; informational)
for k in range(3, 12):
    s1 = sum(C(c1[k]+1, h)*cat(k-1-h) for h in range(1, min(c1[k]+1, k-1)+1))
    s2 = sum(C(c2[k]+1, h)*cat(k-1-h) for h in range(1, min(c2[k]+1, k-1)+1))
    print(f"  k={k}: c1 maximal? {cat(k+1) <= s1}; c2 maximal? {cat(k) <= s2}  (R(2k,c2+1,k) = {cat(k)-s2})")

# ---------------------------------------------------------------- classes
P1 = [t for t in D24 if 2*t[2] <= t[1] - 1]
P2 = [t for t in D24 if t[1] == 2*t[2] and (t[0]-t[1]) <= c2.get(t[2], -1)]
rest = [t for t in D24 if t not in P1 and t not in P2]
P3 = [t for t in rest if t[2] >= hB(t[0], t[1])]
P4 = [t for t in rest if t not in P3]
print("classes:", len(P1), len(P2), len(P3), len(P4))
check((len(P1), len(P2), len(P3), len(P4)) == (145, 34, 28, 42), "class counts 145/34/28/42")
check(all(t[2] < hB(t[0], t[1]) for t in P4), "every P4 triple has k < h_B")
# P1 claim: 3<=k<=11 and c<=c1(k) except (24,15,7)
exc = [t for t in P1 if not (3 <= t[2] <= 11 and t[0]-t[1] <= c1[t[2]])]
print("P1 exceptions:", exc)
check(exc == [(24, 15, 7)], "P1 exception set")
for k in range(3, 12):
    bound = min(24, 4*k - 4) - (2*k + 1)
    check((bound <= c1[k]) == (k != 7), f"class1 proof bound at k={k}: {bound} vs c1={c1[k]}")
check(all(t[0] >= 7 for t in D24), "n>=7 on D24")
# P2 list
p2list = [tuple(int(x) for x in m) for m in re.findall(r"\((\d+),(\d+),(\d+)\)", macro("PTwoList"))]
check(sorted(p2list) == sorted(P2), "P2 printed list")
check(len(p2list) == 34, "34 in P2 list")
# Rising bound check for every P1 (non-exception) and P2 triple directly
def Rr(a, c, k):
    return C(a, k) - C(a, k-1) - sum(C(c, h)*cat(k-1-h) for h in range(1, min(c, k-1)+1))
check(all(Rr(t[1], t[0]-t[1], t[2]) > 0 for t in P1 if t != (24, 15, 7)), "R>0 on P1 minus exception (direct)")
check(all(Rr(t[1], t[0]-t[1], t[2]) > 0 for t in P2), "R>0 on P2 (direct)")
check(Rr(15, 9, 7) == -334, "R(15,9,7) = -334")
check(sum(C(9, h)*cat(6-h) for h in range(1, 7)) == 1764, "1764")
# The 'R>0 rule' (v1.8 21..26) and the c<=c2 rule agree on a=2k triples of D24
a2k = [t for t in D24 if t[1] == 2*t[2]]
check(sorted([t for t in a2k if Rr(t[1], t[0]-t[1], t[2]) > 0]) == sorted(P2), "R>0 rule == c<=c2 rule on a=2k")
print("a=2k triples in D24:", len(a2k))
# tail table
tail = rows("PTail")
tl = []
for r in tail:
    t = triple(r[0]); tl.append(t)
    n, a, k = t; c, d = n-a, 2*a-n; b = bco(n, a)
    check(int(r[1]) == c and int(r[2]) == d, f"tail c,d at {t}")
    check(int(r[3]) == b[k] and int(r[4]) == b[k+1], f"tail b at {t}: {r[3]},{r[4]} vs {b[k]},{b[k+1]}")
    check(b[k+1] <= b[k], f"tail b_(k+1)<=b_k at {t}")
check(sorted(tl) == sorted(P3), "tail table == P3")
two = rows("PTailTwoCol")
flat = []
for r in two:
    flat.append(r[:5]); flat.append(r[5:])
check([x[0] for x in flat] == [x[0] for x in tail] or sorted(triple(x[0]) for x in flat) == sorted(tl), "two-column tail table == tail")
check(all(any(f == t for t in tail) for f in flat), "two-column tail rows equal tail rows")
# breakdown
bd = rows("PBreakdown")
def cols(lst):
    return (len(lst), sum(1 for t in lst if t[1] == 2*t[2]), sum(1 for t in lst if t[2] < hB(t[0], t[1])),
            sum(1 for t in lst if t[2] >= hB(t[0], t[1])))
line_rows = rows("FlxLine"); line_tr = [triple(r[0]) for r in line_rows]
z_rows = rows("FloorZValues"); z_tr = [triple(r[0]) for r in z_rows]
an_rows = rows("FlxAnchored"); an_tr = [triple(r[0]) for r in an_rows]
P1main = [t for t in P1 if t != (24, 15, 7)]
groups = [P1main, [(24, 15, 7)], P2, P3, [t for t in line_tr if t != (24, 15, 7)], z_tr, an_tr]
for g, r in zip(groups, bd[:7]):
    exp = tuple(int(x) for x in r[2:6])
    check(cols(g) == exp, f"breakdown row {r[0]} {r[1]}: {cols(g)} vs {exp}")
check(sorted(sum(groups[4:], [])) == sorted(P4), "line(7)+Z(18)+anchored(17) == P4")
check(len(set(sum(groups[4:], []))) == 42, "P4 tables disjoint")
check(all(t[0] <= 20 for t in z_tr) and len(z_tr) == 18, "Z table = 18 with n<=20")
check(all(21 <= t[0] <= 24 for t in an_tr) and len(an_tr) == 17, "anchored table = 17 with 21<=n<=24")
check(sorted(t for t in P4 if t[0] <= 20) == sorted(z_tr), "Z table = P4 with n<=20")
tot = cols(D24)
check(tot == (249, 50, 203, 46), f"breakdown total {tot}")
print("breakdown total:", tot)

# ---------------------------------------------------------------- G, anchored, lines
def G(w, j, m):
    return C(m, j) - w*C(m, j-1) - (1-w)*C(m, j+1)

def Nlo(c, h, e):
    if h == 2: return Fr(C(c, 2) - e)
    return Fr(max(0, C(c, h) - e*C(c-2, h-2)))

def Nhi(c, h, e):
    if h == 2: return Fr(C(c, 2) - e)
    return min(Fr(C(c, h)), Fr(C(c-2, h-2)) * (C(c, 2) - e) / C(h, 2))

def Bh(a, c, d, h, e):
    return (a-1-e)*C(c-2, h-1) + d*C(c-2, h-2)

def chord(w, a, k, h):
    j = k - h; M = a - h
    p = G(w, j, M)
    q = max([Fr(0)] + [(p - G(w, j, m)) / (M - m) for m in range(0, M)])
    return p, q

def anchored(w, n, a, k, e, lines):
    c, d = n-a, 2*a-n
    val = G(w, k, a)
    p1, q1 = lines(1)
    val += c*p1 - q1*(a-1-e)
    for h in range(2, c+1):
        p, q = lines(h)
        val += min(Nlo(c, h, e)*p, Nhi(c, h, e)*p) - q*Bh(a, c, d, h, e)
    return val

def Rstar(n, a, k, e):
    c, d = n-a, 2*a-n
    val = Fr(C(a, k) - C(a, k-1))
    for h in range(1, min(c, k-1)+1):
        if h == 1:
            Z = Fr((a-2*k+2)*c - (a-1-e)); Nb = Fr(c)
        else:
            s = a-2*k+h+1
            Z = min(s*Nlo(c, h, e), s*Nhi(c, h, e)) - Bh(a, c, d, h, e); Nb = Nhi(c, h, e)
        val += max(cat(k-h-1)*max(-Nb, Z), cat(k-h)*Z)
    return val

# G tables, w = 1/2 (j = 1..8, m = 0..17) and w = 5/12 (j = 1..6, m = 0..12)
def gtable(names, mstarts, w, ncols):
    for name, m0 in zip(names, mstarts):
        for r in rows(name):
            j = int(r[0])
            for i, cell in enumerate(r[1:1+ncols]):
                if cell.strip() == '':
                    continue
                check(num(cell) == G(w, j, m0+i), f"G table w={w} j={j} m={m0+i}: {cell} vs {G(w, j, m0+i)}")
gtable(["FlxGHalfA", "FlxGHalfB", "FlxGHalfC"], [0, 7, 14], Fr(1, 2), 7)
gtable(["FloorGFiveLow", "FloorGFiveHigh"], [0, 7], Fr(5, 12), 7)
check(all(G(Fr(1, 2), j, m) == 2*C(m, j) - Fr(1, 2)*C(m+2, j+1) for j in range(0, 12) for m in range(0, 30)), "Pascal form of G at w=1/2")

# level table of the anchored bound (chords)
lv = rows("FloorLevelPQ")
i = 0; lvl = {}
while i < len(lv):
    rp, rq = lv[i], lv[i+1]
    a, k = pair(rp[0]); w = num(rp[1])
    ps = [x for x in rp[3:] if x.strip()]; qs = [x for x in rq[3:] if x.strip()]
    hmax = min(a-1, k+1)
    check(len(ps) == hmax and len(qs) == hmax, f"level table length at {(a, k, w)}")
    for h in range(1, hmax+1):
        p, q = chord(w, a, k, h)
        check(num(ps[h-1]) == p and num(qs[h-1]) == q, f"level table {(a, k, w)} h={h}: {ps[h-1]},{qs[h-1]} vs {p},{q}")
    lvl[(a, k, w)] = True
    i += 2
print("level table rows:", len(lvl))
check(len(lvl) == 9, "nine (a,k,w) in level table")
# Z values (Prop class4(a))
zs = set()
for r in z_rows:
    t = triple(r[0]); n, a, k = t; c, d = n-a, 2*a-n; w = num(r[3])
    zs.add((a, k, w))
    check(int(r[1]) == c and int(r[2]) == d, f"Z c,d at {t}")
    L = lambda h, w=w, a=a, k=k: chord(w, a, k, h)
    A0 = anchored(w, n, a, k, 0, L); A1 = anchored(w, n, a, k, 1, L)
    check(num(r[4]) == A0 and num(r[5]) == A1, f"Z values at {t}: {r[4]},{r[5]} vs {A0},{A1}")
    check(A0 > 0 and A1 >= A0, f"Z positivity/convexity at {t}")
    allv = [anchored(w, n, a, k, e, L) for e in range(0, c)]
    check(min(allv) == A0 and min(allv) > 0, f"Z global min at {t}")
check(zs == set(lvl), "level table = the (a,k,w) of the Z triples")

# Catalan line bound (Prop flx:prop:line)
nvals = 0
for r in line_rows:
    t = triple(r[0]); n, a, k = t; c, d = n-a, 2*a-n
    check(int(r[1]) == c and int(r[2]) == d and num(r[3]) == 2*k-a, f"line c,d,2k-a at {t}")
    e0 = int(r[4]); v0 = num(r[5]); nb = [num(x) for x in r[6].split(',')]
    vals = {e: Rstar(n, a, k, e) for e in range(0, c)}
    check(vals[e0] == v0 and v0 > 0, f"R* at {t} e0={e0}: {v0} vs {vals[e0]}")
    neigh = [e for e in (e0-1, e0+1) if 0 <= e <= c-1]
    check([vals[e] for e in neigh] == nb, f"R* neighbours at {t}: {nb} vs {[vals[e] for e in neigh]}")
    check(all(vals[e] >= v0 for e in neigh), f"R* local min at {t}")
    check(min(vals.values()) == v0, f"R* global min at {t}")
    nvals += 1 + len(neigh)
print("R* values printed:", nvals)
check(nvals == 21, "21 values of R*")
check(Rstar(22, 16, 8, 0) == 36 and Rstar(22, 16, 8, 1) == Fr(3518, 15), "Example flx:ex:catline")

# line sets
fl = rows("FlxLevel")
sets = {}
i = 0
while i < len(fl):
    rp, rq = fl[i], fl[i+1]
    sid = int(rp[0])
    m = re.match(r"\$\((\d+),(\d+)\)\$,\s*\$(\d+)/(\d+)\$", rp[1].strip())
    a, k = int(m.group(1)), int(m.group(2)); w = Fr(int(m.group(3)), int(m.group(4)))
    ps = [x for x in rp[3:] if x.strip()]; qs = [x for x in rq[3:] if x.strip()]
    star = ['^*' in x for x in ps]
    check(len(ps) == k-1 and len(qs) == k-1, f"line set {sid} length")
    sets[sid] = (a, k, w, [num(x) for x in ps], [num(x) for x in qs], star)
    i += 2
check(sorted(sets) == list(range(1, 8)), "7 line sets")
def lowerhull_ok(w, a, k, h, p, q):
    j = k-h; M = a-h
    pts = [(m, G(w, j, m)) for m in range(0, M+1)]
    # the line y = p - q (M - m); validity
    valid = all(Gm >= p - q*(M-m) for m, Gm in pts)
    touch = [m for m, Gm in pts if Gm == p - q*(M-m)]
    edge = len(touch) >= 2
    horiz = (q == 0 and min(Gm for _, Gm in pts) == p)
    return valid, edge, horiz
for sid, (a, k, w, ps, qs, star) in sets.items():
    for h in range(1, k):
        p, q = ps[h-1], qs[h-1]
        valid, edge, horiz = lowerhull_ok(w, a, k, h, p, q)
        check(valid and q >= 0, f"line set {sid} h={h} invalid line")
        pc, qc = chord(w, a, k, h)
        if star[h-1]:
            check(edge or horiz, f"line set {sid} h={h}: starred line not a hull edge / horizontal through lowest point")
            check(p < pc and q < qc, f"line set {sid} h={h}: starred line not below chord in p and q")
        else:
            check((p, q) == (pc, qc), f"line set {sid} h={h}: unstarred entry is not the chord")
    for h in (k, k+1):
        pc, qc = chord(w, a, k, h)
        cap = (1 - (1-w)*(a-k), Fr(0)) if h == k else (-(1-w), Fr(0))
        check((pc, qc) == cap, f"line set {sid}: caption closed form at h={h}")
nonchord = sorted(s for s in sets if any(sets[s][5]))
print("line sets with a non-chord line:", nonchord)
# anchored triples with line sets (Prop class4(b))
for r in an_rows:
    t = triple(r[0]); n, a, k = t; c, d = n-a, 2*a-n
    w = num(r[3]); sid = int(r[4]); e0 = int(r[5]); v0 = num(r[6]); nb = [num(x) for x in r[7].split(',')]
    check(int(r[1]) == c and int(r[2]) == d, f"anchored c,d at {t}")
    sa, sk, sw, ps, qs, star = sets[sid]
    check((sa, sk, sw) == (a, k, w), f"anchored {t}: line set {sid} is for {(sa, sk, sw)}")
    check(a >= k+2, f"a>=k+2 at {t}")
    def L(h, a=a, k=k, w=w, ps=ps, qs=qs):
        if h <= k-1: return ps[h-1], qs[h-1]
        if h == k: return 1-(1-w)*(a-k), Fr(0)
        if h == k+1: return -(1-w), Fr(0)
        return Fr(0), Fr(0)
    vals = {e: anchored(w, n, a, k, e, L) for e in range(0, c)}
    check(vals[e0] == v0 and v0 > 0, f"A# at {t}: {v0} vs {vals[e0]}")
    neigh = [e for e in (e0-1, e0+1) if 0 <= e <= c-1]
    check([vals[e] for e in neigh] == nb, f"A# neighbours at {t}: {nb} vs {[vals[e] for e in neigh]}")
    check(min(vals.values()) == v0, f"A# global min at {t}")
# which anchored triples use a non-chord set; Remark (i), 'two additions' (9 triples)
grid = [Fr(i, 24) for i in range(25)]
def chordmin(t, w):
    n, a, k = t; c = n-a
    L = lambda h: chord(w, a, k, h)
    return min(anchored(w, n, a, k, e, L) for e in range(0, c))
uses_nonchord = [t for r, t in zip(an_rows, an_tr) if int(r[4]) in nonchord]
print("anchored triples using a non-chord line set:", len(uses_nonchord))
check(len(uses_nonchord) == 13, "13 anchored triples use non-chord lines")
remark_i = [(23, 14, 8), (24, 14, 8), (24, 15, 8), (24, 17, 9)]
for t in an_tr:
    best = max(chordmin(t, w) for w in grid)
    if t in remark_i:
        check(best <= 0, f"Remark (i): chords positive on the grid at {t} (best {best})")
    else:
        check(best > 0, f"chords fail on the grid at {t} (best {best}); text says chords suffice")
check(set(remark_i) <= set(uses_nonchord), "Remark (i) triples use non-chord lines")
print("non-chord triples where chords would suffice:", len([t for t in uses_nonchord if t not in remark_i]))
check(len([t for t in uses_nonchord if t not in remark_i]) == 9, "9 triples where chords suffice")
# (24,17,9), w = 31/96
w = Fr(31, 96); t = (24, 17, 9); n, a, k = t
L = lambda h: chord(w, a, k, h)
A0 = anchored(w, n, a, k, 0, L); A1 = anchored(w, n, a, k, 1, L)
check(A0 == Fr(1405, 48) and A1 >= A0, f"Remark (i) 31/96: {A0}, {A1}")
# Remark (iii): which Z triples does R* settle
settled = [t for t in z_tr if min(Rstar(t[0], t[1], t[2], e) for e in range(0, t[0]-t[1])) > 0]
print("Z triples settled by R*:", settled)
check(sorted(settled) == sorted([(12, 8, 4), (15, 10, 5), (16, 9, 5), (16, 10, 5), (17, 12, 6), (18, 12, 6),
                                 (19, 12, 6), (20, 11, 6), (20, 12, 6), (20, 14, 7)]), "Remark (iii) list")
# R* also on anchored 21..24 triples? (informational)
an_settled = [t for t in an_tr if min(Rstar(t[0], t[1], t[2], e) for e in range(0, t[0]-t[1])) > 0]
print("anchored (21..24) triples settled by R* (info):", an_settled)
# Example fl:ex:1284
check(anchored(Fr(1, 2), 12, 8, 4, 0, lambda h: chord(Fr(1, 2), 8, 4, h)) == Fr(105, 4), "Example 12,8,4")
print()
print("FAILURES:", len(FAIL))
print("RESULT:", "ALL CHECKS PASS" if not FAIL else "SOME CHECKS FAIL")
sys.exit(0 if not FAIL else 1)
