#!/usr/bin/env python3
"""Exploration (floor26): falling side alone (omega = 0) on the tabulated class: level payment and the subset bound."""
from fractions import Fraction as Q
from explore1 import C
from explore2 import Pval
from explore5 import AN
pos=[]
for t in AN:
    n,a,k=t; c=n-a
    v=min(Pval(Q(0),*t))
    SF=C(a,k)-C(a,k+1)-sum(C(c,h)*max(0,C(a-h,k-h+1)-C(a-h,k-h)) for h in range(1,c+1))
    if v>0: pos.append((t,float(v),SF))
print('omega=0 level payment positive at',len(pos),pos)
