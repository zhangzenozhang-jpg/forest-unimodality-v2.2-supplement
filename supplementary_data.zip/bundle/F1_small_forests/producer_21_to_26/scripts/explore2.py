#!/usr/bin/env python3
"""Exploration (floor26): level payment (convex minorant per level) on the triples the anchored bound misses."""
import sys
from fractions import Fraction as Q
from explore1 import C, cat, hB, dom, phi, f, level, B
def lower_hull(pts):
    H=[]
    for p in pts:
        while len(H)>=2 and (H[-1][1]-H[-2][1])*(p[0]-H[-2][0])>=(p[1]-H[-2][1])*(H[-1][0]-H[-2][0]): H.pop()
        H.append(p)
    return H
def psi(H,t):
    # nonincreasing convex minorant at t: min over hull at points <= t
    best=None
    for (x,y) in H:
        if x<=t: best=y if best is None else min(best,y)
    for (x1,y1),(x2,y2) in zip(H,H[1:]):
        if x1<=t<=x2:
            v=y1+(y2-y1)*(t-x1)/(x2-x1); best=v if best is None else min(best,v)
    return best
def levmin(H,lo,hi,X):
    X=Q(X); cands={lo,hi}|{X/x for (x,_) in H if x>0 and lo<=X/x<=hi}
    return min((Q(0) if K==0 else K*psi(H,X/K)) for K in cands)
def Pval(w,n,a,k):
    c,d=n-a,2*a-n
    Hs={h:lower_hull([(Q(x),Q(f(w,k,h,a-h-x))) for x in range(0,a-h+1)]) for h in range(1,c+1)}
    res=[]
    for e in range(0,c):
        tot=Q(f(w,k,0,a))+c*psi(Hs[1],Q(a-1-e,c))
        for h in range(2,c+1):
            if h==2: lo=hi=Q(C(c,2)-e)
            else: lo=Q(max(0,C(c,h)-e*C(c-2,h-2))); hi=min(Q(C(c,h)),Q(C(c-2,h-2)*(C(c,2)-e),C(h,2)))
            X=(a-1-e)*C(c-2,h-1)+d*C(c-2,h-2)
            tot+=levmin(Hs[h],lo,hi,X)
        res.append(tot)
    return res
OPEN=[(23,14,8),(24,14,8),(24,15,8),(24,17,9),(25,13,8),(25,14,8),(25,15,8),(25,16,9),(25,17,9),(26,13,8),(26,14,8),(26,15,8),(26,16,9),(26,17,9),(26,18,9),(26,19,10)]
if __name__=='__main__':
    grid=sorted(set(Q(i,j) for j in (1,2,3,4,5,6,8,10,12,24) for i in range(j+1)))
    for t in OPEN:
        n,a,k=t; best=None
        for w in grid:
            r=Pval(w,n,a,k); m=min(r)
            if best is None or m>best[1]: best=(w,m,r.index(m))
        print(t,'c=%d d=%d'%(n-a,2*a-n),'best omega',best[0],'P min',float(best[1]),'at e',best[2])
