#!/usr/bin/env python3
"""Exploration (floor26): anchored bound with lines chosen among hull edges (one line per level, fixed in e)."""
from fractions import Fraction as Q
from explore1 import C, hB, dom, phi, f, level, B
from explore2 import lower_hull, OPEN
def cand_lines(w,a,k,h):
    pts=[(Q(x),Q(f(w,k,h,a-h-x))) for x in range(0,a-h+1)]
    H=lower_hull(pts); L=set()
    for (x1,y1),(x2,y2) in zip(H,H[1:]):
        s=(y2-y1)/(x2-x1)
        if s<=0: L.add((y1-s*x1,-s))
    L.add((min(y for _,y in pts),Q(0)))
    for (p,q) in L: assert all(y>=p-q*x for x,y in pts)
    return sorted(L)
def Bl(w,n,a,k,e,lines):
    p={h:lines[h][0] for h in lines}; q={h:lines[h][1] for h in lines}
    return B(w,n,a,k,e,p,q)
def best_lines(w,n,a,k,iters=4):
    c=n-a; cands={h:cand_lines(w,a,k,h) for h in range(1,c+1)}
    # start: anchored chord = first candidate with max p
    lines={h:max(cands[h]) for h in cands}
    def score(L): return min(Bl(w,n,a,k,e,L) for e in range(c))
    s=score(lines)
    for _ in range(iters):
        improved=False
        for h in cands:
            for ln in cands[h]:
                if ln==lines[h]: continue
                L2=dict(lines); L2[h]=ln; s2=score(L2)
                if s2>s: s,lines,improved=s2,L2,True
        if not improved: break
    return s,lines
if __name__=='__main__':
    grid=sorted(set(Q(i,j) for j in (1,2,3,4,5,6,8,10,12,24) for i in range(j+1)))
    for t in OPEN:
        n,a,k=t; res=[]
        for w in grid:
            s,L=best_lines(w,n,a,k)
            if s>0: res.append((w,s))
        print(t,'omegas ok:',[str(w) for w,_ in res][:12], 'best', (str(max(res,key=lambda r:r[1])[0]), float(max(r[1] for r in res))) if res else None)
