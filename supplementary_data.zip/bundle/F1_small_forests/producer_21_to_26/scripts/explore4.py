#!/usr/bin/env python3
"""Exploration (floor26): which of the table-class triples does a closed-form Catalan line bound settle?"""
import sys
sys.path.insert(0,'../../floor/scripts')
from fractions import Fraction as Q
from explore1 import dom, hB, phi
import catalan_markov as cm
D=list(dom(21,26))
P4=[t for t in D if t[2]<hB(t[0],t[1]) and not ((2*t[2]<=t[1]-1 or t[1]==2*t[2]) and phi(t[1],t[0]-t[1],t[2])>0)]
print(len(P4))
ALS=sorted(set([Q(i,12) for i in range(13)]+[Q(i,20) for i in range(21)]+[Q(i,24) for i in range(25)]))
ok1=[];okany=[]
for t in P4:
    n,a,k=t
    v1=cm.Phi(Q(1),n,a,k)
    best=max((cm.Phi(al,n,a,k),al) for al in ALS)
    print(t,'delta',2*k-a,'c',n-a,'CM(1)=',v1,'best',best[1],float(best[0]))
    if v1>0: ok1.append(t)
    if best[0]>0: okany.append(t)
print('alpha=1 ok',len(ok1),ok1); print('any alpha ok',len(okany))
