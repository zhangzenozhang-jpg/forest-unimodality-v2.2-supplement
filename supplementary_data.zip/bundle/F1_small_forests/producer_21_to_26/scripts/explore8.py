#!/usr/bin/env python3
"""Exploration (floor26): the Catalan line bound as the anchored formula at omega = 1 with one closed-form line per
level (Catalan line or Catalan floor, fixed in e); and tangent lines of the rising function for (24,16,8)."""
from fractions import Fraction as Q
from itertools import product
from explore1 import C, cat, dom, hB, phi, B
import verify_floor26 as V
T=[(24,15,7),(26,17,8),(21,14,7),(22,14,7),(22,16,8),(23,14,7),(24,13,7),(24,14,7),(25,16,8),(26,16,8),
   (12,8,4),(15,10,5),(16,10,5),(17,12,6),(18,12,6),(19,12,6),(20,11,6),(20,12,6),(20,14,7)]
def lines_for(n,a,k,choice):
    p,q={},{}
    for h in range(1,n-a+1):
        if h<=k-1:
            j=k-h
            if choice[h-1]: p[h],q[h]=Q(cat(j-1)*(a-2*k+h+1)),Q(cat(j-1))
            else: p[h],q[h]=Q(-cat(j-1)),Q(0)
        elif h==k: p[h],q[h]=Q(1),Q(0)
        else: p[h],q[h]=Q(0),Q(0)
    return p,q
for t in T:
    n,a,k=t; c=n-a; L=min(c,k-1); best=None
    for ch in product((1,0),repeat=L):
        p,q=lines_for(n,a,k,ch)
        m=min(B(Q(1),n,a,k,e,p,q) for e in range(c))
        if best is None or m>best[0]: best=(m,ch)
    allline=min(B(Q(1),n,a,k,e,*lines_for(n,a,k,(1,)*L)) for e in range(c))
    print(t,'best fixed choice',float(best[0]),best[1],' all Catalan lines:',float(allline))
# tangent lines at omega=1 for (24,16,8)
def Rj(j,M): return C(M,j)-C(M,j-1)
n,a,k=24,16,8; c=n-a
cands={}
for h in range(1,min(c,k+1)+1):
    j=k-h; pts=[(x,Rj(j,a-h-x)) for x in range(0,a-h+1)]
    L=set([(Q(min(y for _,y in pts)),Q(0))])
    for M0 in range(0,a-h):
        s=Rj(j,M0+1)-Rj(j,M0)   # slope in M
        if s<0: continue
        pp=Q(Rj(j,M0))+s*(a-h-M0); qq=Q(s)
        if all(y>=pp-qq*x for x,y in pts): L.add((pp,qq))
    cands[h]=sorted(L)
best=None
import itertools
keys=sorted(cands)
lines={h:max(cands[h]) for h in keys}
def sc(L): return min(B(Q(1),n,a,k,e,{h:L[h][0] for h in L},{h:L[h][1] for h in L}) for e in range(c))
s=sc(lines)
for _ in range(6):
    for h in keys:
        for ln in cands[h]:
            L2=dict(lines); L2[h]=ln; s2=sc(L2)
            if s2>s: s,lines=s2,L2
print('(24,16,8) omega=1 tangent lines: min B =',float(s),{h:(str(lines[h][0]),str(lines[h][1])) for h in keys})
