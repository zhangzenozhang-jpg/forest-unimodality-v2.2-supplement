#!/usr/bin/env python3
"""Exploration (floor26): omega = 1/2 per-(a,k) line sets with per-triple fallback; (26,15,8) probe."""
from fractions import Fraction as Q
from collections import defaultdict
from explore1 import B
from explore2 import Pval
from explore3 import cand_lines
from explore5 import AN, G, score, search
half=Q(1,2)
print('P at 1/2 for (26,15,8):',[float(v) for v in Pval(half,26,15,8)])
sets={}
for (a,k),grp in sorted(G.items()):
    s0,s,nchg,lines=search(half,a,k,grp)
    if s>0: sets[(a,k)]=[(grp,lines,nchg)]; print((a,k),'group ok at 1/2, changed levels',nchg,'min',float(s)); continue
    lst=[]
    for t in grp:
        s0,s,nchg,lines=search(half,a,k,[t])
        print('  ',t,'alone at 1/2:',float(s0),float(s),nchg)
        lst.append(([t],lines,nchg,s))
    sets[(a,k)]=lst
