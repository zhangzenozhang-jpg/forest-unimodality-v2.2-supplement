#!/usr/bin/env python3
"""Referee fixes M1-M3 and S1-S10 on floor26_body.tex (after rename_shared_v2.py). 30 Sep 2026. Edits in place."""
import os
HERE = os.path.dirname(os.path.abspath(__file__))
fn = os.path.join(HERE, 'floor26_body.tex')
b = open(fn).read()

def rep(old, new):
    global b
    assert b.count(old) == 1, ('count %d: ' % b.count(old)) + old[:100]
    b = b.replace(old, new)

# S6: the four rules
rep("""with $21\\le n\\le26$; we split them by the rules of Section~\\ref{fl:sec:twenty}. Of the $192$ triples, $160$ are""",
    """with $21\\le n\\le26$; we split them by four rules which on $\\cD_{20}$ give the classes of
Section~\\ref{fl:sec:twenty}. Of the $192$ triples, $160$ are""")
# S2 (intro) and S8
rep("""Two arguments of Section~\\ref{fl:sec} do not extend unchanged. At $k=7$ and $k=8$ the corner inequality of
Proposition~\\ref{fl:prop:class1} fails for $n\\le26$; the two triples it misses are settled by a sharper rising
bound, the Catalan line bound of Proposition~\\ref{flx:prop:catbound}.""",
    """Two arguments of Section~\\ref{fl:sec} do not extend unchanged. At $k=7$ and $k=8$ the Catalan inequality of
Proposition~\\ref{fl:prop:class1}, extended to $n\\le26$, fails; the two triples it misses are settled by a sharper
rising bound, the Catalan line bound of Proposition~\\ref{flx:prop:catbound}.""")
rep("""$0\\le i\\le24$; there we replace some chords by other lines below the functions $G_j$ (Lemma~\\ref{flx:lem:lines}).""",
    """$0\\le i\\le24$; there we replace some chords by other lines below the functions $G_j$ (Lemma~\\ref{flx:lem:lines}).
Table~\\ref{flx:tab:level} also uses such lines at $12$ triples where the chords, with some $w_{\\mathrm L}=i/24$, would
suffice.""")
# S9: proof of the Catalan line bound
rep("""$m(J)=a-h-x(J)$ by Proposition~\\ref{fl:prop:inputs}(b), and $m(J)-2j+1=a-2k+h+1-x(J)$. Put
$\\mathsf T_h=(a-2k+h+1)N_h-\\sum_{|J|=h}x(J)$. Lemma~\\ref{flx:lem:catline} with $m=m(J)$, summed over the $N_h$ such
sets, gives""",
    """$m(J)=a-h-x(J)$ by the definition of $x(J)$, and $m(J)-2j+1=a-2k+h+1-x(J)$. Put
$\\mathsf T_h=(a-2k+h+1)N_h-\\mathrm{ex}_h$. Lemma~\\ref{flx:lem:catline}, applied at $m(J)$ and summed over the $N_h$
such sets, gives""")
rep("""$L_h(e_C)\\le N_h\\le U_h(e_C)$ by Proposition~\\ref{fl:prop:inputs}(e) and $\\sum_Jx(J)\\le X_h(e_C)$ by""",
    """$L_h(e_C)\\le N_h\\le U_h(e_C)$ by Proposition~\\ref{fl:prop:inputs}(e) and $\\mathrm{ex}_h\\le X_h(e_C)$ by""")
rep("""so $\\mathsf T_h\\ge\\mathsf Z_h(e_C)$ and $-N_h\\ge-U_h(e_C)$. Hence
level $h$ contributes at least""",
    """so $\\mathsf T_h\\ge\\mathsf Z_h(e_C)$ and $-N_h\\ge-U_h(e_C)$. Hence, as the right side of the display is
nondecreasing in $\\mathsf T_h$ and in $-N_h$, level $h$ contributes at least""")
# S6 again: the classes
rep("""We split $\\cD_{26}\\setminus\\cD_{20}$ by the rules of Section~\\ref{fl:sec:twenty}:""",
    """We split $\\cD_{26}\\setminus\\cD_{20}$ by the following four rules; on $\\cD_{20}$ the same rules give the classes
$\\mathcal P_1,\\dots,\\mathcal P_4$ of Section~\\ref{fl:sec:twenty}:""")
# S7: P3 as a list
rep("""\\item $\\mathcal P^+_3$: the $18$ other triples with $k\\ge h_B(n,a)$, listed in Table~\\ref{flx:tab:tail};""",
    """\\item $\\mathcal P^+_3$: the $18$ other triples with $k\\ge h_B(n,a)$, which are the triples of Table~\\ref{flx:tab:tail};""")
rep("""\\begin{proposition}\\label{flx:prop:class3}
Let $(n,a,k)\\in\\mathcal P^+_3$. Then $k\\ge h_B(n,a)$; in particular $k\\notin W(F)$ for every forest $F$ with $n$ vertices
and independence number $a$.
\\end{proposition}""",
    """\\begin{proposition}\\label{flx:prop:class3}
The comparisons of Table~\\ref{flx:tab:tail} hold. Consequently, for $(n,a,k)$ in that table, $k\\ge h_B(n,a)$, and
$k\\notin W(F)$ for every forest $F$ with $n$ vertices and independence number $a$.
\\end{proposition}""")
# M2 and S5: corners table layout and caption
rep("""\\FlxCornersOne
\\bottomrule
\\end{tabular}
\\qquad
\\begin{tabular}{@{}rccr@{}}""",
    """\\FlxCornersOne
\\bottomrule
\\end{tabular}
\\\\[8pt]
\\begin{tabular}{@{}rccr@{}}""")
rep("""\\caption{The Catalan corner inequalities for $n\\le26$: left, Proposition~\\ref{flx:prop:class1}, $c^+_1=c^+_1(k)$; right,
Proposition~\\ref{flx:prop:class2}, $c^+_2=c^+_2(k)$.}\\label{flx:tab:corners}""",
    """\\caption{The Catalan inequalities for $n\\le26$: top, Proposition~\\ref{flx:prop:class1}, $c^+_1=c^+_1(k)$; bottom,
Proposition~\\ref{flx:prop:class2}, $c^+_2=c^+_2(k)$. The rows with $k\\le6$ (top) and $k\\le7$ (bottom) are not needed for
$21\\le n\\le26$; with them the table serves all $n\\le26$.}\\label{flx:tab:corners}""")
rep("""Let $c^+_1(k)$ be as in the left part of Table~\\ref{flx:tab:corners}.""",
    """Let $c^+_1(k)$ be as in the top part of Table~\\ref{flx:tab:corners}.""")
rep("""Let $c^+_2(k)$ be as in the right part of Table~\\ref{flx:tab:corners}.""",
    """Let $c^+_2(k)$ be as in the bottom part of Table~\\ref{flx:tab:corners}.""")
# S3
rep("""$\\mathcal P^+_1$ with $c=9$ is $(24,15,7)$ ($a=15$ forces $n=24$), and at $k=8$ it is $(26,17,8)$.""",
    """$\\mathcal P^+_1$ with $c=9$ is $(24,15,7)$ (as $n\\le24$ and $a\\ge15$), and at $k=8$ it is $(26,17,8)$ (as $n\\le26$
and $a\\ge17$).""")
# S2 (paragraph after Prop class1)
rep("""The corner of Proposition~\\ref{fl:prop:class1} fails at $k=7,8$ for $n\\le26$:""",
    """At $k=7,8$ the bound $c\\le\\min(26,4k-4)-(2k+1)=9$ is too weak:""")
rep("""$\\mathsf R(17,9,8)=-16$, so no choice of corner settles them by Corollary~\\ref{fl:cor:rise};""",
    """$\\mathsf R(17,9,8)=-16$, so Corollary~\\ref{fl:cor:rise} does not settle them;""")
# S4: the "exactly" of Prop class2 by hand
rep("""which is positive by Table~\\ref{flx:tab:corners}. For the triples with $a=2k$ and $c>c^+_2(k)$ the listing gives
$\\mathsf R\\le0$. Corollary~\\ref{fl:cor:rise} concludes.""",
    """which is positive by Table~\\ref{flx:tab:corners}. For $c>c^+_2(k)$, $\\mathsf R(2k,c,k)\\le\\mathsf R(2k,c^+_2(k)+1,k)$,
which equals $-170$, $-360$, $-774$, $-1578$ for $k=7,8,9,10$; for $k=11,12$ no triple of $\\cD_{26}\\setminus\\cD_{20}$
has $a=2k$ and $c>c^+_2(k)$. Corollary~\\ref{fl:cor:rise} concludes.""")
# S10
rep("""(first two lines)""", """(first two rows)""")
# M3, S5, M1, S1, and remark (iii) (stage 1's class P_4)
rep("""No forest is enumerated. By hand: the $20$ comparisons of Table~\\ref{flx:tab:corners}, the $18$ of""",
    """No forest is enumerated. By hand: the $11$ comparisons of Table~\\ref{flx:tab:corners} with $k\\ge7$ (top) and
$k\\ge8$ (bottom), the $18$ of""")
rep("""the program listed
in Section~\\ref{sec:computer}.""", """the program
\\texttt{verify\\_floor26.py} (Python standard library).""")
rep("""the anchored bound with the chords $(p^\\circ_h,q^\\circ_h)$ is not positive for any $w_{\\mathrm L}\\in\\{0,\\frac1{24},\\dots,1\\}$; for these the
other hull edges are needed.""",
    """the anchored bound with the chords $(p^\\circ_h,q^\\circ_h)$, $\\min_{0\\le e_C\\le c-1}\\mathcal A(e_C)$, is not positive for
any $w_{\\mathrm L}\\in\\{0,\\frac1{24},\\dots,1\\}$; with these weights, lines other than the chords are needed. (A weight off
this grid can suffice: for $(24,17,9)$ and $w_{\\mathrm L}=\\frac{31}{96}$ the chords give $\\mathcal A(0)=\\frac{1405}{48}>0$
and $\\mathcal A(1)\\ge\\mathcal A(0)$.)""")
rep("""(ii) For each of the $32$ triples of Table~\\ref{flx:tab:values}, no lower bound for $i_k-i_{k-1}$ that uses the
data of Proposition~\\ref{fl:prop:inputs} level by level can be positive, and the same holds for $i_k-i_{k+1}$.""",
    """(ii) For each of the $32$ triples of Table~\\ref{flx:tab:values}, no lower bound for $i_k-i_{k-1}$ that uses only the
inequalities of Proposition~\\ref{fl:prop:inputs}(b) and (d)--(f), each level separately and with real weights, can be
positive, and the same holds for $i_k-i_{k+1}$.""")
i0 = b.index('The witnesses are families of level distributions')
i1 = b.index('negative number.', i0) + len('negative number.')
b = b[:i0] + """The witnesses are real arrays, not forests: for some $e_C$, at each level $h$ a nonnegative real array
$N(h,m)$, $0\\le m\\le a-h$, supported on at most two values of $m$, with $\\sum_mN(h,m)$ in $[L_h(e_C),U_h(e_C)]$
(equal to $c$ for $h=1$) and $\\sum_m(a-h-m)N(h,m)$ at most $X_h(e_C)$ (at most $a-1-e_C$ for $h=1$), whose
contributions $\\sum_mN(h,m)\\,d_L(h,m)$ (respectively $\\sum_mN(h,m)\\,d_R(h,m)$) sum with $d_L(0,a)$ (respectively
$d_R(0,a)$) to a negative number; the values $N(h,m)$ are fractions in general.""" + b[i1:]
rep("""So these triples need a weight $0<w_{\\mathrm L}<1$, and the functions $G_j$ for such $w_{\\mathrm L}$ are the
tabulated ones.""", """So these triples need weights $0<w_{\\mathrm L}<1$, and the functions $G_j$ for such weights are the
tabulated ones.""")
rep("""(iii) The Catalan line bound also settles $10$ of the $18$ triples of $\\mathcal P^+_4$ for $n\\le20$""",
    """(iii) The Catalan line bound also settles $10$ of the $18$ triples of $\\mathcal P_4$ (the class for $n\\le20$)""")
open(fn, 'w').write(b)
print('fixed')
