#!/usr/bin/env python3
"""Referee fixes, notation part (30 Sep 2026): one shared notation for the sections on n <= 20 and 21 <= n <= 26.

Reads  ../../floor/floor20_section.tex   (stage 1, read only; not modified)
       floor26_body_v1.tex                (this section's body before the fixes)
Writes ../floor20_section_shared.tex      (stage 1 with the shared notation; same mathematics, same labels)
       floor26_body.tex                   (this section's body with the shared notation; the other fixes follow in
                                           fix_body_v2.py)
Rename table (clashes with the TWIN v1.5 notation table):
  e = e(F[C]) and the variable of the bounds -> e_C        s = e(A,C)-c -> ex_1 (Part I's ex_h at h = 1)
  omega, 1-omega -> w_L, w_R (Part I's weights)             f_omega -> d_LR = w_L d_L + w_R d_R, f_1 -> d_L
  V_omega -> sans-serif V                                   g_j(M) -> G_j(m)
  p_h, q_h (the chords) -> p°_h, q°_h                       calligraphic B -> calligraphic A
  Phi -> sans-serif R                                       N(v) -> N_F(v); bare x in the line inequality -> m
  in this section only: P_i -> P_i^+, c_1, c_2 -> c_1^+, c_2^+ (stage 1 keeps P_i, c_1, c_2 with their meaning)."""
import re, os
HERE = os.path.dirname(os.path.abspath(__file__))

def sub1(t, old, new, count=1):
    assert t.count(old) >= 1, 'missing: ' + old[:90]
    if count == 'all':
        return t.replace(old, new)
    assert t.count(old) == count, 'count %d != %d: %s' % (t.count(old), count, old[:90])
    return t.replace(old, new)

def generic(t):
    t = t.replace('V_\\omega', '\\mathsf V')
    t = t.replace('f_{1/2}', 'd_{\\mathrm{LR}}').replace('f_\\omega', 'd_{\\mathrm{LR}}')
    t = re.sub(r'(?<![A-Za-z\\])f_1(?![0-9])', 'd_L', t)
    t = t.replace('(1-\\omega)', 'w_{\\mathrm R}').replace('1-\\omega', 'w_{\\mathrm R}')
    t = t.replace('\\omega', 'w_{\\mathrm L}')
    t = t.replace('\\mathcal B', '\\mathcal A')
    t = t.replace('\\Phi', '\\mathsf R')
    t = re.sub(r'(?<![A-Za-z\\])g_', 'G_', t)
    t = re.sub(r'(?<![A-Za-z\\])M(?![A-Za-z])', 'm', t)
    for X in ('N', 'L', 'U'):
        t = t.replace(X + '_hp_h', X + '_h\\,p_h').replace(X + '_hq_h', X + '_h\\,q_h')
    t = re.sub(r'(?<![A-Za-z\\])([pq])_(?=[h0-9{])', r'\1^\\circ_', t)
    t = t.replace('e_{\\min}', 'e^{\\min}_C')
    t = t.replace('\\binom Mj', '\\binom mj')
    t = re.sub(r'(?<![A-Za-z\\])e(?![A-Za-z(_^])', 'e_C', t)
    t = t.replace('\\item[(e_C)]', '\\item[(e)]').replace('(e_C) is Lemma', '(e) is Lemma')
    t = re.sub(r'\}\(e_C\)', '}(e)', t)
    return t

# ------------------------------------------------------------------ stage 1, shared notation
s1 = open(os.path.join(HERE, '..', '..', 'floor', 'floor20_section.tex')).read()
s1 = sub1(s1, '% Section: forests with at most twenty vertices (for Part I of the paper).',
          '% Section: forests with at most twenty vertices (for Part I of the paper).\n'
          '% Shared-notation copy (30 Sep 2026): the stage-1 section with the symbols renamed to fit the TWIN v1.5 notation\n'
          '% table, so that it can be printed together with the section on 21 to 26 vertices. Same mathematics, same labels.')
s1 = sub1(s1, 'N(v)', 'N_F(v)', 'all')
s1 = sub1(s1, """let $e=e(F[C])$ be the number of edges with both ends in $C$,
and put $s=e(A,C)-c$.""", """let $e_C=e(F[C])$ be the number of edges with both ends in $C$,
and let $\\mathrm{ex}_h=\\sum_{|J|=h}x(J)$, the sum over the independent $J\\subseteq C$ with $|J|=h$, be the
total excess at size $h$ (Section~\\ref{p1:sec:rows}); thus $\\mathrm{ex}_1=e(A,C)-c$.""")
s1 = sub1(s1, 'Consequently $0\\le s\\le a-1-e$.', 'Consequently $0\\le\\mathrm{ex}_1\\le a-1-e_C$.')
s1 = sub1(s1, """\\item[(f)] For $2\\le h\\le c$: $\\displaystyle\\sum_{J}x(J)\\le s\\binom{c-2}{h-1}+d\\binom{c-2}{h-2}$, the sum
running over the independent $J\\subseteq C$ with $|J|=h$.""",
          """\\item[(f)] For $2\\le h\\le c$: $\\mathrm{ex}_h\\le\\mathrm{ex}_1\\binom{c-2}{h-1}+d\\binom{c-2}{h-2}$.""")
s1 = sub1(s1, 'hence $0\\le s\\le n-1-c-e=a-1-e$.', 'hence $0\\le\\mathrm{ex}_1\\le n-1-c-e_C=a-1-e_C$.')
s1 = re.sub(r'\(f\) is inequality~\\eqref\{p1:eq:SM\} of Theorem~\\ref\{p1:thm:matching\}, in which \$D=e\(A,C\)\$,\s*so that \$D-c=s\$, and \$R_h=\\sum_Jx\(J\)\$\.',
            '(f) is inequality~\\\\eqref{p1:eq:SM} of Theorem~\\\\ref{p1:thm:matching}.', s1)
assert 'D-c=s' not in s1
s1 = sub1(s1, """For $\\omega\\in[0,1]$ and $k\\ge1$ put $V_\\omega(k)=\\omega\\,(i_k-i_{k-1})+(1-\\omega)\\,(i_k-i_{k+1})$ and
\\[
f_\\omega(y,m)=\\binom{m}{k-y}-\\omega\\binom{m}{k-1-y}-(1-\\omega)\\binom{m}{k+1-y}.
\\]""", """For weights $w_{\\mathrm L}\\in[0,1]$ and $w_{\\mathrm R}=1-w_{\\mathrm L}$ and for $k\\ge1$ put
$\\mathsf V(k)=w_{\\mathrm L}(i_k-i_{k-1})+w_{\\mathrm R}(i_k-i_{k+1})$, and, with $d_L$ and $d_R$ as in
Section~\\ref{p1:subsec:certs},
\\begin{align*}
d_{\\mathrm{LR}}(y,m)&=w_{\\mathrm L}\\,d_L(y,m)+w_{\\mathrm R}\\,d_R(y,m)\\\\
&=\\binom{m}{k-y}-w_{\\mathrm L}\\binom{m}{k-1-y}-w_{\\mathrm R}\\binom{m}{k+1-y}.
\\end{align*}""")
s1 = sub1(s1, 'g_{k-h}(a-h-x)\\ \\ge\\ p_h-q_h\\,x\\qquad(0\\le x\\le a-h).',
          'g_{k-h}(m)\\ \\ge\\ p_h-q_h\\,(a-h-m)\\qquad(0\\le m\\le a-h).')
s1 = sub1(s1, '$c\\,p_1-q_1s\\ge c\\,p_1-q_1(a-1-e)$.', '$c\\,p_1-q_1\\mathrm{ex}_1\\ge c\\,p_1-q_1(a-1-e)$.')
s1 = sub1(s1, '$N_hp_h-q_h\\sum_Jx(J)$;', '$N_hp_h-q_h\\,\\mathrm{ex}_h$;')
s1 = sub1(s1, """$\\sum_Jx(J)\\le s\\binom{c-2}{h-1}+d\\binom{c-2}{h-2}\\le X_h(e)$ by Proposition~\\ref{fl:prop:inputs}(f)
and $s\\le a-1-e$.""", """$\\mathrm{ex}_h\\le\\mathrm{ex}_1\\binom{c-2}{h-1}+d\\binom{c-2}{h-2}\\le X_h(e)$ by Proposition~\\ref{fl:prop:inputs}(f)
and $\\mathrm{ex}_1\\le a-1-e$.""")
s1 = sub1(s1, 'the program listed in Section~\\ref{sec:computer}', 'the program \\texttt{verify\\_floor20\\_v2.py} (Python standard library)')
s1 = generic(s1)
def leftover(t):
    pats = [r'\\omega', r'\\Phi', r'\\mathcal B', r'(?<![A-Za-z\\])V_', r'(?<![A-Za-z\\])f_', r'(?<![A-Za-z\\])[pq]_h',
            r'(?<![A-Za-z\\])g_', r'\$M', r'N\(v\)', r'\\Sigma', r' s\\le', r'\$s\$']
    return [p for p in pats if re.search(p, t)]
assert not leftover(s1), leftover(s1)
open(os.path.join(HERE, '..', 'floor20_section_shared.tex'), 'w').write(s1)

# ------------------------------------------------------------------ this section
b = open(os.path.join(HERE, 'floor26_body_v1.tex')).read()
b = sub1(b, 'g_{k-h}(a-h-x)\\ \\ge\\ p^\\sharp_h-q^\\sharp_h\\,x\\qquad\\text{for every integer }0\\le x\\le a-h,',
         'g_{k-h}(m)\\ \\ge\\ p^\\sharp_h-q^\\sharp_h\\,(a-h-m)\\qquad\\text{for every integer }0\\le m\\le a-h,')
b = sub1(b, """The chord of Section~\\ref{fl:sec:anchored}, $(p^\\sharp_h,q^\\sharp_h)=(p_h,q_h)$, is the line through the point
$(0,g_{k-h}(a-h))$; it has the largest $p^\\sharp_h$. The other lines used below support the lower convex hull of the
points $\\bigl(x,g_{k-h}(a-h-x)\\bigr)$, $0\\le x\\le a-h$: each is an edge of that hull or the horizontal line through
its lowest point, with a smaller $p^\\sharp_h$ and a smaller $q^\\sharp_h$ than the chord.""",
         """The chord of Section~\\ref{fl:sec:anchored}, $(p^\\sharp_h,q^\\sharp_h)=(p_h,q_h)$, is the line through the point
$(a-h,g_{k-h}(a-h))$; it has the largest $p^\\sharp_h$. The other lines used below support the lower convex hull of the
points $\\bigl(m,g_{k-h}(m)\\bigr)$, $0\\le m\\le a-h$: each is an edge of that hull or the horizontal line through its
lowest point, with a smaller $p^\\sharp_h$ and a smaller $q^\\sharp_h$ than the chord.""")
b = sub1(b, 'convex hull of the points $(x,g_{k-h}(a-h-x))$, or the horizontal line through its lowest point.',
         'convex hull of the points $(m,g_{k-h}(m))$, or the horizontal line through its lowest point.')
b = sub1(b, 'values $g_{k-h}(M)$, $0\\le M\\le a-h$, which are read off', 'values $g_{k-h}(M)$, $0\\le M\\le a-h$, which are read off')
b = sub1(b, 'Let $e=e(F[C])$. For $h=1$ we have $N_1=c$ and $\\sum_{v\\in C}x(\\{v\\})=s\\le a-1-e$ by',
         'Let $e=e(F[C])$. For $h=1$ we have $N_1=c$ and $\\mathrm{ex}_1\\le a-1-e$ by')
b = sub1(b, 'Proposition~\\ref{fl:prop:inputs}(f) and $s\\le a-1-e$, so $\\Sigma_h',
         'Proposition~\\ref{fl:prop:inputs}(f) and $\\mathrm{ex}_1\\le a-1-e$, so $\\Sigma_h')
b = generic(b)
for i in (1, 2, 3, 4):
    b = b.replace('\\mathcal P_%d' % i, '\\mathcal P^+_%d' % i)
b = re.sub(r'(?<![A-Za-z\\])c_([12])(?![0-9])', r'c^+_\1', b)
b = b.replace('\\Sigma', '\\mathsf T')
assert not leftover(b), leftover(b)
open(os.path.join(HERE, 'floor26_body.tex'), 'w').write(b)
print('wrote ../floor20_section_shared.tex and floor26_body.tex')
