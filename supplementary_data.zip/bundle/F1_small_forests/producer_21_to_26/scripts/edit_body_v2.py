#!/usr/bin/env python3
"""One-off edit of floor26_body.tex: two Catalan lines in the Catalan line bound; counts 160/32 (floor26, 30 Sep 2026)."""
b = open('floor26_body.tex').read()
start = b.index('\\begin{lemma}[Catalan line]')
end = b.index('Where $a\\ge 2k$, $\\Phi^\\ast$ improves on Corollary')
new = open('catline_v2.tex').read()
b = b[:start] + new + b[end:]
rep = [("settled by inequalities between numbers built from Catalan numbers and binomial coefficients, and $33$ by the",
        "settled by inequalities between numbers built from Catalan numbers and binomial coefficients, and $32$ by the"),
       ("Of the $192$ triples, $159$ are", "Of the $192$ triples, $160$ are"),
       ("one of the $8$ triples of $\\mathcal P_4$ in", "one of the $9$ triples of $\\mathcal P_4$ in"),
       ("(first two lines) and at $8$ triples of", "(first two lines) and at $9$ triples of"),
       ("Let $(n,a,k)$ be one of the $33$ triples of Table~\\ref{flx:tab:values}", "Let $(n,a,k)$ be one of the $32$ triples of Table~\\ref{flx:tab:values}"),
       ("\\caption{The $33$ triples of $\\mathcal P_4$ settled by the anchored bound", "\\caption{The $32$ triples of $\\mathcal P_4$ settled by the anchored bound"),
       ("by hand ($159$ triples) or by", "by hand ($160$ triples) or by"),
       ("the anchored bound with values from printed tables ($33$ triples).", "the anchored bound with values from printed tables ($32$ triples)."),
       ("the values of $\\Phi^\\ast$ at the $10$ triples of Table~\\ref{flx:tab:line}", "the values of $\\Phi^\\ast$ at the $11$ triples of Table~\\ref{flx:tab:line}"),
       ("From printed tables: the $33$ triples of Table~\\ref{flx:tab:values}", "From printed tables: the $32$ triples of Table~\\ref{flx:tab:values}"),
       ("""(ii) For $32$ of the $33$ triples of Table~\\ref{flx:tab:values} (all but $(24,16,8)$), no lower bound for
$i_k-i_{k-1}$ that uses the data of Proposition~\\ref{fl:prop:inputs} level by level can be positive, and for all $33$
the same holds for $i_k-i_{k+1}$.""",
        """(ii) For each of the $32$ triples of Table~\\ref{flx:tab:values}, no lower bound for $i_k-i_{k-1}$ that uses the
data of Proposition~\\ref{fl:prop:inputs} level by level can be positive, and the same holds for $i_k-i_{k+1}$."""),
       ("""(iii) The Catalan line bound also settles $9$ of the $18$ triples of $\\mathcal P_4$ for $n\\le20$, namely $(12,8,4)$,
$(15,10,5)$, $(16,10,5)$, $(17,12,6)$, $(18,12,6)$, $(19,12,6)$, $(20,11,6)$, $(20,12,6)$, $(20,14,7)$; with it, the
printed tables are needed for $42$ of the $322$ triples of $\\cD_{26}$.""",
        """(iii) The Catalan line bound also settles $10$ of the $18$ triples of $\\mathcal P_4$ for $n\\le20$, namely $(12,8,4)$,
$(15,10,5)$, $(16,9,5)$, $(16,10,5)$, $(17,12,6)$, $(18,12,6)$, $(19,12,6)$, $(20,11,6)$, $(20,12,6)$, $(20,14,7)$; with
it, the printed tables are needed for $40$ of the $322$ triples of $\\cD_{26}$.""")]
for x, y in rep:
    assert x in b, x[:90]
    b = b.replace(x, y)
open('floor26_body.tex', 'w').write(b)
print('edited')
