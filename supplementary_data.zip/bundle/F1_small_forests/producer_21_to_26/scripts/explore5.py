#!/usr/bin/env python3
"""Exploration (floor26): one line set per (a,k,omega), shared by all n; anchored chord first, hull edges if needed."""
import sys
from fractions import Fraction as Q
from collections import defaultdict
from explore1 import dom, hB, phi, B
from explore3 import cand_lines
sys.path.insert(0,'../../floor/scripts')
import catalan_markov as cm
D=list(dom(21,26))
P4=[t for t in D if t[2]<hB(t[0],t[1]) and not ((2*t[2]<=t[1]-1 or t[1]==2*t[2]) and phi(t[1],t[0]-t[1],t[2])>0)]
CMs=[t for t in P4 if cm.Phi(Q(1),*t)>0]
AN=[t for t in P4 if t not in CMs]
G=defaultdict(list)
for t in AN: G[(t[1],t[2])].append(t)
def score(w,grp,lines):
    return min(min(B(w,n,a,k,e,{h:lines[h][0] for h in lines},{h:lines[h][1] for h in lines}) for e in range(n-a)) for (n,a,k) in grp)
def search(w,a,k,grp):
    hmax=min(a-1,k+1)
    cands={h:cand_lines(w,a,k,h) for h in range(1,hmax+1)}
    lines={h:max(cands[h]) for h in cands}   # anchored chord (largest intercept)
    s0=score(w,grp,lines); s=s0
    for _ in range(5):
        imp=False
        for h in cands:
            for ln in cands[h]:
                if ln==lines[h]: continue
                L2=dict(lines); L2[h]=ln; s2=score(w,grp,L2)
                if s2>s: s,lines,imp=s2,L2,True
        if not imp: break
    nchg=sum(1 for h in cands if lines[h]!=max(cands[h]))
    return s0,s,nchg,lines
grid=[Q(1,2),Q(13,24),Q(11,24),Q(7,12),Q(5,12),Q(2,5),Q(3,5),Q(1,3),Q(5,8),Q(3,8),Q(1,4),Q(3,10),Q(7,24),Q(5,24),Q(1,5)]
if __name__=='__main__':
  for (a,k),grp in sorted(G.items()):
    out=[]
    for w in grid:
        s0,s,nchg,lines=search(w,a,k,grp)
        if s>0: out.append((str(w),float(s0),float(s),nchg))
    print((a,k),[t[0] for t in grp],'ok:',out[:4])
