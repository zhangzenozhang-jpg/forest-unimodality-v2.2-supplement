#!/usr/bin/env python3
"""Writes ../floor26_section.tex = generated table macros (../outputs/floor26_tables.tex) + floor26_body.tex.
Run verify_floor26.py first (it writes the macros)."""
import os
here = os.path.dirname(os.path.abspath(__file__))
tables = open(os.path.join(here, '..', 'outputs', 'floor26_tables.tex')).read()
body = open(os.path.join(here, 'floor26_body.tex')).read()
head = ('% Section: forests with twenty-one to twenty-six vertices (for Part I of the paper; to follow the section on\n'
        '% forests with at most twenty vertices, whose notation and labels fl:* it uses).\n'
        '% The table macros below were computed in exact rational arithmetic; they are not typed by hand.\n')
tables = '\n'.join(l for l in tables.split('\n') if not l.startswith('% generated'))
with open(os.path.join(here, '..', 'floor26_section.tex'), 'w') as fh:
    fh.write(head + tables + '\n' + body)
print('wrote floor26_section.tex')
