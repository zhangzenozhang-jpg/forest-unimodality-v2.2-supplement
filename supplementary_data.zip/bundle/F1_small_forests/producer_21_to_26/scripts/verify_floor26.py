#!/usr/bin/env python3
"""Exact verifier for floor26_section.tex (standard library only; Python 3.9+; integers and fractions only).

No forest is enumerated; every check is on the parameters (n,a,k). Stage 1's files are not read or modified.
Reads one input, ../outputs/floor26_lines.json: for each triple of the tabulated class, the weight omega, one line
(p_h, q_h) per level and the rank e0 at which the anchored bound is smallest. Every other number is recomputed here.
Checks:
 (D)  the parameter set D_26 of Part I (322 triples; counts per n); its 192 triples with 21 <= n <= 26; the window.
 (P)  the four classes of stage 1 applied to 21 <= n <= 26: P1 (2k <= a-1), P2 (a = 2k, Phi > 0), P3 (k >= h_B, the
      rest), P4 (the rest); they partition the 192 triples.
 (C)  the Catalan corner inequalities for P1 and P2 over all n <= 26, and the two P1 triples where they fail.
 (T)  the comparisons b_{k+1} <= b_k for P3.
 (L)  the Catalan line lemma on a grid; the Catalan line bound R(e) on its 10 triples (2 of P1, 8 of P4):
      R(e0) > 0 and R(e0 +- 1) >= R(e0) (convexity), and R(e) > 0 for every e as a cross-check; also on n <= 20.
 (A)  the anchored bound with the given lines on the other 33 triples of P4: q_h >= 0, the line condition
      g_{k-h}(a-h-x) >= p_h - q_h x for 0 <= x <= a-h, B(e0) > 0 and B(e0 +- 1) >= B(e0); all e as a cross-check.
 (S)  the breakdown table for 21 <= n <= 26 and the combined one for n <= 26 (stage 1's classes recomputed on n <= 20).
Writes ../outputs/floor26_tables.tex (LaTeX macros). Exit status 0 iff every check passes."""
import math, sys, os, json
from fractions import Fraction as Q

HERE = os.path.dirname(os.path.abspath(__file__))
OK = [True]

def check(cond, msg):
    if not cond:
        OK[0] = False
        print('FAILED:', msg)

def C(n, k):
    return math.comb(n, k) if n >= 0 and 0 <= k <= n else 0

def cat(j):
    return C(2*j, j)//(j+1) if j >= 0 else 0

def bco(n, a):
    c, d = n-a, 2*a-n
    return [sum(C(c, i)*2**i*C(d, r-i) for i in range(c+1)) for r in range(a+2)]

def hB(n, a):
    b = bco(n, a)
    return b.index(max(b))

def D26():
    out = []
    for n in range(1, 27):
        for a in range((n+1)//2, n):
            H = -(-(n+2*a)//6)
            for k in range(-(-n//4)+1, min(a, H)):
                out.append((n, a, k))
    return out

def Phi(a, c, k):
    return C(a, k)-C(a, k-1)-sum(C(c, h)*cat(k-1-h) for h in range(1, min(c, k-1)+1))

def g(w, j, M):
    return C(M, j)-w*C(M, j-1)-(1-w)*C(M, j+1)

def LU(c, h, e):
    """count bounds L_h(e) <= N_h <= U_h(e) for h >= 2 (Part I, subset / edge-union / pair-extension)."""
    if h == 2:
        return Q(C(c, 2)-e), Q(C(c, 2)-e)
    return Q(max(0, C(c, h)-e*C(c-2, h-2))), min(Q(C(c, h)), Q(C(c-2, h-2)*(C(c, 2)-e), C(h, 2)))

def Xcap(a, c, h, e):
    return Q((a-1-e)*C(c-2, h-1)+(2*a-(a+c))*C(c-2, h-2))

def Bline(w, n, a, k, e, p, q):
    """the anchored bound B(e) of stage 1, with arbitrary lines p_h - q_h x (q_h >= 0) below the level functions."""
    c = n-a
    tot = Q(g(w, k, a))+c*p.get(1, Q(0))-q.get(1, Q(0))*(a-1-e)
    for h in range(2, c+1):
        L, U = LU(c, h, e)
        tot += min(L*p.get(h, Q(0)), U*p.get(h, Q(0)))-q.get(h, Q(0))*Xcap(a, c, h, e)
    return tot

def Zlev(n, a, k, h, e):
    """Z_h(e): (a-2k+2)c-(a-1-e) for h = 1; min over N in {L_h(e), U_h(e)} of (a-2k+h+1)N, minus X_h(e), for h >= 2."""
    c = n-a
    if h == 1:
        return Q((a-2*k+2)*c-(a-1-e))
    L, U = LU(c, h, e)
    kap = a-2*k+h+1
    return min(kap*L, kap*U)-Xcap(a, c, h, e)

def R(n, a, k, e):
    """the Catalan line bound Phi*(e): i_k - i_{k-1} >= Phi*(e(F[C])) (two Catalan lines and the Catalan floor)."""
    c = n-a
    tot = Q(C(a, k)-C(a, k-1))
    for h in range(1, min(c, k-1)+1):
        U = Q(c) if h == 1 else LU(c, h, e)[1]
        z = Zlev(n, a, k, h, e)
        tot += cat(k-h)*z if z >= 0 else cat(k-h-1)*max(-U, z)
    return tot

def tf(v):
    v = Q(v)
    if v.denominator == 1:
        return '%d' % v.numerator
    return '%s%d/%d' % ('-' if v < 0 else '', abs(v.numerator), v.denominator)

def argmin_check(fun, c, label):
    """returns (e0, values); checks value(e0) > 0 and neighbours >= value(e0), and all values > 0."""
    vals = [fun(e) for e in range(c)]
    e0 = vals.index(min(vals))
    check(vals[e0] > 0, label+' value at e0 not positive')
    if e0 >= 1:
        check(vals[e0-1] >= vals[e0], label+' left neighbour')
    if e0+1 <= c-1:
        check(vals[e0+1] >= vals[e0], label+' right neighbour')
    check(all(v > 0 for v in vals), label+' some e not positive')
    return e0, vals

def classes(T):
    P1 = [t for t in T if 2*t[2] <= t[1]-1]
    P2 = [t for t in T if t[1] == 2*t[2] and Phi(t[1], t[0]-t[1], t[2]) > 0]
    P3 = [t for t in T if t not in P1 and t not in P2 and t[2] >= hB(t[0], t[1])]
    P4 = [t for t in T if t not in P1 and t not in P2 and t not in P3]
    return P1, P2, P3, P4

def main():
    log = []
    def pr(*a):
        s = ' '.join(str(x) for x in a); print(s); log.append(s)
    # ---------------- (D) the parameter set and the window
    D = D26()
    cnt = [len([t for t in D if t[0] == n]) for n in range(1, 27)]
    check(len(D) == 322 and cnt[:6] == [0]*6, 'size of D_26')
    check(cnt[6:] == [1, 2, 1, 2, 5, 7, 5, 7, 12, 15, 12, 15, 21, 25, 22, 26, 33, 38, 34, 39], 'counts per n (Part I table)')
    for n in range(1, 27):              # h_B(n,a) <= H(n,a) for all pairs (Remark of Part I), a cross-check
        for a in range((n+1)//2, n+1):
            check(hB(n, a) <= -(-(n+2*a)//6), 'h_B <= H at (%d,%d)' % (n, a))
    T = [t for t in D if t[0] >= 21]
    T20 = [t for t in D if t[0] <= 20]
    inW = lambda t: t[2] < hB(t[0], t[1])
    pr('D_26: %d triples; n<=20: %d (window %d); 21<=n<=26: %d (window %d, outside %d)' % (
        len(D), len(T20), len([t for t in T20 if inW(t)]), len(T), len([t for t in T if inW(t)]), len([t for t in T if not inW(t)])))
    check((len(T), len([t for t in T if inW(t)])) == (192, 168), 'window count 21..26')
    # ---------------- (P) classes
    P1, P2, P3, P4 = classes(T)
    check(sorted(P1+P2+P3+P4) == sorted(T) and len(set(P1+P2+P3+P4)) == 192, 'partition')
    pr('classes 21..26: P1 %d, P2 %d, P3 %d, P4 %d' % (len(P1), len(P2), len(P3), len(P4)))
    check([len(P1), len(P2), len(P3), len(P4)] == [118, 15, 18, 41], 'class sizes')
    check(all(inW(t) for t in P4), 'P4 inside the window')
    # ---------------- (C) Catalan corners over n <= 26
    A1, A2, A3, A4 = classes(D)
    E1 = [t for t in A1 if Phi(t[1], t[0]-t[1], t[2]) <= 0]
    pr('P1 triples (n<=26) with Phi <= 0:', E1)
    check(E1 == [(24, 15, 7), (26, 17, 8)], 'the two P1 exceptions')
    corners1 = []
    for k in sorted(set(t[2] for t in A1)):
        ts = [t for t in A1 if t[2] == k and t not in E1]
        c1 = max(t[0]-t[1] for t in ts)
        check(all(t[1] >= 2*k+1 and t[0]-t[1] <= c1 and t[0] <= 4*k-4 for t in ts), 'P1 shape k=%d' % k)
        check(C(2*k+1, k)-C(2*k+1, k-1) == cat(k+1), 'Catalan lead k=%d' % k)
        lhs, rhs = cat(k+1), sum(C(c1, h)*cat(k-1-h) for h in range(1, min(c1, k-1)+1))
        check(lhs > rhs, 'P1 corner k=%d' % k)
        formula = min(26, 4*k-4)-(2*k+1)
        corners1.append((k, 2*k+1, c1, lhs, rhs, formula))
        pr('P1 corner k=%d (a,c)=(%d,%d): Cat_{k+1}=%d > %d   [min(26,4k-4)-(2k+1) = %d]' % (k, 2*k+1, c1, lhs, rhs, formula))
    c1 = {row[0]: row[2] for row in corners1}
    check(sorted(t for t in A1 if t[0]-t[1] > c1[t[2]]) == E1, 'P1 minus corners = the two exceptions')
    for t in E1:
        n, a, k = t
        pr('P1 exception %s: Phi = Cat_{k+1} - %d = %d' % (t, sum(C(n-a, h)*cat(k-1-h) for h in range(1, min(n-a, k-1)+1)), Phi(a, n-a, k)))
    corners2 = []
    for k in sorted(set(t[2] for t in A2)):
        ts = [t for t in A2 if t[2] == k]
        c2 = max(t[0]-t[1] for t in ts)
        check(C(2*k, k)-C(2*k, k-1) == cat(k), 'Catalan lead (2k) k=%d' % k)
        lhs, rhs = cat(k), sum(C(c2, h)*cat(k-1-h) for h in range(1, min(c2, k-1)+1))
        check(lhs > rhs, 'P2 corner k=%d' % k)
        corners2.append((k, 2*k, c2, lhs, rhs))
        pr('P2 corner k=%d (a,c)=(%d,%d): Cat_k=%d > %d' % (k, 2*k, c2, lhs, rhs))
    c2 = {row[0]: row[2] for row in corners2}
    check(sorted(A2) == sorted(t for t in D if t[1] == 2*t[2] and t[2] in c2 and t[0]-t[1] <= c2[t[2]]), 'P2 = (a=2k, c <= c2(k))')
    check(all(Phi(t[1], t[0]-t[1], t[2]) <= 0 for t in D if t[1] == 2*t[2] and t not in A2), 'a=2k outside P2 has Phi <= 0')
    # monotonicity lemma and Catalan maximum on a grid (both have proofs; cross-checks)
    for k in range(1, 16):
        for a in range(max(0, 2*k-3), 40):
            for c in range(0, 30):
                check(Phi(a+1, c, k) >= Phi(a, c, k) and Phi(a, c+1, k) <= Phi(a, c, k), 'monotonicity %d %d %d' % (a, c, k))
    for j in range(1, 31):
        check(max(C(m, j-1)-C(m, j) for m in range(0, 4*j+4)) == cat(j-1), 'Catalan maximum j=%d' % j)
    # ---------------- (T) P3 comparisons
    tail = []
    for (n, a, k) in sorted(P3):
        b = bco(n, a)
        check(b[k+1] <= b[k], 'tail %s' % ((n, a, k),))
        tail.append((n, a, k, n-a, 2*a-n, b[k], b[k+1]))
    pr('P3: %d comparisons b_{k+1} <= b_k pass' % len(tail))
    # ---------------- (L) Catalan line lemma and bound
    for j in range(1, 31):
        for M in range(0, 4*j+10):
            check(C(M, j)-C(M, j-1) >= cat(j-1)*max(-1, M-2*j+1), 'Catalan line lemma j=%d M=%d' % (j, M))
            check(C(M, j)-C(M, j-1) >= cat(j)*(M-2*j+1), 'second Catalan line j=%d M=%d' % (j, M))
    # the level term: max of the three per-fibre lower bounds, summed, equals the case formula
    for (n, a, k) in D:
        for e in range(n-a):
            for h in range(1, min(n-a, k-1)+1):
                U = Q(n-a) if h == 1 else LU(n-a, h, e)[1]
                z = Zlev(n, a, k, h, e)
                check(max(cat(k-h-1)*max(-U, z), cat(k-h)*z) == (cat(k-h)*z if z >= 0 else cat(k-h-1)*max(-U, z)), 'case formula')
    CL = [t for t in E1]+[t for t in sorted(P4) if min(R(t[0], t[1], t[2], e) for e in range(t[0]-t[1])) > 0]
    check(len(CL) == 11, 'Catalan line class size')
    clrows = []
    for (n, a, k) in CL:
        c = n-a
        e0, vals = argmin_check(lambda e: R(n, a, k, e), c, 'Catalan line %s' % ((n, a, k),))
        clrows.append((n, a, k, c, 2*a-n, 2*k-a, e0, vals))
        pr('Catalan line (%d,%d,%d): e0=%d R(e0)=%s neighbours %s' % (n, a, k, e0, tf(vals[e0]),
           [tf(vals[x]) for x in (e0-1, e0+1) if 0 <= x <= c-1]))
    P4_20 = classes(T20)[3]
    cl20 = [t for t in sorted(P4_20) if min(R(t[0], t[1], t[2], e) for e in range(t[0]-t[1])) > 0]
    pr('n<=20: stage-1 class P4 has %d triples; the Catalan line bound settles %d of them: %s' % (len(P4_20), len(cl20), cl20))
    check(len(P4_20) == 18 and len(cl20) == 10, 'n<=20 Catalan line count')
    # ---------------- (A) anchored bound with supporting lines
    with open(os.path.join(HERE, '..', 'outputs', 'floor26_lines.json')) as fh:
        sets = json.load(fh)
    AN = sorted(t for t in P4 if t not in CL)
    listed = sorted((r['n'], s['a'], s['k']) for s in sets for r in s['triples'])
    check(listed == AN and len(AN) == 32, 'anchored class = P4 minus the Catalan line triples')
    anrows, lsrows, nanch, nall_anch = [], [], 0, 0
    for sid, s in enumerate(sets, 1):
        a, k, w = s['a'], s['k'], Q(s['omega'])
        p = {int(h): Q(v) for h, v in s['p'].items()}
        q = {int(h): Q(v) for h, v in s['q'].items()}
        cmax = max(r['n'] for r in s['triples'])-a
        kinds = []
        for h in sorted(set(range(1, cmax+1)) | set(p)):
            if h not in p:
                check(all(g(w, k-h, M) == 0 for M in range(0, a-h+1)), 'unlisted level %d vanishes' % h)
                continue
            vals = [g(w, k-h, a-h-x) for x in range(0, a-h+1)]
            check(q[h] >= 0, 'q_h >= 0')
            check(all(vals[x] >= p[h]-q[h]*x for x in range(len(vals))), 'line condition set %d h=%d' % (sid, h))
            pa = Q(vals[0]); qa = max([Q(0)]+[(pa-vals[x])/x for x in range(1, len(vals))])
            kinds.append('A' if (p[h], q[h]) == (pa, qa) else 'E')
            if kinds[-1] == 'E':      # a supporting line of the lower convex hull: it touches the graph twice or is flat
                touch = [x for x in range(len(vals)) if vals[x] == p[h]-q[h]*x]
                check(len(touch) >= 2 or (q[h] == 0 and p[h] == min(vals)), 'hull edge set %d h=%d' % (sid, h))
                check(p[h] < pa and q[h] < qa, 'smaller p and q than the chord, set %d h=%d' % (sid, h))
        for h in p:
            check(h <= cmax or h <= min(a-1, k+1), 'level range')
        allA = all(x == 'A' for x in kinds)
        lsrows.append((sid, a, k, w, [r['n'] for r in s['triples']], p, q, kinds))
        for r in s['triples']:
            n = r['n']; c = n-a
            pp = {h: p[h] for h in p if h <= c}; qq = {h: q[h] for h in q if h <= c}
            e0, vals = argmin_check(lambda e: Bline(w, n, a, k, e, pp, qq), c, 'anchored %s' % ((n, a, k),))
            check(e0 == r['e0'], 'recorded e0 %s' % ((n, a, k),))
            anrows.append((n, a, k, c, 2*a-n, w, sid, e0, vals))
            nall_anch += allA
            pr('anchored (%d,%d,%d) omega=%s set %d lines %s e0=%d B(e0)=%s neighbours %s' % (n, a, k, tf(w), sid, ''.join(kinds), e0,
               tf(vals[e0]), [tf(vals[x]) for x in (e0-1, e0+1) if 0 <= x <= c-1]))
    pr('anchored class: %d triples, %d line sets; %d triples use only anchored chords (stage 1 unchanged), %d need a hull edge at some level'
       % (len(anrows), len(sets), nall_anch, len(anrows)-nall_anch))
    # stage 1's anchored chords with omega = 1/2 or 5/12 only (stage 1 verbatim): how many of the 33 would pass
    def stage1_ok(t):
        n, a, k = t
        for w in (Q(1, 2), Q(5, 12)):
            p, q = {}, {}
            for h in range(1, min(a-1, k+1)+1):
                vals = [g(w, k-h, a-h-x) for x in range(0, a-h+1)]
                p[h] = Q(vals[0]); q[h] = max([Q(0)]+[(p[h]-vals[x])/x for x in range(1, len(vals))])
            if Bline(w, n, a, k, 0, p, q) > 0 and Bline(w, n, a, k, 1, p, q) >= Bline(w, n, a, k, 0, p, q):
                return True
        return False
    s1 = [t for t in AN if stage1_ok(t)]
    s1all = [t for t in sorted(P4+E1) if stage1_ok(t)]
    def chords_any(t):
        n, a, k = t
        for i in range(25):
            w = Q(i, 24); p, q = {}, {}
            for h in range(1, min(a-1, k+1)+1):
                vals = [g(w, k-h, a-h-x) for x in range(0, a-h+1)]
                p[h] = Q(vals[0]); q[h] = max([Q(0)]+[(p[h]-vals[x])/x for x in range(1, len(vals))])
            if min(Bline(w, n, a, k, e, p, q) for e in range(n-a)) > 0:
                return True
        return False
    ch = [t for t in sorted(P4+E1) if chords_any(t)]
    pr('on the 43 triples (41 of P4 and the two P1 exceptions): stage 1 verbatim settles %d; anchored chords with some omega = i/24 and '
       'the minimum over all e settle %d; they fail at every omega = i/24 for %d: %s' % (len(s1all), len(ch), 43-len(ch),
       [t for t in sorted(P4+E1) if t not in ch]))
    pr('stage 1 anchored bound verbatim (chords, omega in {1/2, 5/12}, B(0)>0, B(1)>=B(0)): %d of %d' % (len(s1), len(AN)))
    # rising side alone: the exact level payment at omega = 1 (per-level convex minorants; decoupled levels)
    def hull(pts):
        H = []
        for pt in pts:
            while len(H) >= 2 and (H[-1][1]-H[-2][1])*(pt[0]-H[-2][0]) >= (pt[1]-H[-2][1])*(H[-1][0]-H[-2][0]):
                H.pop()
            H.append(pt)
        return H
    def psi(H, t):          # least value at mean excess <= t of a distribution on the level's excess values
        best = min(y for (x, y) in H if x <= t)
        for (x1, y1), (x2, y2) in zip(H, H[1:]):
            if x1 <= t <= x2:
                best = min(best, y1+(y2-y1)*(t-x1)/(x2-x1))
        return best
    def levmin(H, lo, hi, X):
        X = Q(X); cands = {lo, hi} | {X/x for (x, _) in H if x > 0 and lo <= X/x <= hi}
        return min((Q(0) if K == 0 else K*psi(H, X/K)) for K in cands)
    def payment(w, n, a, k, e):
        c = n-a
        Hs = {h: hull([(Q(x), Q(g(w, k-h, a-h-x))) for x in range(0, a-h+1)]) for h in range(1, c+1)}
        tot = Q(g(w, k, a))+c*psi(Hs[1], Q(a-1-e, c))
        for h in range(2, c+1):
            L, U = LU(c, h, e)
            tot += levmin(Hs[h], L, U, Xcap(a, c, h, e))
        return tot
    rise = {t: min(payment(Q(1), t[0], t[1], t[2], e) for e in range(t[0]-t[1])) for t in AN}
    rpos = [t for t in AN if rise[t] > 0]
    pr('rising side alone (level payment at omega = 1) on the anchored class: positive at %s only; negative at the other %d'
       % (rpos, len(AN)-len(rpos)))
    worst = min(AN, key=lambda t: rise[t])
    pr('  most negative: %s value %s; smallest: (21,12,7) value %s' % (worst, tf(rise[worst]), tf(rise[(21, 12, 7)])))
    check(rpos == [], 'rising-side diagnostic')
    check(max(rise[t] for t in AN) < 0, 'rising side strictly negative on the 32')
    pr('  largest of the 32 negative values: %s' % tf(max(rise[t] for t in AN)))
    rise248 = min(payment(Q(1), 24, 16, 8, e) for e in range(8))
    pr('  (24,16,8), now settled by the Catalan line bound: level payment at omega = 1 is %s' % tf(rise248))
    fall = {t: min(payment(Q(0), t[0], t[1], t[2], e) for e in range(t[0]-t[1])) for t in AN}
    check(all(v < 0 for v in fall.values()), 'falling side alone negative on all 33')
    pr('falling side alone (level payment at omega = 0): negative at all %d; largest value %s' % (len(AN), tf(max(fall.values()))))
    # ---------------- (R) n <= 20 recomputed: stage 1's P3 comparisons and P4 anchored values (stage 1 files not read)
    Q1_, Q2_, Q3_, Q4_ = classes(T20)
    check(all(bco(n, a)[k+1] <= bco(n, a)[k] for (n, a, k) in Q3_), 'n<=20 tail comparisons')
    s1rows = []
    for t in sorted(Q4_):
        n, a, k = t
        for w in (Q(1, 2), Q(5, 12)):
            p, q = {}, {}
            for h in range(1, min(a-1, k+1)+1):
                vals = [g(w, k-h, a-h-x) for x in range(0, a-h+1)]
                p[h] = Q(vals[0]); q[h] = max([Q(0)]+[(p[h]-vals[x])/x for x in range(1, len(vals))])
            b0, b1 = Bline(w, n, a, k, 0, p, q), Bline(w, n, a, k, 1, p, q)
            if b0 > 0 and b1 >= b0:
                s1rows.append((t, w, b0, b1)); break
    check(len(s1rows) == 18 and [r[0] for r in s1rows if r[1] != Q(1, 2)] == [(19, 13, 7)], 'n<=20 anchored values (stage 1)')
    check((s1rows[0][2], s1rows[0][3]) == (Q(105, 4), Q(28)), 'stage 1 example (12,8,4)')
    pr('n<=20 recomputed: %d tail comparisons, %d anchored triples (B(0)>0, B(1)>=B(0); omega 5/12 only at (19,13,7))' % (len(Q3_), len(s1rows)))
    # every window triple of D_26 is settled, every other triple is outside the window
    settledW = set(A1) - set(E1) | set(A2) | set(CL) | set(AN) | set(r[0] for r in s1rows)
    check(all(t in settledW for t in D if inW(t)), 'every window triple of D_26 is settled')
    check(all(t in settledW or not inW(t) for t in D), 'coverage')
    check(set(A3) == set(t for t in D if not inW(t) and t not in A1 and t not in A2), 'P3 = the rest outside the window')
    pr('coverage: all %d window triples of D_26 settled; the %d others lie outside the window' % (len([t for t in D if inW(t)]), len([t for t in D if not inW(t)])))
    # ---------------- (F) checks added after the referee report (30 Sep 2026)
    # S4: the 'exactly' of the P2 proposition by hand
    Rv = [Phi(2*k, c2[k]+1, k) for k in (7, 8, 9, 10)]
    check(Rv == [-170, -360, -774, -1578], 'S4 values %s' % Rv)
    check(not [t for t in T if t[1] == 2*t[2] and t[2] in (11, 12) and t[0]-t[1] > c2[t[2]]], 'S4 k = 11, 12')
    check(all(t[2] in c2 and (t[0]-t[1] <= c2[t[2]] or t[2] in (7, 8, 9, 10)) for t in T if t[1] == 2*t[2]), 'S4 coverage')
    # S5: rows of the corner table used for 21 <= n <= 26
    check(sorted(set(t[2] for t in P1)) == list(range(7, 13)) and sorted(set(t[2] for t in P2)) == list(range(8, 13)), 'S5 rows')
    # M1: an off-grid weight for (24,17,9) with the chords
    w = Q(31, 96); n, a, k = 24, 17, 9; pch, qch = {}, {}
    for h in range(1, min(a-1, k+1)+1):
        vals = [g(w, k-h, a-h-x) for x in range(0, a-h+1)]
        pch[h] = Q(vals[0]); qch[h] = max([Q(0)]+[(pch[h]-vals[x])/x for x in range(1, len(vals))])
    bv = [Bline(w, n, a, k, e, pch, qch) for e in range(n-a)]
    check(bv[0] == Q(1405, 48) and bv[1] >= bv[0] and min(bv) == bv[0], 'M1 off-grid example')
    # S8: triples of the anchored class that use a starred line although chords with some grid weight would suffice
    starred = set(t for (n_, a_, k_, c_, d_, w_, sid, e0, vals) in anrows for t in [(n_, a_, k_)]
                  if any(x == 'E' for x in [r for r in lsrows if r[0] == sid][0][7][:min(c_, k_+1)]))
    grid16 = set(t for t in sorted(P4+E1) if not chords_any(t))
    check(len(starred) == 28 and grid16 <= starred and len(starred - grid16) == 12, 'S8 count')
    pr('referee checks: S4 values %s; M1 (24,17,9) at 31/96: A(0) = %s; S8: %d starred, %d needed on the grid, %d others'
       % (Rv, tf(bv[0]), len(starred), len(grid16), len(starred - grid16)))
    # the shared-notation copy of the n <= 20 section keeps every number of its tables
    import re as _re
    src = open(os.path.join(HERE, '..', '..', 'floor', 'floor20_section.tex')).read()
    shr = open(os.path.join(HERE, '..', 'floor20_section_shared.tex')).read()
    blk = lambda t: t[t.index('\\newcommand{\\FloorCornersOne}'):t.index('\\section{Forests with at most twenty')]
    nums = lambda t: _re.findall(r'-?\d+(?:/\d+)?', t)
    check(nums(blk(src)) == nums(blk(shr)), 'shared copy: table numbers unchanged')
    # ---------------- (S) breakdown
    def row(name, S, hand, table):
        return (name, len(S), len([t for t in S if t[1] == 2*t[2]]), len([t for t in S if inW(t)]), len([t for t in S if not inW(t)]), hand, table)
    P1c = [t for t in P1 if t not in E1]; P4cl = [t for t in P4 if t in CL]
    brk = [row('P1 corners', P1c, len(P1c), 0), row('P1 Catalan line', E1, len(E1), 0), row('P2', P2, len(P2), 0),
           row('P3', P3, len(P3), 0), row('P4 Catalan line', P4cl, len(P4cl), 0), row('P4 anchored', AN, 0, len(AN))]
    tot = tuple(sum(b[i] for b in brk) for i in range(1, 7))
    for b in brk: pr('  %-16s %3d  a=2k %2d  k<hB %3d  k>=hB %2d  hand %3d  table %2d' % b)
    pr('  total 21..26     %3d  a=2k %2d  k<hB %3d  k>=hB %2d  hand %3d  table %2d' % tot)
    check(tot == (192, sum(1 for t in T if t[1] == 2*t[2]), 168, 24, 160, 32), 'breakdown 21..26 sums')
    Q1, Q2, Q3, Q4 = classes(T20)
    check([len(Q1), len(Q2), len(Q3), len(Q4)] == [72, 24, 16, 18], 'stage 1 classes on n<=20')
    comb = (len(Q1)+len(P1), len(Q2)+len(P2), len(Q3)+len(P3), len(Q4)+len(P4))
    hand26, table26 = 112+tot[4], 18+tot[5]
    pr('combined n<=26: P1 %d, P2 %d, P3 %d, P4 %d; hand %d, table %d, unresolved 0 (total %d)' % (comb+(hand26, table26, hand26+table26)))
    pr('combined n<=26 if the Catalan line bound is also used for n<=20: hand %d, table %d' % (hand26+len(cl20), table26-len(cl20)))
    check(hand26+table26 == 322, 'combined total')
    # ---------------- LaTeX macros
    out = ['% generated by scripts/verify_floor26.py; do not edit by hand']
    out.append('\\newcommand{\\FlxCornersOne}{%')
    for (k, a0, c1, lhs, rhs, formula) in corners1:
        out.append('%d & $(%d,%d)$ & %d & %d\\\\' % (k, a0, c1, lhs, rhs))
    out.append('}')
    out.append('\\newcommand{\\FlxCornersTwo}{%')
    for (k, a0, c2, lhs, rhs) in corners2:
        out.append('%d & $(%d,%d)$ & %d & %d\\\\' % (k, a0, c2, lhs, rhs))
    out.append('}')
    out.append('\\newcommand{\\FlxTwoList}{%')
    out.append(',\\ '.join('$(%d,%d,%d)$' % t for t in sorted(P2)))
    out.append('}')
    out.append('\\newcommand{\\FlxTail}{%')
    for (n, a, k, c, d, bk, bk1) in tail:
        out.append('$(%d,%d,%d)$ & %d & %d & %d & %d\\\\' % (n, a, k, c, d, bk, bk1))
    out.append('}')
    out.append('\\newcommand{\\FlxLine}{%')
    for (n, a, k, c, d, dl, e0, vals) in clrows:
        nb = ', '.join('$%s$' % tf(vals[x]) for x in (e0-1, e0+1) if 0 <= x <= c-1)
        out.append('$(%d,%d,%d)$ & %d & %d & $%d$ & %d & $%s$ & %s\\\\' % (n, a, k, c, d, dl, e0, tf(vals[e0]), nb))
    out.append('}')
    out.append('\\newcommand{\\FlxAnchored}{%')
    for (n, a, k, c, d, w, sid, e0, vals) in anrows:
        nb = ', '.join('$%s$' % tf(vals[x]) for x in (e0-1, e0+1) if 0 <= x <= c-1)
        out.append('$(%d,%d,%d)$ & %d & %d & $%s$ & %d & %d & $%s$ & %s\\\\' % (n, a, k, c, d, tf(w), sid, e0, tf(vals[e0]), nb))
    out.append('}')
    for (sid, a, k, w, ns, p, q, kinds) in lsrows:
        if k in p:
            check((p[k], q[k]) == (1-(1-w)*(a-k), Q(0)), 'closed form at h = k, set %d' % sid)
        if k+1 in p:
            check((p[k+1], q[k+1]) == (-(1-w), Q(0)), 'closed form at h = k+1, set %d' % sid)
    out.append('\\newcommand{\\FlxLevel}{%')
    for (sid, a, k, w, ns, p, q, kinds) in lsrows:
        hs = [h for h in sorted(p) if h <= k-1]
        pc = ['$%s$' % tf(p[h]) + ('' if kinds[i] == 'A' else '$^*$') for i, h in enumerate(hs)] + ['']*(9-len(hs))
        qc = ['$%s$' % tf(q[h]) for h in hs] + ['']*(9-len(hs))
        out.append('%d & $(%d,%d)$, $%s$ & $p^\\sharp_h$ & %s\\\\' % (sid, a, k, tf(w), ' & '.join(pc)))
        out.append(' & & $q^\\sharp_h$ & %s\\\\[2pt]' % ' & '.join(qc))
    out.append('}')
    names = {'P1 corners': ('$\\mathcal P^+_1$', '$2k\\le a-1$, $c\\le c^+_1(k)$', 'Prop.~\\ref{flx:prop:class1}', 'hand'),
             'P1 Catalan line': ('', '$2k\\le a-1$, $c>c^+_1(k)$', 'Prop.~\\ref{flx:prop:line}', 'hand'),
             'P2': ('$\\mathcal P^+_2$', '$a=2k$, $c\\le c^+_2(k)$', 'Prop.~\\ref{flx:prop:class2}', 'hand'),
             'P3': ('$\\mathcal P^+_3$', 'Table~\\ref{flx:tab:tail}', 'Prop.~\\ref{flx:prop:class3}', 'hand'),
             'P4 Catalan line': ('$\\mathcal P^+_4$', 'Table~\\ref{flx:tab:line}', 'Prop.~\\ref{flx:prop:line}', 'hand'),
             'P4 anchored': ('', 'Table~\\ref{flx:tab:values}', 'Prop.~\\ref{flx:prop:class4}', 'table')}
    out.append('\\newcommand{\\FlxBreakdown}{%')
    for b in brk:
        nm, rule, how, kind = names[b[0]]
        out.append('%s & %s & %d & %d & %d & %d & %s & %s\\\\' % (nm, rule, b[1], b[2], b[3], b[4], how, kind))
    out.append('\\midrule')
    out.append('total & & %d & %d & %d & %d & & %d / %d\\\\' % (tot[0], tot[1], tot[2], tot[3], tot[4], tot[5]))
    out.append('}')
    out.append('\\newcommand{\\FlxCombined}{%')
    q20 = [len(Q1), len(Q2), len(Q3), len(Q4)]; q26 = [len(P1), len(P2), len(P3), len(P4)]
    for i in range(4):
        out.append('$\\mathcal P_%d$, $\\mathcal P^+_%d$ & %d & %d & %d\\\\' % (i+1, i+1, q20[i], q26[i], q20[i]+q26[i]))
    out.append('\\midrule')
    out.append('total & %d & %d & %d\\\\' % (sum(q20), sum(q26), sum(q20)+sum(q26)))
    out.append('by hand & 112 & %d & %d\\\\' % (tot[4], 112+tot[4]))
    out.append('by printed tables & 18 & %d & %d\\\\' % (tot[5], 18+tot[5]))
    out.append('}')
    # the g-values used to check the lines by hand: omega = 1/2, j = 1..9, M = 0..19; omega = 13/24, j = 1..7, M = 0..14
    for part, w, js, Ms in (('Half', Q(1, 2), range(1, 10), range(0, 20)), ('Odd', Q(13, 24), range(1, 8), range(0, 15))):
        for blk, rng in (('A', [M for M in Ms if M < 7]), ('B', [M for M in Ms if 7 <= M < 14]), ('C', [M for M in Ms if M >= 14])):
            out.append('\\newcommand{\\FlxG%s%s}{%%' % (part, blk))
            for j in js:
                cells = ['$%s$' % tf(g(w, j, M)) for M in rng] + ['']*(7-len(rng))
                out.append('%d & %s\\\\' % (j, ' & '.join(cells)))
            out.append('}')
    # Pascal form of the omega = 1/2 table: g_j(M) = 2 C(M,j) - C(M+2,j+1)/2
    check(all(g(Q(1, 2), j, M) == 2*C(M, j)-Q(C(M+2, j+1), 2) for j in range(-2, 12) for M in range(0, 30)), 'Pascal form of g at 1/2')
    # the g-rows actually used by the lines must lie inside the printed ranges
    for (sid, a, k, w, ns, p, q, kinds) in lsrows:
        for h in p:
            j, r = k-h, a-h
            if j >= 1:
                check((w == Q(1, 2) and j <= 9 and r <= 19) or (w == Q(13, 24) and j <= 7 and r <= 14), 'g-table range')
    with open(os.path.join(HERE, '..', 'outputs', 'floor26_tables.tex'), 'w') as fh:
        fh.write('\n'.join(out)+'\n')
    pr('ALL CHECKS PASS' if OK[0] else 'SOME CHECK FAILED')
    sys.exit(0 if OK[0] else 1)

if __name__ == '__main__':
    main()
