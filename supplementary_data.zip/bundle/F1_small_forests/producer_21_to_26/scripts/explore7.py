#!/usr/bin/env python3
"""Exploration (floor26): can a rising-only (omega = 1) bound reach the tabulated class? Full level payment at omega=1."""
from fractions import Fraction as Q
from explore2 import Pval
from explore5 import AN
res=[]
for t in AN:
    v=min(Pval(Q(1),*t)); res.append((t,float(v)))
print([r for r in res if r[1]>0]); print('omega=1 level payment positive at',len([r for r in res if r[1]>0]),'of',len(res))
