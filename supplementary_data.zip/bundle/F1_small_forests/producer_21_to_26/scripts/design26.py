#!/usr/bin/env python3
"""Design step (floor26): choose, for the anchored class, the weight omega and one supporting line per level.
Writes ../outputs/floor26_lines.json.  The choices are verified independently by verify_floor26.py; nothing
here is trusted by the verifier except the choices themselves (omega, the lines (p_h,q_h), the rank e0)."""
import json, os
from fractions import Fraction as Q
from explore1 import B
from explore5 import AN, G, search, score
import verify_floor26 as V
from collections import defaultdict
G2 = defaultdict(list)
for _k, _g in G.items():
    for _t in _g:
        if min(V.R(_t[0], _t[1], _t[2], e) for e in range(_t[0]-_t[1])) <= 0:
            G2[_k].append(_t)
G = {k_: v_ for k_, v_ in G2.items() if v_}
from explore3 import cand_lines
half = Q(1, 2)
def ok(w, grp):
    a, k = grp[0][1], grp[0][2]
    s0, s, nchg, lines = search(w, a, k, grp)
    if s <= 0: return False, lines
    # revert to the anchored chord (largest intercept) wherever the bound stays positive
    anch = {h: max(cand_lines(w, a, k, h)) for h in lines}
    for h in sorted(lines):
        if lines[h] != anch[h]:
            L2 = dict(lines); L2[h] = anch[h]
            if score(w, grp, L2) > 0: lines = L2
    return True, lines
sets = []
for (a, k), grp in sorted(G.items()):
    grp = sorted(grp)
    i = 0
    while i < len(grp):
        j = len(grp)
        while j > i:
            good, lines = ok(half, grp[i:j])
            if good: break
            j -= 1
        if j > i:
            sets.append((half, grp[i:j], lines)); i = j; continue
        for w in (Q(13, 24), Q(7, 12), Q(5, 8), Q(3, 5), Q(11, 24), Q(5, 12)):
            good, lines = ok(w, [grp[i]])
            if good: sets.append((w, [grp[i]], lines)); break
        else:
            raise SystemExit('no line set for %s' % (grp[i],))
        i += 1
out = []
for (w, grp, lines) in sets:
    a, k = grp[0][1], grp[0][2]
    rows = []
    for (n, a_, k_) in grp:
        c = n-a
        vals = [B(w, n, a, k, e, {h: lines[h][0] for h in lines}, {h: lines[h][1] for h in lines}) for e in range(c)]
        rows.append({'n': n, 'e0': vals.index(min(vals))})
    out.append({'a': a, 'k': k, 'omega': str(w), 'triples': rows,
                'p': {str(h): str(lines[h][0]) for h in sorted(lines)}, 'q': {str(h): str(lines[h][1]) for h in sorted(lines)}})
    print((a, k), str(w), [r['n'] for r in rows], [r['e0'] for r in rows])
here = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(here, '..', 'outputs', 'floor26_lines.json'), 'w') as fh:
    json.dump(out, fh, indent=1)
print(len(out), 'line sets for', sum(len(s['triples']) for s in out), 'triples')
