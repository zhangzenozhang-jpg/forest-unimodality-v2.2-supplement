#!/usr/bin/env python3
"""Exploration (floor26): classify D_26 with 21<=n<=26 by stage-1 rules; anchored bound over an omega grid."""
import math
from fractions import Fraction as Q
def C(n,k): return math.comb(n,k) if n>=0 and 0<=k<=n else 0
def cat(j): return C(2*j,j)//(j+1) if j>=0 else 0
def bco(n,a):
    c,d=n-a,2*a-n
    return [sum(C(c,j)*2**j*C(d,s-j) for j in range(c+1)) for s in range(a+1)]
def hB(n,a):
    b=bco(n,a); return b.index(max(b))
def dom(n0,n1):
    for n in range(n0,n1+1):
        for a in range((n+1)//2,n):
            for k in range((n+3)//4+1,min(a,(n+2*a+5)//6)):
                yield n,a,k
def phi(a,c,k): return C(a,k)-C(a,k-1)-sum(C(c,h)*cat(k-1-h) for h in range(1,min(c,k-1)+1))
def f(w,k,y,m): return C(m,k-y)-w*C(m,k-y-1)-(1-w)*C(m,k-y+1)
def level(w,a,k,hmax):
    p,q={},{}
    for h in range(1,hmax+1):
        p[h]=Q(f(w,k,h,a-h))
        q[h]=max([Q(0)]+[(p[h]-f(w,k,h,a-h-x))/x for x in range(1,a-h+1)])
    return p,q
def B(w,n,a,k,e,p,q):
    c,d=n-a,2*a-n
    tot=Q(f(w,k,0,a))+c*p.get(1,0)-q.get(1,0)*(a-1-e)
    for h in range(2,c+1):
        if h==2: lo=hi=Q(C(c,2)-e)
        else:
            lo=Q(max(0,C(c,h)-e*C(c-2,h-2))); hi=min(Q(C(c,h)),Q(C(c-2,h-2)*(C(c,2)-e),C(h,2)))
        X=(a-1-e)*C(c-2,h-1)+d*C(c-2,h-2)
        tot+=min(lo*p.get(h,0),hi*p.get(h,0))-q.get(h,0)*X
    return tot
if __name__=='__main__':
    D=list(dom(21,26)); print('triples 21..26:',len(D))
    W=[t for t in D if t[2]<hB(t[0],t[1])]; print('window',len(W),'outside',len(D)-len(W))
    grid=sorted(set(Q(i,j) for j in (1,2,3,4,5,6,8,10,12,24) for i in range(j+1)))
    cls={}
    for (n,a,k) in D:
        c=n-a; inw=k<hB(n,a)
        if 2*k<=a-1 and phi(a,c,k)>0: cls[(n,a,k)]=('P1',inw); continue
        if a==2*k and phi(a,c,k)>0: cls[(n,a,k)]=('P2',inw); continue
        if not inw: cls[(n,a,k)]=('P3',inw); continue
        good=[]
        for w in grid:
            p,q=level(w,a,k,min(a-1,k+1))
            vals=[B(w,n,a,k,e,p,q) for e in range(0,c)]
            if min(vals)>0: good.append((w,vals.index(min(vals)),min(vals)))
        cls[(n,a,k)]=('P4' if good else 'OPEN',inw,good[:3] if good else None, 2*k<=a-1, a==2*k)
    from collections import Counter
    print(Counter(v[0] for v in cls.values()))
    for t,v in sorted(cls.items()):
        if v[0] in ('P4','OPEN'): print(t,v)
    # P1 failures
    print('2k<=a-1 with phi<=0:',[t for t in D if 2*t[2]<=t[1]-1 and phi(t[1],t[0]-t[1],t[2])<=0])
    print('a=2k with phi<=0:',[t for t in D if t[1]==2*t[2] and phi(t[1],t[0]-t[1],t[2])<=0])
