#!/usr/bin/env python3
"""A test, not a proof: on random forests, the Catalan line bound i_k - i_{k-1} >= Phi*(e(F[C])) for every k >= 2,
and the anchored bound with the line sets of ../outputs/floor26_lines.json, V_omega(k) >= B#(e(F[C])), at every
random forest whose (n,a,k) is a triple of that file (forests with 21..26 vertices, biased towards those (n,a))."""
import random, sys, json, os
from fractions import Fraction as Q
from verify_floor26 import R, Bline
HERE = os.path.dirname(os.path.abspath(__file__))
def indep_poly(n, adj):
    seen = [False]*n; poly = [1]
    def mul(p, q):
        r = [0]*(len(p)+len(q)-1)
        for i, x in enumerate(p):
            for j, y in enumerate(q): r[i+j] += x*y
        return r
    def dp(v, par):
        a, b = [1], [0, 1]      # a: v not in S; b: v in S
        for u in adj[v]:
            if u == par: continue
            ua, ub = dp(u, v)
            s = [0]*max(len(ua), len(ub))
            for i, x in enumerate(ua): s[i] += x
            for i, x in enumerate(ub): s[i] += x
            a = mul(a, s); b = mul(b, ua)
        return a, b
    for v in range(n):
        if not seen[v]:
            stack = [v]; seen[v] = True
            while stack:
                x = stack.pop()
                for y in adj[x]:
                    if not seen[y]: seen[y] = True; stack.append(y)
            a, b = dp(v, -1)
            s = [0]*max(len(a), len(b))
            for i, x in enumerate(a): s[i] += x
            for i, x in enumerate(b): s[i] += x
            poly = mul(poly, s)
    return poly
def max_indep(n, adj):
    deg = [len(adj[v]) for v in range(n)]; alive = [True]*n; A = []
    while any(alive):
        v = next((v for v in range(n) if alive[v] and deg[v] <= 1), None)
        A.append(v); alive[v] = False
        for u in adj[v]:
            if alive[u]:
                alive[u] = False
                for w in adj[u]:
                    if alive[w]: deg[w] -= 1
    return A
def rand_forest(n, rng, p_edge):
    adj = [[] for _ in range(n)]
    for v in range(1, n):
        if rng.random() < p_edge:
            u = rng.randrange(v) if rng.random() < 0.6 else max(0, v-1-rng.randrange(min(v, 3)))
            adj[u].append(v); adj[v].append(u)
    return adj
sets = json.load(open(os.path.join(HERE, '..', 'outputs', 'floor26_lines.json')))
lines = {}
for s in sets:
    for r in s['triples']:
        lines[(r['n'], s['a'], s['k'])] = (Q(s['omega']), {int(h): Q(v) for h, v in s['p'].items()}, {int(h): Q(v) for h, v in s['q'].items()})
rng = random.Random(20260930); tested = fails = anch = 0
for it in range(int(sys.argv[1]) if len(sys.argv) > 1 else 3000):
    n = rng.randrange(8, 27)
    adj = rand_forest(n, rng, rng.choice([1.0, 0.95, 0.85]))
    A = set(max_indep(n, adj)); a = len(A)
    if a == n: continue
    C = [v for v in range(n) if v not in A]; c = len(C)
    e = sum(1 for v in C for u in adj[v] if u in C and u > v)
    i = indep_poly(n, adj) + [0, 0]
    for k in range(2, a+1):
        tested += 1
        if i[k]-i[k-1] < R(n, a, k, e): fails += 1; print('Catalan line FAIL', n, a, k, e)
        if (n, a, k) in lines:
            w, p, q = lines[(n, a, k)]
            pp = {h: p[h] for h in p if h <= c}; qq = {h: q[h] for h in q if h <= c}
            V = w*(i[k]-i[k-1])+(1-w)*(i[k]-i[k+1]); anch += 1
            if V < Bline(w, n, a, k, e, pp, qq): fails += 1; print('anchored FAIL', n, a, k, e)
print('forest test: %d (forest, k) pairs, %d anchored-class matches, %d failures' % (tested, anch, fails))
sys.exit(1 if fails else 0)
