#!/usr/bin/env python3
"""Exploration (floor26): Catalan line bound with the second line Cat_j (M-2j+1) (slope Cat_j through the zero)."""
from fractions import Fraction as Q
import verify_floor26 as V
from verify_floor26 import C, cat, LU, Xcap, D26, hB, classes
def R2(n,a,k,e):
    c,dl=n-a,2*k-a
    tot=Q(C(a,k)-C(a,k-1))
    Y=Q((2-dl)*c-(a-1-e)); tot+=max(cat(k-2)*max(Q(-c),Y), cat(k-1)*Y)
    for h in range(2,min(c,k-1)+1):
        L,U=LU(c,h,e); kap=h+1-dl
        Y=min(kap*L,kap*U)-Xcap(a,c,h,e)
        tot+=max(cat(k-h-1)*max(-U,Y), cat(k-h)*Y)
    return tot
# lemma check
for j in range(1,31):
    for M in range(0,4*j+10):
        assert C(M,j)-C(M,j-1) >= cat(j)*(M-2*j+1), (j,M)
D=D26(); W=[t for t in D if t[2]<hB(t[0],t[1])]
P1,P2,P3,P4=classes([t for t in D if t[0]>=21]); Q1,Q2,Q3,Q4=classes([t for t in D if t[0]<=20])
E1=[(24,15,7),(26,17,8)]
for name,S in (('21..26 P4+E1',sorted(P4)+E1),('n<=20 P4',sorted(Q4))):
    old=[t for t in S if min(V.R(t[0],t[1],t[2],e) for e in range(t[0]-t[1]))>0]
    new=[t for t in S if min(R2(t[0],t[1],t[2],e) for e in range(t[0]-t[1]))>0]
    print(name,'old',len(old),'new',len(new),'gained',[t for t in new if t not in old])
