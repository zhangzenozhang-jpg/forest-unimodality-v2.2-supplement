import time, random, sys, json
from fractions import Fraction as Fr
import certs, model as M, checker as CK, ivad as V
random.seed(7)
name = sys.argv[1]; n = int(sys.argv[2])
path, cert = certs.load(name)
cov, leaves = certs.verify_cover(cert)
print(name, json.dumps(cov))
band = M.Band(cert['segment'])
sample = random.sample(range(len(leaves)), n)
t0 = time.time(); tot = {'pieces':0,'ysplits':0,'centered':0}
for idx in sample:
    b, tok = leaves[idx]
    if len(b) == 4: b = b + (Fr(0), Fr(1))
    t = time.time()
    c = CK.Cell(band, *b)
    ok, lb, info = c.run()
    for k in tot: tot[k] += c.stats[k]
    print(idx, tok, ok, None if lb is None else '%.3e' % V.f(lb), info, c.stats, '%.2fs' % (time.time()-t), [float(z) for z in b], flush=True)
print('avg per cell %.3fs' % ((time.time()-t0)/n), tot)
