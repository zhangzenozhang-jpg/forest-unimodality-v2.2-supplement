#!/bin/zsh
cd "/Users/kvallier/Desktop/Erdos 993/ProofRuns/2026-09-28_analytic_large_n/LEAN/referee/o2/review_replay"
while ! grep -q "^DONE" log_L1.txt 2>/dev/null; do sleep 10; done
./run_gaps.sh 1 H2b
