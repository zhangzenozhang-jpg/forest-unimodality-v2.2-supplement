"""Consistency check of the certified bounds against actual values: for every replayed cell the
certified lower bound must not exceed the float minimum of Phi sampled inside the cell."""
import json, sys, os
HERE = os.path.dirname(os.path.abspath(__file__))
for band in sys.argv[1:]:
    est = json.load(open(os.path.join(HERE, 'floatmin_%s.json' % band.replace('_r2', ''))))['est']
    bad = []; n = 0; ratio = []
    for line in open(os.path.join(HERE, 'results_%s.jsonl' % band)):
        r = json.loads(line)
        if 'i' not in r or r['lb'] is None:
            continue
        n += 1
        e = est[r['i']]
        if r['lb'] > e * (1 + 1e-9) + 1e-12:
            bad.append((r['i'], r['lb'], e))
        if e > 0:
            ratio.append(r['lb'] / e)
    ratio.sort()
    print(band, 'cells', n, 'violations (certified lb > sampled value)', len(bad), bad[:3],
          'lb/est quantiles: min %.3g median %.3g max %.3g' % (ratio[0], ratio[len(ratio)//2], ratio[-1]))
