import sys, time
from fractions import Fraction as Fr
from collections import defaultdict
import certs, model as M, checker as CK, ivad as V
path, cert = certs.load('central_3')
cov, leaves = certs.verify_cover(cert)
band = M.Band(cert['segment'])
for idx in [2387, 1326]:
    b, tok = leaves[idx]
    c = CK.Cell(band, *(b + (Fr(0), Fr(1))))
    succ = defaultdict(list); fails = defaultdict(list)
    orig = c.piece
    def wrapped(label, ya, yb, orig=orig):
        ok, lb, info = orig(label, ya, yb)
        (succ if ok else fails)[label].append((float(ya), float(yb), None if lb is None else V.f(lb), info if not ok else info[1]))
        return ok, lb, info
    c.piece = wrapped
    t = time.time(); print(c.run(), time.time() - t)
    for label in succ:
        print(label, 'ok', len(succ[label]), 'fail', len(fails[label]), 'min width ok %.4g' % min(yb - ya for ya, yb, _, _ in succ[label]))
        print('    fails:', [(round(a, 4), round(b_, 4), f[3] if f[2] is None else round(f[2], 7), f[3]) for (a, b_, *_), f in zip(fails[label], fails[label])][:12])
