"""Second, deliberately simple rigorous checker (cross-check of checker.py's logic): natural
interval enclosures only (no centred forms, no anchors, no line searches), with plain
bisection of the (lam, x, y) box; the parent labels and the model are those of model.py.
usage: python3 naive_check.py BAND NSAMPLE"""
import sys, os, json, random, time
from fractions import Fraction as Fr
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import certs, model as M, ivad as V
from ivad import AD, I, ONE, isub, idiv, imul
from checker import dyadic_floor

def labels(Bb, y0, y1):
    out = [('low', y0), ('high', y0)]
    Plo, Phi = Bb.P.v
    for j in range(1, 8):
        if V.mpf_lt(Phi, V.fr_lo(Fr(j, 8))):
            continue
        thr = isub(ONE, idiv(I(j), imul(I(8), (Plo, Plo))))[0]
        ys = max(y0, dyadic_floor(thr))
        if ys <= y1:
            out.append((j, ys))
    return out

BUDGET = int(os.environ.get('NAIVE_BUDGET', '100000000'))


class Budget(Exception):
    pass


def ok_box(band, l0, l1, x0, x1, y0, y1, depth, maxdepth, count):
    count[0] += 1
    if count[0] > BUDGET:
        raise Budget()
    try:
        Bb = M.make_base(band, AD(I(l0, l1)), AD(I(x0, x1)))
        good = True
        for label, ys in labels(Bb, y0, y1):
            tri = M.regimes(Bb, label, AD(I(ys, y1)))
            for k, (A, Bc, D) in enumerate(tri):
                m = M.qmin_lb(A.v[0], Bc.v[0], D.v[0], k == 1)
                if m is None or V.negative(m):
                    good = False; break
            if not good: break
    except (V.ZeroDiv, AssertionError):
        good = False
    if good:
        return True
    if depth >= maxdepth:
        return False
    # bisect the relatively widest coordinate
    wl, wx, wy = (l1 - l0) / Fr(1, 64), (x1 - x0) / max(x0, Fr(1, 64)) * 4, (y1 - y0) * 8
    if wl >= wx and wl >= wy:
        m = (l0 + l1) / 2; parts = [(l0, m, x0, x1, y0, y1), (m, l1, x0, x1, y0, y1)]
    elif wx >= wy:
        m = (x0 + x1) / 2; parts = [(l0, l1, x0, m, y0, y1), (l0, l1, m, x1, y0, y1)]
    else:
        m = (y0 + y1) / 2; parts = [(l0, l1, x0, x1, y0, m), (l0, l1, x0, x1, m, y1)]
    return all(ok_box(band, *p, depth + 1, maxdepth, count) for p in parts)

band_name = sys.argv[1]; ns = int(sys.argv[2])
path, cert = certs.load(band_name); cov, leaves = certs.verify_cover(cert)
band = M.Band(cert['segment'])
random.seed(7)
idx = random.sample(range(len(leaves)), ns)
res = {'pass': 0, 'fail': 0, 'boxes': 0}
t0 = time.process_time()
fails = []
for i in idx:
    b = leaves[i][0]; b = b if len(b) == 6 else b + (Fr(0), Fr(1))
    cnt = [0]
    try:
        ok = ok_box(band, *b, 0, 22, cnt)
    except Budget:
        res['budget_exceeded'] = res.get('budget_exceeded', 0) + 1
        continue
    res['boxes'] += cnt[0]
    if ok: res['pass'] += 1
    else: res['fail'] += 1; fails.append(i)
res['cpu'] = round(time.process_time() - t0, 1); res['failed_cells'] = fails[:20]
print(band_name, res, flush=True)
with open(os.path.join(HERE, 'naive_check.jsonl'), 'a') as fh:
    fh.write(json.dumps({'band': band_name, 'sample': ns, **res}) + '\n')
