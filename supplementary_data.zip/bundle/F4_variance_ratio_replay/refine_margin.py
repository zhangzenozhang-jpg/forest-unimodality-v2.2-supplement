"""Refined certified lower bound of min Phi on single certificate cells (reporting only):
split the cell's (lam,x) box into n x n sub-boxes, and in each run the reporting-mode check
with y-refinement until pieces certify `frac` * (float-estimated cell minimum).
usage: python3 refine_margin.py BAND n frac idx [idx ...]"""
import sys, os, json, time
from fractions import Fraction as Fr
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import certs, model as M, checker as CK, ivad as V
from mpmath.libmp import to_float, round_floor
band = sys.argv[1]; n = int(sys.argv[2]); frac = Fr(sys.argv[3]); idxs = [int(a) for a in sys.argv[4:]]
path, cert = certs.load(band)
cov, leaves = certs.verify_cover(cert)
B = M.Band(cert['segment'])
fm = json.load(open(os.path.join(HERE, 'floatmin_%s.json' % band)))
res = []
for i in idxs:
    b = leaves[i][0]
    box = b if len(b) == 6 else b + (Fr(0), Fr(1))
    l0, l1, x0, x1, y0, y1 = box
    goal = V.fr_lo(frac * Fr(fm['est'][i]).limit_denominator(10 ** 12))
    t0 = time.process_time()
    worst = None
    ok_all = True
    for a in range(n):
        for c in range(n):
            sub = (l0 + (l1 - l0) * a / n, l0 + (l1 - l0) * (a + 1) / n, x0 + (x1 - x0) * c / n, x0 + (x1 - x0) * (c + 1) / n, y0, y1)
            cell = CK.Cell(B, *sub)
            ok, lb, info = cell.run(full=True, goal=goal)
            ok_all = ok_all and ok
            if lb is not None and (worst is None or V.mpf_lt(lb, worst[0])):
                worst = (lb, info, [str(z) for z in sub])
    r = {'i': i, 'box': [str(z) for z in b], 'float_est_min': fm['est'][i], 'n': n, 'goal_frac': str(frac), 'ok': ok_all,
         'refined_certified_min': to_float(worst[0], rnd=round_floor), 'where': worst[1], 'subbox': worst[2],
         'cpu': round(time.process_time() - t0, 1)}
    print(json.dumps(r), flush=True)
    res.append(r)
with open(os.path.join(HERE, 'refined_%s.jsonl' % band), 'a') as fh:
    for r in res:
        fh.write(json.dumps(r) + '\n')
