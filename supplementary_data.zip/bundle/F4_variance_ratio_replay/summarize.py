"""Aggregate replay results per band.  usage: python3 summarize.py BAND [BAND ...]"""
import sys, os, json
from collections import Counter
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import certs

allout = {}
for band in sys.argv[1:]:
    path, cert = certs.load(band.replace('_r2', ''))
    n_leaves = cert['leaves']
    rows = [json.loads(l) for l in open(os.path.join(HERE, 'results_%s.jsonl' % band))]
    cells = [r for r in rows if 'i' in r]
    meta = [r for r in rows if 'i' not in r]
    idx = Counter(r['i'] for r in cells)
    dup = [i for i, c in idx.items() if c > 1]
    missing = sorted(set(range(n_leaves)) - set(idx))
    fails = [r for r in cells if not r['ok']]
    sub = [r for r in cells if r['subcells'] > 1]
    hows = Counter(tuple(r['info'][:3]) if r['info'] else None for r in cells if r['ok'])
    out = {
        'certificate_leaves': n_leaves, 'replayed_cells': len(idx), 'duplicates': len(dup), 'missing': len(missing),
        'failures': len(fails), 'fail_examples': [(r['i'], r['box'], r['info'], r['failinfo']) for r in fails[:5]],
        'cells_needing_lamx_subdivision': len(sub), 'total_leaf_subcells': sum(r['subcells'] for r in cells),
        'max_subdivision_depth': max(r['maxdepth'] for r in cells),
        'subdivided_examples': [(r['i'], r['box'], r['subcells'], r['maxdepth']) for r in sorted(sub, key=lambda r: -r['subcells'])[:5]],
        'y_splits_total': sum(r['stats'].get('ysplits', 0) for r in cells),
        'line_evals_total': sum(r['stats'].get('line_evals', 0) for r in cells),
        'det_route_uses': sum(r['stats'].get('det_used', 0) for r in cells),
        'cpu_seconds_total': round(sum(r['cpu'] for r in cells), 1),
        'runs': meta,
    }
    allout[band] = out
    print(band, json.dumps({k: v for k, v in out.items() if k not in ('runs',)}, default=str))
    print('   runs:', meta)
json.dump(allout, open(os.path.join(HERE, 'summary_%s.json' % '_'.join(sys.argv[1:])), 'w'), indent=1, default=str)
