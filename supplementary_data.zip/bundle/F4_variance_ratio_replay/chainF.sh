#!/bin/zsh
cd "/Users/kvallier/Desktop/Erdos 993/ProofRuns/2026-09-28_analytic_large_n/LEAN/referee/o2/review_replay"
while ! grep -q "^DONE" log_H3b_r2.txt 2>/dev/null; do sleep 10; done
nice -n 5 python3 -B frozen_v2/driver.py L23 --workers 3 --indices L23_partA_indices.json --tag _partA >> log_L23_partA.txt 2>&1
