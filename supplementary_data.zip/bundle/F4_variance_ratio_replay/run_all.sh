#!/bin/zsh
# sequential band replays with the frozen_v1 code, each with W workers, all under nice 10
cd "/Users/kvallier/Desktop/Erdos 993/ProofRuns/2026-09-28_analytic_large_n/LEAN/referee/o2/review_replay"
W=${W:-4}
for b in "$@"; do
  nice -n 10 python3 -B frozen_v1/driver.py $b --workers $W >> log_$b.txt 2>&1
done
