"""NON-RIGOROUS finite sanity check of the conclusion Var(K) <= gamma/(1+lam) * W on random
small forests (brute force), at activities in each replayed band (incl. band endpoints)."""
import random, itertools, json, os
from fractions import Fraction as Fr
random.seed(42)
bands = [('low', Fr(1, 3), Fr(3, 5), 2.0), ('central', Fr(4, 5), Fr(13, 10), 1.6), ('upper_shoulder', Fr(13, 10), Fr(8, 5), 1.7)]


def forest(n):
    par = [-1] * n
    for v in range(1, n):
        par[v] = random.randrange(v) if random.random() < 0.9 else -1   # occasional new component
    return [(v, par[v]) for v in range(1, n) if par[v] >= 0]


out = {}
for name, lo, hi, gamma in bands:
    worst = (1e9, None)
    for trial in range(1500):
        n = random.randint(1, 13)
        edges = forest(n)
        lam = float(random.choice([lo, hi, lo + (hi - lo) * Fr(random.randint(0, 100), 100)]))
        adj = [set() for _ in range(n)]
        for a, b in edges:
            adj[a].add(b); adj[b].add(a)
        Z = 0.0; m1 = 0.0; m2 = 0.0; marg = [0.0] * n
        indep = []
        for S in range(1 << n):
            ok = all(not (S >> a & 1 and S >> b & 1) for a, b in edges)
            if not ok:
                continue
            indep.append(S)
            k = bin(S).count('1'); w = lam ** k
            Z += w; m1 += w * k; m2 += w * k * k
            for v in range(n):
                if S >> v & 1:
                    marg[v] += w
        marg = [m / Z for m in marg]
        var = m2 / Z - (m1 / Z) ** 2
        W = max(sum(marg[v] for v in range(n) if S >> v & 1) for S in indep)
        ratio = var / (gamma / (1 + lam) * W)
        if ratio > worst[0] or worst[1] is None:
            if worst[1] is None or ratio > worst[0]:
                worst = (ratio, dict(n=n, edges=edges, lam=lam))
    out[name] = {'max Var/(cW)': worst[0], 'at': worst[1]}
    print(name, out[name], flush=True)
json.dump(out, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'theorem_sanity.json'), 'w'), indent=1, default=str)
