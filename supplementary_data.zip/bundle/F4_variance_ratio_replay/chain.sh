#!/bin/zsh
cd "/Users/kvallier/Desktop/Erdos 993/ProofRuns/2026-09-28_analytic_large_n/LEAN/referee/o2/review_replay"
while pgrep -f "frozen_v1/driver.py central_0" > /dev/null; do sleep 10; done
W=3 ./run_all.sh central_1 central_2 upper_shoulder low
