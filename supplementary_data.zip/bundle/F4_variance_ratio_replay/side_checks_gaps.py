"""Gap-band (8 rows) header/inventory checks, coefficient guards, parse-depth check, leaf
endpoint D_1 >= 0, and whole-window [1/3,7/3] coverage at the Profile30 prices over all 14
rows -- referee's own code.  Writes side_checks_gaps.json."""
import json, sys, os, gzip, math, time
from fractions import Fraction as Fr
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import certs
import ivad as V
from ivad import I, AD
import model as M
import checker as CK
from mpmath.libmp import to_float, round_floor

G = certs.GAPS
inv = json.load(open(G + 'GAP_CERTIFICATE_INVENTORY.json'))
invrows = {r['name']: r for r in inv['rows']}
ext = {}
for d in 'ABC':
    ci = json.load(open(G + 'checker_extended_%s/CERTIFICATES.json' % d))
    co = json.load(open(G + 'checker_extended_%s/COEFFICIENTS.json' % d))
    cos = {s['name']: s for s in co['segments']}
    for c in ci['certificates']:
        if c['name'] in certs.GAP_BANDS:
            ext[c['name']] = (d, c, cos.get(c['name']))
PROFILE = [(Fr(1, 3), Fr(3, 5), Fr(2)), (Fr(3, 5), Fr(4, 5), Fr(17, 10)), (Fr(4, 5), Fr(13, 10), Fr(8, 5)),
           (Fr(13, 10), Fr(8, 5), Fr(17, 10)), (Fr(8, 5), Fr(7, 3), Fr(2))]
out = {'headers': {}, 'guards': {}, 'leaf_endpoint_D1': {}}


def depth_of(b, seg):
    lo, hi = Fr(seg['lo']), Fr(seg['hi'])
    d = int(round(math.log2((hi - lo) / (b[1] - b[0]))))
    for a, c in zip(certs.XEDGES, certs.XEDGES[1:]):
        if a <= b[2] and b[3] <= c:
            d += int(round(math.log2((c - a) / (b[3] - b[2]))))
            break
    return d


for n in certs.GAP_BANDS:
    path, cert = certs.load(n)
    sha = certs.sha256(path)
    seg = cert['segment']
    table = json.load(open(G + 'fit/tables/%s.json' % n))
    table_core = {k: v for k, v in table.items() if k != 'fit_info'}
    r = invrows[n]
    d, ec, eseg = ext[n]
    cov, leaves = certs.verify_cover(cert)
    depth = max(depth_of(b, seg) for b, _ in leaves)
    h = {
        'sha256': sha, 'sha_eq_gap_inventory': sha == r['certificate_sha256'],
        'sha_eq_extended_CERTIFICATES': sha == ec['sha256'], 'extended_dir': d,
        'format': cert['format'], 'status': cert['status'], 'inventory_status': r['status'],
        'segment_eq_fit_table': seg == table_core, 'segment_eq_extended_COEFFICIENTS': seg == eseg,
        'lo_hi_gamma_eq_inventory': (Fr(seg['lo']), Fr(seg['hi']), Fr(seg['gamma'])) == (Fr(r['lo']), Fr(r['hi']), Fr(r['gamma'])),
        'leaves_eq_inventory': cert['leaves'] == r['leaves'],
        'lo': seg['lo'], 'hi': seg['hi'], 'gamma': str(Fr(seg['gamma'])),
        'cover': cov, 'max_depth_my_parse': depth, 'max_depth_matches': depth == cert['max_depth'],
    }
    out['headers'][n] = h
    g = {}
    for side in ['left', 'right']:
        co = {k: [Fr(z) for z in seg[side][k]] for k in ['u', 'v', 's', 'tau']}
        w, ell = Fr(seg[side]['w']), Fr(seg[side]['ell'])
        g[side] = {'u_in_[0,1]': all(0 <= z <= 1 for z in co['u']), 'v_in_[0,1]': all(0 <= z <= 1 for z in co['v']),
                   's_in_[0,4]': all(0 <= z <= 4 for z in co['s']), '|tau|<=4': all(abs(z) <= 4 for z in co['tau']),
                   'w_in_[0,2]': 0 <= w <= 2, 'ell>=1/1000': ell >= Fr(1, 1000),
                   'u,v>=1/100_on_[0,1/8]': min(co['u'][0], co['u'][1], co['v'][0], co['v'][1]) >= Fr(1, 100),
                   'u8=v8=s8=0': co['u'][8] == 0 and co['v'][8] == 0 and co['s'][8] == 0,
                   'min_uv_first_segment': str(min(co['u'][0], co['u'][1], co['v'][0], co['v'][1])), 'ell': str(ell)}
    g['all_ok'] = all(all(v for k, v in g[s].items() if isinstance(v, bool)) for s in ['left', 'right'])
    out['guards'][n] = g
    print(n, {k: v for k, v in h.items() if k != 'cover'}, 'guards', g['all_ok'], flush=True)

# ---------------------------------------------------------------- whole-window coverage, 14 rows
rows = []
r2 = json.load(open(certs.PKT + 'CERTIFICATES.json'))['certificates']
for c in r2:
    if c['name'] in certs.BANDS:
        rows.append((c['name'], Fr(c['lo']), Fr(c['hi']), Fr(c['gamma'])))
for n in certs.GAP_BANDS:
    seg = certs.load(n)[1]['segment']
    rows.append((n, Fr(seg['lo']), Fr(seg['hi']), Fr(seg['gamma'])))


def covered(a, b, g):
    """closed [a,b] covered by the union of closed rows with gamma_row <= g (sweep)."""
    elig = sorted((lo, hi, name) for name, lo, hi, gr in rows if gr <= g and hi >= a and lo <= b)
    at = a
    used = []
    for lo, hi, name in elig:
        if lo > at:
            break
        if hi > at or (hi == at and not used):
            used.append(name)
        at = max(at, hi)
        if at >= b:
            break
    return at >= b, str(at), used


cov14 = []
for a, b, g in PROFILE:
    ok, through, used = covered(a, b, g)
    cov14.append({'band': '[%s,%s]' % (a, b) if a == Fr(1, 3) else '(%s,%s]' % (a, b), 'gamma': str(g),
                  'closed_interval_covered': ok, 'through': through, 'rows_used': used})
    print('coverage', cov14[-1], flush=True)
out['whole_window_coverage_14_rows'] = cov14
out['rows'] = [(n, str(lo), str(hi), str(g)) for n, lo, hi, g in rows]


# ---------------------------------------------------------------- physical leaf endpoint
def leaf_endpoint(name, nl=64):
    path, cert = certs.load(name)
    band = M.Band(cert['segment'])
    lo, hi = band.lo, band.hi
    worst = None
    fails = 0
    t0 = time.process_time()
    for i in range(nl):
        l0 = lo + (hi - lo) * i / nl
        l1 = lo + (hi - lo) * (i + 1) / nl
        c = CK.Cell(band, l0, l1, Fr(1), Fr(1), Fr(0), Fr(1))
        for label, (ys0, ys1) in c.labels():
            stack = [(ys0, ys1, 0)]
            while stack:
                a, b, d = stack.pop()
                tri = M.regimes(c.Bbox, label, AD(I(a, b), CK.YSLOT))
                lb = tri[1][2].v[0]
                if V.mpf_lt(lb, CK.REPORT_TAU):
                    lb = CK.lmax(lb, c.two_step(label, 1, 'D', tri[1], a, b, V.fzero, exhaustive=True))
                if lb is None or V.negative(lb):
                    if d < 12:
                        m = (a + b) / 2
                        stack += [(a, m, d + 1), (m, b, d + 1)]
                        continue
                    fails += 1
                    continue
                if worst is None or V.mpf_lt(lb, worst[0]):
                    worst = (lb, float(l0), float(l1), label, float(a), float(b))
    return {'lambda_strips': nl, 'fails': fails, 'min_D1_lower_bound': to_float(worst[0], rnd=round_floor),
            'at': {'lam': [worst[1], worst[2]], 'label': worst[3], 'y': [worst[4], worst[5]]},
            'cpu_s': round(time.process_time() - t0, 1)}


for n in certs.GAP_BANDS:
    out['leaf_endpoint_D1'][n] = leaf_endpoint(n)
    print(n, out['leaf_endpoint_D1'][n], flush=True)
json.dump(out, open(os.path.join(HERE, 'side_checks_gaps.json'), 'w'), indent=1, default=str)
