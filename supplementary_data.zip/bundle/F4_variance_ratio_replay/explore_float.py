"""NON-RIGOROUS float exploration of the local payment Phi (referee's own code).

Used only to calibrate the rigorous replay (where margins are thin).  Implements
Phi directly from PRO_R2_PROOF.md sections 2, 4, 5 (definitions (4),(7),(8),(11)),
not from the author's checkers.
"""
import json, sys
import numpy as np
from fractions import Fraction as F

SRC = '/Users/kvallier/Desktop/Erdos 993/ProofRuns/2026-09-28_analytic_large_n/SOUL/O2_FINAL/R2_PACKET/'
COEF = json.load(open(SRC + 'COEFFICIENTS.json'))
SEGS = {s['name']: s for s in COEF['segments']}


def table(seg, lam):
    lo, hi = float(F(seg['lo'])), float(F(seg['hi']))
    w = (lam - lo) / (hi - lo) if hi > lo else lam * 0
    out = {}
    for k in ['u', 'v', 's', 'tau']:
        L = np.array([float(F(z)) for z in seg['left'][k]])
        R = np.array([float(F(z)) for z in seg['right'][k]])
        out[k] = (1 - w)[..., None] * L + w[..., None] * R
    for k in ['w', 'ell']:
        out[k] = (1 - w) * float(F(seg['left'][k])) + w * float(F(seg['right'][k]))
    return out


def interp(vals, xx):
    s = np.clip(xx * 8, 0, 8)
    j = np.minimum(np.floor(s).astype(int), 7)
    fr = s - j
    a = np.take_along_axis(vals, j[..., None], -1)[..., 0]
    b = np.take_along_axis(vals, (j + 1)[..., None], -1)[..., 0]
    return a + (b - a) * fr


def fq(pi, q):
    return np.maximum((1 + q) * pi / (2 * q), (1 + q) * pi / (2 * q * q) + (q - 1) / (2 * q))


def quadmin_half(A, B, D):
    out = np.where(B >= 0, D, D - B * B / (4 * np.where(A > 0, A, 1)))
    out = np.where((A < 0) | ((A <= 0) & (B < 0)), -np.inf, out)
    return out


def quadmin_unit(A, B, D):
    m = np.minimum(D, A + B + D)
    with np.errstate(divide='ignore', invalid='ignore'):
        eta = -B / (2 * A)
        inner = (A > 0) & (eta > 0) & (eta < 1)
        mv = D - B * B / (4 * A)
    return np.where(inner, np.minimum(m, mv), m)


def phi_parts(seg, gamma, lam, x, Y, label, gform='max'):
    """Return (min over z of Phi, per-regime mins) for arrays lam,x,Y (broadcast)."""
    lam, x, Y = np.broadcast_arrays(lam, x, Y)
    tb = table(seg, lam)
    q = lam / (1 + lam); p = q * x; r = 1 - q * Y; c = gamma / (1 + lam)
    P = (1 - p) / (1 - q * p)
    Hc = np.minimum(q, 1 - p / (lam * (1 - p)))
    Mup = np.maximum(1 - r, (1 - p * r) * Hc)
    g4 = (1 + fq(p * r, q) - fq(Mup, q)) / 2
    g = np.maximum(fq(p * r, q), g4) if gform == 'max' else g4
    T = np.log(lam * (1 - p) / p); L = np.log(1 + lam)
    j = np.floor(T / L)
    H = j * lam + np.exp(T - j * L) - 1
    phi = j * q + 1 - np.exp(-(T - j * L))
    h = p / (-np.log1p(-p))
    G = np.log(p / (lam * (1 - p) ** 2))
    up, vp, sp, taup = [interp(tb[k], x) for k in ['u', 'v', 's', 'tau']]
    Au = up / (p * T); Av = vp / (p * T); As = r * sp / H
    if label == 'low':
        tx = Y
    elif label == 'high':
        tx = P
    else:
        tx = np.full_like(Y, label / 8.0)
    ut, vt, st, taut = [interp(tb[k], tx) for k in ['u', 'v', 's', 'tau']]
    w, ell = tb['w'], tb['ell']
    Nu = r * (1 - p) + h * ut + (1 - r) * (1 - p) * st
    Nv = r * (1 - p) + h * vt + (1 - r) * (1 - p) * st
    beta = r * taup + (1 - r) * taut + w
    D0 = c * r * g - r * taup - w + w * r * phi - ell * G / p + Av + As
    D1 = c * r * g - Nv + (1 - r) * taut + w * r * phi - ell * G / p
    m0 = quadmin_half(Av + As - Nu, 2 * (Av + As) - beta, D0)
    m1 = quadmin_unit(Av + As - Nv, 2 * Nv - beta, D1)
    m2 = quadmin_half(Au + As - Nv, beta - 2 * Nv, D1)
    valid = np.ones_like(Y, dtype=bool)
    if isinstance(label, int):
        valid = (Y <= label / 8.0) & (label / 8.0 <= P)
    return np.minimum(np.minimum(m0, m1), m2), (m0, m1, m2), valid


def phi_direct(seg, gamma, lam, x, Y, tq, z):
    """Phi evaluated straight from (11) (scalar), for self-test of the quadratic forms."""
    tb = table(seg, np.array(lam))
    q = lam / (1 + lam); p = q * x; r = 1 - q * Y; c = gamma / (1 + lam)
    Hc = min(q, 1 - p / (lam * (1 - p)))
    Mup = max(1 - r, (1 - p * r) * Hc)
    g = max(fq(p * r, q), (1 + fq(p * r, q) - fq(Mup, q)) / 2)
    T = np.log(lam * (1 - p) / p); L = np.log(1 + lam); j = np.floor(T / L)
    H = j * lam + np.exp(T - j * L) - 1; phi = j * q + 1 - np.exp(-(T - j * L))
    h = p / (-np.log1p(-p)); G = np.log(p / (lam * (1 - p) ** 2))
    I = lambda k, xx: float(interp(tb[k][None, :], np.array([xx]))[0])
    u_p, v_p, s_p, tau_p = [I(k, x) for k in ['u', 'v', 's', 'tau']]
    u_t, v_t, s_t, tau_t = [I(k, tq) for k in ['u', 'v', 's', 'tau']]
    w, ell = float(tb['w']), float(tb['ell'])
    pos = lambda a: max(a, 0.0)
    Ru = u_p * pos(z - 1) ** 2 / (p * T) - u_t * h * pos(-z) ** 2
    Rv = v_p * pos(1 - z) ** 2 / (p * T) - v_t * h * pos(z) ** 2
    Rs = r * s_p * (1 - z) ** 2 / H - (1 - r) * s_t * (1 - p) * z * z
    Rtau = r * tau_p * (z - 1) + (1 - r) * tau_t * z
    Rw = z - 1 + r * phi
    return c * r * g - r * (1 - p) * z * z + Ru + Rv + Rs + Rtau + w * Rw - ell * G / p


if __name__ == '__main__':
    bands = [('low', 2.0), ('central_0', 1.6), ('central_1', 1.6), ('central_2', 1.6), ('central_3', 1.6), ('upper_shoulder', 1.7)]
    xs = np.concatenate([np.geomspace(2 ** -16, 1 / 8, 60), np.linspace(1 / 8, 1 - 1e-7, 400)])
    for name, gamma in bands:
        seg = SEGS[name]
        lo, hi = float(F(seg['lo'])), float(F(seg['hi']))
        lams = np.linspace(lo, hi, 25)
        worst = (np.inf, None)
        for lam in lams:
            q = lam / (1 + lam)
            X = xs[:, None]
            P = (1 - q * X) / (1 - q * q * X)
            ys = np.linspace(0, 1, 81)[None, :]
            Y = P * (1 - ys)
            for label in ['low', 'high'] + list(range(1, 8)):
                m, parts, valid = phi_parts(seg, gamma, np.full_like(Y, lam), np.broadcast_to(X, Y.shape), Y, label)
                m = np.where(valid, m, np.inf)
                k = np.unravel_index(np.argmin(m), m.shape)
                if m[k] < worst[0]:
                    worst = (m[k], (lam, float(X[k[0], 0]), float(Y[k]), label, [float(pp[k]) for pp in parts]))
        print(name, 'min_z Phi over grid =', worst[0], 'at lam,x,Y,label,parts', worst[1], flush=True)
