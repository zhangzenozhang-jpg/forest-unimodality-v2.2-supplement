#!/bin/zsh
cd "/Users/kvallier/Desktop/Erdos 993/ProofRuns/2026-09-28_analytic_large_n/LEAN/referee/o2/review_replay"
while ! grep -q "^DONE" log_low.txt 2>/dev/null; do sleep 15; done
./run_gaps.sh 3 H8 H4b H3b L23 H2b
