#!/bin/zsh
cd "/Users/kvallier/Desktop/Erdos 993/ProofRuns/2026-09-28_analytic_large_n/LEAN/referee/o2/review_replay"
while ! grep -q "^DONE" log_H2b.txt 2>/dev/null; do sleep 10; done
./gap_refine.sh
echo GAP_REFINE_DONE > gap_refine.done
