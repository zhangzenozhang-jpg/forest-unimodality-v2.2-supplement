#!/bin/zsh
cd "/Users/kvallier/Desktop/Erdos 993/ProofRuns/2026-09-28_analytic_large_n/LEAN/referee/o2/review_replay"
nice -n 10 python3 -B refine_margin.py H8 2 1/2 1111 > /dev/null
nice -n 10 python3 -B refine_margin.py H4b 2 1/2 1305 > /dev/null
nice -n 10 python3 -B refine_margin.py H3b 2 1/2 1191 > /dev/null
nice -n 10 python3 -B refine_margin.py L23 2 1/2 1582 > /dev/null
nice -n 10 python3 -B refine_margin.py L1 2 1/2 910 > /dev/null
nice -n 10 python3 -B refine_margin.py L4e 2 1/2 586 > /dev/null
nice -n 10 python3 -B refine_margin.py H2b 2 1/2 1094 > /dev/null
nice -n 10 python3 -B refine_margin.py H1 2 1/2 555 > /dev/null
nice -n 10 python3 -B gap_sanity.py > gap_sanity.log 2>&1
