"""NON-RIGOROUS sanity checks for the 8 gap rows: actual records on random trees (domain
inclusion + Phi at the record, as in records_sanity.py) and the brute-force O2 conclusion on
small forests at the gap activities; plus a dense float scan of the former H4 pocket region
(x in [0.04,0.09], Y in [0.2,0.35], parent-low) for H2b/H3b/H4b."""
import random, itertools, json, os, sys
import numpy as np
from fractions import Fraction as Fr
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
exec(open(os.path.join(HERE, 'records_sanity.py')).read().split("bands = [")[0])
import certs
random.seed(31)
out = {'records': {}, 'pocket_scan': {}, 'theorem': {}}
for name in certs.GAP_BANDS:
    seg = certs.load(name)[1]['segment']; gamma = float(Fr(seg['gamma']))
    lo, hi = float(Fr(seg['lo'])), float(Fr(seg['hi']))
    nrec = 0; outside = 0; minphi = (np.inf, None)
    for trial in range(120):
        lam = random.uniform(lo, hi)
        kind = random.choice(['recursive', 'recursive', 'star', 'path', 'caterpillar', 'spider'])
        n = random.randint(1, 60)
        par = random_tree(n, kind)
        p, r, z, pi, ch = records(par, lam); q = lam / (1 + lam)
        for v in range(n):
            x = p[v] / q
            t = p[par[v]] if par[v] >= 0 else 0.0
            omr = pi[par[v]] if par[v] >= 0 else 0.0
            rmin = 1 / (1 + lam * (1 - p[v])); tmax = lam * (1 - p[v]) / (1 + lam * (1 - p[v]))
            ok = (0 < p[v] <= q * (1 + 1e-12)) and (rmin * (1 - 1e-12) <= r[v] <= 1 + 1e-12)
            if par[v] >= 0:
                ok = ok and (omr <= t * (1 + 1e-12)) and (t <= tmax * (1 + 1e-12))
            outside += (not ok); nrec += 1
            if not ch[v]:
                val = float(EF.phi_direct(seg, gamma, lam, 1 - 1e-9, omr / q, t / q, 1.0))
            else:
                val = float(EF.phi_direct(seg, gamma, lam, x, omr / q, t / q, z[v]))
            if val < minphi[0]:
                minphi = (val, dict(lam=lam, n=n, kind=kind, x=x, z=z[v]))
    out['records'][name] = dict(records=nrec, outside=outside, min_Phi=minphi[0], at=minphi[1])
    print(name, out['records'][name], flush=True)
    if name in ('H2b', 'H3b', 'H4b'):
        L = np.linspace(lo, hi, 21)[:, None, None]
        X = np.linspace(0.04, 0.09, 101)[None, :, None]
        Yv = np.linspace(0.2, 0.35, 151)[None, None, :]
        lam, x, Y = np.broadcast_arrays(L, X, Yv)
        best = np.inf
        for label in ['low', 'high', 1, 2]:
            m, parts, valid = EF.phi_parts(seg, gamma, lam, x, Y, label)
            m = np.where(valid, m, np.inf)
            best = min(best, float(m.min()))
        out['pocket_scan'][name] = best
        print('  pocket-region float min', best, flush=True)
# brute-force conclusion on small forests
for label, lo, hi, gamma in [('L-range', Fr(3, 5), Fr(4, 5), 1.7), ('H-range', Fr(8, 5), Fr(7, 3), 2.0)]:
    worst = 0.0
    for trial in range(300):
        n = random.randint(1, 11)
        par = [-1] * n
        for v in range(1, n):
            par[v] = random.randrange(v) if random.random() < 0.9 else -1
        edges = [(v, par[v]) for v in range(1, n) if par[v] >= 0]
        lam = float(random.choice([lo, hi, lo + (hi - lo) * Fr(random.randint(0, 100), 100)]))
        Z = m1 = m2 = 0.0; marg = [0.0] * n; indep = []
        for S in range(1 << n):
            if any(S >> a & 1 and S >> b & 1 for a, b in edges):
                continue
            indep.append(S); k = bin(S).count('1'); w = lam ** k
            Z += w; m1 += w * k; m2 += w * k * k
            for v in range(n):
                if S >> v & 1:
                    marg[v] += w
        marg = [mm / Z for mm in marg]
        var = m2 / Z - (m1 / Z) ** 2
        W = max(sum(marg[v] for v in range(n) if S >> v & 1) for S in indep)
        worst = max(worst, var / (gamma / (1 + lam) * W))
    out['theorem'][label] = worst
    print(label, 'max Var/(cW)', worst, flush=True)
json.dump(out, open(os.path.join(HERE, 'gap_sanity.json'), 'w'), indent=1, default=str)
