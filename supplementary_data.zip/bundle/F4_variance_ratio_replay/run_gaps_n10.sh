#!/bin/zsh
# absolute niceness 10 (this environment's base niceness is 5), frozen_v2 code
cd "/Users/kvallier/Desktop/Erdos 993/ProofRuns/2026-09-28_analytic_large_n/LEAN/referee/o2/review_replay"
nice -n 5 python3 -B frozen_v2/driver.py H3b --workers 3 --tag _r2 >> log_H3b_r2.txt 2>&1
nice -n 5 python3 -B frozen_v2/driver.py L23 --workers 3 >> log_L23.txt 2>&1
