#!/bin/zsh
cd "/Users/kvallier/Desktop/Erdos 993/ProofRuns/2026-09-28_analytic_large_n/LEAN/referee/o2/review_replay"
while [ ! -f gap_refine.done ]; do sleep 10; done
nice -n 5 python3 -B frozen_v2/driver.py L23 --workers 1 --indices L23_partB_indices.json --tag _partB >> log_L23_partB.txt 2>&1
