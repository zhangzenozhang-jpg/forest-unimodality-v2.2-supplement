"""NON-RIGOROUS sanity check of the record coordinates: on random finite trees at activities in
each band, compute the actual records (p, r, t, z) from the hard-core recursions, check that
they lie in the domain covered by the certificates (Lemma 1), and evaluate Phi (float, (11)).
Also checks Var(K) = sum pi (1-p) z^2 against brute-force enumeration on small trees."""
import random, itertools, json, os, sys
import numpy as np
from fractions import Fraction as Fr
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import explore_float as EF

random.seed(993)


def random_tree(n, kind):
    par = [-1]
    for v in range(1, n):
        if kind == 'recursive':
            par.append(random.randrange(v))
        elif kind == 'star':
            par.append(0)
        elif kind == 'path':
            par.append(v - 1)
        elif kind == 'caterpillar':
            par.append(v - 1 if v % 3 else max(0, v - 2))
        else:  # broom / spider
            par.append(0 if v <= 4 else v - 4)
    return par


def records(par, lam):
    n = len(par)
    ch = [[] for _ in range(n)]
    for v in range(1, n):
        ch[par[v]].append(v)
    order = list(range(n))[::-1]          # children have larger labels
    p = [0.0] * n
    z = [0.0] * n
    for v in order:
        prod = 1.0
        for u in ch[v]:
            prod *= (1 - p[u])
        p[v] = lam * prod / (1 + lam * prod)
        z[v] = 1 - sum(p[u] * z[u] for u in ch[v])
    pi = [0.0] * n
    r = [1.0] * n
    for v in range(n):
        if par[v] >= 0:
            r[v] = 1 - pi[par[v]]
        pi[v] = p[v] * r[v]
    return p, r, z, pi, ch


def brute_var(par, lam):
    n = len(par)
    edges = [(v, par[v]) for v in range(1, n)]
    Z = 0.0; m1 = 0.0; m2 = 0.0
    for S in itertools.product([0, 1], repeat=n):
        if any(S[a] and S[b] for a, b in edges):
            continue
        k = sum(S); w = lam ** k
        Z += w; m1 += w * k; m2 += w * k * k
    return m2 / Z - (m1 / Z) ** 2


bands = [('low', 2.0), ('central_0', 1.6), ('central_1', 1.6), ('central_2', 1.6), ('central_3', 1.6), ('upper_shoulder', 1.7)]
report = {}
maxvar = 0.0
for name, gamma in bands:
    seg = EF.SEGS[name]
    lo, hi = float(Fr(seg['lo'])), float(Fr(seg['hi']))
    nrec = 0; outside = 0; minphi = (np.inf, None)
    for trial in range(400):
        lam = random.uniform(lo, hi)
        kind = random.choice(['recursive', 'recursive', 'star', 'path', 'caterpillar', 'spider'])
        n = random.randint(1, 40)
        par = random_tree(n, kind)
        p, r, z, pi, ch = records(par, lam)
        if n <= 12:
            vb = brute_var(par, lam)
            vi = sum(pi[v] * (1 - p[v]) * z[v] ** 2 for v in range(n))
            maxvar = max(maxvar, abs(vb - vi))
        q = lam / (1 + lam)
        for v in range(n):
            x = p[v] / q
            nrec += 1
            rmin = 1 / (1 + lam * (1 - p[v]))
            tmax = lam * (1 - p[v]) / (1 + lam * (1 - p[v]))
            t = p[par[v]] if par[v] >= 0 else 0.0
            omr = pi[par[v]] if par[v] >= 0 else 0.0      # 1 - r without cancellation
            ok = (0 < p[v] <= q * (1 + 1e-12)) and (rmin * (1 - 1e-12) <= r[v] <= 1 + 1e-12)
            if par[v] >= 0:
                ok = ok and (omr <= t * (1 + 1e-12)) and (t <= tmax * (1 + 1e-12))
            outside += (not ok)
            if not ch[v]:
                # physical leaf: only z = 1 and own terms vanish: Phi = D_1 at x = 1
                val = float(EF.phi_direct(seg, gamma, lam, 1 - 1e-9, omr / q, t / q, 1.0))
            else:
                val = float(EF.phi_direct(seg, gamma, lam, x, omr / q, t / q, z[v]))
            if val < minphi[0]:
                minphi = (val, dict(lam=lam, n=n, kind=kind, v=v, x=x, r=r[v], tq=t / q, z=z[v], leaf=not ch[v]))
    report[name] = {'records': nrec, 'outside_certified_domain': outside, 'min_Phi_at_actual_records': minphi[0], 'at': minphi[1]}
    print(name, report[name], flush=True)
report['max_abs_Var_identity_error_n<=12'] = maxvar
print('Var identity max abs error (n<=12, brute force):', maxvar)
json.dump(report, open(os.path.join(HERE, 'records_sanity.json'), 'w'), indent=1, default=str)
