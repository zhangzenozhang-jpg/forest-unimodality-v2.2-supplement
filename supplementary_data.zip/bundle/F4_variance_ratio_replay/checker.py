"""Referee's own cell checker for the local payment Phi.

For a cell  lam in [l0,l1], x in [x0,x1], y in [y0,y1]  and every parent label, prove that
the k-th quadratic of (13), q_k(eta) = A eta^2 + B eta + D, is >= 0 on its complete
response range (k = 0: z<=0, eta>=0;  k = 1: 0<=z<=1, eta in [0,1];  k = 2: z>=1,
eta>=0), i.e. Phi >= 0 for every real z.

Lower bounds used for a scalar quantity X over the cell-piece  (X one of A, B, D,
Det = 4AD - B^2, or m = min_eta q_k):
  natural : interval value over the box (for m: min_eta A.lo eta^2 + B.lo eta + D.lo,
            valid because eta >= 0).
  tight   : centred form about the box centre intersected with the natural enclosure.
  two-step: for th' = (l',x',y'):  X(th') >= X(l_a,x_a,y') - err_lx  (mean value in
            (lam,x) at fixed y, gradient enclosed over the whole box; the anchor coordinate
            is the lo/hi end where the gradient component has a sign, else the midpoint with
            err += |grad|*radius), and X(l_a,x_a,y') >= min over the y-piece along the fixed
            anchor line, computed by rigorous 1-D subdivision.  For m the (lam,x)-gradient is
            Z^2 dA + Z dB + dD with Z an enclosure of all minimisers (one-sided argument
            m(th') - m(th_a) >= q(eta';th') - q(eta';th_a), eta' a minimiser at th').
Pass rules: unit regime: m >= 0.  Half-line: A >= 0 and D >= 0 and (B >= 0, or m >= 0
(needs A > 0 for Z), or Det >= 0).  A failing piece is bisected in y (YDEPTH levels); a
cell that still fails is bisected in (lam,x) by the driver (depth <= 10).
"""
from fractions import Fraction as Fr
import math
import ivad as V
from ivad import AD, I, ONE, ZERO, iadd, isub, imul, idiv, isq, ineg, icap, ZeroDiv
from model import make_base, regimes, qmin_lb

YDEPTH = 10
LINE_DEPTH = 18
REPORT_TAU = V.fr_lo(Fr(1, 50))
TWO_I = I(2)
FOUR_I = I(4)
YSLOT = (None, None, ONE)


def sym(r):
    return (V.fr_lo(-r), V.fr_hi(r))


def dyadic_floor(m, bits=48):
    q = V.to_fr(m)
    return Fr(math.floor(q * (1 << bits)), 1 << bits)


def minimizers(A, Bc, unit):
    """Enclosure of all minimisers of A eta^2 + B eta + D on the regime's eta-range for all
    (A,B) in the given enclosures; None if it cannot be bounded (half-line)."""
    if unit:
        if V.positive(A[0]):
            v = idiv(ineg(Bc), imul(TWO_I, A))
            return (V.mn(V.fone, V.mx(V.fzero, v[0])), V.mn(V.fone, V.mx(V.fzero, v[1])))
        return (V.fzero, V.fone)
    if V.nonneg(Bc[0]) and V.nonneg(A[0]):
        return ZERO
    if V.positive(A[0]):
        v = idiv(ineg(Bc), imul(TWO_I, A))
        return (V.mx(V.fzero, v[0]), V.mx(V.fzero, v[1]))
    return None


def grad_m(A, Bc, D, Z, i):
    Z2 = isq(Z)
    gm = None
    for gx, w in ((A.g[i], Z2), (Bc.g[i], Z), (D.g[i], ONE)):
        if gx is not None:
            t = imul(gx, w)
            gm = t if gm is None else iadd(gm, t)
    return gm


def quantity(kind, tri, unit, Z=None):
    """(lower bound of value, gradient slots or None) of a quantity of the triple."""
    A, Bc, D = tri
    if kind == 'A':
        return A.v[0], A.g
    if kind == 'B':
        return Bc.v[0], Bc.g
    if kind == 'D':
        return D.v[0], D.g
    if kind == 'Det':
        X = (A * D) * FOUR_I - Bc.sq()
        return X.v[0], X.g
    # kind == 'm'
    lb = qmin_lb(A.v[0], Bc.v[0], D.v[0], unit)
    if Z is None:
        Z = minimizers(A.v, Bc.v, unit)
    if Z is None:
        return lb, None
    return lb, tuple(grad_m(A, Bc, D, Z, i) for i in range(3))


def point_lb(kind, tri, unit):
    if kind == 'm':
        A, Bc, D = tri
        return qmin_lb(A.v[0], Bc.v[0], D.v[0], unit)
    return quantity(kind, tri, unit)[0]


def lmax(a, b):
    if a is None:
        return b
    if b is None:
        return a
    return V.mx(a, b)


class Cell:
    def __init__(self, band, l0, l1, x0, x1, y0, y1):
        self.band = band
        self.box = [(Fr(l0), Fr(l1)), (Fr(x0), Fr(x1)), (Fr(y0), Fr(y1))]
        self.rad = [(b - a) / 2 for a, b in self.box]
        self.radI = [sym(r) for r in self.rad]
        self.radHi = [V.fr_hi(r) for r in self.rad]
        self.point_bases = {}
        self.line_cache = {}
        (a, b), (c, d) = self.box[0], self.box[1]
        lam = AD(I(a, b), (ONE, None, None))
        x = AD(I(c, d), (None, ONE, None))
        self.Bbox = make_base(band, lam, x)
        self.stats = {'pieces': 0, 'ysplits': 0, 'centered': 0, 'line_evals': 0, 'det_used': 0}

    def coord(self, i, code):
        a, b = self.box[i]
        return a if code < 0 else b if code > 0 else (a + b) / 2

    def base_at(self, cl, cx):
        key = (cl, cx)
        B = self.point_bases.get(key)
        if B is None:
            B = make_base(self.band, AD(I(self.coord(0, cl))), AD(I(self.coord(1, cx))))
            self.point_bases[key] = B
        return B

    def labels(self):
        out = [('low', self.box[2]), ('high', self.box[2])]
        Plo, Phi = self.Bbox.P.v
        y0, y1 = self.box[2]
        for j in range(1, 8):
            if V.mpf_lt(Phi, V.fr_lo(Fr(j, 8))):
                continue            # knot j/8 > P everywhere: never an admissible parent
            # admissible records satisfy y >= 1 - j/(8P) >= 1 - j/(8 P.lo)
            thr = isub(ONE, idiv(I(j), imul(I(8), (Plo, Plo))))[0]
            ys = max(y0, dyadic_floor(thr))
            if ys > y1:
                continue
            out.append((j, (ys, y1)))
        return out

    # ------------------------------------------------------------ anchor line
    def line_tri(self, label, code, a, b):
        key = (label, code, a, b)
        t = self.line_cache.get(key)
        if t is None:
            self.stats['line_evals'] += 1
            Bp = self.base_at(*code)
            yv = AD(I(a, b), YSLOT) if a != b else AD(I(a))
            t = regimes(Bp, label, yv)
            self.line_cache[key] = t
        return t

    def line_lb(self, label, k, kind, code, ya, yb, target, exhaustive=False):
        """Rigorous lower bound of min_{y in [ya,yb]} X(lam_a, x_a, y) for the quantity
        `kind` of regime k.  Sub-intervals are refined until their bound clears `target`
        (or LINE_DEPTH).  Non-exhaustive: None as soon as one sub-interval cannot clear
        target.  Exhaustive: minimum over all final sub-interval bounds."""
        unit = (k == 1)
        stack = [(ya, yb, 0)]
        L = None
        while stack:
            a, b, d = stack.pop()
            tri = self.line_tri(label, code, a, b)[k]
            best, g = quantity(kind, tri, unit)
            if (best is None or V.mpf_lt(best, target)) and a != b and g is not None:
                gy = g[2]
                if gy is None:
                    ycode, err = 0, V.fzero
                elif V.nonneg(gy[0]):
                    ycode, err = -1, V.fzero
                elif V.nonpos(gy[1]):
                    ycode, err = 1, V.fzero
                else:
                    ycode = 0
                    err = V.mpf_mul(V.iabsmax(gy), V.fr_hi((b - a) / 2), V.PREC, V.RC)
                yp = a if ycode < 0 else b if ycode > 0 else (a + b) / 2
                pt = point_lb(kind, self.line_tri(label, code, yp, yp)[k], unit)
                if pt is not None:
                    best = lmax(best, V.mpf_sub(pt, err, V.PREC, V.RF))
            if best is not None and not V.mpf_lt(best, target):
                L = best if L is None else V.mn(L, best)
                continue
            if d >= LINE_DEPTH or a == b:
                if not exhaustive or best is None:
                    return None
                L = best if L is None else V.mn(L, best)
                continue
            m = (a + b) / 2
            stack.append((a, m, d + 1))
            stack.append((m, b, d + 1))
        return L

    def seg_bound(self, label, k, kind, code, a, b):
        """(certified lower bound over [a,b] along the anchor line, point value estimate)."""
        unit = (k == 1)
        tri = self.line_tri(label, code, a, b)[k]
        best, g = quantity(kind, tri, unit)
        est = None
        if a != b and g is not None:
            gy = g[2]
            if gy is None:
                ycode, err = 0, V.fzero
            elif V.nonneg(gy[0]):
                ycode, err = -1, V.fzero
            elif V.nonpos(gy[1]):
                ycode, err = 1, V.fzero
            else:
                ycode = 0
                err = V.mpf_mul(V.iabsmax(gy), V.fr_hi((b - a) / 2), V.PREC, V.RC)
            yp = a if ycode < 0 else b if ycode > 0 else (a + b) / 2
            pt = point_lb(kind, self.line_tri(label, code, yp, yp)[k], unit)
            if pt is not None:
                est = pt
                best = lmax(best, V.mpf_sub(pt, err, V.PREC, V.RF))
        if est is None:
            pt = point_lb(kind, self.line_tri(label, code, (a + b) / 2, (a + b) / 2)[k], unit)
            est = pt
        return best, est

    def line_bb(self, label, k, kind, code, ya, yb, budget=160, rtol=Fr(1, 20), target=None):
        """Branch-and-bound certified lower bound of min_{[ya,yb]} X(lam_a,x_a,.) (reporting).
        Returns the minimum of the certified bounds of the final sub-intervals."""
        import heapq
        lb, est = self.seg_bound(label, k, kind, code, ya, yb)
        if lb is None:
            lb = V.mpf_neg(V.from_int(10 ** 9))
        heap = [(V.f(lb), 0, lb, ya, yb, 0)]
        upper = V.f(est) if est is not None else float('inf')
        cnt = 1
        evals = 0
        while heap and evals < budget:
            fl, _, lbm, a, b, d = heap[0]
            if d >= LINE_DEPTH or a == b:
                break
            if upper - fl <= float(rtol) * max(abs(upper), 1e-12) and (target is None or not V.mpf_lt(lbm, target)):
                break
            heapq.heappop(heap)
            m = (a + b) / 2
            for (u, w) in ((a, m), (m, b)):
                l2, e2 = self.seg_bound(label, k, kind, code, u, w)
                evals += 1
                if l2 is None:
                    l2 = V.mpf_neg(V.from_int(10 ** 9))
                if e2 is not None:
                    upper = min(upper, V.f(e2))
                cnt += 1
                heapq.heappush(heap, (V.f(l2), cnt, l2, u, w, d + 1))
        out = None
        for item in heap:
            out = item[2] if out is None else V.mn(out, item[2])
        return out

    def two_step(self, label, k, kind, tri_box, ya, yb, extra, Z=None, exhaustive=False):
        unit = (k == 1)
        _, g = quantity(kind, tri_box, unit, Z)
        if g is None:
            return None
        code = []
        err = V.fzero
        for i in range(2):
            gi = g[i]
            if gi is None or self.rad[i] == 0:
                code.append(0)
            elif V.nonneg(gi[0]):
                code.append(-1)
            elif V.nonpos(gi[1]):
                code.append(1)
            else:
                code.append(0)
                err = V.mpf_add(err, V.mpf_mul(V.iabsmax(gi), self.radHi[i], V.PREC, V.RC), V.PREC, V.RC)
        if exhaustive:
            L = self.line_bb(label, k, kind, tuple(code), ya, yb, target=err)
        else:
            target = V.mpf_add(err, extra, V.PREC, V.RC)
            L = self.line_lb(label, k, kind, tuple(code), ya, yb, target, exhaustive)
        if L is None:
            return None
        return V.mpf_sub(L, err, V.PREC, V.RF)

    # ------------------------------------------------------------ one piece
    def regime(self, label, k, tri_box, center_k, radI, ya, yb, full):
        """Return (ok, margin lower bound, how)."""
        unit = (k == 1)
        A, Bc, D = tri_box
        nat = qmin_lb(A.v[0], Bc.v[0], D.v[0], unit)
        accept = lambda z: z is not None and V.nonneg(z) and not (full and V.mpf_lt(z, REPORT_TAU))
        if accept(nat):
            return True, nat, 'nat'
        self.stats['centered'] += 1
        tight = []
        for X, Xc in zip((A, Bc, D), center_k):
            enc = Xc.v
            for i in range(3):
                if X.g[i] is not None:
                    enc = iadd(enc, imul(X.g[i], radI[i]))
            tight.append(icap(X.v, enc))
        At, Bt, Dt = tight
        nat2 = qmin_lb(At[0], Bt[0], Dt[0], unit)
        if accept(nat2):
            return True, nat2, 'tight'
        best = lmax(nat, nat2)
        extra = REPORT_TAU if full else V.fzero
        if unit:
            Z = minimizers(At, Bt, unit)
            cen = self.two_step(label, k, 'm', tri_box, ya, yb, extra, Z, exhaustive=full)
            best = lmax(best, cen)
            ok = best is not None and V.nonneg(best)
            return ok, best, 'm'
        # half-line
        lbA = At[0]
        if not V.positive(lbA):
            lbA = lmax(lbA, self.two_step(label, k, 'A', tri_box, ya, yb, V.fzero))
        lbD = Dt[0]
        if V.negative(lbD) or (full and V.mpf_lt(lbD, REPORT_TAU)):
            lbD = lmax(lbD, self.two_step(label, k, 'D', tri_box, ya, yb, V.fzero, exhaustive=full))
        if V.negative(lbA) or V.negative(lbD):
            return False, best, 'A/D'
        lbB = Bt[0]
        if V.negative(lbB):
            lbB = lmax(lbB, self.two_step(label, k, 'B', tri_box, ya, yb, V.fzero))
        if V.nonneg(lbB):
            # A >= 0, B >= 0: the minimum over eta >= 0 is D
            return True, lmax(best, lbD), 'AB+'
        if V.positive(lbA):
            v = idiv(ineg((lbB, lbB)), imul(TWO_I, (lbA, lbA)))      # -B/(2A) <= -lbB/(2 lbA)
            Z = (V.fzero, v[1])
            cen = self.two_step(label, k, 'm', tri_box, ya, yb, extra, Z, exhaustive=full)
            best = lmax(best, cen)
            if best is not None and V.nonneg(best):
                return True, best, 'm'
            det = self.two_step(label, k, 'Det', tri_box, ya, yb, V.fzero)
            if det is not None and V.nonneg(det) and V.positive(At[1]):
                self.stats['det_used'] += 1
                # m >= min(D, Det/(4A)) >= min(lbD, det/(4 A.hi))
                return True, V.mn(lbD, idiv((det, det), imul(FOUR_I, (At[1], At[1])))[0]), 'Det'
        return False, best, 'half'

    def piece(self, label, ya, yb, full=False):
        self.stats['pieces'] += 1
        try:
            tri = regimes(self.Bbox, label, AD(I(ya, yb), YSLOT))
        except ZeroDiv:
            return False, None, ('zerodiv', label)
        center = None
        radI = None
        best = None
        for k in range(3):
            A, Bc, D = tri[k]
            nat = qmin_lb(A.v[0], Bc.v[0], D.v[0], k == 1)
            if not (nat is not None and V.nonneg(nat) and not (full and V.mpf_lt(nat, REPORT_TAU))):
                if center is None:
                    center = regimes(self.base_at(0, 0), label, AD(I((ya + yb) / 2)))
                    radI = [self.radI[0], self.radI[1], sym((yb - ya) / 2)]
                try:
                    ok, lb, how = self.regime(label, k, tri[k], center[k], radI, ya, yb, full)
                except AssertionError:
                    return False, None, ('empty-cap', label, k)
            else:
                ok, lb, how = True, nat, 'nat'
            if not ok:
                return False, lb, ('fail', label, k, how, None if lb is None else V.f(lb))
            if best is None or V.mpf_lt(lb, best[0]):
                best = (lb, k, how)
        return True, best[0], (label, best[1], best[2], float(ya), float(yb))

    def run(self, max_ydepth=YDEPTH, full=False, goal=None):
        """Returns (ok, margin (mpf lower bound) or None, info).  With `goal` (reporting only),
        passing pieces whose certified bound is below goal are also bisected (to max_ydepth)."""
        worst = None
        for label, (ys0, ys1) in self.labels():
            stack = [(ys0, ys1, 0)]
            while stack:
                ya, yb, d = stack.pop()
                ok, lb, info = self.piece(label, ya, yb, full)
                if ok and goal is not None and V.mpf_lt(lb, goal) and d < max_ydepth and ya != yb:
                    m = (ya + yb) / 2
                    stack.append((ya, m, d + 1))
                    stack.append((m, yb, d + 1))
                    continue
                if ok:
                    if worst is None or V.mpf_lt(lb, worst[0]):
                        worst = (lb, info)
                    continue
                if d >= max_ydepth or ya == yb:
                    return False, lb, info
                self.stats['ysplits'] += 1
                m = (ya + yb) / 2
                stack.append((ya, m, d + 1))
                stack.append((m, yb, d + 1))
        return True, worst[0], worst[1]
