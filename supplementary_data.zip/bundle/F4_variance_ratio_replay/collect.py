"""Collect every number for the replay report into replay_data.json (data only), all 14 rows."""
import json, os, sys, hashlib
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import certs
R2 = ['low', 'central_0', 'central_1', 'central_2', 'central_3', 'upper_shoulder']
GAP = certs.GAP_BANDS
side = json.load(open(os.path.join(HERE, 'side_checks.json')))
sideg = json.load(open(os.path.join(HERE, 'side_checks_gaps.json')))
data = {'code_sha256': {}, 'tail': side['tail'], 'coverage_14': sideg['whole_window_coverage_14_rows'], 'bands': {}}
for sub in ['frozen_v1', 'frozen_v2']:
    for f in sorted(os.listdir(os.path.join(HERE, sub))):
        if f.endswith('.py'):
            data['code_sha256'][sub + '/' + f] = hashlib.sha256(open(os.path.join(HERE, sub, f), 'rb').read()).hexdigest()
for b in R2 + GAP:
    if b in R2:
        hdr = {k: v for k, v in side['headers'][b].items() if k != 'gamma_vs_cap'}
        guards = side['coefficient_guards'][b]['all_ok']
        leaf = side['leaf_endpoint_D1'][b]
    else:
        hdr = sideg['headers'][b]
        guards = sideg['guards'][b]['all_ok']
        leaf = sideg['leaf_endpoint_D1'][b]
    d = {'header': hdr, 'guards_ok': guards, 'leaf_endpoint': leaf}
    p = os.path.join(HERE, 'results_%s.jsonl' % b)
    p2 = os.path.join(HERE, 'results_%s_r2.jsonl' % b)
    if os.path.exists(p2):
        p = p2                      # re-run at absolute niceness 10 supersedes an aborted partial run
    import glob
    parts = sorted(glob.glob(os.path.join(HERE, 'results_%s_part*.jsonl' % b)))
    if parts:
        rows = [json.loads(l) for q in parts for l in open(q)]     # disjoint index halves, run concurrently
        p = None
    elif os.path.exists(p):
        rows = [json.loads(l) for l in open(p)]
    else:
        rows = None
    if rows is not None:
        cells = [r for r in rows if 'i' in r]
        meta = [r for r in rows if 'i' not in r]
        ids = set(r['i'] for r in cells)
        nleaves = hdr['cover']['leaves']
        d['replay'] = {
            'cells_replayed': len(ids), 'rows': len(cells), 'certificate_leaves': nleaves,
            'all_cells_present': ids == set(range(nleaves)),
            'failures': sum(not r['ok'] for r in cells),
            'fail_rows': [r for r in cells if not r['ok']][:5],
            'cells_needing_lamx_subdivision': sum(r['subcells'] > 1 for r in cells),
            'total_leaf_subcells': sum(r['subcells'] for r in cells),
            'max_subdivision_depth': max(r['maxdepth'] for r in cells),
            'max_subcells_one_cell': max(r['subcells'] for r in cells),
            'cpu_seconds': round(sum(r['cpu'] for r in cells), 1),
            'wall_seconds': [round(m.get('elapsed'), 1) for m in meta if 'elapsed' in m],
            'workers': 3 if b in R2 else None,
        }
    fm = os.path.join(HERE, 'floatmin_%s.json' % b)
    if os.path.exists(fm):
        f = json.load(open(fm))
        d['float_min_estimate'] = {'min': f['min'], 'cell': f['argmin']}
    rf = os.path.join(HERE, 'refined_%s.jsonl' % b)
    if os.path.exists(rf):
        rr = [json.loads(l) for l in open(rf)]
        best = {}
        for r in rr:
            if r['i'] not in best or r['refined_certified_min'] > best[r['i']]['refined_certified_min']:
                best[r['i']] = r
        d['refined'] = sorted(best.values(), key=lambda r: r['refined_certified_min'])
        d['refined_all_ok'] = all(r['ok'] for r in rr)
    data['bands'][b] = d
json.dump(data, open(os.path.join(HERE, 'replay_data.json'), 'w'), indent=1, default=str)
for b, d in data['bands'].items():
    r = d.get('replay', {})
    fmn = d.get('float_min_estimate', {})
    ref = d.get('refined', [])
    tight = None
    if fmn and ref:
        tight = [x for x in ref if x['i'] == fmn['cell']]
    print(b, d['header']['sha256'][:12], 'cover', d['header']['cover']['volume_leaves_eq_roots'], 'cells', r.get('cells_replayed'), '/', d['header']['cover']['leaves'],
          'fails', r.get('failures'), 'subdiv', r.get('cells_needing_lamx_subdivision'), 'subcells', r.get('total_leaf_subcells'),
          'maxdepth', r.get('max_subdivision_depth'), 'cpu', r.get('cpu_seconds'), 'wall', r.get('wall_seconds'),
          'floatmin %.3e@%s' % (fmn.get('min', float('nan')), fmn.get('cell')),
          'cert@floatmin', None if not tight else '%.3e' % tight[0]['refined_certified_min'],
          'minrefined', None if not ref else ('%.3e@%d' % (ref[0]['refined_certified_min'], ref[0]['i'])),
          'leafD1 %.3e' % d['leaf_endpoint']['min_D1_lower_bound'])
