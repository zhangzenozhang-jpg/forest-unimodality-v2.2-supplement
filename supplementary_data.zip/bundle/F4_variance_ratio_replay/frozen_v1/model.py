"""Referee's own implementation of the local payment Phi (PRO_R2_PROOF.md (11), (13)).

Coordinates of a record: activity lam, x = p/q, and normalized parent coordinate
y in [0,1] with Y = (1-r)/q = P*(1-y), P = (1-p)/(1-qp)   (so r runs over the whole
physical interval [1/(1+lam(1-p)), 1] as y runs over [0,1]).
Parent cavity t (Lemma 1: 1-r <= t <= q P) enters only through the coefficient
fields at t/q; Phi is affine in them and they are piecewise linear in t/q with knots
j/8, so the parent is tested at   'low' t/q = Y,  'high' t/q = P,  and knots j/8
admissible in [Y, P].

Source: g = max(f_q(pr), (1 + f_q(pr) - f_q(M_up))/2)  -- the Lemma 2 definition
itself (the certificates use the simplified forms (4)/(5), which are <= this).

For x >= 7/8 the removable forms (16) are used: T = e k(e,lam), A_u = 8u_7/(p k),
A_v = 8v_7/(p k), A_s = 8 r s_7 x/(1+lam), phi = (1+lam)e/(1+lam e) (j = 0 there),
which are exact identities for x<1 given u_8 = v_8 = s_8 = 0 (checked).
"""
from fractions import Fraction as Fr
from mpmath.libmp import mpf_le, mpf_lt, to_float
import ivad as V
from ivad import AD, I, ONE, ZERO, iadd, isub, imul, idiv, isq, ineg, ihull, imax, imin, ad_log, ad_max, ad_min, ad_hull, ad_pow_int

KNOTS = [Fr(j, 8) for j in range(9)]
NAMES = ['u', 'v', 's', 'tau']
KERNEL_N = 32


class Band:
    def __init__(self, seg):
        self.seg = seg
        self.name = seg['name']
        self.lo = Fr(seg['lo'])
        self.hi = Fr(seg['hi'])
        self.gamma = Fr(seg['gamma'])
        width = self.hi - self.lo
        self.tabL = {k: [Fr(z) for z in seg['left'][k]] for k in NAMES}
        self.tabR = {k: [Fr(z) for z in seg['right'][k]] for k in NAMES}
        for k in ['w', 'ell']:
            self.tabL[k] = Fr(seg['left'][k])
            self.tabR[k] = Fr(seg['right'][k])
        for k in ['u', 'v', 's']:
            assert self.tabL[k][8] == 0 and self.tabR[k][8] == 0, 'leaf knot must vanish for (16)'
        # exact slopes in lambda
        self.slope = {}
        for k in NAMES:
            self.slope[k] = [(self.tabR[k][j] - self.tabL[k][j]) / width for j in range(9)]
        for k in ['w', 'ell']:
            self.slope[k] = (self.tabR[k] - self.tabL[k]) / width
        self.slopeI = {k: ([I(z) for z in v] if isinstance(v, list) else I(v)) for k, v in self.slope.items()}
        self.baseI = {k: ([I(z) for z in v] if isinstance(v, list) else I(v)) for k, v in self.tabL.items()}

    # coefficient value c(lam) = L + slope*(lam - lo), as AD in the lambda slot
    def coef(self, lam, dlam):
        """lam: AD for activity; dlam = lam - lo as AD.  Returns dict of AD objects."""
        out = {}
        for k in NAMES:
            out[k] = [AD(iadd(self.baseI[k][j], imul(self.slopeI[k][j], dlam.v)),
                         (self.slopeI[k][j] if lam.g[0] is not None else None, None, None))
                      for j in range(9)]
        for k in ['w', 'ell']:
            out[k] = AD(iadd(self.baseI[k], imul(self.slopeI[k], dlam.v)),
                        (self.slopeI[k] if lam.g[0] is not None else None, None, None))
        return out


EIGHT = I(8)
IJ = [I(j) for j in range(200)]
SEVEN8 = I(Fr(7, 8))
HALF = I(Fr(1, 2))
TWO = I(2)


KN_MPF = [V.fr_lo(Fr(j, 8)) for j in range(9)]      # exact dyadics
KN_INT = [V.from_int(j) for j in range(9)]


def interp4(Cs, xi):
    """piecewise-linear interpolation of several knot tables Cs[k][0..8] (AD) at xi (AD).
    The true argument lies in [0,1]; a segment is used only if its intersection with
    the argument range has positive length (or the range is a single point).  This is
    valid for the mean-value inclusion: the interpolant is continuous and, at a knot,
    the lambda-derivative is the same from both sides."""
    lo, hi = xi.v
    if V.negative(lo):
        lo = V.fzero
    if V.mpf_lt(V.fone, hi):
        hi = V.fone
    point = (lo == hi)
    jlo = max(0, min(7, int(8 * to_float(lo)) - 1))
    jhi = max(0, min(7, int(8 * to_float(hi)) + 1))
    g8 = tuple(None if z is None else imul(z, EIGHT) for z in xi.g)
    outs = [[] for _ in Cs]
    for j in range(jlo, jhi + 1):
        slo = V.mx(lo, KN_MPF[j])
        shi = V.mn(hi, KN_MPF[j + 1])
        if not (mpf_lt(slo, shi) or (point and mpf_le(slo, shi))):
            continue
        s0 = V.mx(V.fzero, V.mpf_sub(V.mpf_shift(slo, 3), KN_INT[j], V.PREC, V.RF))
        s1 = V.mn(V.fone, V.mpf_sub(V.mpf_shift(shi, 3), KN_INT[j], V.PREC, V.RC))
        if mpf_lt(s1, s0):
            s0 = s1
        s = AD((s0, s1), g8)
        for k, C in enumerate(Cs):
            outs[k].append(C[j] + (C[j + 1] - C[j]) * s)
    assert outs[0], 'interpolation argument outside [0,1]'
    return [o[0] if len(o) == 1 else ad_hull(o) for o in outs]


def interp(C, xi):
    return interp4([C], xi)[0]


def kernel(lam, e):
    """k(e,lam) = log(1+lam e)/e - log(1-e)/e for 0 <= e <= 1/8, as AD.
    Series sum_{n<N} a_n e^n, a_n = ((-1)^n lam^{n+1} + 1)/(n+1), with rigorous tails:
      |R|   <= [lam^{N+1} e^N/(1-lam e) + e^N/(1-e)]/(N+1)
      |R_l| <= (lam e)^N/(1-lam e)
      |R_e| <= lam^{N+1} e^{N-1}/(1-lam e) + e^{N-1}/(1-e)."""
    N = KERNEL_N
    lp = [lam]
    for n in range(1, N):
        lp.append(lp[-1] * lam)          # lp[n] = lam^{n+1}
    coefs = []
    for n in range(N):
        t = lp[n] if n % 2 == 0 else -lp[n]
        coefs.append((t + ONE) * I(Fr(1, n + 1)))
    acc = coefs[N - 1]
    for n in range(N - 2, -1, -1):
        acc = acc * e + coefs[n]
    # tails at the box maxima (all bounds increasing in lam and e)
    lh = (lam.v[1], lam.v[1])
    eh = (e.v[1], e.v[1]) if not V.negative(e.v[1]) else ZERO
    le = imul(lh, eh)
    one_m_le = isub(ONE, le)
    one_m_e = isub(ONE, eh)
    eN = V.ipow(eh, N)
    lN1 = V.ipow(lh, N + 1)
    rho = idiv(iadd(idiv(imul(lN1, eN), one_m_le), idiv(eN, one_m_e)), I(N + 1))
    rho_l = idiv(V.ipow(le, N), one_m_le)
    eN1 = V.ipow(eh, N - 1)
    rho_e = iadd(idiv(imul(lN1, eN1), one_m_le), idiv(eN1, one_m_e))
    sym = lambda r: (V.mpf_neg(r[1]), r[1])
    v = iadd(acc.v, sym(rho))
    g = list(acc.g)
    # d/dlam slot: add tail; x slot: dk/dx = -dk/de * ... acc already carries chain rule via e.g; add tail for e-part
    if g[0] is not None:
        g[0] = iadd(g[0], sym(rho_l))
    if g[1] is not None:
        g[1] = iadd(g[1], sym(rho_e))   # |de/dx| = 1
    return AD(v, tuple(g))


class Base:
    """(lam,x)-dependent quantities of one cell (as AD over the (lam,x) box, or at a point)."""
    __slots__ = ('q', 'p', 'omp', 'P', 'c', 'C', 'up', 'vp', 'sp', 'taup', 'Au', 'Av', 'S1', 'phi',
                 'h', 'ellGp', 'Hc', 'a1', 'a2', 'b', 'high', 'wphi', 'w', 'leaf', 'jr')


def make_base(band, lam, x):
    """lam, x: AD variables (with or without gradient slots)."""
    B = Base()
    dlam = lam - I(band.lo)
    C = band.coef(lam, dlam)
    B.C = C
    one_p_lam = lam + ONE
    q = lam / one_p_lam
    p = q * x
    omp = ONE - p
    B.q, B.p, B.omp = q, p, omp
    B.P = omp / (ONE - q * p)
    B.c = AD(I(band.gamma)) / one_p_lam
    B.up, B.vp, B.sp, B.taup = interp4([C[k] for k in NAMES], x)
    e = ONE - x
    leaf = V.mpf_le(SEVEN8[1], x.v[0])     # x >= 7/8 on the whole box
    B.leaf = leaf
    if leaf:
        k = kernel(lam, e)
        pk = p * k
        B.Au = (C['u'][7] * EIGHT) / pk
        B.Av = (C['v'][7] * EIGHT) / pk
        B.S1 = (C['s'][7] * EIGHT) * x / one_p_lam
        B.phi = one_p_lam * e / (ONE + lam * e)
        B.jr = (0, 0)
    else:
        assert V.mpf_le(x.v[1], SEVEN8[1]), 'cell straddles 7/8'
        Aq = (ONE + lam * e) / x          # = lam(1-p)/p
        T = ad_log(Aq)
        pT = p * T
        B.Au = B.up / pT
        B.Av = B.vp / pT
        # packing index j: largest j with (1+lam)^j <= Aq.  Range over the box without logs.
        base_lo = iadd(ONE, (lam.v[0], lam.v[0]))
        base_hi = iadd(ONE, (lam.v[1], lam.v[1]))
        jmax = 0
        while V.mpf_le(V.ipow(base_lo, jmax + 1)[0], Aq.v[1]):
            jmax += 1
        jmin = 0
        while V.mpf_le(V.ipow(base_hi, jmin + 1)[1], Aq.v[0]):
            jmin += 1
        assert jmin <= jmax
        B.jr = (jmin, jmax)
        Hs, phis = [], []
        for j in range(jmin, jmax + 1):
            pw = ad_pow_int(one_p_lam, j)
            Hs.append(lam * IJ[j] + Aq / pw - ONE)
            phis.append(q * IJ[j] + ONE - pw / Aq)
        H = Hs[0] if len(Hs) == 1 else ad_hull(Hs)
        B.phi = phis[0] if len(phis) == 1 else ad_hull(phis)
        B.S1 = B.sp / H
    B.h = p / (-ad_log(omp))
    G = ad_log(p / (lam * omp.sq()))
    B.ellGp = C['ell'] * G / p
    B.Hc = ad_min(q, ONE - p / (lam * omp))
    # f_q(pi) = max(a1 pi, a2 pi - b): a1=(1+q)/(2q), a2=(1+q)/(2q^2), b=(1-q)/(2q)
    one_p_q = ONE + q
    twoq = q * TWO
    B.a1 = one_p_q / twoq
    B.a2 = B.a1 / q
    B.b = (ONE - q) / twoq
    B.w = C['w']
    B.wphi = C['w'] * B.phi
    B.high = interp4([C[k] for k in NAMES], B.P)
    return B


def fq(B, pi):
    return ad_max(B.a1 * pi, B.a2 * pi - B.b)


def regimes(B, label, y):
    """Return the three (A,B,D) triples of (13) for parent label at normalized y (AD)."""
    Y = B.P * (ONE - y)
    qY = B.q * Y                 # = 1 - r = parent's original marginal
    r = ONE - qY
    pr = B.p * r
    fpr = fq(B, pr)
    Mup = ad_max(qY, (ONE - pr) * B.Hc)
    g = ad_max(fpr, (ONE + fpr - fq(B, Mup)) * HALF)
    As = r * B.S1
    if label == 'low':
        ut, vt, st, taut = interp4([B.C[k] for k in NAMES], Y)
    elif label == 'high':
        ut, vt, st, taut = B.high
    else:
        ut, vt, st, taut = [B.C[k][label] for k in NAMES]
    romp = r * B.omp
    qYomp = qY * B.omp
    hs = qYomp * st
    Nu = romp + B.h * ut + hs
    Nv = romp + B.h * vt + hs
    rtaup = r * B.taup
    qYtaut = qY * taut
    beta = rtaup + qYtaut + B.w
    common = B.c * r * g + r * B.wphi - B.ellGp
    AvAs = B.Av + As
    D0 = common - rtaup - B.w + AvAs
    D1 = common - Nv + qYtaut
    twoNv = Nv * TWO
    return ((AvAs - Nu, AvAs * TWO - beta, D0),
            (AvAs - Nv, twoNv - beta, D1),
            (B.Au + As - Nv, beta - twoNv, D1))


# ------------------------------------------------------------ quadratic minima
def qmin_lb(A, Bc, D, unit):
    """Rigorous lower bound (mpf) for min over eta of A eta^2 + Bc eta + D where
    A,Bc,D are exact mpf numbers (coefficient lower bounds), eta in [0,1] (unit) or
    eta >= 0.  Returns None for -infinity."""
    if unit:
        cands = [D, iadd(iadd((A, A), (Bc, Bc)), (D, D))[0]]
        if V.positive(A) and V.negative(Bc):
            twoA = V.mpf_add(A, A, V.PREC, V.RF)
            if V.mpf_lt(V.mpf_neg(Bc), twoA):
                vert = isub((D, D), idiv(isq((Bc, Bc)), imul(I(4), (A, A))))[0]
                cands.append(vert)
        m = cands[0]
        for z in cands[1:]:
            m = V.mn(m, z)
        return m
    if not V.negative(Bc):
        return D if not V.negative(A) else None
    if not V.positive(A):
        return None
    return isub((D, D), idiv(isq((Bc, Bc)), imul(I(4), (A, A))))[0]
