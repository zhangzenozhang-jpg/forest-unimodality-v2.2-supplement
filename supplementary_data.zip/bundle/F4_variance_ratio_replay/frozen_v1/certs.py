"""Referee's own certificate parser and exact cover verification (no author code)."""
import gzip, json, hashlib
from fractions import Fraction as Fr

PKT = '/Users/kvallier/Desktop/Erdos 993/ProofRuns/2026-09-28_analytic_large_n/SOUL/O2_FINAL/R2_PACKET/'
EPS = Fr(1, 65536)
# PRO_R2_PROOF.md 9.3: initial x edges [2^-16,2^-12,2^-10,2^-8,2^-6,1/8,2/8,...,1]
XEDGES = [Fr(1, 2 ** 16), Fr(1, 2 ** 12), Fr(1, 2 ** 10), Fr(1, 2 ** 8), Fr(1, 2 ** 6)] + [Fr(j, 8) for j in range(1, 9)]
YEDGES = [Fr(j, 8) for j in range(9)]

BANDS = {  # name -> (file, expected sha from the task inventory)
    'low': 'norm_cert_low.json.gz',
    'central_0': 'tight_cert_central_0.json.gz',
    'central_1': 'tight_cert_central_1.json.gz',
    'central_2': 'tight_cert_central_2.json.gz',
    'central_3': 'tight_cert_central_3.json.gz',
    'upper_shoulder': 'tight_cert_upper_shoulder.json.gz',
}


def sha256(path):
    return hashlib.sha256(open(path, 'rb').read()).hexdigest()


def load(name):
    path = PKT + BANDS[name]
    with gzip.open(path, 'rt', encoding='utf-8') as fh:
        cert = json.load(fh)
    return path, cert


def parse(cert):
    """Replay the DFS token string: stack initialised with the root boxes in listed
    order, pop from the end; a split pushes (lower half, upper half).  Returns the
    list of leaf boxes (exact Fractions) in token order, plus counters."""
    seg = cert['segment']
    lo, hi = Fr(seg['lo']), Fr(seg['hi'])
    fmt = cert['format']
    if fmt == 'ASTRA_O2_INTERVAL_TREE_V1':
        roots = [(lo, hi, a, b, c, d) for a, b in zip(XEDGES, XEDGES[1:]) for c, d in zip(YEDGES, YEDGES[1:])]
        split_tok = {'l': 0, 'x': 1, 'y': 2}
        leaf_tok = {'a', 'f'}
    elif fmt == 'ASTRA_O2_TIGHT_YPOLY_TREE_V1':
        roots = [(lo, hi, a, b) for a, b in zip(XEDGES, XEDGES[1:])]
        split_tok = {'l': 0, 'x': 1}
        leaf_tok = {'r'}
    else:
        raise ValueError('unknown format ' + fmt)
    stack = list(roots)
    leaves = []
    nsplit = 0
    for pos, tok in enumerate(cert['tokens']):
        if not stack:
            raise ValueError('extra tokens after the stack emptied at %d' % pos)
        box = stack.pop()
        if tok in split_tok:
            j = split_tok[tok]
            m = (box[2 * j] + box[2 * j + 1]) / 2
            left = list(box); right = list(box)
            left[2 * j + 1] = m; right[2 * j] = m
            stack.append(tuple(left)); stack.append(tuple(right))
            nsplit += 1
        elif tok in leaf_tok:
            leaves.append((box, tok))
        else:
            raise ValueError('unknown token %r' % tok)
    if stack:
        raise ValueError('uncovered boxes remain: %d' % len(stack))
    return roots, leaves, nsplit


def volume(box):
    v = Fr(1)
    for j in range(len(box) // 2):
        v *= box[2 * j + 1] - box[2 * j]
    return v


def verify_cover(cert):
    roots, leaves, nsplit = parse(cert)
    total = sum(volume(r) for r in roots)
    covered = sum(volume(b) for b, _ in leaves)
    seg = cert['segment']
    lo, hi = Fr(seg['lo']), Fr(seg['hi'])
    dims = len(roots[0]) // 2
    expect = (hi - lo) * (1 - XEDGES[0]) * (1 if dims == 3 else 1)
    # every leaf inside the root domain, positive volume
    for b, _ in leaves:
        assert lo <= b[0] < b[1] <= hi and XEDGES[0] <= b[2] < b[3] <= 1
        if dims == 3:
            assert 0 <= b[4] < b[5] <= 1
    return {
        'roots': len(roots), 'leaves': len(leaves), 'splits': nsplit,
        'tokens': len(cert['tokens']), 'leaves_declared': cert['leaves'],
        'leaf_count_matches': len(leaves) == cert['leaves'],
        'tokens_eq_calls': len(cert['tokens']) == cert.get('calls'),
        'volume_roots_eq_domain': total == expect,
        'volume_leaves_eq_roots': covered == total,
        'x_range': [str(XEDGES[0]), '1'], 'lambda_range': [str(lo), str(hi)],
        'max_depth_declared': cert.get('max_depth'), 'remaining_declared': len(cert.get('remaining', [])),
    }, leaves
