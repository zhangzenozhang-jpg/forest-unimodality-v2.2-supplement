"""Parallel replay driver (<= 4 workers; launch under `nice -n 10`).

usage: python3 driver.py BAND [--sample FRACTION] [--workers 4] [--rerun-worst K]
Writes results_<BAND>.jsonl (one line per certificate leaf, in completion order) and
summary_<BAND>.json in this directory.
"""
import sys, os, json, time, random, argparse
from fractions import Fraction as Fr
from multiprocessing import Pool
from mpmath.libmp import to_float, round_floor

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import certs
import model as M
import checker as CK
import ivad as V

MAXDEPTH = 10
_BAND = None


def _init(segment):
    global _BAND
    _BAND = M.Band(segment)


def fl(m):
    return None if m is None else to_float(m, rnd=round_floor)


def check_box(box, depth, full=False):
    """Check box; on failure bisect in (lam,x) up to MAXDEPTH.  Returns dict."""
    st = {'pieces': 0, 'ysplits': 0, 'centered': 0, 'line_evals': 0}
    try:
        c = CK.Cell(_BAND, *box)
        ok, lb, info = c.run(full=full)
        st = dict(c.stats)
    except (V.ZeroDiv, AssertionError) as exc:     # enclosure too wide: treat as a failed test
        ok, lb, info = False, None, ('exception', repr(exc))
    if ok:
        return {'ok': True, 'lb': lb, 'info': info, 'leaves': 1, 'maxdepth': depth, 'stats': st, 'failinfo': None}
    if depth >= MAXDEPTH:
        return {'ok': False, 'lb': lb, 'info': info, 'leaves': 1, 'maxdepth': depth, 'stats': st, 'failinfo': [str(z) for z in box]}
    l0, l1, x0, x1, y0, y1 = box
    rl = (l1 - l0) / (1 + l0)
    rx = (x1 - x0) / (1 + x0)
    if rl >= rx:
        m = (l0 + l1) / 2
        kids = [(l0, m, x0, x1, y0, y1), (m, l1, x0, x1, y0, y1)]
    else:
        m = (x0 + x1) / 2
        if x0 < Fr(7, 8) < x1:
            m = Fr(7, 8)
        kids = [(l0, l1, x0, m, y0, y1), (l0, l1, m, x1, y0, y1)]
    out = {'ok': True, 'lb': None, 'info': None, 'leaves': 0, 'maxdepth': depth, 'stats': st, 'failinfo': None}
    for kb in kids:
        r = check_box(kb, depth + 1, full)
        out['leaves'] += r['leaves']
        out['maxdepth'] = max(out['maxdepth'], r['maxdepth'])
        for k in st:
            out['stats'][k] += r['stats'].get(k, 0)
        if not r['ok']:
            out['ok'] = False
            out['failinfo'] = r['failinfo']
            out['lb'] = r['lb']
            out['info'] = r['info']
            return out
        if out['lb'] is None or V.mpf_lt(r['lb'], out['lb']):
            out['lb'] = r['lb']
            out['info'] = r['info']
    return out


def work(task):
    idx_list, boxes, full = task
    res = []
    for idx, bs in zip(idx_list, boxes):
        box = tuple(Fr(z) for z in bs)
        if len(box) == 4:
            box = box + (Fr(0), Fr(1))
        t0 = time.process_time()
        w0 = time.time()
        try:
            r = check_box(box, 0, full)
        except Exception as exc:          # any exception = failure to certify
            r = {'ok': False, 'lb': None, 'info': ('exception', repr(exc)), 'leaves': 1, 'maxdepth': 0, 'stats': {}, 'failinfo': bs}
        res.append({'i': idx, 'box': bs, 'ok': r['ok'], 'lb': fl(r['lb']), 'info': r['info'],
                    'subcells': r['leaves'], 'maxdepth': r['maxdepth'], 'stats': r['stats'],
                    'failinfo': r['failinfo'], 'cpu': round(time.process_time() - t0, 4),
                    'wall': round(time.time() - w0, 3)})
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('band')
    ap.add_argument('--workers', type=int, default=4)
    ap.add_argument('--sample', type=float, default=None)
    ap.add_argument('--indices', default=None, help='json file with a list of leaf indices to (re)check')
    ap.add_argument('--full', action='store_true', help='compute centred margins (reporting mode)')
    ap.add_argument('--tag', default='')
    ap.add_argument('--chunk', type=int, default=16)
    args = ap.parse_args()
    assert args.workers <= 4
    path, cert = certs.load(args.band)
    cov, leaves = certs.verify_cover(cert)
    idx = list(range(len(leaves)))
    if args.indices:
        idx = json.load(open(args.indices))
    elif args.sample:
        random.seed(20260928)
        idx = sorted(random.sample(idx, int(round(args.sample * len(idx)))))
    # interleave for load balance
    random.seed(1)
    order = idx[:]
    random.shuffle(order)
    tasks = []
    for s in range(0, len(order), args.chunk):
        part = order[s:s + args.chunk]
        tasks.append((part, [[str(z) for z in leaves[i][0]] for i in part], args.full))
    out = os.path.join(os.path.dirname(HERE), 'results_%s%s.jsonl' % (args.band, args.tag))
    t0 = time.time()
    n = 0
    nfail = 0
    with open(out, 'a') as fh, Pool(args.workers, initializer=_init, initargs=(cert['segment'],)) as pool:
        fh.write(json.dumps({'start': time.strftime('%Y-%m-%dT%H:%M:%S'), 'band': args.band, 'cells': len(idx), 'full': args.full}) + '\n')
        for res in pool.imap_unordered(work, tasks):
            for r in res:
                fh.write(json.dumps(r) + '\n')
                n += 1
                nfail += (not r['ok'])
            fh.flush()
            if n % 400 < args.chunk:
                print('%s %d/%d fails=%d elapsed=%.0fs' % (args.band, n, len(idx), nfail, time.time() - t0), flush=True)
        fh.write(json.dumps({'end': time.strftime('%Y-%m-%dT%H:%M:%S'), 'elapsed': time.time() - t0, 'n': n, 'fails': nfail}) + '\n')
    print('DONE', args.band, n, 'fails', nfail, 'elapsed %.0fs' % (time.time() - t0), flush=True)


if __name__ == '__main__':
    main()
