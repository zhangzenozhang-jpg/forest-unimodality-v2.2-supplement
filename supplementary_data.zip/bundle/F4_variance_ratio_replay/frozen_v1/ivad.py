"""Referee's own rigorous interval arithmetic + first-order interval AD.

Arithmetic: mpmath.libmp raw mpf numbers with directed rounding at PREC=128 bits
(outward rounding on every operation).  log is computed at PREC+24 bits with
directed rounding and then nudged outward by 4 ulps of that working precision
before the final outward rounding to PREC, so containment does not depend on
mpmath's final-rounding heuristics.  No floating point is used for acceptance.

AD: value interval + three gradient slots (lambda, x, y); None = exact zero.
max/min/hull use the hull of the active branch gradients, which is a valid
enclosure of the a.e. derivative of the (Lipschitz, piecewise smooth) result
along any segment, hence valid in the mean-value inclusion.
"""
from fractions import Fraction as Fr
from mpmath.libmp import (from_rational, from_int, mpf_add, mpf_sub, mpf_mul, mpf_div,
                          mpf_neg, mpf_log, mpf_lt, mpf_le, mpf_shift, fzero, fone,
                          to_float, to_rational, round_floor as RF, round_ceiling as RC)

PREC = 128
WP = PREC + 24


class ZeroDiv(Exception):
    pass


# ---------------------------------------------------------------- scalars
def mn(a, b):
    return a if mpf_le(a, b) else b


def mx(a, b):
    return b if mpf_le(a, b) else a


def nonneg(m):      # m >= 0 (finite values only are ever produced)
    return m[0] == 0


def nonpos(m):      # m <= 0
    return m[0] == 1 or not m[1]


def positive(m):
    return m[0] == 0 and m[1] != 0


def negative(m):
    return m[0] == 1


def fr_lo(q):
    q = Fr(q)
    return from_rational(q.numerator, q.denominator, PREC, RF)


def fr_hi(q):
    q = Fr(q)
    return from_rational(q.numerator, q.denominator, PREC, RC)


def to_fr(m):
    p, q = to_rational(m)
    return Fr(int(p), int(q))


# ---------------------------------------------------------------- intervals
def I(lo, hi=None):
    """Outward-rounded interval from rationals."""
    if hi is None:
        hi = lo
    return (fr_lo(lo), fr_hi(hi))


ZERO = (fzero, fzero)
ONE = (fone, fone)


def iadd(a, b):
    return (mpf_add(a[0], b[0], PREC, RF), mpf_add(a[1], b[1], PREC, RC))


def isub(a, b):
    return (mpf_sub(a[0], b[1], PREC, RF), mpf_sub(a[1], b[0], PREC, RC))


def ineg(a):
    return (mpf_neg(a[1]), mpf_neg(a[0]))


def imul(a, b):
    a0, a1 = a
    b0, b1 = b
    if a0[0] == 0:                       # a >= 0
        if b0[0] == 0:
            return (mpf_mul(a0, b0, PREC, RF), mpf_mul(a1, b1, PREC, RC))
        if b1[0] == 1 or not b1[1]:
            return (mpf_mul(a1, b0, PREC, RF), mpf_mul(a0, b1, PREC, RC))
        return (mpf_mul(a1, b0, PREC, RF), mpf_mul(a1, b1, PREC, RC))
    if a1[0] == 1 or not a1[1]:          # a <= 0
        if b0[0] == 0:
            return (mpf_mul(a0, b1, PREC, RF), mpf_mul(a1, b0, PREC, RC))
        if b1[0] == 1 or not b1[1]:
            return (mpf_mul(a1, b1, PREC, RF), mpf_mul(a0, b0, PREC, RC))
        return (mpf_mul(a0, b1, PREC, RF), mpf_mul(a0, b0, PREC, RC))
    # a straddles 0
    if b0[0] == 0:
        return (mpf_mul(a0, b1, PREC, RF), mpf_mul(a1, b1, PREC, RC))
    if b1[0] == 1 or not b1[1]:
        return (mpf_mul(a1, b0, PREC, RF), mpf_mul(a0, b0, PREC, RC))
    return (mn(mpf_mul(a0, b1, PREC, RF), mpf_mul(a1, b0, PREC, RF)),
            mx(mpf_mul(a0, b0, PREC, RC), mpf_mul(a1, b1, PREC, RC)))


def idiv(a, b):
    b0, b1 = b
    if b0[0] == 0 and b0[1]:             # b > 0
        a0, a1 = a
        if a0[0] == 0:
            return (mpf_div(a0, b1, PREC, RF), mpf_div(a1, b0, PREC, RC))
        if a1[0] == 1 or not a1[1]:
            return (mpf_div(a0, b0, PREC, RF), mpf_div(a1, b1, PREC, RC))
        return (mpf_div(a0, b0, PREC, RF), mpf_div(a1, b0, PREC, RC))
    if b1[0] == 1:                       # b < 0
        return idiv(ineg(a), ineg(b))
    raise ZeroDiv('division by an interval containing 0')


def isq(a):
    a0, a1 = a
    if a0[0] == 0:
        return (mpf_mul(a0, a0, PREC, RF), mpf_mul(a1, a1, PREC, RC))
    if a1[0] == 1 or not a1[1]:
        return (mpf_mul(a1, a1, PREC, RF), mpf_mul(a0, a0, PREC, RC))
    return (fzero, mx(mpf_mul(a0, a0, PREC, RC), mpf_mul(a1, a1, PREC, RC)))


def _nudge(m, k, up):
    """move m outward by k ulps at working precision WP (exact arithmetic)."""
    if not m[1]:
        d = mpf_shift(fone, -(WP + 64))
    else:
        d = mpf_shift(fone, m[2] + m[3] - WP + k)
    return mpf_add(m, d, WP + 8, RC) if up else mpf_sub(m, d, WP + 8, RF)


def ilog(a):
    a0, a1 = a
    if not positive(a0):
        raise ZeroDiv('log of nonpositive interval')
    lo = _nudge(mpf_log(a0, WP, RF), 2, False)
    hi = _nudge(mpf_log(a1, WP, RC), 2, True)
    return (mpf_add(lo, fzero, PREC, RF), mpf_add(hi, fzero, PREC, RC))


def ihull(a, b):
    return (mn(a[0], b[0]), mx(a[1], b[1]))


def imax(a, b):
    return (mx(a[0], b[0]), mx(a[1], b[1]))


def imin(a, b):
    return (mn(a[0], b[0]), mn(a[1], b[1]))


def icap(a, b):
    lo, hi = mx(a[0], b[0]), mn(a[1], b[1])
    if mpf_lt(hi, lo):
        raise AssertionError('empty intersection of two valid enclosures')
    return (lo, hi)


def iscale(a, q):
    return imul(a, I(q))


def iabsmax(a):
    """max |a| as an mpf upper bound."""
    return mx(mpf_neg(a[0]), a[1])


def ipow(a, n):
    """a**n for integer n>=0, a>0 (binary powering, outward rounded)."""
    out = ONE
    base = a
    while n:
        if n & 1:
            out = imul(out, base)
        n >>= 1
        if n:
            base = imul(base, base)
    return out


def f(m):
    return to_float(m)


def istr(a):
    return '[%.12g, %.12g]' % (to_float(a[0]), to_float(a[1]))


# ---------------------------------------------------------------- AD
NOG = (None, None, None)


def gadd(x, y):
    if x is None:
        return y
    if y is None:
        return x
    return iadd(x, y)


def gsub(x, y):
    if y is None:
        return x
    if x is None:
        return ineg(y)
    return isub(x, y)


def gmul(x, s):
    return None if x is None else imul(x, s)


def ghull(x, y):
    if x is None and y is None:
        return None
    return ihull(ZERO if x is None else x, ZERO if y is None else y)


class AD:
    __slots__ = ('v', 'g')

    def __init__(self, v, g=NOG):
        self.v = v
        self.g = g

    # binary ops accept AD or plain interval (constant)
    def __add__(a, b):
        if isinstance(b, AD):
            ag, bg = a.g, b.g
            return AD(iadd(a.v, b.v), (gadd(ag[0], bg[0]), gadd(ag[1], bg[1]), gadd(ag[2], bg[2])))
        return AD(iadd(a.v, b), a.g)

    __radd__ = __add__

    def __sub__(a, b):
        if isinstance(b, AD):
            ag, bg = a.g, b.g
            return AD(isub(a.v, b.v), (gsub(ag[0], bg[0]), gsub(ag[1], bg[1]), gsub(ag[2], bg[2])))
        return AD(isub(a.v, b), a.g)

    def __rsub__(a, b):          # b - a with b a constant interval
        ag = a.g
        return AD(isub(b, a.v), (None if ag[0] is None else ineg(ag[0]),
                                 None if ag[1] is None else ineg(ag[1]),
                                 None if ag[2] is None else ineg(ag[2])))

    def __neg__(a):
        ag = a.g
        return AD(ineg(a.v), (None if ag[0] is None else ineg(ag[0]),
                              None if ag[1] is None else ineg(ag[1]),
                              None if ag[2] is None else ineg(ag[2])))

    def __mul__(a, b):
        if isinstance(b, AD):
            av, bv, ag, bg = a.v, b.v, a.g, b.g
            return AD(imul(av, bv), (gadd(gmul(ag[0], bv), gmul(bg[0], av)),
                                     gadd(gmul(ag[1], bv), gmul(bg[1], av)),
                                     gadd(gmul(ag[2], bv), gmul(bg[2], av))))
        ag = a.g
        return AD(imul(a.v, b), (gmul(ag[0], b), gmul(ag[1], b), gmul(ag[2], b)))

    __rmul__ = __mul__

    def __truediv__(a, b):
        if isinstance(b, AD):
            v = idiv(a.v, b.v)
            bv, ag, bg = b.v, a.g, b.g
            out = []
            for i in range(3):
                num = gsub(ag[i], gmul(bg[i], v))
                out.append(None if num is None else idiv(num, bv))
            return AD(v, tuple(out))
        ag = a.g
        return AD(idiv(a.v, b), tuple(None if x is None else idiv(x, b) for x in ag))

    def __rtruediv__(a, b):      # constant b / a
        return AD(b) / a

    def sq(a):
        two_v = iadd(a.v, a.v)
        ag = a.g
        return AD(isq(a.v), (gmul(ag[0], two_v), gmul(ag[1], two_v), gmul(ag[2], two_v)))


def ad_log(a):
    ag = a.g
    return AD(ilog(a.v), tuple(None if x is None else idiv(x, a.v) for x in ag))


def ad_hull(items):
    v = items[0].v
    g = list(items[0].g)
    for it in items[1:]:
        v = ihull(v, it.v)
        for i in range(3):
            g[i] = ghull(g[i], it.g[i])
    return AD(v, tuple(g))


def ad_max(a, b):
    if not isinstance(b, AD):
        b = AD(b)
    if not isinstance(a, AD):
        a = AD(a)
    if mpf_le(b.v[1], a.v[0]):
        return a
    if mpf_le(a.v[1], b.v[0]):
        return b
    h = ad_hull([a, b])
    return AD(imax(a.v, b.v), h.g)


def ad_min(a, b):
    if not isinstance(b, AD):
        b = AD(b)
    if not isinstance(a, AD):
        a = AD(a)
    if mpf_le(a.v[1], b.v[0]):
        return a
    if mpf_le(b.v[1], a.v[0]):
        return b
    h = ad_hull([a, b])
    return AD(imin(a.v, b.v), h.g)


def ad_pow_int(base, n):
    """base**n, base>0 an AD, n>=0 integer."""
    if n == 0:
        return AD(ONE)
    v = ipow(base.v, n)
    dv = imul(I(n), ipow(base.v, n - 1))
    return AD(v, tuple(gmul(x, dv) for x in base.g))
