"""Self-tests: (i) quadratic forms (13) vs direct (11) in floats; (ii) interval model
at points vs float model; (iii) cover parse of all six certificates; (iv) timing."""
import random, time, json, sys
import numpy as np
from fractions import Fraction as Fr
import explore_float as EF
import ivad as V
from ivad import AD, I
import model as M
import certs
random.seed(1)
bands = [('low', 2.0), ('central_0', 1.6), ('central_1', 1.6), ('central_2', 1.6), ('central_3', 1.6), ('upper_shoulder', 1.7)]
# (i) direct Phi vs quadratic forms
worst = 0
for name, gamma in bands:
    seg = EF.SEGS[name]
    lo, hi = float(Fr(seg['lo'])), float(Fr(seg['hi']))
    for _ in range(3000):
        lam = random.uniform(lo, hi); x = random.choice([random.uniform(2**-16, 0.1), random.uniform(0.1, 0.999)])
        q = lam/(1+lam); p = q*x; P = (1-p)/(1-q*p); Y = random.uniform(0, P)
        tq = random.uniform(Y, P)
        z = random.choice([random.uniform(-5, 0), random.uniform(0, 1), random.uniform(1, 6)])
        d = EF.phi_direct(seg, gamma, lam, x, Y, tq, z)
        # quadratic form with parent at tq: reuse phi_parts machinery via a knot-free evaluation
        tb = EF.table(seg, np.array(lam))
        Ic = lambda k, xx: float(EF.interp(tb[k][None, :], np.array([xx]))[0])
        r = 1 - q*Y; c = gamma/(1+lam)
        Hc = min(q, 1 - p/(lam*(1-p))); Mup = max(1-r, (1-p*r)*Hc)
        g = max(EF.fq(p*r, q), (1 + EF.fq(p*r, q) - EF.fq(Mup, q))/2)
        T = np.log(lam*(1-p)/p); L = np.log(1+lam); j = np.floor(T/L)
        H = j*lam + np.exp(T-j*L) - 1; phi = j*q + 1 - np.exp(-(T-j*L))
        h = p/(-np.log1p(-p)); G = np.log(p/(lam*(1-p)**2))
        up, vp, sp, taup = [Ic(k, x) for k in 'u v s tau'.split()]
        ut, vt, st, taut = [Ic(k, tq) for k in 'u v s tau'.split()]
        w, ell = float(tb['w']), float(tb['ell'])
        Au, Av, As = up/(p*T), vp/(p*T), r*sp/H
        Nu = r*(1-p) + h*ut + (1-r)*(1-p)*st; Nv = r*(1-p) + h*vt + (1-r)*(1-p)*st
        beta = r*taup + (1-r)*taut + w
        D0 = c*r*g - r*taup - w + w*r*phi - ell*G/p + Av + As
        D1 = c*r*g - Nv + (1-r)*taut + w*r*phi - ell*G/p
        if z <= 0: e = -z; qv = (Av+As-Nu)*e*e + (2*(Av+As)-beta)*e + D0
        elif z <= 1: e = 1-z; qv = (Av+As-Nv)*e*e + (2*Nv-beta)*e + D1
        else: e = z-1; qv = (Au+As-Nv)*e*e + (beta-2*Nv)*e + D1
        worst = max(worst, abs(qv-d)/(1+abs(d)))
print('(i) max rel diff direct(11) vs quadratic(13):', worst)
# (ii) interval model at points vs float model
worst2 = 0; cnt = 0
for name, gamma in bands:
    seg = EF.SEGS[name]; band = M.Band(seg)
    lo, hi = Fr(seg['lo']), Fr(seg['hi'])
    for _ in range(150):
        lam = lo + (hi-lo)*Fr(random.randint(0, 1000), 1000)
        x = random.choice([Fr(random.randint(1, 10**6), 10**6*8), Fr(random.randint(1, 10**6), 10**6), Fr(7,8) + Fr(random.randint(0, 10**6), 8*10**6)])
        if x < Fr(1, 65536): x = Fr(1, 65536)
        y = Fr(random.randint(0, 1000), 1000)
        B = M.make_base(band, AD(I(lam)), AD(I(x)))
        for label in ['low', 'high'] + list(range(1, 8)):
            tri = M.regimes(B, label, AD(I(y)))
            if x == 1: continue
            lamf, xf, yf = float(lam), float(x), float(y)
            q = lamf/(1+lamf); P = (1-q*xf)/(1-q*q*xf); Y = P*(1-yf)
            mins, parts, valid = EF.phi_parts(seg, float(gamma), np.array([lamf]), np.array([xf]), np.array([Y]), label)
            for k in range(3):
                A, Bc, D = tri[k]
                ival = M.qmin_lb(A.v[0], Bc.v[0], D.v[0], k == 1)
                fl = float(parts[k][0])
                iv = V.f(ival) if ival is not None else -np.inf
                if np.isfinite(fl) and np.isfinite(iv):
                    worst2 = max(worst2, abs(iv - fl)/(1+abs(fl))); cnt += 1
                elif np.isfinite(fl) != np.isfinite(iv):
                    print('finite mismatch', name, lam, x, y, label, k, fl, iv)
print('(ii) max rel diff interval-model vs float-model (min over eta):', worst2, 'n=', cnt)
