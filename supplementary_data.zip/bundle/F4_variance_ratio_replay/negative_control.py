"""Negative control: lower the price gamma slightly on the tightest cells; the checker must
fail (it is not vacuous).  Also re-run the same cells at the true gamma."""
import sys, os, json, copy
from fractions import Fraction as Fr
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import certs, model as M, checker as CK, ivad as V
out = []
for band, idx, gam in [('central_3', 2378, Fr(1592, 1000)), ('central_0', 2523, Fr(1595, 1000)), ('low', 15290, Fr(19, 10))]:
    path, cert = certs.load(band); cov, leaves = certs.verify_cover(cert)
    b = leaves[idx][0]; box = b if len(b) == 6 else b + (Fr(0), Fr(1))
    for g in [Fr(cert['segment']['gamma']), gam]:
        seg = copy.deepcopy(cert['segment']); seg['gamma'] = str(g)
        c = CK.Cell(M.Band(seg), *box)
        ok, lb, info = c.run()
        r = {'band': band, 'cell': idx, 'gamma': str(g), 'ok': ok, 'lb': None if lb is None else V.f(lb), 'info': info}
        print(r, flush=True); out.append(r)
json.dump(out, open(os.path.join(HERE, 'negative_control.json'), 'w'), indent=1, default=str)
