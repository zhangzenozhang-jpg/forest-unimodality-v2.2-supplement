import cProfile, pstats, sys
from fractions import Fraction as Fr
import certs, model as M, checker as CK
path, cert = certs.load('central_3')
cov, leaves = certs.verify_cover(cert)
band = M.Band(cert['segment'])
def run():
    for idx in [1326, 617, 197, 2387]:
        b, tok = leaves[idx]
        c = CK.Cell(band, *(b + (Fr(0), Fr(1))))
        c.run()
cProfile.run('run()', '/tmp/claude_prof.out') if False else None
pr = cProfile.Profile(); pr.enable(); run(); pr.disable()
st = pstats.Stats(pr); st.sort_stats('tottime').print_stats(18)
