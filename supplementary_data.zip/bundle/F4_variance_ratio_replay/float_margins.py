"""NON-RIGOROUS per-cell float estimate of min Phi (over a 3x3x17 grid x all parent labels,
exact min over z).  Used only to rank cells (tightest first) and to give context for the
certified margins.  usage: python3 float_margins.py BAND"""
import sys, os, json
import numpy as np
from fractions import Fraction as Fr
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import certs
import explore_float as EF

band = sys.argv[1]
path, cert = certs.load(band)
cov, leaves = certs.verify_cover(cert)
seg = cert['segment']
gamma = float(Fr(seg['gamma']))
boxes = np.array([[float(z) for z in (b if len(b) == 6 else b + (Fr(0), Fr(1)))] for b, _ in leaves])
N = len(boxes)
res = np.full(N, np.inf)
lab = np.full(N, -1)
t3 = np.array([0.0, 0.5, 1.0])
ty = np.linspace(0, 1, 33)
labels = ['low', 'high'] + list(range(1, 8))
for s in range(0, N, 1500):
    B = boxes[s:s + 1500]
    n = len(B)
    lam = (B[:, 0, None] + (B[:, 1] - B[:, 0])[:, None] * t3[None, :])[:, :, None, None] * np.ones((1, 3, 3, 33))
    x = (B[:, 2, None] + (B[:, 3] - B[:, 2])[:, None] * t3[None, :])[:, None, :, None] * np.ones((1, 3, 3, 33))
    x = np.minimum(x, 1 - 1e-9)
    y = (B[:, 4, None] + (B[:, 5] - B[:, 4])[:, None] * ty[None, :])[:, None, None, :] * np.ones((1, 3, 3, 33))
    q = lam / (1 + lam)
    P = (1 - q * x) / (1 - q * q * x)
    Y = P * (1 - y)
    # extra samples at the kinks: parent knots Y = j/8 and the source kink Y_f = (x - kappa)/p
    lam1, x1 = lam[..., :1], x[..., :1]
    q1 = lam1 / (1 + lam1); P1 = (1 - q1 * x1) / (1 - q1 * q1 * x1)
    ylo = B[:, 4][:, None, None, None]; yhi = B[:, 5][:, None, None, None]
    kappa = 1 / (1 + q1)
    extra = [np.full_like(P1, j / 8.0) for j in range(1, 8)] + [np.maximum(x1 - kappa, 0) / (q1 * x1)]
    Yk = np.concatenate(extra, axis=-1)
    yk = 1 - Yk / P1
    Yk = np.where((yk >= ylo) & (yk <= yhi), Yk, P1 * (1 - ylo))
    lamE = np.concatenate([lam, np.broadcast_to(lam1, Yk.shape)], axis=-1)
    xE = np.concatenate([x, np.broadcast_to(x1, Yk.shape)], axis=-1)
    YE = np.concatenate([Y, Yk], axis=-1)
    for li, label in enumerate(labels):
        m, parts, valid = EF.phi_parts(seg, gamma, lamE, xE, YE, label)
        m = np.where(valid, m, np.inf)
        mm = m.reshape(n, -1).min(axis=1)
        better = mm < res[s:s + n]
        res[s:s + n] = np.where(better, mm, res[s:s + n])
        lab[s:s + n] = np.where(better, li, lab[s:s + n])
out = {'band': band, 'n': N, 'min': float(res.min()), 'argmin': int(res.argmin()),
       'est': [float(v) for v in res], 'label': [int(v) for v in lab]}
json.dump(out, open(os.path.join(HERE, 'floatmin_%s.json' % band), 'w'))
order = np.argsort(res)
print(band, 'cells', N, 'float min %.3e at cell %d' % (res.min(), res.argmin()), 'box', leaves[res.argmin()][0])
print('smallest 10:', [(int(i), float('%.3e' % res[i])) for i in order[:10]])
print('quantiles', {q: float('%.3e' % np.quantile(res, q)) for q in [0.001, 0.01, 0.1, 0.5]})
