"""Header/inventory checks, coefficient guards, small-message tail (14)-(15) and the physical
leaf endpoint (x = 1, z = 1: D_1 >= 0) -- referee's own code and arithmetic.
Writes side_checks.json."""
import json, sys, time, hashlib, gzip, os
from fractions import Fraction as Fr
from mpmath.libmp import to_float, round_floor, round_ceiling
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import certs
import ivad as V
from ivad import I, AD, ONE, iadd, isub, imul, idiv, ilog
import model as M
import checker as CK

PKT = certs.PKT
out = {}

# ---------------------------------------------------------------- headers
inv = json.load(open(PKT + 'CERTIFICATES.json'))
coef = json.load(open(PKT + 'COEFFICIENTS.json'))
segs = {s['name']: s for s in coef['segments']}
invby = {c['name']: c for c in inv['certificates']}
PROFILE = [(Fr(1, 3), Fr(3, 5), Fr(2)), (Fr(3, 5), Fr(4, 5), Fr(17, 10)), (Fr(4, 5), Fr(13, 10), Fr(8, 5)),
           (Fr(13, 10), Fr(8, 5), Fr(17, 10)), (Fr(8, 5), Fr(7, 3), Fr(2))]


def required_gamma(lam):
    """Profile30 cap with every shared edge assigned to the band on its left."""
    for a, b, g in PROFILE:
        if (lam == a == Fr(1, 3)) or (a < lam <= b):
            return g
    raise ValueError


hdr = {}
for name, fn in certs.BANDS.items():
    path = PKT + fn
    sha = certs.sha256(path)
    with gzip.open(path, 'rt', encoding='utf-8') as fh:
        cert = json.load(fh)
    it = invby[name]
    seg = cert['segment']
    d = {
        'sha256': sha, 'sha_matches_inventory': sha == it['sha256'],
        'format': cert['format'], 'status': cert['status'], 'inventory_status': it['status'],
        'segment_equals_COEFFICIENTS': seg == segs[name],
        'lo_hi_gamma_equal_inventory': (Fr(seg['lo']), Fr(seg['hi']), Fr(seg['gamma'])) == (Fr(it['lo']), Fr(it['hi']), Fr(it['gamma'])),
        'leaves_equal_inventory': cert['leaves'] == it['leaves'],
        'engine_inventory': it['engine'],
        'lo': seg['lo'], 'hi': seg['hi'], 'gamma': seg['gamma'],
    }
    lo, hi, g = Fr(seg['lo']), Fr(seg['hi']), Fr(seg['gamma'])
    # gamma <= required cap at every activity of the closed band: check at the endpoints and at
    # every profile edge inside (the cap is piecewise constant)
    pts = {lo, hi} | {e for a, b, _ in PROFILE for e in (a, b) if lo <= e <= hi}
    pts |= {(a + b) / 2 for a, b in zip(sorted(pts), sorted(pts)[1:])}
    d['gamma_vs_cap'] = {str(p): [str(g), str(required_gamma(p)), g <= required_gamma(p)] for p in sorted(pts)}
    d['band_payable_everywhere_by_this_certificate'] = all(v[2] for v in d['gamma_vs_cap'].values())
    cov, leaves = certs.verify_cover(cert)
    d['cover'] = cov
    hdr[name] = d
out['headers'] = hdr

# ---------------------------------------------------------------- coefficient guards
guards = {}
for name in certs.BANDS:
    seg = segs[name]
    res = {}
    for side in ['left', 'right']:
        co = {k: [Fr(z) for z in seg[side][k]] for k in ['u', 'v', 's', 'tau']}
        w, ell = Fr(seg[side]['w']), Fr(seg[side]['ell'])
        res[side] = {
            'u_in_[0,1]': all(0 <= z <= 1 for z in co['u']), 'v_in_[0,1]': all(0 <= z <= 1 for z in co['v']),
            's_in_[0,4]': all(0 <= z <= 4 for z in co['s']), '|tau|<=4': all(abs(z) <= 4 for z in co['tau']),
            'w_in_[0,2]': 0 <= w <= 2, 'ell>=1/1000': ell >= Fr(1, 1000),
            'u,v>=1/100_on_[0,1/8]': min(co['u'][0], co['u'][1], co['v'][0], co['v'][1]) >= Fr(1, 100),
            'u8=v8=s8=0': co['u'][8] == 0 and co['v'][8] == 0 and co['s'][8] == 0,
            'min_uv_first_segment': str(min(co['u'][0], co['u'][1], co['v'][0], co['v'][1])),
            'ell': str(ell),
        }
    res['all_ok'] = all(all(v for k, v in res[s].items() if isinstance(v, bool)) for s in ['left', 'right'])
    guards[name] = res
out['coefficient_guards'] = guards

# ---------------------------------------------------------------- small-message tail (14)-(15)
eps = Fr(1, 65536)
L1 = ilog(I(Fr(7, 3) / eps))                                  # log((7/3)/eps)
L2 = ilog(I(Fr(1, 3) * (1 - eps) ** 2 / eps))                 # log((1/3)(1-eps)^2/eps)
pT_bound = imul(I(eps), L1)                                   # eps*log((7/3)/eps) >= p T
Astar = Fr(1, 100) / (12 * eps)
final = Fr(9, 1000) / eps - 25
out['tail'] = {
    'epsilon': str(eps),
    'log((7/3)/eps)': [to_float(L1[0], rnd=round_floor), to_float(L1[1], rnd=round_ceiling)],
    'log((7/3)/eps) < 12 (so pT < 12 eps)': V.mpf_lt(L1[1], I(12)[0]),
    'log((7/3)/eps) > 1 (p log(C/p) increasing on (0,eps])': V.mpf_lt(I(1)[1], L1[0]),
    'log((1/3)(1-eps)^2/eps)': [to_float(L2[0], rnd=round_floor), to_float(L2[1], rnd=round_ceiling)],
    '-G > 9': V.mpf_lt(I(9)[1], L2[0]),
    'x <= eps/q <= 4 eps < 1/8 for lam >= 1/3': 4 * eps < Fr(1, 8),
    'A_* = (1/100)/(12 eps)': str(Astar), 'A_* - 12 >= 1': Astar - 12 >= 1,
    'tail lower bound 9/(1000 eps) - 25': str(final), 'tail positive': final > 0,
    'overlap: cover starts at x = eps, tail covers x <= eps/q with q < 1': True,
}

# ---------------------------------------------------------------- physical leaf endpoint
def leaf_endpoint(name, nl=64):
    band = M.Band(segs[name])
    lo, hi = band.lo, band.hi
    worst = None
    fails = 0
    t0 = time.process_time()
    for i in range(nl):
        l0 = lo + (hi - lo) * i / nl
        l1 = lo + (hi - lo) * (i + 1) / nl
        c = CK.Cell(band, l0, l1, Fr(1), Fr(1), Fr(0), Fr(1))
        for label, (ys0, ys1) in c.labels():
            stack = [(ys0, ys1, 0)]
            while stack:
                a, b, d = stack.pop()
                tri = M.regimes(c.Bbox, label, AD(I(a, b), CK.YSLOT))
                D1 = tri[1][2]
                lb = D1.v[0]
                if V.mpf_lt(lb, CK.REPORT_TAU):
                    alt = c.two_step(label, 1, 'D', tri[1], a, b, V.fzero, exhaustive=True)
                    lb = CK.lmax(lb, alt)
                if lb is None or V.negative(lb):
                    if d < 12:
                        m = (a + b) / 2
                        stack += [(a, m, d + 1), (m, b, d + 1)]
                        continue
                    fails += 1
                    continue
                if worst is None or V.mpf_lt(lb, worst[0]):
                    worst = (lb, float(l0), float(l1), label, float(a), float(b))
    return {'lambda_strips': nl, 'fails': fails, 'min_D1_lower_bound': to_float(worst[0], rnd=round_floor),
            'at': {'lam': [worst[1], worst[2]], 'label': worst[3], 'y': [worst[4], worst[5]]},
            'cpu_s': round(time.process_time() - t0, 1)}


leaf = {}
for name in certs.BANDS:
    leaf[name] = leaf_endpoint(name)
    print(name, leaf[name], flush=True)
out['leaf_endpoint_D1'] = leaf
json.dump(out, open(os.path.join(HERE, 'side_checks.json'), 'w'), indent=1, default=str)
print(json.dumps({k: v for k, v in out.items() if k != 'headers'}, indent=1, default=str))
for n, d in hdr.items():
    print(n, {k: v for k, v in d.items() if k not in ('gamma_vs_cap', 'cover')}, d['cover']['volume_leaves_eq_roots'], d['band_payable_everywhere_by_this_certificate'])
