"""Certified margins in reporting mode (centred bounds + branch-and-bound along anchor lines)
for the tightest cells of a band: the K smallest float-estimated minima plus the J smallest
replay-recorded bounds.  usage: python3 worst_margins.py BAND [K] [J]"""
import sys, os, json, time
from fractions import Fraction as Fr
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import certs, driver
from mpmath.libmp import to_float, round_floor
band = sys.argv[1]
K = int(sys.argv[2]) if len(sys.argv) > 2 else 40
J = int(sys.argv[3]) if len(sys.argv) > 3 else 20
path, cert = certs.load(band)
cov, leaves = certs.verify_cover(cert)
driver._init(cert['segment'])
fm = json.load(open(os.path.join(HERE, 'floatmin_%s.json' % band)))
est = fm['est']
rec = {}
for line in open(os.path.join(HERE, 'results_%s.jsonl' % band)):
    r = json.loads(line)
    if 'i' in r:
        rec[r['i']] = r
sel = sorted(range(len(est)), key=lambda i: est[i])[:K]
sel += [i for i in sorted(rec, key=lambda i: rec[i]['lb'] if rec[i]['lb'] is not None else -1) if i not in sel][:J]
out = []
t0 = time.time()
for i in sel:
    b = leaves[i][0]
    box = b if len(b) == 6 else b + (Fr(0), Fr(1))
    r = driver.check_box(box, 0, full=True)
    lbf = driver.fl(r['lb'])
    best = max([v for v in (lbf, rec.get(i, {}).get('lb')) if v is not None], default=None)
    out.append({'i': i, 'box': [str(z) for z in b], 'float_est_min': est[i], 'replay_lb': rec.get(i, {}).get('lb'),
                'full_ok': r['ok'], 'full_lb': lbf, 'certified_margin': best, 'where': r['info'], 'subcells': r['leaves']})
    print(out[-1], flush=True)
out.sort(key=lambda d: (d['certified_margin'] if d['certified_margin'] is not None else -1))
json.dump({'band': band, 'selected': len(sel), 'elapsed': time.time() - t0, 'cells': out}, open(os.path.join(HERE, 'worst_%s.json' % band), 'w'), indent=1)
print('WORST', band, out[:5])
