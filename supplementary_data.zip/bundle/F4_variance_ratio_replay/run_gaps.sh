#!/bin/zsh
# sequential gap-band replays with the frozen_v2 code (checker/model/ivad identical to frozen_v1)
cd "/Users/kvallier/Desktop/Erdos 993/ProofRuns/2026-09-28_analytic_large_n/LEAN/referee/o2/review_replay"
W=$1; shift
for b in "$@"; do
  nice -n 10 python3 -B frozen_v2/driver.py $b --workers $W >> log_$b.txt 2>&1
done
