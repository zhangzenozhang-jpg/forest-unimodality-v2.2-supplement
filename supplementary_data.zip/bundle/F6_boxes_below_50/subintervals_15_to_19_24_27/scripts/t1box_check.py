#!/usr/bin/python3
"""Independent replay (outside Lean) of the band test of Section apC:sec:t1box (lower-tail criterion)
on the 178 coverings of Lemma apC:lem:T1boxes.

Written from the paper (appendix_C_inputs.tex lines 745-812, part2_body.tex lines 591-650,
appendix_C_inputs.tex lines 665-695); the Lean files are used only as a data source (parse_data.py).

Arithmetic.  Every per-box and per-fiber quantity ((S), (T), (Mg), rhs_T, the kernel floor, lev, the half-line
tests (i), the certification of the range ends) is decided in exact rational arithmetic (gmpy2 mpq), except the
(Mg) tail sum, which is enclosed in ball arithmetic (python-flint arb, 256 bits) with an exact mpq fallback whenever
the sign of the margin is not certified.  The per-atom first- and second-order bounds are evaluated for all atoms
of a box at once in rigorous float64 interval arithmetic (every +,-,*,/ result is pushed outward by one ulp with
nextafter, which encloses the exact value under IEEE round-to-nearest); the binomial values b_M(j;q) at
q in {q_l, q_0, q_h} are carried along M by the recurrence b_{M+1}(j)=(1-q)b_M(j)+q b_M(j-1) in the same interval
arithmetic.  An atom is accepted only if the lower end of its first- or second-order margin is >= 0; every other
atom is re-decided in exact rational arithmetic (exact binomials C(M,j)p^j(d-p)^(M-j)/d^M), and the exact
decision is final.  The atoms j=-1 and j=M+1 are always decided exactly.  Floats only propose the enumeration
radius (ceil(sqrt(lev/eta))+1), whose ends are then certified exactly, as in the paper.
"""
import sys, os, time, math, pickle, csv, json, argparse
import numpy as np
import gmpy2
from gmpy2 import mpq, mpz
from flint import arb, fmpq, ctx

ctx.prec = 256
NINF, PINF = -np.inf, np.inf
TAUS = [mpq(0), mpq(1, 20), mpq(1, 10), mpq(1, 5), mpq(3, 10)]
REXTRA = 0          # robustness option: widen the proposed radius by REXTRA (0 = the paper's proposal)
FULLRANGE = False    # robustness option: enumerate every atom -1..M+1 of every fiber with lev > 0


def Q(fr):
    return mpq(int(fr.numerator), int(fr.denominator))


def floor_q(x):
    return int(x.numerator // x.denominator)


def ceil_q(x):
    return -int((-x.numerator) // x.denominator)


def to_arb(x):
    return arb(fmpq(int(x.numerator), int(x.denominator)))


# ---------------------------------------------------------------- interval helpers (float64, outward rounding)
def rd(x):
    return np.nextafter(x, NINF)


def ru(x):
    return np.nextafter(x, PINF)


def ic(x):
    """Enclosure of an exact rational by two floats (2 ulps outward, valid for any conversion error < 1 ulp)."""
    f = float(x)
    lo = np.nextafter(np.nextafter(f, NINF), NINF)
    hi = np.nextafter(np.nextafter(f, PINF), PINF)
    return (lo, hi)


def iadd(a, b):
    return (rd(a[0] + b[0]), ru(a[1] + b[1]))


def isub(a, b):
    return (rd(a[0] - b[1]), ru(a[1] - b[0]))


def imul(a, b):
    p1 = a[0] * b[0]; p2 = a[0] * b[1]; p3 = a[1] * b[0]; p4 = a[1] * b[1]
    lo = np.minimum(np.minimum(p1, p2), np.minimum(p3, p4))
    hi = np.maximum(np.maximum(p1, p2), np.maximum(p3, p4))
    return (rd(lo), ru(hi))


def imul_pos(a, b):
    """both intervals nonnegative"""
    return (rd(a[0] * b[0]), ru(a[1] * b[1]))


def iexact_div(num, den):
    """exact float integers num/den (den != 0): correctly rounded quotient pushed outward"""
    f = num / den
    return (rd(f), ru(f))


def isq(a):
    lo, hi = a
    l2 = lo * lo; h2 = hi * hi
    pos = lo >= 0; neg = hi <= 0
    rlo = np.where(pos, l2, np.where(neg, h2, 0.0))
    rhi = np.maximum(l2, h2)
    return (np.where(rlo > 0, rd(rlo), 0.0), ru(rhi))


def iabsmax(a):
    return np.maximum(np.abs(a[0]), np.abs(a[1]))


# ---------------------------------------------------------------- exponential partial sums (cached)
_EH = {}


def ehat_arb(ell, ml):
    """1/sum_{i<120} (ell*ml)^i/i!  as an arb ball (rigorous)."""
    key = (ell, ml)
    if key not in _EH:
        x = to_arb(ell * ml)
        s = arb(1); t = arb(1)
        for i in range(1, 120):
            t = t * x / i
            s = s + t
        _EH[key] = 1 / s
    return _EH[key]


_EHQ = {}


def ehat_exact(ell, ml):
    key = (ell, ml)
    if key not in _EHQ:
        x = ell * ml
        s = mpq(0); t = mpq(1)
        for i in range(120):
            if i > 0:
                t = t * x / i
            s += t
        _EHQ[key] = 1 / s
    return _EHQ[key]


# ---------------------------------------------------------------- B(q*) cache, q* = (j-1)/(M-2)
_BSTAR = {}


def bstar_iv(M, j):
    key = (M, j)
    if key not in _BSTAR:
        num = math.comb(M, j) * (j - 1) ** (j - 1) * (M - j - 1) ** (M - j - 1)
        den = (M - 2) ** (M - 2)
        _BSTAR[key] = ic(mpq(num, den))
    return _BSTAR[key]


# ---------------------------------------------------------------- the exact atom test
def exact_atom(bx, M, j, rhs):
    """Exact first- and second-order bounds of part2 (F)(ii) with w_L=w_R=1.  Returns (pass, m1, m2)."""
    ql, qh, q0, dq, eta, xi = bx["ql"], bx["qh"], bx["q0"], bx["dq"], bx["eta"], bx["xi"]
    dstar = bx["dstar"]
    # Q_delta: exact min of eta d^2 + xi d on [j - qh M, j - ql M]
    a = j - qh * M; b = j - ql * M
    if dstar < a:
        Qd = eta * a * a + xi * a
    elif dstar > b:
        Qd = eta * b * b + xi * b
    else:
        Qd = -xi * xi / (4 * eta)
    d0 = j - q0 * M
    if j == -1 or j == M + 1:
        if j == -1:
            kap0 = -(1 - q0) ** M
            K1 = M * (1 - ql) ** (M - 1) if M >= 1 else mpq(0)
            K2 = M * (M - 1) * (1 - ql) ** (M - 2) if M >= 2 else mpq(0)
            kp0 = M * (1 - q0) ** (M - 1) if M >= 1 else mpq(0)
        else:
            kap0 = -(q0 ** M)
            K1 = M * qh ** (M - 1) if M >= 1 else mpq(0)
            K2 = M * (M - 1) * qh ** (M - 2) if M >= 2 else mpq(0)
            kp0 = -M * q0 ** (M - 1) if M >= 1 else mpq(0)
    else:
        def Bq(q):
            return mpq(math.comb(M, j)) * q ** (j - 1) * (1 - q) ** (M - j - 1)
        Bl, B0, Bh = Bq(ql), Bq(q0), Bq(qh)
        cands = [Bl, Bh]
        if M != 2:
            qs = mpq(j - 1, M - 2)
            if ql < qs < qh:
                cands.append(Bq(qs))
        Bmax = max(cands)
        kL = mpq(M + 1 - 2 * j, M - j + 1); kR = mpq(2 * j + 1 - M, j + 1)
        K = lambda q: kL * (1 - q) ** 2 + kR * q ** 2
        Kp = lambda q: -2 * kL * (1 - q) + 2 * kR * q
        Kc = [abs(K(ql)), abs(K(qh))]
        if kL + kR != 0:
            v = kL / (kL + kR)
            if ql <= v <= qh:
                Kc.append(abs(K(v)))
        Kmax = max(Kc)
        Kpmax = max(abs(Kp(ql)), abs(Kp(qh)))
        Kpp = abs(2 * (kL + kR))
        LBmax = max(abs(mpq(j - 1) / x - mpq(M - j - 1) / (1 - y)) for x in (ql, qh) for y in (ql, qh))
        LBpmax = abs(j - 1) / ql ** 2 + abs(M - j - 1) / (1 - qh) ** 2
        K1 = Bmax * (Kpmax + LBmax * Kmax)
        K2 = Bmax * (Kpp + 2 * LBmax * Kpmax + (LBmax ** 2 + LBpmax) * Kmax)
        kap0 = B0 * K(q0)
        LB0 = mpq(j - 1) / q0 - mpq(M - j - 1) / (1 - q0)
        kp0 = B0 * (Kp(q0) + LB0 * K(q0))
    m1 = kap0 - dq * K1 + Qd - rhs
    kt0 = kap0 + xi * d0 + eta * d0 * d0
    ktp = kp0 - M * (xi + 2 * eta * d0)
    m2 = kt0 - dq * abs(ktp) - dq * dq * (K2 + 2 * eta * M * M) / 2 - rhs
    return (m1 >= 0 or m2 >= 0), m1, m2


# ---------------------------------------------------------------- one box
def check_box(band, lam, bxraw, stats, exact_sample=0, rng=None):
    """Returns dict with pass flag, reasons, margins and counts."""
    res = {"ok": True, "why": []}
    ql, qh, ml, mh, m0 = (Q(bxraw[k]) for k in ("ql", "qh", "ml", "mh", "m0"))
    eta, xi, alpha, beta, gamma = (Q(bxraw[k]) for k in ("mu", "c", "alpha", "beta", "gamma"))
    z = [Q(x) for x in bxraw["z"]]
    N, cm = bxraw["N"], bxraw["cm"]
    D, theta = Q(band["D"]), Q(band["theta"])
    ell = [Q(x) for x in band["ell"]]

    def fail(msg):
        res["ok"] = False
        if len(res["why"]) < 5:
            res["why"].append(msg)

    # (S)
    if not (0 < ql < qh < 1): fail("S:q")
    if not eta > 0: fail("S:eta")
    if not gamma > 0: fail("S:gamma")
    if any(x < 0 for x in z): fail("S:z")
    if not (0 < ml <= mh): fail("S:m")
    if not (cm < ml + 1): fail("S:M*")
    if not lam >= 0: fail("S:lam")
    res["cm_is_ceil_ml"] = (cm == ceil_q(ml))
    if not res["ok"]:
        return res
    q0 = (ql + qh) / 2; dq = (qh - ql) / 2
    vl, vh = ql * (1 - ql), qh * (1 - qh)
    vmin = min(vl, vh)
    vmax = mpq(1, 4) if ql <= mpq(1, 2) <= qh else max(vl, vh)
    dstar = -xi / (2 * eta); c2 = xi * xi / (4 * eta)
    bx = dict(ql=ql, qh=qh, q0=q0, dq=dq, eta=eta, xi=xi, dstar=dstar)

    def psi0(M):
        t = M - m0
        return alpha + beta * t - gamma * t * t

    def kfloor(M):
        V = vmin * M
        if V >= 25:
            return 1 / (20 * V) + 1 / (V * V)
        return 1 / vmin

    # (T)
    VN = vmin * N
    if not VN >= 25: fail("T:vminN<25")
    tslack = -(1 / (20 * VN) + 1 / (VN * VN)) - c2 - psi0(N) if VN > 0 else mpq(-1)
    if not tslack >= 0: fail("T:psi0")
    tslope = -(beta - 2 * gamma * (N - m0))
    if not tslope >= 0: fail("T:slope")
    res["T_slack"] = tslack
    res["T_slope_slack"] = tslope

    # (Mg)  -- ball arithmetic for the tail sum, exact fallback
    base = alpha + min(beta * (ml - m0), beta * (mh - m0)) - gamma * (D * mh + max((ml - m0) ** 2, (mh - m0) ** 2)) \
        - eta * theta * vmax * mh
    rho = [(1 + lam) / (1 + lam * t) for t in TAUS[:len(ell)]]
    eh_a = [ehat_arb(ell[r], ml) for r in range(len(ell))]
    rho_a = [to_arb(x) for x in rho]
    pw = [arb(1) for _ in rho_a]
    tail = arb(0)
    one = arb(1)
    for Mp in range(len(z)):
        if Mp > 0:
            pw = [pw[r] * rho_a[r] for r in range(len(pw))]
        if z[Mp] == 0:
            continue
        if Mp > cm:
            tail = tail + to_arb(z[Mp])
            continue
        best = one
        for r in range(len(pw)):
            u = (eh_a[r] * pw[r]).upper()
            if u < best:
                best = u
        tail = tail + to_arb(z[Mp]) * best
    mg_lo = to_arb(base) - tail
    if mg_lo > 0:
        mg = mg_lo
        mg_exact = False
    else:  # exact fallback
        tl = mpq(0)
        ehq = [ehat_exact(ell[r], ml) for r in range(len(ell))]
        for Mp in range(len(z)):
            if z[Mp] == 0:
                continue
            if Mp > cm:
                tl += z[Mp]
            else:
                tl += z[Mp] * min([mpq(1)] + [ehq[r] * rho[r] ** Mp for r in range(len(ell))])
        mgq = base - tl
        mg = to_arb(mgq)
        mg_exact = True
        if not mgq > 0:
            fail("Mg")
    res["Mg"] = float(mg.mid())
    res["Mg_rel"] = float((mg / to_arb(alpha)).mid()) if alpha != 0 else float("nan")
    res["Mg_exact_fallback"] = mg_exact

    # (F): fibers M < N
    zs = [mpq(0)] * (max(N, len(z)) + 2)
    acc = mpq(0)
    for Mp in range(len(z) - 1, -1, -1):
        acc += z[Mp]
        zs[Mp] = acc
    # interval constants
    qv = {"l": ql, "0": q0, "h": qh}
    pl, dl = int(ql.numerator), int(ql.denominator)
    ph, dh = int(qh.numerator), int(qh.denominator)
    # binomial carry: rows 0..2 lower bounds (ql,q0,qh), rows 3..5 upper bounds
    qs_lo = np.array([ic(ql)[0], ic(q0)[0], ic(qh)[0], ic(ql)[1], ic(q0)[1], ic(qh)[1]])
    om = [ic(1 - ql), ic(1 - q0), ic(1 - qh)]
    oms = np.array([om[0][0], om[1][0], om[2][0], om[0][1], om[1][1], om[2][1]])
    qcol = np.array([ic(ql)[0], ic(q0)[0], ic(qh)[0], ic(ql)[1], ic(q0)[1], ic(qh)[1]])[:, None]
    omcol = oms[:, None]
    dirs = np.array([NINF, NINF, NINF, PINF, PINF, PINF])[:, None]
    V = np.ones((6, 1))
    res["F_slack"] = (float("inf"), -1, -1)
    # atom collection
    A_M, A_j, A_rlo, A_rhi, A_b = [], [], [], [], []
    rhs_of = {}
    n_fib = 0; n_fib_lev = 0; n_atoms = 0; n_exact = 0; n_end_fallback = 0
    for M in range(N):
        if M > 0:
            ext = np.zeros((6, M + 2))
            ext[:, 1:M + 1] = V
            t1 = np.nextafter(omcol * ext[:, 1:], dirs)
            t2 = np.nextafter(qcol * ext[:, :-1], dirs)
            V = np.nextafter(t1 + t2, dirs)
        n_fib += 1
        rhs = psi0(M) - zs[M]
        lev = rhs + kfloor(M) + c2
        if lev <= 0:
            continue
        n_fib_lev += 1
        # (i) half-line tests
        a = -2 - ql * M
        minL = -c2 if dstar <= a else eta * a * a + xi * a
        b = M + 2 - qh * M
        minR = -c2 if dstar >= b else eta * b * b + xi * b
        if not (rhs <= minL and rhs <= minR):
            fail(f"F(i) M={M}")
            continue
        # (ii) proposed range (float radius), ends certified exactly
        rbox = math.ceil(math.sqrt(float(lev / eta))) + 1 + REXTRA
        jlo = floor_q(ql * M + dstar) - rbox
        jhi = ceil_q(qh * M + dstar) + rbox
        jlo = min(max(jlo, -1), M + 1); jhi = min(max(jhi, -1), M + 1)
        if jlo > -1:
            Dm = ql * M + dstar - (jlo - 1)
            if not (Dm >= 0 and eta * Dm * Dm >= lev):
                jlo = -1; n_end_fallback += 1
        if jhi < M + 1:
            Dp = (jhi + 1) - qh * M - dstar
            if not (Dp >= 0 and eta * Dp * Dp >= lev):
                jhi = M + 1; n_end_fallback += 1
        if FULLRANGE:
            jlo, jhi = -1, M + 1
        if jlo > jhi:
            continue
        rhs_of[M] = rhs
        n_atoms += jhi - jlo + 1
        # end atoms exactly
        for jj in (-1, M + 1):
            if jlo <= jj <= jhi:
                ok, m1, m2 = exact_atom(bx, M, jj, rhs)
                n_exact += 1
                if float(max(m1, m2)) < res["F_slack"][0]:
                    res["F_slack"] = (float(max(m1, m2)), M, jj)
                if not ok:
                    fail(f"F(ii) atom M={M} j={jj}")
        j0 = max(jlo, 0); j1 = min(jhi, M)
        if j0 <= j1:
            rlo, rhi = ic(rhs)
            js = np.arange(j0, j1 + 1)
            A_M.append(np.full(js.shape, M, dtype=np.int64)); A_j.append(js.astype(np.int64))
            A_rlo.append(np.full(js.shape, rlo)); A_rhi.append(np.full(js.shape, rhi))
            A_b.append(V[:, j0:j1 + 1])
    res["fibers"] = n_fib; res["fibers_lev_pos"] = n_fib_lev; res["atoms"] = n_atoms
    res["end_fallbacks"] = n_end_fallback
    if A_M:
        Ms = np.concatenate(A_M); js = np.concatenate(A_j)
        rhs_iv = (np.concatenate(A_rlo), np.concatenate(A_rhi))
        bv = np.concatenate(A_b, axis=1)
        p1, p2, slk = vector_atoms(bx, Ms, js, rhs_iv, bv, pl, dl, ph, dh)
        okv = p1 | p2
        bad = np.nonzero(~okv)[0]
        n_exact += len(bad)
        for k in bad:
            M = int(Ms[k]); j = int(js[k])
            ok, m1, m2 = exact_atom(bx, M, j, rhs_of[M])
            slk[k] = float(max(m1, m2))
            if not ok:
                fail(f"F(ii) atom M={M} j={j} m1={float(m1):.3e} m2={float(m2):.3e}")
        kmin = int(np.argmin(slk))
        # the binding atom of the box is always re-decided exactly; its exact slack is the one reported
        Mk = int(Ms[kmin]); jk = int(js[kmin])
        okk, m1k, m2k = exact_atom(bx, Mk, jk, rhs_of[Mk])
        stats["argmin_exact"] = stats.get("argmin_exact", 0) + 1
        if not okk:
            fail(f"F(ii) argmin atom M={Mk} j={jk} exact fail")
        if (bool(p1[kmin]) and not m1k >= 0) or (bool(p2[kmin]) and not m2k >= 0):
            stats["sample_mismatch"] += 1
        sk = float(max(m1k, m2k))
        if sk < res["F_slack"][0]:
            res["F_slack"] = (sk, Mk, jk)
        res["atoms_first_order_iv"] = int(p1.sum()); res["atoms_second_only_iv"] = int((~p1 & p2).sum())
        # optional consistency sample: exact recomputation of random interval-accepted atoms
        if exact_sample and rng is not None and len(Ms) > 0:
            idx = rng.choice(len(Ms), size=min(exact_sample, len(Ms)), replace=False)
            for k in idx:
                M = int(Ms[k]); j = int(js[k])
                ok, m1, m2 = exact_atom(bx, M, j, rhs_of[M])
                stats["sample_checked"] += 1
                if bool(p1[k]) and not (m1 >= 0):
                    stats["sample_mismatch"] += 1
                if bool(p2[k]) and not (m2 >= 0):
                    stats["sample_mismatch"] += 1
    else:
        res["atoms_first_order_iv"] = 0; res["atoms_second_only_iv"] = 0
    res["exact_atoms"] = n_exact
    return res


def vector_atoms(bx, Ms, js, rhs, bv, pl, dl, ph, dh):
    """Rigorous interval evaluation of the first- and second-order margins for atoms 0<=j<=M.
    Returns boolean arrays (first-order margin certified >= 0, second-order margin certified >= 0)."""
    ql, qh, q0, dq, eta, xi = bx["ql"], bx["qh"], bx["q0"], bx["dq"], bx["eta"], bx["xi"]
    Mf = Ms.astype(np.float64); jf = js.astype(np.float64)
    n = len(Ms)
    one = lambda c: (np.full(n, c[0]), np.full(n, c[1]))
    bl = (bv[0], bv[3]); b0 = (bv[1], bv[4]); bh = (bv[2], bv[5])
    inv_l = ic(1 / (ql * (1 - ql))); inv_0 = ic(1 / (q0 * (1 - q0))); inv_h = ic(1 / (qh * (1 - qh)))
    Bl = imul_pos(bl, inv_l); B0 = imul_pos(b0, inv_0); Bh = imul_pos(bh, inv_h)
    # Bmax
    jm1 = js - 1; Mm2 = Ms - 2
    big = Ms >= 3
    le_l = jm1 * dl <= pl * Mm2          # q* <= ql
    ge_h = jm1 * dh >= ph * Mm2          # q* >= qh
    Bmax = np.where(le_l, Bl[1], np.where(ge_h, Bh[1], 0.0))
    inside = big & ~le_l & ~ge_h
    if inside.any():
        for k in np.nonzero(inside)[0]:
            Bmax[k] = bstar_iv(int(Ms[k]), int(js[k]))[1]
    small = ~big
    Bmax = np.where(small, np.maximum(Bl[1], Bh[1]), Bmax)
    # kernels
    n1 = Mf + 1 - 2 * jf; d1 = Mf - jf + 1; n2 = 2 * jf + 1 - Mf; d2 = jf + 1
    kL = iexact_div(n1, d1); kR = iexact_div(n2, d2)
    def Kat(q):
        a = imul(kL, one(ic((1 - q) ** 2))); b = imul(kR, one(ic(q * q)))
        return iadd(a, b)
    def Kpat(q):
        a = imul(kL, one(ic(-2 * (1 - q)))); b = imul(kR, one(ic(2 * q)))
        return iadd(a, b)
    Kl, K0, Kh = Kat(ql), Kat(q0), Kat(qh)
    Kmax = np.maximum(iabsmax(Kl), iabsmax(Kh))
    # vertex kL/(kL+kR) = n1 d2 / S, S = n1 d2 + n2 d1 (integers)
    n1i = (Ms + 1 - 2 * js); d1i = (Ms - js + 1); n2i = (2 * js + 1 - Ms); d2i = (js + 1)
    S = n1i * d2i + n2i * d1i
    vn = n1i * d2i
    sgn = np.sign(S)
    vin = (S != 0) & ((vn * dl - pl * S) * sgn >= 0) & ((ph * S - vn * dh) * sgn >= 0)
    if vin.any():
        Kv = iexact_div((n1i * n2i).astype(np.float64), np.where(S != 0, S, 1).astype(np.float64))
        Kmax = np.where(vin, np.maximum(Kmax, iabsmax(Kv)), Kmax)
    Kpl, Kp0, Kph = Kpat(ql), Kpat(q0), Kpat(qh)
    Kpmax = np.maximum(iabsmax(Kpl), iabsmax(Kph))
    Kpp = ru(2 * iabsmax(iadd(kL, kR)))
    # |L_B|max over the four combinations
    jm1f = jf - 1; mj = Mf - jf - 1
    t1 = [imul((jm1f, jm1f), one(ic(1 / x))) for x in (ql, qh)]
    t2 = [imul((mj, mj), one(ic(1 / (1 - x)))) for x in (ql, qh)]
    LBmax = np.zeros(n)
    for a in t1:
        for b in t2:
            LBmax = np.maximum(LBmax, iabsmax(isub(a, b)))
    LBp = ru(ru(np.abs(jm1f) * ic(1 / ql ** 2)[1]) + ru(np.abs(mj) * ic(1 / (1 - qh) ** 2)[1]))
    K1 = ru(Bmax * ru(Kpmax + ru(LBmax * Kmax)))
    K2 = ru(Bmax * ru(ru(Kpp + ru(2 * ru(LBmax * Kpmax))) + ru(ru(ru(LBmax * LBmax) + LBp) * Kmax)))
    kap0 = imul(B0, K0)
    eta_iv = ic(eta); xi_iv = ic(xi); dstar_iv = ic(bx["dstar"]); c2_iv = ic(xi * xi / (4 * eta))
    dq_hi = ic(dq)[1]
    aa = isub((jf, jf), imul((Mf, Mf), one(ic(qh))))
    bb = isub((jf, jf), imul((Mf, Mf), one(ic(ql))))
    dA = isub(aa, one(dstar_iv)); dB = isub(one(dstar_iv), bb)
    dist_lo = np.maximum(0.0, np.maximum(dA[0], dB[0]))
    Q_lo = rd(rd(eta_iv[0] * rd(dist_lo * dist_lo)) - c2_iv[1])
    m1_lo = rd(rd(rd(kap0[0] - ru(dq_hi * K1)) + Q_lo) - rhs[1])
    p1 = m1_lo >= 0
    # second order
    d0 = isub((jf, jf), imul((Mf, Mf), one(ic(q0))))
    kt0 = iadd(iadd(kap0, imul(one(xi_iv), d0)), imul(one(eta_iv), isq(d0)))
    LB0 = isub(imul((jm1f, jm1f), one(ic(1 / q0))), imul((mj, mj), one(ic(1 / (1 - q0)))))
    kp0 = imul(B0, iadd(Kp0, imul(LB0, K0)))
    inner = iadd(one(xi_iv), imul(one(ic(2 * eta)), d0))
    ktp = isub(kp0, imul((Mf, Mf), inner))
    rem = ru(ru(ic(dq * dq / 2)[1] * ru(K2 + ru(ic(2 * eta)[1] * ru(Mf * Mf)))))
    m2_lo = rd(rd(rd(kt0[0] - ru(dq_hi * iabsmax(ktp))) - rem) - rhs[1])
    p2 = m2_lo >= 0
    return p1, p2, np.maximum(m1_lo, m2_lo)


# ---------------------------------------------------------------- covering
def check_cover(cov):
    band = cov["band"]; cap = Q(cov["cap"]); boxes = cov["boxes"]; slabs = cov["slabs"]
    lamLo, lamHi, mmin = Q(band["lamLo"]), Q(band["lamHi"]), Q(band["mmin"])
    qlo = lamLo / (1 + lamLo); qhi = lamHi / (1 + lamHi)
    why = []
    if not slabs:
        return False, ["no slabs"]
    if not slabs[0]["lo"] <= qlo: why.append("first slab lo > q(lamLo)")
    if not slabs[-1]["hi"] >= qhi: why.append("last slab hi < q(lamHi)")
    for k in range(1, len(slabs)):
        if not Q(slabs[k]["lo"]) <= Q(slabs[k - 1]["hi"]): why.append(f"gap before slab {k}")
    nempty = 0
    for k, s in enumerate(slabs):
        lo, hi = Q(s["lo"]), Q(s["hi"])
        if lo > hi: nempty += 1
        ch = s["chain"]
        if not ch:
            why.append(f"slab {k} empty chain"); continue
        if any(i >= len(boxes) for i in ch):
            why.append(f"slab {k} bad index"); continue
        for i in ch:
            b = boxes[i]
            if not (Q(b["ql"]) <= lo and hi <= Q(b["qh"])): why.append(f"slab {k} box {i} not containing slab")
        if not Q(boxes[ch[0]]["ml"]) <= mmin: why.append(f"slab {k} chain start ml > mmin")
        for a, b in zip(ch, ch[1:]):
            if not Q(boxes[b]["ml"]) <= Q(boxes[a]["mh"]): why.append(f"slab {k} chain gap {a}->{b}")
        if not Q(boxes[ch[-1]]["mh"]) >= cap: why.append(f"slab {k} chain end mh < cap")
    used = set(i for s in slabs for i in s["chain"])
    return (not why), why[:5], len(used), nempty


def split_pairs(boxes):
    keyf = lambda b: (b["ql"], b["qh"], b["m0"], b["mu"], b["c"], b["alpha"], b["beta"], b["gamma"], tuple(b["z"]))
    groups = {}
    for i, b in enumerate(boxes):
        groups.setdefault(keyf(b), []).append(i)
    npair = 0; nonabut = 0
    for k, ids in groups.items():
        if len(ids) == 2:
            a, b = (boxes[i] for i in ids)
            if a["mh"] == b["ml"] or b["mh"] == a["ml"]:
                npair += 1
            else:
                nonabut += 1
        elif len(ids) > 2:
            nonabut += 1
    return npair, nonabut


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pkl"); ap.add_argument("outdir")
    ap.add_argument("--only", default=None, help="comma list of covering names")
    ap.add_argument("--families", default="coarse_lower,coarse_upper,above_m52,above_m48,above_m45,above_m44")
    ap.add_argument("--sample", type=int, default=3, help="exact re-check of this many interval-accepted atoms per box")
    ap.add_argument("--tag", default="run")
    ap.add_argument("--rextra", type=int, default=0)
    ap.add_argument("--fullrange", action="store_true")
    args = ap.parse_args()
    global REXTRA, FULLRANGE
    REXTRA = args.rextra; FULLRANGE = args.fullrange
    covs = pickle.load(open(args.pkl, "rb"))
    fams = args.families.split(",")
    only = set(args.only.split(",")) if args.only else None
    rng = np.random.default_rng(993)
    os.makedirs(args.outdir, exist_ok=True)
    csvp = os.path.join(args.outdir, f"coverings_{args.tag}.csv")
    boxp = os.path.join(args.outdir, f"boxes_{args.tag}.csv")
    logp = os.path.join(args.outdir, f"log_{args.tag}.txt")
    fc = open(csvp, "w", newline=""); wc = csv.writer(fc)
    fb = open(boxp, "w", newline=""); wb = csv.writer(fb)
    fl = open(logp, "a")
    wc.writerow(["family", "covering", "theorem", "result", "cover_ok", "boxes_entries", "boxes_used_in_chains",
                 "boxes_failed", "split_pairs", "fibers", "fibers_lev_pos", "atoms", "atoms_exact",
                 "atoms_first_order", "atoms_second_order_only", "range_end_fallbacks",
                 "least_Mg", "least_Mg_box", "least_Mg_rel", "least_Mg_rel_box", "least_T_slack", "least_T_slack_box",
                 "least_T_slope_slack", "least_F_atom_slack", "least_F_box_M_j", "Mg_exact_fallbacks", "cm_eq_ceil_ml_all", "runtime_s", "fail_reasons"])
    wb.writerow(["covering", "box_index", "box_name", "ok", "N", "cm", "fibers", "fibers_lev_pos", "atoms",
                 "atoms_exact", "Mg", "Mg_rel", "T_slack", "F_slack", "why"])
    stats = {"sample_checked": 0, "sample_mismatch": 0}
    tot = {}
    for cov in covs:
        if cov["family"] not in fams: continue
        if only and cov["name"] not in only: continue
        t0 = time.time()
        band = cov["band"]
        bandsane = all(Q(x) >= 0 for x in [band["D"], band["theta"]] + list(band["ell"]))
        cover_ok, cwhy, nused, nempty = check_cover(cov)
        nb_fail = 0; agg = {"fibers": 0, "fibers_lev_pos": 0, "atoms": 0, "exact_atoms": 0, "fo": 0, "so": 0, "endfb": 0, "mgx": 0}
        least_mg = None; least_rel = None; least_t = None; least_slope = None; allcm = True
        least_f = (float("inf"), -1, -1, -1)
        reasons = []
        if not bandsane: reasons.append("band params negative")
        if not cover_ok: reasons += cwhy
        for bi, b in enumerate(cov["boxes"]):
            lam = Q(band["lamHi"]) if cov["tail"][0] == "const" else Q(b["qh"]) / (1 - Q(b["qh"]))
            r = check_box(band, lam, b, stats, exact_sample=args.sample, rng=rng)
            if not r["ok"]:
                nb_fail += 1
                reasons.append(f"box {bi}: " + "; ".join(r["why"]))
            allcm &= r.get("cm_is_ceil_ml", False)
            agg["fibers"] += r.get("fibers", 0); agg["fibers_lev_pos"] += r.get("fibers_lev_pos", 0)
            agg["atoms"] += r.get("atoms", 0); agg["exact_atoms"] += r.get("exact_atoms", 0)
            agg["fo"] += r.get("atoms_first_order_iv", 0); agg["so"] += r.get("atoms_second_only_iv", 0)
            agg["endfb"] += r.get("end_fallbacks", 0); agg["mgx"] += int(r.get("Mg_exact_fallback", False))
            if "Mg" in r:
                if least_mg is None or r["Mg"] < least_mg[0]: least_mg = (r["Mg"], bi)
                if least_rel is None or r["Mg_rel"] < least_rel[0]: least_rel = (r["Mg_rel"], bi)
            if r.get("F_slack", (float("inf"),))[0] < least_f[0]:
                least_f = (r["F_slack"][0], bi, r["F_slack"][1], r["F_slack"][2])
            if "T_slack" in r:
                ts = float(r["T_slack"])
                if least_t is None or ts < least_t[0]: least_t = (ts, bi)
                sl = float(r["T_slope_slack"])
                if least_slope is None or sl < least_slope: least_slope = sl
            wb.writerow([cov["name"], bi, cov["box_names"][bi], r["ok"], b["N"], b["cm"], r.get("fibers"),
                         r.get("fibers_lev_pos"), r.get("atoms"), r.get("exact_atoms"),
                         "%.6e" % r["Mg"] if "Mg" in r else "", "%.6e" % r["Mg_rel"] if "Mg_rel" in r else "",
                         "%.6e" % float(r["T_slack"]) if "T_slack" in r else "",
                         "%.6e" % r["F_slack"][0] if "F_slack" in r else "", "|".join(r["why"])])
        sp = split_pairs(cov["boxes"])
        ok = bandsane and cover_ok and nb_fail == 0
        dt = time.time() - t0
        wc.writerow([cov["family"], cov["name"], cov["theorem"], "PASS" if ok else "FAIL", cover_ok, len(cov["boxes"]), nused,
                     nb_fail, sp[0], agg["fibers"], agg["fibers_lev_pos"], agg["atoms"], agg["exact_atoms"], agg["fo"], agg["so"],
                     agg["endfb"], "%.6e" % least_mg[0], least_mg[1], "%.6e" % least_rel[0], least_rel[1],
                     "%.6e" % least_t[0], least_t[1], "%.6e" % least_slope, "%.6e" % least_f[0], "%d/%d/%d" % least_f[1:], agg["mgx"], allcm, "%.1f" % dt,
                     " | ".join(reasons[:6])])
        fc.flush(); fb.flush()
        msg = (f"{time.strftime('%H:%M:%S')} {cov['family']} {cov['name']}: {'PASS' if ok else 'FAIL'} boxes={len(cov['boxes'])} "
               f"atoms={agg['atoms']} exact={agg['exact_atoms']} leastMg={least_mg[0]:.3e}@{least_mg[1]} "
               f"rel={least_rel[0]:.3e} Tslack={least_t[0]:.3e} Fslack={least_f[0]:.3e}@{least_f[1:]} split={sp} sample={stats} {dt:.1f}s")
        print(msg, flush=True); fl.write(msg + "\n"); fl.flush()
        f = cov["family"]
        t = tot.setdefault(f, {"cov": 0, "pass": 0, "entries": 0, "atoms": 0, "time": 0.0})
        t["cov"] += 1; t["pass"] += int(ok); t["entries"] += len(cov["boxes"]); t["atoms"] += agg["atoms"]; t["time"] += dt
    fl.write(f"{time.strftime('%H:%M:%S')} TOTALS {json.dumps(tot)} sample={stats}\n")
    print("TOTALS", json.dumps(tot), stats)


if __name__ == "__main__":
    main()
