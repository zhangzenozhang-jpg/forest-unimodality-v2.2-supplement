#!/usr/bin/python3
"""The fine-box limit of the LOWER-TAIL criterion (Theorem p2:thm:T1) on the order-44 rectangles above m_44, and an
exact obstruction where it fails.

Point LP at (q, mu) (DIAGNOSTIC, float, HiGHS): theta*(q, mu; D) = min E delta^2/(q(1-q) mu) over probability laws on
atoms (M, j) with E M = mu, E delta = 0, E (M - mu)^2 <= D mu, P(M <= M') <= T(M') for 0 <= M' <= ceil(mu)
(M_1 = ceil(mu) + 1), T(M') = min(1, min_r e^{-l_r mu} ((1+lam)/(1+lam tau_r))^{M'}) with the piece's five rates, and
   kernel 'kappa': E kappa(M, j) <= 0, kappa = f_L/q + f_R/(1-q)   (what a lower-tail certificate can exclude), or
   kernel 'two'  : E f_L <= 0 and E f_R <= 0                         (a valley at k).
A lower-tail certificate can exist at (q, mu) only if theta*_kappa >= theta.  A law feasible for the 'two' LP with
E delta^2 <= theta q(1-q) mu is a mixture with a valley that meets every hypothesis of Theorem p2:thm:T1: the
parameters are then not valley-free, no lower-tail certificate exists (Theorem p2:thm:T1), and no box containing
(q, mu) passes the band test with any tail base >= lam (Theorem apC:thm:t1box).

Modes:
  scan OUT piece D nlam nm           grid of theta*_kappa and theta*_two over [lam_lo, lam_hi] x [m_44, m_45]
  witness OUT piece lam mu D         exact witness (kernel 'two'), verified in exact rational arithmetic
  dstar OUT piece lam mu             largest D with theta*_kappa >= theta and with theta*_two >= theta at the point
"""
import sys, json, math, time
from fractions import Fraction as F
from math import comb, ceil
import numpy as np
from scipy.special import gammaln
from scipy.optimize import linprog
import pickle

TAUS = [F(0), F(1, 20), F(1, 10), F(1, 5), F(3, 10)]
PKL = __import__('os').path.join(__import__('os').path.dirname(__file__), '..', 'outputs', 'stage1', 't1', 'coverings.pkl')


def piece_params(p):
    covs = pickle.load(open(PKL, 'rb'))
    c = [x for x in covs if x['name'] == 'N44/P%02d' % p][0]
    b = c['band']
    return dict(theta=F(b['theta']), D=F(b['D']), ell=[F(x) for x in b['ell']], lamLo=F(b['lamLo']), lamHi=F(b['lamHi']),
                mmin=F(b['mmin']), cap=F(c['cap']))


def tail_T(lam, mu, ell, Mp):
    v = 1.0
    for t, l in zip(TAUS, ell):
        v = min(v, math.exp(-float(l) * mu) * ((1 + lam) / (1 + lam * float(t))) ** Mp)
    return v


def lp(qf, mf, Df, ell, kernel, eps=0.0, Mextra=35, tshrink=0.0):
    v = qf * (1 - qf); lam = qf / (1 - qf)
    Mmax = int(3 * mf + Mextra)
    Ms = np.concatenate([np.full(M + 9, M, dtype=float) for M in range(Mmax + 1)])
    Js = np.concatenate([np.arange(-4, M + 5, dtype=float) for M in range(Mmax + 1)])

    def binom(j):
        ok = (j >= 0) & (j <= Ms)
        jj = np.where(ok, j, 0)
        z = np.exp(gammaln(Ms + 1) - gammaln(jj + 1) - gammaln(Ms - jj + 1) + jj * np.log(qf) + (Ms - jj) * np.log1p(-qf))
        return np.where(ok, z, 0)
    b0, bm, bp = binom(Js), binom(Js - 1), binom(Js + 1)
    fL = (1 - qf) * b0 - qf * bm
    fR = qf * b0 - (1 - qf) * bp
    delta = Js - qf * Ms
    if kernel == 'two':
        rows = [fL, fR]; rhs = [-eps, -eps]
    else:
        rows = [fL / qf + fR / (1 - qf)]; rhs = [-eps]
    rows.append((Ms - mf) ** 2); rhs.append(Df * mf - eps)
    for Mp in range(0, int(math.ceil(mf)) + 1):
        rows.append((Ms <= Mp).astype(float)); rhs.append(tail_T(lam, mf, ell, Mp) * (1 - tshrink))
    res = linprog(delta ** 2 / (v * mf), A_ub=np.array(rows), b_ub=rhs,
                  A_eq=np.array([np.ones_like(Ms), Ms, delta]), b_eq=[1.0, mf, 0.0], bounds=(0, None), method='highs')
    if not res.success:
        return float('nan'), None
    return float(res.fun), (Ms, Js, res.x)


def exp_neg_lower(x, K=80):
    x = F(x)
    assert 0 <= x < K + 2
    s = F(1); t = F(1)
    for i in range(1, K + 1):
        t = t * x / i
        s += t
    tail = t * x / (K + 1) / (1 - x / (K + 2))
    return 1 / (s + tail)


def bq(M, j, q):
    return comb(M, j) * q ** j * (1 - q) ** (M - j) if 0 <= j <= M else F(0)


def solve3(A, b):
    def det(m):
        return (m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1]) - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0])
                + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]))
    d = det(A)
    if d == 0:
        raise ZeroDivisionError
    out = []
    for c in range(3):
        m = [row[:] for row in A]
        for r in range(3):
            m[r][c] = b[r]
        out.append(det(m) / d)
    return out


def verify(atoms, lam, q, mu, theta, D, ell, kernel='two'):
    M1 = ceil(mu) + 1
    W = sum(w for _, _, w in atoms); EM = sum(w * M for M, _, w in atoms)
    Ed = sum(w * (j - q * M) for M, j, w in atoms); Ed2 = sum(w * (j - q * M) ** 2 for M, j, w in atoms)
    VarM = sum(w * (M - mu) ** 2 for M, _, w in atoms)
    EfL = sum(w * ((1 - q) * bq(M, j, q) - q * bq(M, j - 1, q)) for M, j, w in atoms)
    EfR = sum(w * (q * bq(M, j, q) - (1 - q) * bq(M, j + 1, q)) for M, j, w in atoms)
    cdf = []
    ok_cdf = True
    for Mp in range(M1):
        Fm = sum(w for M, _, w in atoms if M <= Mp)
        # exact lower bound of T(Mp) = min(1, min_r e^{-l_r mu} ((1+lam)/(1+lam tau_r))^Mp)
        Tl = min([F(1)] + [exp_neg_lower(l * mu) * ((1 + lam) / (1 + lam * t)) ** Mp for t, l in zip(TAUS, ell)])
        cdf.append(dict(Mp=Mp, P_M_le=float(Fm), T_lower=float(Tl), slack=float(Tl - Fm)))
        ok_cdf &= (Fm <= Tl)
    budget = theta * q * (1 - q) * mu
    Ekap = EfL / q + EfR / (1 - q)
    checks = dict(nonneg=all(w >= 0 for _, _, w in atoms), mass_one=(W == 1), mean_mu=(EM == mu), mean_delta_zero=(Ed == 0),
                  delta2_le_budget=(Ed2 <= budget), varM_le_Dmu=(VarM <= D * mu), cdf_le_T_below_M1=ok_cdf)
    if kernel == 'two':
        checks.update(valley_left=(EfL <= 0), valley_right=(EfR <= 0))
    else:
        checks.update(E_kappa_le_0=(Ekap <= 0))
    return dict(ok=all(checks.values()), checks=checks, M1=M1, kernel=kernel, E_kappa=float(Ekap), E_delta2_over_qq1mu=float(Ed2 / (q * (1 - q) * mu)),
                VarM_over_mu=float(VarM / mu), E_fL=float(EfL), E_fR=float(EfR), cdf=cdf,
                exact=dict(E_delta2=str(Ed2), budget=str(budget), VarM=str(VarM), Dmu=str(D * mu)))


def witness(p, lam, mu, D, kernel='two'):
    P = piece_params(p)
    q = lam / (1 + lam)
    for eps, tsh in ((1e-9, 1e-7), (1e-8, 1e-6), (1e-7, 1e-5)):
        val, sol = lp(float(q), float(mu), float(D), P['ell'], kernel, eps=eps, tshrink=tsh)
        if sol is None:
            return dict(piece=p, label='LP infeasible', lp=val)
        Ms, Js, x = sol
        supp = [i for i in np.argsort(-x) if x[i] > 1e-13]
        den = 10 ** 18
        atoms = [[int(Ms[i]), int(Js[i]), F(round(x[i] * den), den)] for i in supp]
        atoms = [a for a in atoms if a[2] > 0]
        done = False
        for trip in [(0, 1, 2), (0, 1, 3), (0, 2, 3), (1, 2, 3), (0, 1, 4), (0, 2, 4), (1, 2, 4)]:
            if max(trip) >= len(atoms):
                continue
            A = [[F(1)] * 3, [F(atoms[t][0]) for t in trip], [atoms[t][1] - q * atoms[t][0] for t in trip]]
            try:
                corr = solve3(A, [F(1) - sum(a[2] for a in atoms), mu - sum(a[2] * a[0] for a in atoms),
                                  -sum(a[2] * (a[1] - q * a[0]) for a in atoms)])
            except ZeroDivisionError:
                continue
            for t, c in zip(trip, corr):
                atoms[t][2] += c
            done = True
            break
        assert done
        ver = verify([(a[0], a[1], a[2]) for a in atoms], lam, q, mu, P['theta'], D, P['ell'], kernel)
        out = dict(piece=p, lam=str(lam), q=str(q), mu=str(mu), mu_dec=float(mu), theta=str(P['theta']), D=str(D),
                   rates=[str(x) for x in P['ell']], kernel=kernel, lp_theta_star=val, eps=eps, support=len(atoms),
                   atoms=[dict(M=a[0], j=a[1], w=str(a[2]), w_dec=float(a[2])) for a in atoms], verification=ver,
                   label='PROVED (exact rational verification)' if ver['ok'] else 'NOT VERIFIED')
        if ver['ok']:
            return out
    return out


def main():
    mode = sys.argv[1]; out = sys.argv[2]; p = int(sys.argv[3])
    P = piece_params(p)
    th = float(P['theta'])
    if mode == 'scan':
        D = float(F(sys.argv[4])); nl = int(sys.argv[5]); nm = int(sys.argv[6])
        lams = [P['lamLo'] + (P['lamHi'] - P['lamLo']) * F(i, nl - 1) for i in range(nl)]
        ms = [P['mmin'] + (P['cap'] - P['mmin']) * F(i, nm - 1) for i in range(nm)]
        grid = []; worst = None; nfk = 0; nf2 = 0
        t0 = time.time()
        for lam in lams:
            q = float(lam / (1 + lam))
            for m in ms:
                tk, _ = lp(q, float(m), D, P['ell'], 'kappa'); t2, _ = lp(q, float(m), D, P['ell'], 'two')
                grid.append([float(lam), float(m), tk, t2])
                nfk += not (tk >= th); nf2 += not (t2 >= th)
                if worst is None or tk < worst[2]:
                    worst = [float(lam), float(m), tk, t2]
        res = dict(piece=p, D=D, theta=th, lam=[str(P['lamLo']), str(P['lamHi'])], m=[str(P['mmin']), str(P['cap'])],
                   points=len(grid), fail_kappa=nfk, fail_two=nf2, worst=worst, grid=grid)
        json.dump(res, open(out, 'w'), indent=1)
        print('N44/P%02d D %.4f: %d points; fail (kappa) %d, fail (two-sided) %d; worst theta*_kappa %.5f, theta*_two %.5f '
              'at lam %.5f m %.4f; %.0fs' % (p, D, len(grid), nfk, nf2, worst[2], worst[3], worst[0], worst[1], time.time() - t0), flush=True)
    elif mode == 'witness':
        lam, mu, D = F(sys.argv[4]), F(sys.argv[5]), F(sys.argv[6])
        kernel = sys.argv[7] if len(sys.argv) > 7 else 'two'
        res = witness(p, lam, mu, D, kernel)
        json.dump(res, open(out, 'w'), indent=1)
        v = res.get('verification', {})
        print('N44/P%02d witness at lam %s mu %s D %s: %s; support %s; E delta^2/(q(1-q)mu) %.6f vs theta %s; Var M/mu %.6f; '
              'min CDF slack %.3e; failed checks %s' % (p, lam, mu, D, res['label'], res.get('support'), v.get('E_delta2_over_qq1mu', float('nan')),
                                                       res.get('theta'), v.get('VarM_over_mu', float('nan')),
                                                       min(c['slack'] for c in v.get('cdf', [dict(slack=float('nan'))])),
                                                       [k for k, b in v.get('checks', {}).items() if not b]), flush=True)
    elif mode == 'dstar':
        lam, mu = F(sys.argv[4]), F(sys.argv[5])
        q = float(lam / (1 + lam))
        res = {}
        for ker in ('kappa', 'two'):
            a, b = 0.9, 1.6
            while b - a > 1e-5:
                c = (a + b) / 2
                t, _ = lp(q, float(mu), c, P['ell'], ker)
                if t >= th:
                    a = c
                else:
                    b = c
            res[ker] = a
        json.dump(dict(piece=p, lam=str(lam), mu=str(mu), D_star=res), open(out, 'w'), indent=1)
        print('N44/P%02d at lam %s mu %s (%.4f): largest D with a certificate in the fine-box limit: kappa %.5f, two-sided %.5f' % (
            p, lam, mu, float(mu), res['kappa'], res['two']), flush=True)


if __name__ == '__main__':
    main()
