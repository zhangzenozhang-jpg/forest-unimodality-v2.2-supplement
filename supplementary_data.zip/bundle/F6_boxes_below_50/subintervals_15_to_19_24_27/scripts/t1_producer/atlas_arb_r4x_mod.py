"""Lane R4X TRIAL COPY (DIAGNOSTIC; referee_verdict: null) of R52's atlas_arb_r52.py, itself a copy of
SOUL/O4/atlas_arb.py (sha256 442a1b62...).  Used only to count the dual boxes a new lower strip needs.
Changes from R52's copy (all in the source/validation layer; the box theorem, candidate LP, Arb slack,
CDF repair and cover check are byte-identical):
  * the band is a (sub-)band given on the command line: parent Profile30 band index (its O3 rates, read-only
    from SOUL/O3 and hash-checked), sub-band activity edges inside the parent band, explicit floor m_min
    (from r4x_floors.band_floor, recorded with N and record set), explicit strip top (--cap);
  * optional cap overrides --D, --theta (a TRIAL: they name the O1/O2 refit the strip would need), and an
    optional t = 0 rate override --ell0 for a sub-band O3 run (o3probe/); every override is recorded in
    SOURCE.json and the Profile30 cap-region assertions are skipped for overridden caps.
Everything written here is DIAGNOSTIC; the copied code writes the word CERTIFIED, LABEL.json overrides it.

Sound Arb parameter-box atlas, preserving the exact-dual proof design.

Only candidate search uses scipy. A --verify pass uses rational data and
Arb outward enclosures. Every accepted box is uniform in q and m.
"""
from exact_dual_copy import *
# act1_test: the floor is not recomputed here; the strip's floor is Lean's mmin44 of the piece (checked by the band
# test replay t1box_check.py and by t1_indep_check.py, whose covers must start at Lean's mmin44).
def band_floor(a, b, N, kind='lean2'):
    return dict(m=F(0))
SOUL=Path('/Users/kvallier/Desktop/Erdos 993/ProofRuns/2026-09-28_analytic_large_n/SOUL')
from flint import arb,ctx
import argparse
from math import isqrt

ctx.prec=128

def A(x):
    x=F(x);return arb(x.numerator)/arb(x.denominator)
def exact_endpoint(x,upper=False):
    z=x.upper() if upper else x.lower()
    n,e=z.man_exp();return F(int(n))*(F(2)**int(e))
def amin(values):return min(x.lower() for x in values)
def amax(values):return max(x.upper() for x in values)

def binrow(M,q):
    r=[(1-q)**M]
    for j in range(M):r.append(r[-1]*(M-j)/(j+1)*q/(1-q))
    return r

def quadratic_min(mu,c,lo,hi):
    x=max(lo,min(hi,-c/(2*mu)))
    return mu*x*x+c*x

def t_upper(m,q_hi,r,rates):
    return min(x.upper() for x in [arb(1)]+[(-A(F(v['ell'])*m)).exp()*A(1/(1-q_hi+q_hi*F(v['t'])))**r for v in rates])

def parent_rates(bi):
    per=json.loads((SOUL/'O4'/'per_unit_rates.json').read_text())['rows']
    row=per[bi-1];band=list(map(F,row['lambda_band']));rates=[]
    for v in row['values']:
        t=F(v['t']);suffix=str(t).replace('/','_')
        src=SOUL/'O3'/f'repaired_band_{bi:02d}_t_{suffix}.json'
        if src.exists():
            new=json.loads(src.read_text())
            assert new['status']=='CERTIFIED' and new['certificate']['ok']
            assert list(map(F,new['lambda_band']))==band and F(new['t'])==t
            rates.append(dict(t=str(t),ell=new['ell'],source=str(src),sha256=hashlib.sha256(src.read_bytes()).hexdigest()))
        else:
            rates.append(dict(t=str(t),ell=v['ell'],source='copied per_unit_rates.json',sha256=hashlib.sha256((SOUL/'O4'/'per_unit_rates.json').read_bytes()).hexdigest()))
    return row['lambda_band'],rates

def profile_caps(a,b):
    mid=(a+b)/2
    if F(4,5)<=mid<=F(13,10):return F(3,5),F(6,5)
    elif F(3,5)<=mid<=F(8,5):return F(7,10),F(7,5)
    return F(1),F(8,5)

def make_band(args):
    plam,rates=parent_rates(args.band)
    pa,pb=map(F,plam)
    a=F(args.lam_lo) if args.lam_lo else pa;b=F(args.lam_hi) if args.lam_hi else pb
    assert pa<=a<b<=pb,(pa,a,b,pb)
    theta,D=profile_caps(pa,pb)
    over={}
    if args.theta:over['theta']=[str(theta),args.theta];theta=F(args.theta)
    if args.D:over['D']=[str(D),args.D];D=F(args.D)
    if args.ell0:
        assert F(rates[0]['t'])==0
        over['ell0']=[rates[0]['ell'],args.ell0,args.ell0_source]
        rates[0]=dict(t='0',ell=args.ell0,source='OVERRIDE:'+args.ell0_source,sha256=None)
    fl=band_floor(a,b,args.N,args.kind)['m']
    if args.mmin:fl=max(fl,F(args.mmin))
    den=dict(kind=args.kind,n_min=args.N,m_min=str(fl),rule='r4x_floors.band_floor on the sub-band edges')
    return dict(index=args.band,parent_lambda_band=plam,lambda_band=[str(a),str(b)],rates=rates,
        D=str(D),theta=str(theta),density=den,m_min=den['m_min'],overrides=over)

def validate_source(band):
    a,b=map(F,band['lambda_band']);pa,pb=map(F,band['parent_lambda_band'])
    assert 0<pa<=a<b<=pb
    assert F(band['m_min'])==F(band['density']['m_min'])
    assert F(band['density']['m_min'])>=band_floor(a,b,band['density']['n_min'],band['density']['kind'])['m']
    assert 0<F(band['theta'])<=1 and 0<=F(band['D'])<=F(8,5)
    if not band['overrides']:
        assert (F(band['theta']),F(band['D']))==profile_caps(pa,pb)
    for rate in band['rates']:
        t,ell=map(F,(rate['t'],rate['ell']))
        assert 0<=t<1 and ell>0
        if rate['source'].startswith('OVERRIDE:'):
            continue
        if rate['source']=='copied per_unit_rates.json':
            path=SOUL/'O4'/'per_unit_rates.json'
            assert hashlib.sha256(path.read_bytes()).hexdigest()==rate['sha256']
            source=json.loads(path.read_text())['rows'][band['index']-1]
            assert source['lambda_band']==band['parent_lambda_band']
            assert any(F(v['t'])==t and F(v['ell'])==ell for v in source['values'])
        else:
            path=Path(rate['source'])
            assert hashlib.sha256(path.read_bytes()).hexdigest()==rate['sha256']
            source=json.loads(path.read_text())
            assert source['status']=='CERTIFIED' and source['certificate']['ok']
            assert source['lambda_band']==band['parent_lambda_band']
            assert F(source['t'])==t and F(source['ell'])==ell

def uniform_slack(ql,qh,m,cert):
    mu,c=cert['mu'],cert['c'];gamma=cert['gamma']
    assert mu>0 and gamma>0 and all(z>=0 for z in cert['z'])
    q=(ql+qh)/2;radius=A((qh-ql)/2)
    alo,aq,ahi=map(A,(ql,q,qh));vmin=min(ql*(1-ql),qh*(1-qh))
    N=max(ceil(m)+1,len(cert['z']))
    while vmin*N<16 or pi(N,m,cert)>-F(1,4)/(vmin*N)-c*c/(4*mu) or cert['beta']-2*gamma*(N-m)>0:N*=2
    worst=arb(0);witness=None;checks=0;per_fibre=[]
    coef=1/(aq*(1-aq))-2
    for M in range(N):
        worst_M=arb(0)
        rhs_fraction=pi(M,m,cert)-sum(cert['z'][M:],F(0))
        rhs=A(rhs_fraction)
        # kappa>=-B uniformly. Outside the following exact quadratic
        # sublevel range, the pointwise dual follows without PMF evaluation.
        B=F(1,4)/(vmin*M) if vmin*M>=16 else F(1)
        radius2=(rhs_fraction+B+c*c/(4*mu))/mu
        if radius2<=0:
            js=range(0)
        else:
            radius_int=isqrt(ceil(radius2))+1
            center=-c/(2*mu)
            jlo=max(-1,floor(ql*M+center-radius_int))
            jhi=min(M+1,ceil(qh*M+center+radius_int))
            js=range(jlo,jhi+1)
        if js:rlo,r0,rhi=[binrow(M,qq) for qq in [alo,aq,ahi]]
        for j in js:
            if j==-1:
                kap=-r0[0];der=M*(1-alo)**(M-1) if M else arb(0)
            elif j==M+1:
                kap=-r0[M];der=M*ahi**(M-1) if M else arb(0)
            else:
                kap=coef*r0[j]-(r0[j-1] if j else 0)-(r0[j+1] if j<M else 0)
                aa=F(M+1-2*j,M-j+1);bb=F(2*j+1-M,j+1)
                wvalues=[rlo[j]/(alo*(1-alo)),rhi[j]/(ahi*(1-ahi))]
                if M!=2:
                    star=F(j-1,M-2)
                    if ql<star<qh:
                        astar=A(star)
                        wvalues.append(comb(M,j)*astar**j*(1-astar)**(M-j)/(astar*(1-astar)))
                wmax=amax(wvalues)
                ps=[aa*(1-qq)**2+bb*qq**2 for qq in [ql,qh]]
                if aa+bb:
                    vertex=aa/(aa+bb)
                    if ql<vertex<qh:ps.append(aa*(1-vertex)**2+bb*vertex**2)
                pabs=A(max(map(abs,ps)))
                dpabs=A(max(abs(-2*aa+2*(aa+bb)*qq) for qq in [ql,qh]))
                labs=A(max(abs(F(j-1)/u-F(M-j-1)/(1-v)) for u in [ql,qh] for v in [ql,qh]))
                der=wmax*(dpabs+labs*pabs)
            qmin=quadratic_min(mu,c,F(j)-qh*M,F(j)-ql*M)
            slack=(kap-radius*der+A(qmin)-rhs).lower();checks+=1
            if slack<worst_M:worst_M=slack
            if slack<worst:worst,witness=slack,[M,j]
        # Remaining integer j are bounded by continuous quadratic half-lines.
        vertex=-c/(2*mu)
        for low,high in [(None,F(-2)-ql*M),(F(M+2)-qh*M,None)]:
            at=vertex
            if low is not None:at=max(at,low)
            if high is not None:at=min(at,high)
            slack=(A(mu*at*at+c*at)-rhs).lower();checks+=1
            if slack<worst_M:worst_M=slack
            if slack<worst:worst,witness=slack,[M,'outside']
        per_fibre.append(exact_endpoint(worst_M))
    return exact_endpoint(worst),witness,N,checks,per_fibre

def candidate_fibre(q,m,D,Ts):
    """Large-m search with only O(m) LP variables, fixed mu/c per try.
    The binomial atoms are evaluated numerically only to find a candidate;
    uniform_slack subsequently certifies or repairs it with Arb bounds.
    """
    import numpy as np
    from scipy.special import gammaln
    from scipy.optimize import linprog
    from math import pi as PI,log,sqrt
    qf,mf,Df=map(float,(q,m,D));v=qf*(1-qf);sq=1-2*qf
    Mmax=int(3*mf+35);Ms=np.arange(Mmax+1,dtype=float)
    atoms=[]
    for M in range(Mmax+1):
        j=np.arange(M+1,dtype=float)
        probs=np.exp(gammaln(M+1)-gammaln(j+1)-gammaln(M-j+1)+j*log(qf)+(M-j)*log(1-qf))
        K=(1/v-2)*np.pad(probs,(1,1))-np.pad(probs,(2,0))-np.pad(probs,(0,2))
        d=np.arange(-1,M+2,dtype=float)-qf*M
        atoms.append((K,d))
    Aub=np.array([(Ms-mf)**2]+[(Ms<=r).astype(float) for r in range(len(Ts))])
    bub=[Df*mf]+list(map(float,Ts))
    best=None
    for factor in [1.0,0.8,1.2]:
        mu=float(exp(-.5)/sqrt(2*PI)/(v*mf)**2.5*factor)
        c=-mu*sq*(sq*sq*mf-1)/(1+sq*sq)
        hvals=[]
        for M,(K,d) in enumerate(atoms):
            vertex=-c/(2*mu)
            left=min(vertex,-2-qf*M);right=max(vertex,M+2-qf*M)
            hvals.append(min(float(np.min(K+c*d+mu*d*d)),mu*left*left+c*left,mu*right*right+c*right))
        H=np.array(hvals)
        scale=mu*v*mf
        res=linprog(H/scale,A_ub=Aub,b_ub=bub,A_eq=np.array([np.ones_like(Ms),Ms]),b_eq=[1,mf],bounds=(0,None),method='highs')
        assert res.success,res.message
        if best is None or res.fun>best[0]:best=(float(res.fun),mu,c,scale,res)
    value,mu,c,scale,res=best
    den=10**16
    return dict(mu=rationalize(mu,den),c=rationalize(c,den),
        alpha=rationalize((res.eqlin.marginals[0]+res.eqlin.marginals[1]*mf)*scale,den)-F(1,10**12),
        beta=rationalize(res.eqlin.marginals[1]*scale,den),
        gamma=max(F(1,den),rationalize(-res.ineqlin.marginals[0]*scale,den)),
        z=[max(F(0),rationalize(-z*scale,den)) for z in res.ineqlin.marginals[1:]],
        numerical_optimum=value)

def certify_box(ql,qh,ml,mh,band,stored=None):
    q=(ql+qh)/2;m=(ml+mh)/2;D,theta=map(F,(band['D'],band['theta']))
    la,lb=map(F,band['lambda_band'])
    assert la<=ql/(1-ql)<=qh/(1-qh)<=lb
    assert ml<=mh and F(band['m_min'])<=ml
    rates=band['rates']
    alpha_change=F(0);running=F(0)
    if stored is None:
        Ts=[float(t_upper(m,q,r,rates)) for r in range(ceil(m))]
        cert=candidate(q,m,D,F(1),Ts) if m<=60 else candidate_fibre(q,m,D,Ts)
    else:
        cert={k:([F(x) for x in v] if isinstance(v,list) else F(v)) for k,v in stored['dual'].items() if k!='numerical_optimum'}
    worst,witness,N,checks,per_fibre=uniform_slack(ql,qh,m,cert)
    if stored is None:
        # Keep rare-small-M q-enclosure losses in their CDF accounts, rather
        # than charging their unweighted maximum against the whole law.
        cut=min(len(cert['z']),ceil(m/2))
        alpha_change=min(per_fibre[cut:]+[F(0)])-F(1,10**12)
        cert['alpha']+=alpha_change
        for r in range(cut-1,-1,-1):
            need=max(F(0),-per_fibre[r]+alpha_change)
            new=max(running,need)
            cert['z'][r]+=new-running
            running=new
        # The CDF repair may make a low-fibre enclosure exactly zero.
        # Retain a rational guard for independent outward recomputation.
        cert['alpha']-=F(1,10**12)
        alpha_change-=F(1,10**12)
    else:assert worst>=0,(stored['q'],stored['m'],worst,witness)
    Tlow=[t_upper(ml,qh,r,rates) for r in range(len(cert['z']))]
    radius=max((ml-m)**2,(mh-m)**2)
    bterm=min(cert['beta']*(ml-m),cert['beta']*(mh-m))
    vmax=F(1,4) if ql<=F(1,2)<=qh else max(ql*(1-ql),qh*(1-qh))
    margin=A(cert['alpha']+bterm-cert['gamma']*(D*mh+radius)-cert['mu']*theta*vmax*mh)
    margin-=sum((A(z)*t for z,t in zip(cert['z'],Tlow)),arb(0))
    lower=exact_endpoint(margin)
    if stored is not None:assert lower>0
    return dict(claim_label='CERTIFIED' if lower>0 else 'DIAGNOSTIC',referee_verdict=None,
        q=[str(ql),str(qh)],m=[str(ml),str(mh)],D=str(D),theta=str(theta),
        margin_lower=str(lower),margin_decimal=float(lower),arb_precision=128,
        cutoff=N,integer_states=checks,alpha_adjustment=str(alpha_change),raw_worst_slack=str(worst),cdf_repair_total=str(running),worst_atom=witness,
        dual={k:([str(x) for x in v] if isinstance(v,list) else str(v)) for k,v in cert.items()})

def cover_check(rows,ql,qh,ml,mh):
    # Check slabs separately to avoid a quadratic cross-product of all edges.
    qe=sorted(set([ql,qh]+[F(x) for row in rows for x in row['q']]))
    assert qe[0]==ql and qe[-1]==qh
    for left,right in zip(qe,qe[1:]):
        ivs=sorted((F(row['m'][0]),F(row['m'][1])) for row in rows if F(row['q'][0])<=left and right<=F(row['q'][1]))
        tip=ml
        for a,b in ivs:
            if a>tip:break
            tip=max(tip,b)
        assert tip>=mh,(left,right,tip,mh)
    return len(qe)-1

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--band',type=int,required=True);ap.add_argument('--cap',type=str,required=True)
    ap.add_argument('--root-dir',required=True);ap.add_argument('--sub',default='');ap.add_argument('--verify',action='store_true')
    ap.add_argument('--kind',default='lean2');ap.add_argument('--N',type=int,required=True);ap.add_argument('--mmin',default='')
    ap.add_argument('--lam-lo',default='');ap.add_argument('--lam-hi',default='')
    ap.add_argument('--D',default='');ap.add_argument('--theta',default='');ap.add_argument('--ell0',default='');ap.add_argument('--ell0-source',default='')
    args=ap.parse_args()
    cap=F(args.cap);folder=HERE/args.root_dir/(f'band_{args.band:02d}'+(('_'+args.sub) if args.sub else ''));folder.mkdir(parents=True,exist_ok=True)
    sourcepath=folder/'SOURCE.json'
    if not sourcepath.exists():sourcepath.write_text(json.dumps(make_band(args),indent=2)+'\n')
    (folder/'LABEL.json').write_text(json.dumps(dict(claim_label='DIAGNOSTIC',referee_verdict=None,lane='R4X',
        note='trial strip for boxes-count estimation; the copied constructor prints CERTIFIED, which this label overrides'),indent=1)+'\n')
    band=json.loads(sourcepath.read_text());a,b=map(F,band['lambda_band']);ql,qh=a/(1+a),b/(1+b);ml=F(band['m_min'])
    validate_source(band)
    assert ml<cap
    if args.verify:
        rows=[];states=0
        for path in sorted(folder.glob('box_*.json')):
            row=json.loads(path.read_text());lo,hi=map(F,row['q']);low,high=map(F,row['m'])
            result=certify_box(lo,hi,low,high,band,stored=row);states+=result['integer_states'];rows.append(row)
        slabs=cover_check(rows,ql,qh,ml,cap)
        result=dict(claim_label='CERTIFIED',referee_verdict=None,result='PASS',boxes=len(rows),integer_states=states,slabs=slabs,full_cover=True,lambda_band=band['lambda_band'],m=[str(ml),str(cap)],source_validated=True,checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),arb_precision=ctx.prec)
        (folder/'VERIFIED.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);return
    # Resume accepted boxes by reconstructing pending rectangles from an atomic
    # checkpoint. No previous certificate is deleted or overwritten.
    checkpath=folder/'QUEUE.json'
    rows=[json.loads(p.read_text()) for p in sorted(folder.glob('box_*.json'))]
    if checkpath.exists():pending=[tuple(map(F,r[:4]))+(int(r[4]),) for r in json.loads(checkpath.read_text())]
    else:pending=[(ql,qh,ml,cap,0)]
    tries=0;start=time.time()
    while pending:
        lo,hi,low,high,depth=pending.pop()
        row=certify_box(lo,hi,low,high,band);tries+=1
        if F(row['margin_lower'])>0:
            (folder/f'box_{len(rows):06d}.json').write_text(json.dumps(row,indent=2)+'\n');rows.append(row)
        elif depth>=24:
            raise RuntimeError('subdivision budget; retained boxes not full cover')
        elif 4*(hi-lo)*((low+high)/2)**2 >= high-low:
            mid=(lo+hi)/2;pending.extend([(lo,mid,low,high,depth+1),(mid,hi,low,high,depth+1)])
        else:
            mid=(low+high)/2;pending.extend([(lo,hi,low,mid,depth+1),(lo,hi,mid,high,depth+1)])
        checkpath.write_text(json.dumps([[str(x) for x in r] for r in pending])+'\n')
        print('band',args.band,'try',tries,'accepted',len(rows),'pending',len(pending),'q',float(lo),float(hi),'m',float(low),float(high),'margin',row['margin_decimal'],'seconds',round(time.time()-start,1),flush=True)
    slabs=cover_check(rows,ql,qh,ml,cap)
    result=dict(claim_label='CERTIFIED',referee_verdict=None,full_cover=True,boxes=len(rows),slabs=slabs,lambda_band=band['lambda_band'],q=[str(ql),str(qh)],m=[str(ml),str(cap)],D=band['D'],theta=band['theta'],source='SOURCE.json',needs_saved_dual_replay=True)
    (folder/'SUMMARY.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)

if __name__=='__main__':main()
