SUPPLEMENTARY ARCHIVE of "Unimodality of the independence sequence of a forest", draft version 2.1 (1 October 2026)

What this is
  The data of the computer-assisted steps of the paper that are verified outside the formal proof, the programs that
  produced them, and the independent checkers of every family of Section 7 of the paper. The plain text data file
  twin_v2.1_data.txt (also distributed separately) lists the constants of the subintervals and bands, the sub-intervals
  and polygons of the variance-bound checks and the coverings above a mean of 50. MANIFEST.sha256 gives the SHA-256 sum
  of every other file of this archive; the paper prints the SHA-256 sum of MANIFEST.sha256 and of the text file.
  Families verified in the formal proof (F2, F4, F5, F8, and 36 coverings of F6 and 25 of F7) have their data in the
  formal proof, branch fiber-floor-21, commit aa8ba75f693476c4dca886a4a58dbcc0f5f74ae2; the independent replays of those
  families are here.

Not included
  Internal reports and notes, the coverings of the earlier second criterion below a mean of 50 (not used by this route),
  and the certified variance-bound covers of the earlier route (not used by this route). Some folders keep intermediate
  files of their programs (parsed data, logs); only the files named below are inputs or outputs of a check of the paper.

Layout (one folder per family; "producer" = the program that built the data, "independent" = a program written
separately from the text, by another AI instance)
  F1_small_forests/                   Section 6 and Appendix A (Propositions on the 8 + 35 triples, the partition)
    producer_n_le_20/, producer_21_to_26/   the two verification programs of the earlier version and their outputs
                                            (the printed tables are restrictions of these outputs to n <= 24)
    independent_previous_version/       verify_part1_v20_refB.py and its output
    independent_this_version/           verify_part1_v21_refB.py (adapted to the tables of this version; 1,373 checks,
                                        0 failures) and its output
  F2_F8_kernel_facts_replay/          the 428 integer cases (item4_cases.py), the isolated-vertex and tail-hypothesis
                                      bounds (item23_isolated_thirdmean.py) and the other kernel facts, checked by a
                                      program written from the text
  F3_variance_bound/                  Theorem 4.21 (4,321 interval checks)
    producer_mid/                       segment mid: data and verifier outputs (final_data/, outputs/)
    producer_other_segments/            segments lo, u1 to u4: data and verifier outputs
    independent_mid/                    rt_verify.py (passes all 1,283 comparison checks with the halves)
    independent_other_segments/         rv_verify.py (precision 2^-72; passes all 1,381 comparison checks)
    independent_reruns/                 reruns of both on the final data, and indep_check.py
  F4_variance_ratio_replay/           Lemma 4.37: replay of the 84,156 pieces of the 14 intervals by separate code
                                      (128-bit outward-rounded intervals; results_*.jsonl)
  F5_laplace_independent_cover/       Lemma 4.42(a), (b): o3_unit_check.py on its own cover (376,180 cells, balls at 96
                                      bits), all 176 cases, least U >= 1.1e-3
  F6_boxes_below_50/                  Lemma 5.4 on subintervals 15 to 19, 24, 27 (new and rechecked boxes)
  F6_F7_hand_caps/                    Lemma 5.4 on subintervals 38, 39, 43, 44, 47 to 54, and Lemma 5.6 on bands 24,
                                      26 to 29 at the hand-proved caps (outputs/stage2/final_lower_tail_coverings.json,
                                      outputs/stage2/band27_split/)
  F6_F7_one_criterion/                Lemma 5.4, the 229 boxes from m*(iota) to 50 (outputs/), and the conversion of
                                      the 227 entries above 50 (Proposition 5.5)
  F6_F7_independent/                  independent exact checkers: one_criterion/ (ref_mgf_check.py for the 229 boxes,
                                      least margin 2.44e-5; ref_convert_check.py for the 227 converted entries in the
                                      floor variant, least margin 1.56e-6, largest cutoff 935), hand_caps/,
                                      subintervals_15_to_19_24_27/
  F7_formal_coverings_replay/         t1box_check.py: replay of the 178 tail-priced coverings of the formal proof
                                      (652,658 fibers, 20,092,720 atoms, least margin 1.4e-7)

Programs are Python 3 (standard library, with gmpy2 or mpmath where imported); each folder's logs show the commands
that were run and their results.
