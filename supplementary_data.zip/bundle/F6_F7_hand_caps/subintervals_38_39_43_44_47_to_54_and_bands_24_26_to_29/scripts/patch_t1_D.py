#!/usr/bin/python3
"""Copy the parsed lower-tail coverings (parse_data.py output) with the cap D replaced by NEWD on the named coverings.
Usage: patch_t1_D.py IN.pkl OUT.pkl NEWD name1,name2,...   (exact rational NEWD, e.g. 6/5)"""
import sys, pickle
from fractions import Fraction as F
inp, out, newd, names = sys.argv[1], sys.argv[2], F(sys.argv[3]), sys.argv[4].split(",")
covs = pickle.load(open(inp, "rb"))
sel = []
for c in covs:
    if c["name"] in names:
        print(c["name"], "D", c["band"]["D"], "->", newd, "theta", c["band"]["theta"], "lam", c["band"]["lamLo"], c["band"]["lamHi"])
        c["band"]["D"] = newd
        sel.append(c)
assert len(sel) == len(names), (len(sel), names)
pickle.dump(sel, open(out, "wb"))
