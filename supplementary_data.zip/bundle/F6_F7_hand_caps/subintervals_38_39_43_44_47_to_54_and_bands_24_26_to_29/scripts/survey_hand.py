#!/usr/bin/python3
"""Stage 2 survey (DIAGNOSTIC, floating point LPs, HiGHS through scipy): the fine-box limit of the criteria at the
hand-proved caps on every check that failed on the existing boxes in Stage 1.

For a point (q, mu) with lambda = q/(1-q) and the cap D = hand cap of the point (sup over a 1e-9 neighbourhood inside the
covering's activity range):
  th_kappa = min E delta^2/(q(1-q) mu) s.t. E M = mu, E delta = 0, Var M <= D mu, P(M <= M') <= T(M') (M' <= ceil mu),
             E kappa <= 0                                   (what a LOWER-TAIL certificate can exclude; T with tail base lambda)
  th_mgf   = min E delta^2/(q(1-q) mu) s.t. E M = mu, E delta = 0, Var M <= D mu, E s_r^M <= e^{-l_r mu} (r<5),
             E f_L <= 0, E f_R <= 0                         (what an MGF certificate can exclude; a valley)
A certificate of the criterion can exist at (q, mu) only if th >= theta (weak duality).  If th_mgf < theta, the law found
is a valley mixture meeting every hypothesis available to the route (the Laplace bounds imply the CDF bounds T).
Modes:  mgf  OUT pieces nlam mstep          (MGF rectangles R_iota from the rung-21 floor to m_44)
        t1   OUT names  nlam nm             (lower-tail coverings by name: both LPs)
"""
import sys, os, json, time, math, pickle
from fractions import Fraction as F
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from handcap import hand_sup
from survey_point_lp import theta_star
from lean_mgf_data import n44_tables, mgf_strip, qof
import t1_point_lp as T1

PKL = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'outputs', 'stage1', 'coverings.pkl')
EPS = F(1, 10 ** 9)


def cap_at(lam, lo, hi):
    return hand_sup(max(lo, lam - EPS), min(hi, lam + EPS))


def dstar(fn, theta, lo=1.0, hi=3.0, tol=2e-3):
    if not fn(lo) >= theta:
        return lo
    if fn(hi) >= theta:
        return hi
    while hi - lo > tol:
        mid = (lo + hi) / 2
        if fn(mid) >= theta:
            lo = mid
        else:
            hi = mid
    return lo


def main():
    mode, out = sys.argv[1], sys.argv[2]
    res = {}
    if mode == 'mgf':
        pieces = [int(x) for x in sys.argv[3].split(',')]
        nl = int(sys.argv[4]); mden = int(sys.argv[5])
        T = n44_tables()
        for p in pieces:
            t0 = time.time()
            lo, hi = T['pieceLo'][p], T['pieceHi'][p]
            theta = float(T['theta44'][p]); rates = [float(x) for x in T['rates44'][p]]
            mlo = mgf_strip(p)['mlo']; mhi = T['mmin44'][p]
            m25 = F(8) / (2 * qof(hi))
            lams = [lo + (hi - lo) * F(i, nl - 1) for i in range(nl)]
            ms = sorted(set([mlo, m25, mhi] + [F(k, mden) for k in range(math.ceil(mlo * mden), math.floor(mhi * mden) + 1)]))
            grid = []; worst = None
            for lam in lams:
                q = float(qof(lam)); D = float(cap_at(lam, lo, hi))
                for m in ms:
                    t = theta_star(q, float(m), D, rates)
                    grid.append([float(lam), float(m), D, t, bool(m >= m25)])
                    if worst is None or t < worst[3]:
                        worst = [float(lam), float(m), D, t]
            nf = sum(1 for g in grid if not g[3] >= theta)
            nf25 = sum(1 for g in grid if not g[3] >= theta and g[4])
            wl = F(worst[0]).limit_denominator(10 ** 6)
            ds = dstar(lambda d: theta_star(float(qof(wl)), worst[1], d, rates), theta)
            res[p] = dict(kind='MGF', piece=p, lam=[str(lo), str(hi)], m=[float(mlo), float(mhi)], m25=float(m25), theta=theta,
                          points=len(grid), fail=nf, fail_above_m25=nf25, worst=worst, D_star_at_worst=ds, grid=grid,
                          seconds=round(time.time() - t0, 1))
            print('R_%d [%s,%s]: %d points, fail %d (above m25: %d); worst th* %.5f vs theta %.3f at lam %.4f m %.4f D %.2f; '
                  'D* there %.4f; %.0fs' % (p, lo, hi, len(grid), nf, nf25, worst[3], theta, worst[0], worst[1], worst[2], ds,
                                            time.time() - t0), flush=True)
            json.dump(res, open(out, 'w'), indent=1)
    else:
        names = sys.argv[3].split(',')
        nl = int(sys.argv[4]); nm = int(sys.argv[5])
        covs = {c['name']: c for c in pickle.load(open(PKL, 'rb'))}
        for nmz in names:
            t0 = time.time()
            c = covs[nmz]; b = c['band']
            lo, hi = F(b['lamLo']), F(b['lamHi']); theta = float(b['theta']); ell = [F(x) for x in b['ell']]
            mlo, mhi = F(b['mmin']), F(c['cap'])
            lams = [lo + (hi - lo) * F(i, nl - 1) for i in range(nl)]
            ms = [mlo + (mhi - mlo) * F(i, nm - 1) for i in range(nm)]
            grid = []; wk = None; wm = None
            for lam in lams:
                q = float(qof(lam)); D = float(cap_at(lam, lo, hi))
                for m in ms:
                    tk, _ = T1.lp(q, float(m), D, ell, 'kappa')
                    tm = theta_star(q, float(m), D, [float(x) for x in ell])
                    grid.append([float(lam), float(m), D, tk, tm])
                    if wk is None or tk < wk[3]:
                        wk = [float(lam), float(m), D, tk]
                    if wm is None or tm < wm[3]:
                        wm = [float(lam), float(m), D, tm]
            nfk = sum(1 for g in grid if not g[3] >= theta)
            nfm = sum(1 for g in grid if not g[4] >= theta)
            wl = F(wk[0]).limit_denominator(10 ** 6)
            dsk = dstar(lambda d: T1.lp(float(qof(wl)), wk[1], d, ell, 'kappa')[0], theta)
            wl2 = F(wm[0]).limit_denominator(10 ** 6)
            dsm = dstar(lambda d: theta_star(float(qof(wl2)), wm[1], d, [float(x) for x in ell]), theta)
            res[nmz] = dict(kind='lower-tail', covering=nmz, lam=[str(lo), str(hi)], m=[float(mlo), float(mhi)], theta=theta,
                            points=len(grid), fail_kappa=nfk, fail_mgf=nfm, worst_kappa=wk, worst_mgf=wm,
                            D_star_kappa_at_worst=dsk, D_star_mgf_at_worst=dsm, grid=grid, seconds=round(time.time() - t0, 1))
            print('%s [%s,%s] m [%.2f,%.2f] theta %.2f: %d pts; fail kappa %d, fail MGF %d; worst th*_kappa %.4f (lam %.4f m %.2f D %.2f) '
                  'D*_kappa %.3f; worst th*_mgf %.4f (lam %.4f m %.2f) D*_mgf %.3f; %.0fs' % (
                      nmz, lo, hi, float(mlo), float(mhi), theta, len(grid), nfk, nfm, wk[3], wk[0], wk[1], wk[2], dsk,
                      wm[3], wm[0], wm[1], dsm, time.time() - t0), flush=True)
            json.dump(res, open(out, 'w'), indent=1)


if __name__ == '__main__':
    main()
