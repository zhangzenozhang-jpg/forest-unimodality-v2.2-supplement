#!/usr/bin/python3
"""act1_test: a SECOND, independently written checker of the band test for the lower-tail criterion
(appendix_C_inputs.tex, Section apC:sec:t1box; part2_body.tex, Section p2:sec:atlas for the atom bounds).
Written from the paper's statement only; it shares no code with t1box_check.py (the first replay) or with any producer.

Arithmetic: exact rationals only (gmpy2.mpq); no floating point in any decision.
Per box: (S), (T), (Mg) exactly as stated.  (F): for every fibre M < N: lev = rhs_T(M) + B(M) + xi^2/(4 eta) with the
kernel floor B(M) = 1/(20 v M) + 1/(v M)^2 if v M >= 25, else 1/v (v = v_min); if lev <= 0 the fibre passes; otherwise
(i) the two half-line tests, and (ii) every atom j in [-1, M+1] is examined: it passes if
   eta * dist(delta*, [j - qh M, j - ql M])^2 >= lev   (then kappa >= -B(M) gives the inequality for every q of the box;
   the paper's checker reaches the same atoms through its certified range ends), or
   the first-order bound, or the second-order bound (the paper's formulas, w_L = w_R = 1).
Cover: consecutive q-slabs from q(lam_lo) to q(lam_hi), each with a chain of boxes from m_min to m_cap.
Input: a pickle of coverings (build_t1_cov.py or parse_data.py format).  Usage: t1_indep_check.py IN.pkl OUT.json [names]
"""
import sys, json, time, pickle
from math import comb, isqrt
import gmpy2
from gmpy2 import mpq

TAU = [mpq(0), mpq(1, 20), mpq(1, 10), mpq(1, 5), mpq(3, 10)]
import os as _os
sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
from handcap import hand_sup_q
HANDCAP = _os.environ.get('UPPER_D_HANDCAP') == '1'   # upper_d_test: per-box hand cap
TAILCONST = _os.environ.get('UPPER_D_TAILCONST') == '1'   # upper_d_test: honour a covering's constant tail base
cov_tail = ('lamBox', None)


def Q(x):
    return mpq(int(x.numerator), int(x.denominator))


def qmin_on(eta, xi, lo, hi):
    """exact minimum of eta d^2 + xi d over d in [lo, hi] (lo or hi may be None: unbounded); eta > 0"""
    d = -xi / (2 * eta)
    if lo is not None and d < lo:
        d = lo
    if hi is not None and d > hi:
        d = hi
    return eta * d * d + xi * d


def ehat_T(x):
    """1/sum_{i<120} x^i/i!"""
    s = mpq(1); t = mpq(1)
    for i in range(1, 120):
        t = t * x / i
        s += t
    return 1 / s


def check_box(band, b):
    """returns (ok, reasons, stats)"""
    why = []
    ql, qh, ml, mh, m0 = Q(b['ql']), Q(b['qh']), Q(b['ml']), Q(b['mh']), Q(b['m0'])
    eta, xi, al, be, ga = Q(b['mu']), Q(b['c']), Q(b['alpha']), Q(b['beta']), Q(b['gamma'])
    z = [Q(x) for x in b['z']]
    N, Mstar = int(b['N']), int(b['cm'])
    D, th = Q(band['D']), Q(band['theta'])
    if HANDCAP:   # upper_d_test: the hand-proved cap of the box's activities (the table handcap.py)
        from fractions import Fraction as _F
        _d = hand_sup_q(_F(int(ql.numerator), int(ql.denominator)), _F(int(qh.numerator), int(qh.denominator)))
        D = mpq(_d.numerator, _d.denominator)
    ell = [Q(x) for x in band['ell']]
    lamb = qh / (1 - qh)                                   # the tail base of the box
    if TAILCONST and cov_tail[0] == 'const':               # upper_d_test: the coarse coverings' constant tail base
        lamb = Q(cov_tail[1])
    # (S)
    if not (0 < ql < qh < 1): why.append('S q')
    if not eta > 0: why.append('S eta')
    if not ga > 0: why.append('S gamma')
    if any(x < 0 for x in z): why.append('S z')
    if not (0 < ml <= mh): why.append('S m')
    if not Mstar < ml + 1: why.append('S M*')
    if why:
        return False, why, {}
    v = min(ql * (1 - ql), qh * (1 - qh))
    vmax = mpq(1, 4) if ql <= mpq(1, 2) <= qh else max(ql * (1 - ql), qh * (1 - qh))
    cc = xi * xi / (4 * eta)
    dstar = -xi / (2 * eta)

    def psi0(M):
        x = M - m0
        return al + be * x - ga * x * x

    def floorB(M):
        u = v * M
        return 1 / (20 * u) + 1 / (u * u) if u >= 25 else 1 / v
    # (T)
    u = v * N
    if not u >= 25: why.append('T vN<25')
    elif not psi0(N) <= -(1 / (20 * u) + 1 / (u * u)) - cc: why.append('T psi0(N)')
    if not be - 2 * ga * (N - m0) <= 0: why.append('T slope')
    # (Mg)
    eh = [ehat_T(l * ml) for l in ell]
    tail = mpq(0)
    for Mp, zz in enumerate(z):
        if zz == 0:
            continue
        if Mp <= Mstar:
            T = mpq(1)
            for r in range(5):
                T = min(T, eh[r] * ((1 + lamb) / (1 + lamb * TAU[r])) ** Mp)
        else:
            T = mpq(1)
        tail += zz * T
    mg = al + min(be * (ml - m0), be * (mh - m0)) - ga * (D * mh + max((ml - m0) ** 2, (mh - m0) ** 2)) - eta * th * vmax * mh - tail
    if not mg > 0: why.append('Mg %.3e' % float(mg))
    # (F)
    q0 = (ql + qh) / 2; dq = (qh - ql) / 2
    zs = [mpq(0)] * (len(z) + 1)                            # suffix sums: sum_{M' >= M} z_M'
    for k in range(len(z) - 1, -1, -1):
        zs[k] = zs[k + 1] + z[k]
    n_eval = n_skip = 0
    least = None
    cache = {}

    def pw(q, k):
        key = (q, k)
        if key not in cache:
            cache[key] = q ** k
        return cache[key]
    for M in range(N):
        rhs = psi0(M) - (zs[M] if M < len(zs) else 0)
        lev = rhs + floorB(M) + cc
        if lev <= 0:
            continue
        # (i) half-lines j <= -2 and j >= M + 2 (kernel 0 there)
        if not qmin_on(eta, xi, None, -2 - ql * M) >= rhs: why.append('F(i) left M=%d' % M)
        if not qmin_on(eta, xi, M + 2 - qh * M, None) >= rhs: why.append('F(i) right M=%d' % M)
        for j in range(-1, M + 2):
            lo_d, hi_d = j - qh * M, j - ql * M
            dist = (lo_d - dstar) if dstar < lo_d else ((dstar - hi_d) if dstar > hi_d else mpq(0))
            if eta * dist * dist >= lev:
                n_skip += 1
                continue
            n_eval += 1
            d0 = j - q0 * M
            Qd = qmin_on(eta, xi, lo_d, hi_d)
            if j == -1:
                k0 = -pw(1 - q0, M)
                K1 = M * pw(1 - ql, M - 1) if M >= 1 else mpq(0)
                K2 = M * (M - 1) * pw(1 - ql, M - 2) if M >= 2 else mpq(0)
                k1 = M * pw(1 - q0, M - 1) if M >= 1 else mpq(0)            # d/dq of -(1-q)^M
            elif j == M + 1:
                k0 = -pw(q0, M)
                K1 = M * pw(qh, M - 1) if M >= 1 else mpq(0)
                K2 = M * (M - 1) * pw(qh, M - 2) if M >= 2 else mpq(0)
                k1 = -M * pw(q0, M - 1) if M >= 1 else mpq(0)
            else:
                A = mpq(M + 1 - 2 * j, M - j + 1); Bc = mpq(2 * j + 1 - M, j + 1)
                C = comb(M, j)

                def Bf(q):
                    return C * pw(q, j) * pw(1 - q, M - j) / (q * (1 - q))
                cand = [Bf(ql), Bf(qh)]
                if M != 2:
                    qs = mpq(j - 1, M - 2)
                    if ql < qs < qh:
                        cand.append(Bf(qs))
                Bmax = max(cand)
                Kf = lambda q: A * (1 - q) ** 2 + Bc * q * q
                Kp = lambda q: -2 * A * (1 - q) + 2 * Bc * q
                Kc = [abs(Kf(ql)), abs(Kf(qh))]
                if A + Bc != 0:
                    qv = A / (A + Bc)
                    if ql < qv < qh:
                        Kc.append(abs(Kf(qv)))
                Kmax = max(Kc)
                Kpmax = max(abs(Kp(ql)), abs(Kp(qh)))
                Kpp = abs(2 * (A + Bc))
                Lmax = max(abs(mpq(j - 1) / a - mpq(M - j - 1) / (1 - c)) for a in (ql, qh) for c in (ql, qh))
                Lpmax = abs(mpq(j - 1)) / (ql * ql) + abs(mpq(M - j - 1)) / ((1 - qh) * (1 - qh))
                K1 = Bmax * (Kpmax + Lmax * Kmax)
                K2 = Bmax * (Kpp + 2 * Lmax * Kpmax + (Lmax * Lmax + Lpmax) * Kmax)
                B0 = Bf(q0)
                L0 = mpq(j - 1) / q0 - mpq(M - j - 1) / (1 - q0)
                k0 = B0 * Kf(q0)
                k1 = B0 * (Kp(q0) + L0 * Kf(q0))
            s1 = k0 - dq * K1 + Qd - rhs
            if s1 >= 0:
                s = s1
            else:
                kt0 = k0 + xi * d0 + eta * d0 * d0
                kt1 = k1 - M * (xi + 2 * eta * d0)
                s = kt0 - dq * abs(kt1) - dq * dq * (K2 + 2 * eta * M * M) / 2 - rhs
                if s < 0:
                    why.append('F atom M=%d j=%d slack %.3e' % (M, j, float(s)))
                    if len(why) > 10:
                        return False, why, {}
            if least is None or s < least[0]:
                least = (s, M, j)
    return (not why), why, dict(Mg=float(mg), atoms_evaluated=n_eval, atoms_skipped=n_skip,
                                least_atom=(float(least[0]), least[1], least[2]) if least else None)


def check_cover(cov):
    band = cov['band']; boxes = cov['boxes']; slabs = cov['slabs']
    a, b = Q(band['lamLo']), Q(band['lamHi'])
    qlo, qhi = a / (1 + a), b / (1 + b)
    mmin, cap = Q(band['mmin']), Q(cov['cap'])
    why = []
    if not slabs or Q(slabs[0]['lo']) > qlo: why.append('cover start')
    if not slabs or Q(slabs[-1]['hi']) < qhi: why.append('cover end')
    for s1, s2 in zip(slabs, slabs[1:]):
        if Q(s2['lo']) > Q(s1['hi']): why.append('slab gap')
    for s in slabs:
        lo, hi = Q(s['lo']), Q(s['hi'])
        top = None
        for k, i in enumerate(s['chain']):
            bx = boxes[i]
            if not (Q(bx['ql']) <= lo and hi <= Q(bx['qh'])): why.append('box not containing slab')
            if k == 0 and Q(bx['ml']) > mmin: why.append('chain start')
            if k > 0 and Q(bx['ml']) > top: why.append('chain gap')
            top = Q(bx['mh'])
        if top is None or top < cap: why.append('chain end')
    return (not why), why[:5]


def main():
    covs = pickle.load(open(sys.argv[1], 'rb'))
    names = set(sys.argv[3].split(',')) if len(sys.argv) > 3 else None
    out = []
    for cov in covs:
        if names and cov['name'] not in names:
            continue
        t0 = time.time()
        global cov_tail
        cov_tail = cov.get('tail', ('lamBox', None))
        band = cov['band']
        sane = all(Q(x) >= 0 for x in [band['D'], band['theta']] + list(band['ell']))
        cok, cwhy = check_cover(cov)
        nfail = 0; least_mg = None; reasons = []
        for i, b in enumerate(cov['boxes']):
            ok, why, st = check_box(band, b)
            if not ok:
                nfail += 1
                reasons.append('box %d: %s' % (i, '; '.join(why[:3])))
            elif least_mg is None or st['Mg'] < least_mg[0]:
                least_mg = (st['Mg'], i)
        res = dict(covering=cov['name'], D=str(band['D']), boxes=len(cov['boxes']), result='PASS' if (sane and cok and nfail == 0) else 'FAIL',
                   cover_ok=cok, cover_why=cwhy, boxes_failed=nfail, least_Mg=least_mg, reasons=reasons[:10],
                   seconds=round(time.time() - t0, 1))
        out.append(res)
        print('%s D=%s: %s boxes %d failed %d cover %s least Mg %s %.1fs %s' % (
            cov['name'], band['D'], res['result'], len(cov['boxes']), nfail, cok, ('%.3e@%d' % least_mg) if least_mg else '-',
            res['seconds'], ' | '.join(reasons[:3])), flush=True)
    json.dump(out, open(sys.argv[2], 'w'), indent=1)


if __name__ == '__main__':
    main()
