#!/bin/bash
# run_slot.sh SLOT cmd... : run cmd under nice -n 10 holding the mkdir-lock of compute slot SLOT (A, B or C).
# At most one process per slot; three slots in all (the task's limit of 3 parallel processes).
# (upper_d_test copy: the lock lives in certfree/upper_d_test/, the only folder this test writes to.)
SLOT="$1"; shift
LOCK="/Users/kvallier/Desktop/Erdos 993/ProofRuns/2026-09-28_analytic_large_n/LEAN/certfree/upper_d_test/.slot_$SLOT.lock"
until mkdir "$LOCK" 2>/dev/null; do sleep 2; done
trap 'rmdir "$LOCK"' EXIT
nice -n 10 "$@"
