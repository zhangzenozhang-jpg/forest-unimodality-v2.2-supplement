#!/bin/sh
# Second, independent evaluation (bc, 60 decimal digits, written separately from largemean_D.py) of the two final
# inequalities of the large-mean theorem with eps = 21/4000 (D = 21/10, mu >= 400), and of the paper's controls (eps = 1/250).
bc -l <<'BC'
scale=60
define c(e) { return (6/25)*(3/10-20*e) - (1/6)*(1+15*e)/8 - (1+30*e)/75 - 1/250; }
define o(e) { return -(1/4)*(20*e) - (1/3)*(1+15*e)/8 - (1+30*e)/75 - 1/250 + (9/1600)*75*(1/3-4*e); }
print "central eps=1/250   : ", c(1/250), "  (707/60000   = ", 707/60000, ")\n"
print "outer   eps=1/250   : ", o(1/250), "  (2031/40000  = ", 2031/40000, ")\n"
print "central eps=21/4000 : ", c(21/4000), "  (4697/960000  = ", 4697/960000, ")\n"
print "outer   eps=21/4000 : ", o(21/4000), "  (13163/320000 = ", 13163/320000, ")\n"
BC
