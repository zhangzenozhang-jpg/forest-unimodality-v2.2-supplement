#!/usr/bin/python3
"""DIAGNOSTIC: the largest cap D for which the LOWER-TAIL criterion's fine-box limit closes (th*_kappa >= theta), minimized
over a grid of each covering's rectangle (nl activities x nm means, exact grid points, LPs by HiGHS); bisection to 1e-3.
Usage: dstar_grid.py OUT.json names nl nm"""
import sys, os, json, pickle, time
from fractions import Fraction as F
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import t1_point_lp as T1
PKL = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'outputs', 'stage1', 'coverings.pkl')


def main():
    out = sys.argv[1]; names = sys.argv[2].split(','); nl = int(sys.argv[3]); nm = int(sys.argv[4])
    covs = {c['name']: c for c in pickle.load(open(PKL, 'rb'))}
    res = {}
    for name in names:
        t0 = time.time()
        c = covs[name]; b = c['band']
        lo, hi = F(b['lamLo']), F(b['lamHi']); th = float(b['theta']); ell = [F(x) for x in b['ell']]
        mlo, mhi = F(b['mmin']), F(c['cap'])
        best = None; grid = []
        for i in range(nl):
            lam = lo + (hi - lo) * F(i, nl - 1); q = float(lam / (1 + lam))
            for k in range(nm):
                mu = float(mlo + (mhi - mlo) * F(k, nm - 1))
                a, bb = 0.8, 3.0
                if T1.lp(q, mu, bb, ell, 'kappa')[0] >= th:
                    a = bb
                else:
                    while bb - a > 1e-3:
                        m_ = (a + bb) / 2
                        if T1.lp(q, mu, m_, ell, 'kappa')[0] >= th:
                            a = m_
                        else:
                            bb = m_
                grid.append([float(lam), mu, a])
                if best is None or a < best[2]:
                    best = [float(lam), mu, a]
        res[name] = dict(lam=[str(lo), str(hi)], m=[float(mlo), float(mhi)], theta=th, min_D_star=best, grid=grid,
                         seconds=round(time.time() - t0, 1))
        print('%s: min D*_kappa over %dx%d grid = %.4f at lam %.4f mu %.3f (%.0fs)' % (name, nl, nm, best[2], best[0], best[1], time.time() - t0), flush=True)
        json.dump(res, open(out, 'w'), indent=1)


if __name__ == '__main__':
    main()
