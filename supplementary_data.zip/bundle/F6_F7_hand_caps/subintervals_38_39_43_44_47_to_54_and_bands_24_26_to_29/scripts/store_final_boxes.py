#!/usr/bin/python3
"""upper_d_test, after the referee (F7): store every box of the final lower-tail coverings used at the hand caps with
the values that the assembly convention fixes (m0 = midpoint of the m-range, the cutoff N = least valid cutoff, M* = cm =
ceil(m_l)), as the Lean data do, together with q, m, the dual (eta = mu, xi = c, alpha, beta, gamma, prices z) and the
covering's band parameters.  Sources: t1_hand/cov_hand.pkl (strips S25, S27, S29, S30), t1_hand_const/cov_hand_const.pkl
(coarse L25, L27, L29, L30, U25, U27, U29, U30), band27_split/cov_band27_split.pkl (S28, L28, U28 split at lambda = 2).
Usage: store_final_boxes.py OUT.json"""
import sys, os, json, pickle
from fractions import Fraction as F
H = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'outputs', 'stage2')
S = lambda x: str(F(x))
out = []
srcs = [('t1_hand/cov_hand.pkl', lambda n: n.startswith('N52/') and not n.startswith('N52/S28')),
        ('t1_hand_const/cov_hand_const.pkl', lambda n: not n.startswith('Atlas/L28') and not n.startswith('Atlas/U28')),
        ('band27_split/cov_band27_split.pkl', lambda n: True)]
for path, keep in srcs:
    for c in pickle.load(open(os.path.join(H, path), 'rb')):
        if not keep(c['name']):
            continue
        b = c['band']
        out.append(dict(covering=c['name'], source=path, family=c['family'], lam=[S(b['lamLo']), S(b['lamHi'])], D=S(b['D']),
                        theta=S(b['theta']), rates=[S(x) for x in b['ell']], m=[S(b['mmin']), S(c['cap'])],
                        tail=[c['tail'][0], (S(c['tail'][1]) if c['tail'][1] is not None else None)],
                        slabs=[dict(lo=S(s['lo']), hi=S(s['hi']), chain=s['chain']) for s in c['slabs']],
                        boxes=[dict(file=x.get('file', ''), q=[S(x['ql']), S(x['qh'])], m=[S(x['ml']), S(x['mh'])], m0=S(x['m0']),
                                    N=int(x['N']), Mstar=int(x['cm']), eta=S(x['mu']), xi=S(x['c']), alpha=S(x['alpha']),
                                    beta=S(x['beta']), gamma=S(x['gamma']), z=[S(v) for v in x['z']]) for x in c['boxes']]))
json.dump(dict(note='final lower-tail coverings at the hand caps, after the referee (band 27 split at lambda = 2)',
               coverings=out), open(sys.argv[1], 'w'), indent=1)
print(len(out), 'coverings,', sum(len(c['boxes']) for c in out), 'entries:', ', '.join('%s %d' % (c['covering'], len(c['boxes'])) for c in out))
