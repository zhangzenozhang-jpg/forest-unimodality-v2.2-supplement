#!/usr/bin/python3
"""upper_d_test Stage 2: the MGF criterion at the hand-proved cap on the subintervals 38-54, on the rectangles
[q(lam_lo), q(lam_hi)] x [m_lo, m_hi] of a subinterval (theta44 and rates44 of the subinterval, Lean's data; D = the
hand-proved cap, sup over the subinterval, handcap.py).  Two kinds of rectangle:
  full  : [m_21(iota), m_52(band)]  (R_iota rebuilt, extended up to the floor of the band strip of order 52)
  ext   : [m_44(iota), m_52(band)]  (the existing boxes of R_iota pass at the hand cap; the extension replaces the
          lower-tail coverings of the orders 44, 45 and 48 on this subinterval)
m_52(band) = Lean's stripFloor of the band containing the subinterval (the floor of the N52 strip S_band).
build:  boxes by the producer's certify_box (copy of lane M30's constructor), adaptive splitting as in mgf_ext.py.
check:  (1) the producer's exact replay check_box/check_cover (replay_mgf.py), (2) the independent checker
        check_box/check_cover (indep_mgf_check.py, lane R1's program), both against the rectangle.
Usage: mgf_hand.py build|check|existing kind piece[,piece]      (existing: replay Lean's R_iota boxes at the hand cap)
"""
import sys, os, json, time, pickle
from fractions import Fraction as F
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE)); sys.path.insert(0, str(HERE / 'mgf_producer'))
OUT = HERE.parent / 'outputs' / 'stage2' / 'mgf_hand'
from lean_mgf_data import n44_tables, qof, mgf_strip
from handcap import hand_sup

T = n44_tables()
COVS = {c['name']: c for c in pickle.load(open(HERE.parent / 'outputs' / 'stage1' / 'coverings.pkl', 'rb'))}


def band_m52(lo, hi):
    for nm, c in COVS.items():
        if nm.startswith('N52/S') and F(c['band']['lamLo']) <= lo and hi <= F(c['band']['lamHi']):
            return F(c['band']['mmin']), nm
    raise KeyError((lo, hi))


def rect(kind, p):
    lo, hi = T['pieceLo'][p], T['pieceHi'][p]
    m52, sname = band_m52(lo, hi)
    ml = mgf_strip(p)['mlo'] if kind == 'full' else T['mmin44'][p]
    return lo, hi, ml, m52, sname


def hand_D(p):
    return hand_sup(T['pieceLo'][p], T['pieceHi'][p])


def build(kind, p):
    import atlas_mgf as A
    lo, hi, ml, mh, sname = rect(kind, p)
    pieces = json.loads((HERE / 'mgf_producer' / 'pieces_N44.json').read_text())
    piece = dict(pieces['pieces'][p])
    assert piece['piece'] == p and [F(x) for x in piece['lam']] == [lo, hi]
    assert F(piece['theta']) == T['theta44'][p]
    assert [(F(t), F(e)) for t, e in piece['tilts']] == [(F(t), e) for t, e in zip(['0', '1/20', '1/10', '1/5', '3/10'], T['rates44'][p])]
    D = hand_D(p)
    piece.update(D=str(D))
    ql, qh = qof(lo), qof(hi)
    folder = OUT / kind / ('strip_%02d' % p); folder.mkdir(parents=True, exist_ok=True)
    assert not list(folder.glob('box_*.json')), 'boxes exist; never overwrite'
    pending = [(ql, qh, ml, mh, 0)]; rows = []; tries = 0; t0 = time.time(); holes = []
    while pending:
        lo_, hi_, low, high, depth = pending.pop()
        row = A.certify_box(lo_, hi_, low, high, piece, 44); tries += 1
        if F(row['margin_lower']) > 0:
            (folder / ('box_%06d.json' % len(rows))).write_text(json.dumps(row, indent=1) + '\n'); rows.append(row)
        elif depth >= 30 or (hi_ - lo_ <= F(1, 5000) and high - low <= F(1, 32)):
            holes.append([str(lo_), str(hi_), str(low), str(high)])
        elif row['constructor']['margin_before_q_repair'] <= 0 and high - low > F(1, 64):
            mid = (low + high) / 2; pending.extend([(lo_, hi_, low, mid, depth + 1), (lo_, hi_, mid, high, depth + 1)])
        elif 4 * (hi_ - lo_) * ((low + high) / 2) ** 2 >= (high - low) or high - low <= F(1, 64):
            mid = (lo_ + hi_) / 2; pending.extend([(lo_, mid, low, high, depth + 1), (mid, hi_, low, high, depth + 1)])
        else:
            mid = (low + high) / 2; pending.extend([(lo_, hi_, low, mid, depth + 1), (lo_, hi_, mid, high, depth + 1)])
    slabs, gaps = A.build_cover(rows, ql, qh, ml, mh)
    cover = dict(claim_label='data (upper_d_test; verified by mgf_hand.py check)', kind=kind, piece=p, lam=[str(lo), str(hi)],
                 q=[str(ql), str(qh)], m=[str(ml), str(mh)], m_top_is=sname + ' floor (m_52)', D=str(D), boxes=len(rows),
                 slabs=slabs, gaps=gaps, holes=holes, full_cover=(not gaps and not holes))
    (folder / 'COVER.json').write_text(json.dumps(cover, indent=1) + '\n')
    print('%s strip %d [%s,%s] x [%.4f,%.4f] D=%s: %d boxes, %d tries, holes %d, gaps %d, min margin %s, %.1fs' % (
        kind, p, lo, hi, float(ml), float(mh), D, len(rows), tries, len(holes), len(gaps),
        ('%.2e' % min(r['margin_decimal'] for r in rows)) if rows else '-', time.time() - t0), flush=True)


def checkers(p, D):
    import replay_mgf as R
    import indep_mgf_check as I
    inp = R.strip_inputs(p, 21)
    inp['D'] = D
    I.D_OVERRIDE[p] = D
    Tl = I.lean_tables(); recs = I.lean_records()
    inp2 = I.piece_inputs(p, 21, Tl, recs)
    assert inp2['D'] == D and inp['theta'] == inp2['theta'] == T['theta44'][p]
    return R, I, inp, inp2


def check(kind, p):
    lo, hi, ml, mh, sname = rect(kind, p)
    D = hand_D(p)
    folder = OUT / kind / ('strip_%02d' % p)
    rows = [json.loads(x.read_text()) for x in sorted(folder.glob('box_*.json'))]
    cover = json.loads((folder / 'COVER.json').read_text())
    R, I, inp, inp2 = checkers(p, D)
    f1 = []; mm1 = None
    for i, r in enumerate(rows):
        res = R.check_box(R.Box(r), inp, 44, ml, mh)
        if not res[0]:
            f1.append('box %d: %s' % (i, res[3][:3]))
        else:
            mm1 = res[4] if mm1 is None else min(mm1, res[4])
    f1 += R.check_cover(cover, [R.Box(r) for r in rows], qof(lo), qof(hi), ml, mh)
    f2 = []; mm2 = None
    for i, r in enumerate(rows):
        r = dict(r); r['D'] = str(inp2['D'])
        res = I.check_box(r, inp2, 21, ml, mh, {})
        if not res['ok']:
            f2.append('box %d: %s' % (i, res['failures'][:3]))
        else:
            mm2 = F(res['margin']) if mm2 is None else min(mm2, F(res['margin']))
    f2 += I.check_cover(cover, rows, qof(lo), qof(hi), ml, mh)
    out = dict(kind=kind, piece=p, rect=dict(lam=[str(lo), str(hi)], m=[str(ml), str(mh)]), D=str(D), boxes=len(rows),
               replay=dict(result='PASS' if not f1 else 'FAIL', failures=f1[:10], min_margin=float(mm1) if mm1 else None),
               independent=dict(result='PASS' if not f2 else 'FAIL', failures=f2[:10], min_margin=float(mm2) if mm2 else None))
    (folder / 'VERIFIED_upper_d.json').write_text(json.dumps(out, indent=1) + '\n')
    print('%s strip %d [%.4f,%.4f] D=%s: %d boxes; producer replay %s (min margin %s); independent %s (min margin %s) %s' % (
        kind, p, float(ml), float(mh), D, len(rows), out['replay']['result'], out['replay']['min_margin'],
        out['independent']['result'], out['independent']['min_margin'], (f1 + f2)[:2]), flush=True)
    return out


if __name__ == '__main__':
    mode, kind = sys.argv[1], sys.argv[2]
    for p in [int(x) for x in sys.argv[3].split(',')]:
        (build if mode == 'build' else check)(kind, p)
