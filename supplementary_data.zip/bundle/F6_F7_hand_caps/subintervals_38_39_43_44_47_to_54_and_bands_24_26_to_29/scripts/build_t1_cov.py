#!/usr/bin/python3
"""Stage 2: turn the constructor's new lower-tail boxes (outputs/stage2/t1_D65/band_*/box_*.json) into coverings in the
format of the band test replay (t1box_check.py) and of the second checker (t1_indep_check.py).

Per box (as in the paper's data, Section apC:sec:t1box): q-range, m-range, the saved dual (eta = mu, xi = c, alpha
(already containing the constructor's alpha adjustment), beta, gamma, prices z^T_0, z^T_1, ...), centre m0 = (ml + mh)/2,
cutoff N = the least N >= 25/v_min with (T): psi0(N) <= -(1/(20 v N) + 1/(v N)^2) - xi^2/(4 eta) and beta - 2 gamma (N - m0) <= 0,
and M* = cm = ceil(ml).  The band: Lean's parameters of N44/Pxx (parse_data.py) with D replaced by 6/5; the strip is
[mmin44(p), piece44Cap(p)]; tail base per box lamBox = qh/(1 - qh).  The cover: q-slabs between consecutive box q-edges,
each with a greedy chain in m.  Boxes that do not meet the strip or are not used by a chain are dropped (recorded).
Usage: build_t1_cov.py OUT.pkl NEWD piece:folder [piece:folder ...]
"""
import sys, os, json, glob, pickle
from fractions import Fraction as F
from math import ceil

HERE = os.path.dirname(os.path.abspath(__file__))
PKL = os.path.join(HERE, '..', 'outputs', 'stage1', 't1', 'coverings.pkl')


def cutoff(b):
    ql, qh = b['ql'], b['qh']
    v = min(ql * (1 - ql), qh * (1 - qh))
    m0 = b['m0']
    N = ceil(F(25) / v)
    while True:
        u = v * N
        x = N - m0
        psi = b['alpha'] + b['beta'] * x - b['gamma'] * x * x
        if u >= 25 and psi <= -(1 / (20 * u) + 1 / (u * u)) - b['c'] * b['c'] / (4 * b['mu']) \
                and b['beta'] - 2 * b['gamma'] * (N - m0) <= 0:
            return N
        N += 1


def chain_for(boxes, lo, hi, mlo, mhi):
    cand = [k for k, b in enumerate(boxes) if b['ql'] <= lo and hi <= b['qh']]
    s = mlo; chain = []
    while True:
        best = None
        for k in cand:
            b = boxes[k]
            if b['ml'] <= s and (best is None or b['mh'] > boxes[best]['mh']):
                best = k
        if best is None:
            raise RuntimeError(('gap', float(lo), float(hi), float(s)))
        chain.append(best)
        if boxes[best]['mh'] >= mhi:
            return chain
        if boxes[best]['mh'] <= s:
            raise RuntimeError(('stuck', float(lo), float(hi), float(s)))
        s = boxes[best]['mh']


def main():
    out = sys.argv[1]; newD = F(sys.argv[2])
    base = {c['name']: c for c in pickle.load(open(PKL, 'rb'))}
    covs = []
    for spec in sys.argv[3:]:
        p, folder = spec.split(':', 1)
        p = int(p)
        ref = base['N44/P%02d' % p]
        band = dict(ref['band']); band['D'] = newD
        lam_lo, lam_hi = F(band['lamLo']), F(band['lamHi'])
        qlo, qhi = lam_lo / (1 + lam_lo), lam_hi / (1 + lam_hi)
        mlo, mhi = F(band['mmin']), F(ref['cap'])
        src = json.load(open(os.path.join(folder, 'SOURCE.json')))
        assert [F(x) for x in src['lambda_band']] == [lam_lo, lam_hi], (p, src['lambda_band'])
        assert F(src['m_min']) == mlo and F(src['D']) == newD and F(src['theta']) == F(band['theta']), p
        assert [F(r['ell']) for r in src['rates']] == [F(x) for x in band['ell']], ('rates differ from Lean', p)
        raw = []
        for path in sorted(glob.glob(os.path.join(folder, 'box_*.json'))):
            r = json.load(open(path))
            d = r['dual']
            b = dict(ql=F(r['q'][0]), qh=F(r['q'][1]), ml=F(r['m'][0]), mh=F(r['m'][1]),
                     mu=F(d['mu']), c=F(d['c']), alpha=F(d['alpha']), beta=F(d['beta']), gamma=F(d['gamma']),
                     z=[F(x) for x in d['z']], file=os.path.basename(path))
            b['m0'] = (b['ml'] + b['mh']) / 2
            assert qlo <= b['ql'] < b['qh'] <= qhi, (p, path)
            if b['mh'] > mlo and b['ml'] < mhi:
                raw.append(b)
        qe = sorted(set([qlo, qhi] + [b['ql'] for b in raw] + [b['qh'] for b in raw]))
        qe = [x for x in qe if qlo <= x <= qhi]
        slabs = [dict(lo=a, hi=b_, chain=chain_for(raw, a, b_, mlo, mhi)) for a, b_ in zip(qe, qe[1:])]
        used = sorted(set(k for s in slabs for k in s['chain']))
        remap = {k: i for i, k in enumerate(used)}
        boxes = []
        for k in used:
            b = raw[k]
            boxes.append(dict(ql=b['ql'], qh=b['qh'], ml=b['ml'], mh=b['mh'], m0=b['m0'], mu=b['mu'], c=b['c'], alpha=b['alpha'],
                              beta=b['beta'], gamma=b['gamma'], z=b['z'], N=cutoff(b), cm=ceil(b['ml']), file=b['file']))
        slabs = [dict(lo=s['lo'], hi=s['hi'], chain=[remap[k] for k in s['chain']]) for s in slabs]
        covs.append(dict(family='above_m44', name='N44/P%02d_D65' % p, theorem='act1_test new covering', index=p,
                         band=band, tail=('lamBox', None), cap=mhi, boxes=boxes, slabs=slabs,
                         box_names=[b['file'] for b in boxes], data_file=folder,
                         dropped=len(raw) - len(used), total_constructed=len(glob.glob(os.path.join(folder, 'box_*.json')))))
        print('N44/P%02d at D = %s: %d boxes constructed, %d meet the strip, %d used by the %d slabs; cutoffs %d..%d' % (
            p, newD, covs[-1]['total_constructed'], len(raw), len(used), len(slabs),
            min(b['N'] for b in boxes), max(b['N'] for b in boxes)), flush=True)
    pickle.dump(covs, open(out, 'wb'))


if __name__ == '__main__':
    main()
