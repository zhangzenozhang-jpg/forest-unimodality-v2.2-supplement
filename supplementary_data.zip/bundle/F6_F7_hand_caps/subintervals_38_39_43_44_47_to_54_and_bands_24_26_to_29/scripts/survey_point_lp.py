#!/usr/bin/python3
"""DIAGNOSTIC (floating point, HiGHS through scipy): the fine-box limit of the MGF criterion on the rectangles R_iota.

At a point (q, mu) the primal LP of the MGF criterion is
   theta*(q, mu; D) = min E delta^2 / (q(1-q) mu)  over probability laws w on atoms (M, j), M <= 3 mu + 35, -4 <= j <= M + 4,
   subject to  E M = mu, E delta = 0 (delta = j - qM), E (M - mu)^2 <= D mu, E s_r^M <= exp(-l_r mu) (r < 5),
               E f_L(M, j) <= 0, E f_R(M, j) <= 0  (a valley: both tilted valley inequalities).
An MGF certificate can exist at (q, mu) only if theta*(q, mu; D) >= theta(iota) (weak duality: a law feasible for the
primal with E delta^2 <= theta q(1-q) mu contradicts (Mg)).  This script maps theta* - theta over each rectangle on a grid,
at the hand cap D = 6/5 and at the certified cap, and bisects the largest D with theta* >= theta at the worst points.
Usage: survey_point_lp.py OUTJSON pieces [nlam] [mstep_den]
"""
import sys, json, math, time
from fractions import Fraction as F
import numpy as np
from scipy.special import gammaln
from scipy.optimize import linprog
from lean_mgf_data import n44_tables, mgf_strip, qof

TAUS = [0.0, 0.05, 0.1, 0.2, 0.3]


def theta_star(q, m, D, rates, Mextra=35, ret_sol=False):
    v = q * (1 - q)
    Mmax = int(3 * m + Mextra)
    Ms = np.concatenate([np.full(M + 9, M, dtype=float) for M in range(Mmax + 1)])
    Js = np.concatenate([np.arange(-4, M + 5, dtype=float) for M in range(Mmax + 1)])

    def binom(j):
        ok = (j >= 0) & (j <= Ms)
        jj = np.where(ok, j, 0)
        z = np.exp(gammaln(Ms + 1) - gammaln(jj + 1) - gammaln(Ms - jj + 1) + jj * np.log(q) + (Ms - jj) * np.log1p(-q))
        return np.where(ok, z, 0)
    b0, bm, bp = binom(Js), binom(Js - 1), binom(Js + 1)
    fL = (1 - q) * b0 - q * bm
    fR = q * b0 - (1 - q) * bp
    delta = Js - q * Ms
    sL, sR = np.abs(fL).max(), np.abs(fR).max()
    rows = [fL / sL, fR / sR, (Ms - m) ** 2]
    rhs = [0.0, 0.0, D * m]
    for t, ell in zip(TAUS, rates):
        s = 1 - q + q * t
        rows.append(s ** Ms); rhs.append(math.exp(-ell * m))
    res = linprog(delta ** 2 / (v * m), A_ub=np.array(rows), b_ub=rhs,
                  A_eq=np.array([np.ones_like(Ms), Ms, delta]), b_eq=[1.0, m, 0.0], bounds=(0, None), method='highs')
    if not res.success:
        return (float('nan'), None) if ret_sol else float('nan')
    if ret_sol:
        return float(res.fun), (Ms, Js, res.x)
    return float(res.fun)


def D_star(q, m, theta, rates, lo=0.8, hi=1.6, tol=2e-4):
    """largest D with theta*(q, m; D) >= theta (theta* is nonincreasing in D)."""
    if theta_star(q, m, lo, rates) < theta:
        return lo
    if theta_star(q, m, hi, rates) >= theta:
        return hi
    while hi - lo > tol:
        mid = (lo + hi) / 2
        if theta_star(q, m, mid, rates) >= theta:
            lo = mid
        else:
            hi = mid
    return lo


def main():
    out = sys.argv[1]
    pieces = [int(x) for x in sys.argv[2].split(",")]
    nlam = int(sys.argv[3]) if len(sys.argv) > 3 else 9
    mden = int(sys.argv[4]) if len(sys.argv) > 4 else 16
    T = n44_tables()
    res = {}
    for p in pieces:
        t0 = time.time()
        lo, hi = T["pieceLo"][p], T["pieceHi"][p]
        theta = float(T["theta44"][p]); rates = [float(x) for x in T["rates44"][p]]
        mlo = mgf_strip(p)["mlo"]; mhi = T["mmin44"][p]
        Dcert = 21 / 20 if p == 24 else 23 / 20 if p == 27 else float(T["D44"][p])
        lams = [lo + (hi - lo) * F(i, nlam - 1) for i in range(nlam)]
        ms = sorted(set([mlo, mhi] + [F(k, mden) for k in range(math.ceil(mlo * mden), math.floor(mhi * mden) + 1)]))
        grid = []
        worst65 = None; worstc = None; nfail65 = 0; nfailc = 0
        for lam in lams:
            q = float(qof(lam))
            for m in ms:
                mf = float(m)
                t65 = theta_star(q, mf, 1.2, rates)
                tc = theta_star(q, mf, Dcert, rates)
                grid.append([float(lam), mf, t65, tc])
                if not (t65 >= theta):
                    nfail65 += 1
                if not (tc >= theta):
                    nfailc += 1
                if worst65 is None or t65 - theta < worst65[0]:
                    worst65 = (t65 - theta, float(lam), mf)
                if worstc is None or tc - theta < worstc[0]:
                    worstc = (tc - theta, float(lam), mf)
        # D* at the worst points of each lambda column (the column minimum of theta* at 6/5)
        dstars = []
        for lam in lams:
            col = [g for g in grid if g[0] == float(lam)]
            g = min(col, key=lambda r: r[2])
            dstars.append(dict(lam=g[0], m=g[1], theta_star_65=g[2], D_star=D_star(float(qof(F(g[0]).limit_denominator(10**6))), g[1], theta, rates)))
        # global D* = min over the grid of D_star where theta*(6/5) < theta (sampled: the 12 lowest points)
        low = sorted(grid, key=lambda r: r[2])[:12]
        dlow = [dict(lam=g[0], m=g[1], theta_star_65=g[2], D_star=D_star(float(qof(F(g[0]).limit_denominator(10**6))), g[1], theta, rates)) for g in low]
        res[p] = dict(piece=p, lam=[str(lo), str(hi)], m=[float(mlo), float(mhi)], theta=theta, D_cert=Dcert, rates=rates,
                      points=len(grid), fail_at_65=nfail65, fail_at_cert=nfailc,
                      worst_65=dict(slack=worst65[0], lam=worst65[1], m=worst65[2]),
                      worst_cert=dict(slack=worstc[0], lam=worstc[1], m=worstc[2]),
                      column_D_star=dstars, lowest_points_D_star=dlow, D_star_min=min(d['D_star'] for d in dlow + dstars),
                      grid=grid, seconds=round(time.time() - t0, 1))
        print("piece %d [%s,%s] m [%.3f,%.3f]: %d points; fail at 6/5: %d, at D_cert %.3f: %d; worst theta*-theta at 6/5 %+.4f "
              "(lam %.4f, m %.4f); at cert %+.4f; min D* %.4f; %.0fs" % (
                  p, lo, hi, float(mlo), float(mhi), len(grid), nfail65, Dcert, nfailc, worst65[0], worst65[1], worst65[2],
                  worstc[0], res[p]['D_star_min'], time.time() - t0), flush=True)
        json.dump(res, open(out, "w"), indent=1)


if __name__ == "__main__":
    main()
