#!/usr/bin/python3
"""Read-only parser of the Lean data modules of the MGF covering of the rectangles R_iota (Lemma p2:lem:strips)
and of the N44 parameter tables, at /Users/kvallier/Desktop/Erdos993-Lean-FiberFloor (commit aa8ba75).

Reads ONLY: Analytic/MGF/Data/R21Sxx.lean (boxes, slabs, floor mlo), Analytic/N44/Data/Params.lean (pieceLo, pieceHi,
theta44, D44, mmin44, rates44).  The field order of MBox is (ql, qh, ml, mh, m0, nu=eta, c=xi, alpha, beta, gamma,
a=w_L, b=w_R, z[5], N) (structure MBox of MGF/Checker.lean, fields only).  Exact rationals (fractions.Fraction).
"""
import re
from fractions import Fraction as F

LEANROOT = "/Users/kvallier/Desktop/Erdos993-Lean-FiberFloor/Erdos993Lean/Analytic"
RT = re.compile(r"R \((-?\d+)\) (\d+)")


def mkrat(n, d):
    n, d = int(n), int(d)
    return F(0) if d == 0 else F(n, d)


def strip_comments(s):
    s = re.sub(r"/-.*?-/", "", s, flags=re.S)
    return re.sub(r"--[^\n]*", "", s)


def list_body(text, name):
    m = re.search(r"def " + re.escape(name) + r"\b[^\n]*:=", text)
    if not m:
        raise KeyError(name)
    i = text.index("[", m.end())
    depth = 0
    for k in range(i, len(text)):
        if text[k] == "[":
            depth += 1
        elif text[k] == "]":
            depth -= 1
            if depth == 0:
                return text[i:k + 1]
    raise ValueError(name)


def rats(s):
    return [mkrat(a, b) for a, b in RT.findall(s)]


def n44_tables():
    t = strip_comments(open(f"{LEANROOT}/N44/Data/Params.lean", encoding="utf-8").read())
    T = {k: rats(list_body(t, k)) for k in ("pieceLo", "pieceHi", "theta44", "D44", "mmin44")}
    rb = list_body(t, "rates44").strip()[1:-1]
    T["rates44"] = [rats(x) for x in re.findall(r"\[[^\[\]]*\]", rb)]
    for k, v in T.items():
        assert len(v) == 55, (k, len(v))
    assert all(len(r) == 5 for r in T["rates44"])
    return T


def parse_box_body(body):
    toks = re.findall(r"R \((-?\d+)\) (\d+)|(\[)|(\])|(\d+)", body)
    vals, z, N = [], [], None
    state = 0
    for a, b, lb, rb, nat in toks:
        if lb:
            state = 1
            continue
        if rb:
            state = 2
            continue
        if a or b:
            (z if state == 1 else vals).append(mkrat(a, b))
        elif nat:
            assert state == 2
            N = int(nat)
    assert len(vals) == 12 and len(z) == 5 and N is not None, (len(vals), len(z), N)
    names = ["ql", "qh", "ml", "mh", "m0", "nu", "c", "alpha", "beta", "gamma", "a", "b"]
    d = dict(zip(names, vals))
    d["z"] = z
    d["N"] = N
    return d


def mgf_strip(p):
    path = f"{LEANROOT}/MGF/Data/R21S{p:02d}.lean"
    raw = open(path, encoding="utf-8").read()
    t = strip_comments(raw)
    boxes = {}
    for m in re.finditer(r"def (boxR21S\d+_\d+) : MBox :=\s*⟨(.*?)⟩", t, flags=re.S):
        boxes[m.group(1)] = parse_box_body(m.group(2))
    lb = list_body(t, f"boxesR21S{p:02d}")
    order = [x.strip() for x in lb.strip()[1:-1].split(",") if x.strip()]
    assert len(order) == len(boxes) == len(set(order)), (p, len(order), len(boxes))
    blist = [boxes[nm] for nm in order]
    sb = list_body(t, f"slabsR21S{p:02d}")
    slabs = []
    for m in re.finditer(r"⟨\s*R \((-?\d+)\) (\d+),\s*R \((-?\d+)\) (\d+),\s*\[([\d,\s]*)\]\s*⟩", sb):
        slabs.append(dict(lo=mkrat(m.group(1), m.group(2)), hi=mkrat(m.group(3), m.group(4)),
                          chain=[int(x) for x in re.findall(r"\d+", m.group(5))]))
    assert sb.count("⟨") == len(slabs)
    m = re.search(r"def mloR21S%02d : Rat := R \((-?\d+)\) (\d+)" % p, t)
    mlo = mkrat(m.group(1), m.group(2))
    return dict(boxes=blist, names=order, slabs=slabs, mlo=mlo, path=path)


def qof(lam):
    return F(lam) / (1 + F(lam))
