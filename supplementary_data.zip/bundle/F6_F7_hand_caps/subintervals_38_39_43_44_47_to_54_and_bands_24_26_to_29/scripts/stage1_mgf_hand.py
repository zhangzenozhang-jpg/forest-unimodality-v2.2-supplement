#!/usr/bin/python3
"""Stage 1 (DIAGNOSTIC on the existing boxes; exact rational arithmetic): the margin test (Mg) of the MGF box test
(part2_body.tex, Section p2:sec:atlas) on the existing boxes of the rectangles R_iota, iota = 38..54, at the certified
cap D(iota) and at the hand-proved cap (handcap.py: per box, the sup of Dhat over the activities of its q-range).

(Mg): alpha + min_{m in {ml,mh}} beta (m - m0) - gamma (D mh + max_{m in {ml,mh}} (m - m0)^2) - eta theta vmax mh
      - sum_r z_r ehat_r > 0,   ehat_r = 1/sum_{i<=120} (l_r ml)^i / i!,  vmax = max_{[ql,qh]} q(1-q).
(S), (T), (F) and the cover do not contain D.  For every box also D_box = the largest D at which its (Mg) holds
(exact rational; the box passes iff D < D_box), and whether the box lies wholly below the rung-25 floor
m_25(iota) = 8/(2 q(lamhat_{iota+1})) (Part II from n >= 25: such a box is no longer needed).
Usage: stage1_mgf_hand.py OUTJSON [pieces]
"""
import sys, os, json, time
from fractions import Fraction as F
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lean_mgf_data import n44_tables, mgf_strip, qof
from handcap import hand_sup_q


def ehat(x, K=120):
    s = F(1); t = F(1)
    for i in range(1, K + 1):
        t = t * x / i
        s += t
    return 1 / s


def main():
    out = sys.argv[1]
    pieces = [int(x) for x in sys.argv[2].split(",")] if len(sys.argv) > 2 else list(range(38, 55))
    T = n44_tables()
    res = {}
    for p in pieces:
        t0 = time.time()
        S = mgf_strip(p)
        theta = T["theta44"][p]
        rates = T["rates44"][p]
        Dc = T["D44"][p]
        qlo, qhi = qof(T["pieceLo"][p]), qof(T["pieceHi"][p])
        mlo, mhi = S["mlo"], T["mmin44"][p]
        m25 = F(8) / (2 * qhi)
        rows = []
        for i, b in enumerate(S["boxes"]):
            ql, qh, ml, mh, m0 = b["ql"], b["qh"], b["ml"], b["mh"], b["m0"]
            vmax = F(1, 4) if ql <= F(1, 2) <= qh else max(ql * (1 - ql), qh * (1 - qh))
            U = [ehat(l * ml) for l in rates]
            base = b["alpha"] + min(b["beta"] * (ml - m0), b["beta"] * (mh - m0)) \
                - b["gamma"] * max((ml - m0) ** 2, (mh - m0) ** 2) - b["nu"] * theta * vmax * mh \
                - sum(z * u for z, u in zip(b["z"], U))
            Dh = hand_sup_q(ql, qh)
            mg_c = base - b["gamma"] * Dc * mh
            mg_h = base - b["gamma"] * Dh * mh
            Dbox = base / (b["gamma"] * mh) if b["gamma"] > 0 else None
            below25 = mh < m25
            rows.append(dict(box=i, name=S["names"][i], q=[str(ql), str(qh)], m=[str(ml), str(mh)], N=b["N"],
                             lam=[float(ql / (1 - ql)), float(qh / (1 - qh))],
                             gamma=str(b["gamma"]), D_hand=str(Dh), Mg_cert=str(mg_c), Mg_cert_dec=float(mg_c),
                             Mg_hand=str(mg_h), Mg_hand_dec=float(mg_h), D_box=str(Dbox), D_box_dec=float(Dbox),
                             pass_cert=mg_c > 0, pass_hand=mg_h > 0, below_m25=below25))
        nfail = sum(1 for r in rows if not r["pass_hand"])
        nfail25 = sum(1 for r in rows if not r["pass_hand"] and not r["below_m25"])
        least_h = min(rows, key=lambda r: F(r["Mg_hand"]))
        least_D = min(rows, key=lambda r: F(r["D_box"]))
        least_D25 = min([r for r in rows if not r["below_m25"]] or rows, key=lambda r: F(r["D_box"]))
        res[p] = dict(piece=p, lam=[str(T["pieceLo"][p]), str(T["pieceHi"][p])], q=[str(qlo), str(qhi)],
                      m=[str(mlo), str(mhi)], m_dec=[float(mlo), float(mhi)], m25=str(m25), m25_dec=float(m25),
                      theta=str(theta), D_cert=str(Dc), D_hand_set=sorted(set(r["D_hand"] for r in rows)),
                      boxes=len(rows), boxes_fail_hand=nfail, boxes_fail_hand_above_m25=nfail25,
                      boxes_fail_cert=sum(1 for r in rows if not r["pass_cert"]),
                      least_Mg_hand=dict(box=least_h["box"], value=least_h["Mg_hand_dec"]),
                      least_D_box=dict(box=least_D["box"], value=least_D["D_box"], dec=least_D["D_box_dec"]),
                      least_D_box_above_m25=dict(box=least_D25["box"], dec=least_D25["D_box_dec"]),
                      rows=rows, seconds=round(time.time() - t0, 2))
        print("R_%d lam [%s,%s] m [%.4f,%.4f] m25 %.4f D_cert %s D_hand %s: boxes %d, fail at cert %d, fail at hand %d "
              "(above m25: %d); least Mg hand %.3e (box %d); least D_box %.5f (box %d); above m25 %.5f" % (
                  p, T["pieceLo"][p], T["pieceHi"][p], float(mlo), float(mhi), float(m25), Dc,
                  ",".join(res[p]["D_hand_set"]), len(rows), res[p]["boxes_fail_cert"], nfail, nfail25,
                  least_h["Mg_hand_dec"], least_h["box"], least_D["D_box_dec"], least_D["box"], least_D25["D_box_dec"]),
              flush=True)
    json.dump(res, open(out, "w"), indent=1)


if __name__ == "__main__":
    main()
