#!/usr/bin/python3
"""Stage 1 (DIAGNOSTIC, exact): the margin test (Mg) of the MGF box test (part2_body.tex, Section p2:sec:atlas) on the
existing boxes of the rectangles R_iota, at the certified cap D(iota) and at the hand cap D = 6/5.

(Mg): alpha + min_{m in {ml,mh}} beta (m - m0) - gamma (D mh + max_{m in {ml,mh}} (m - m0)^2) - eta theta vmax mh
      - sum_r z_r ehat_r > 0,   ehat_r = 1/sum_{i<=120} (l_r ml)^i / i!,  vmax = max_{[ql,qh]} q(1-q).
(S), (T), (F) and the cover do not contain D; they are re-run in full by stage1_mgf_full.py.
For every box also D_box = the largest D at which its (Mg) holds (exact rational; the box passes iff D < D_box).
Usage: stage1_mgf_mg.py OUTJSON [pieces]
"""
import sys, json, time
from fractions import Fraction as F
from lean_mgf_data import n44_tables, mgf_strip, qof

HAND_D = F(6, 5)


def ehat(x, K=120):
    s = F(1); t = F(1)
    for i in range(1, K + 1):
        t = t * x / i
        s += t
    return 1 / s


def D_cert(p, T):
    return F(21, 20) if p == 24 else F(23, 20) if p == 27 else T["D44"][p]


def main():
    out = sys.argv[1]
    pieces = [int(x) for x in sys.argv[2].split(",")] if len(sys.argv) > 2 else [15, 16, 17, 18, 19, 24, 27]
    T = n44_tables()
    res = {}
    for p in pieces:
        t0 = time.time()
        S = mgf_strip(p)
        theta = T["theta44"][p]
        rates = T["rates44"][p]
        Dc = D_cert(p, T)
        qlo, qhi = qof(T["pieceLo"][p]), qof(T["pieceHi"][p])
        mlo, mhi = S["mlo"], T["mmin44"][p]
        rows = []
        for i, b in enumerate(S["boxes"]):
            ql, qh, ml, mh, m0 = b["ql"], b["qh"], b["ml"], b["mh"], b["m0"]
            vmax = F(1, 4) if ql <= F(1, 2) <= qh else max(ql * (1 - ql), qh * (1 - qh))
            U = [ehat(l * ml) for l in rates]
            base = b["alpha"] + min(b["beta"] * (ml - m0), b["beta"] * (mh - m0)) \
                - b["gamma"] * max((ml - m0) ** 2, (mh - m0) ** 2) - b["nu"] * theta * vmax * mh \
                - sum(z * u for z, u in zip(b["z"], U))
            mg_c = base - b["gamma"] * Dc * mh
            mg_h = base - b["gamma"] * HAND_D * mh
            Dbox = base / (b["gamma"] * mh) if b["gamma"] > 0 else None
            rows.append(dict(box=i, name=S["names"][i], q=[str(ql), str(qh)], m=[str(ml), str(mh)], N=b["N"],
                             gamma=str(b["gamma"]), alpha=float(b["alpha"]),
                             Mg_cert=str(mg_c), Mg_cert_dec=float(mg_c), Mg_hand=str(mg_h), Mg_hand_dec=float(mg_h),
                             D_box=str(Dbox), D_box_dec=float(Dbox), pass_cert=mg_c > 0, pass_hand=mg_h > 0))
        nfail = sum(1 for r in rows if not r["pass_hand"])
        least_c = min(rows, key=lambda r: F(r["Mg_cert"]))
        least_h = min(rows, key=lambda r: F(r["Mg_hand"]))
        least_D = min(rows, key=lambda r: F(r["D_box"]))
        res[p] = dict(piece=p, lam=[str(T["pieceLo"][p]), str(T["pieceHi"][p])], q=[str(qlo), str(qhi)],
                      m=[str(mlo), str(mhi)], m_dec=[float(mlo), float(mhi)], theta=str(theta), D_cert=str(Dc),
                      boxes=len(rows), slabs=len(S["slabs"]), boxes_fail_hand=nfail,
                      boxes_fail_cert=sum(1 for r in rows if not r["pass_cert"]),
                      least_Mg_cert=dict(box=least_c["box"], value=least_c["Mg_cert_dec"]),
                      least_Mg_hand=dict(box=least_h["box"], value=least_h["Mg_hand_dec"]),
                      least_D_box=dict(box=least_D["box"], value=least_D["D_box"], dec=least_D["D_box_dec"]),
                      rows=rows, seconds=round(time.time() - t0, 2))
        print("R_%d lam [%s,%s] m [%.4f,%.4f] D_cert %s: boxes %d, (Mg) fails at D=6/5: %d; least Mg cert %.3e (box %d), "
              "least Mg hand %.3e (box %d); least D_box %.5f (box %d)" % (
                  p, T["pieceLo"][p], T["pieceHi"][p], float(mlo), float(mhi), Dc, len(rows), nfail,
                  least_c["Mg_cert_dec"], least_c["box"], least_h["Mg_hand_dec"], least_h["box"],
                  least_D["D_box_dec"], least_D["box"]), flush=True)
    json.dump(res, open(out, "w"), indent=1)


if __name__ == "__main__":
    main()
