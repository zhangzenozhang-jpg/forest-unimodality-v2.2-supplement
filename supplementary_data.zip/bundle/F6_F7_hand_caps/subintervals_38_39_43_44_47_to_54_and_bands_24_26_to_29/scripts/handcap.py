#!/usr/bin/python3
"""The hand-proved variance caps (for_tong/TWIN_v1.8/p2_hand.tex, (I2); Theorem mc:thm:var):
Var M <= Dhat(lambda) mu_M with Dhat = 6/5 on [1/3,263/200], 7/5 on (263/200,3/2], 8/5 on (3/2,7/4], 9/5 on (7/4,2],
21/10 on (2,7/3].  hand_sup(lo, hi) = max of Dhat over the closed activity interval [lo, hi] (exact rationals)."""
from fractions import Fraction as F

HB = [(F(1, 3), F(263, 200), F(6, 5)), (F(263, 200), F(3, 2), F(7, 5)), (F(3, 2), F(7, 4), F(8, 5)),
      (F(7, 4), F(2), F(9, 5)), (F(2), F(7, 3), F(21, 10))]


def dhat(lam):
    lam = F(lam)
    if lam <= HB[0][1]:
        return HB[0][2]
    for a, b, d in HB[1:]:
        if a < lam <= b:
            return d
    return HB[-1][2]   # above 7/3 (never used: activities lie in (1/3, 7/3))


def hand_sup(lo, hi):
    lo, hi = F(lo), F(hi)
    assert lo <= hi
    best = dhat(lo)
    for a, b, d in HB:
        if lo <= b and hi > a:   # the piece (a, b] meets [lo, hi]
            best = max(best, d)
    return best


def hand_sup_q(ql, qh):
    """hand_sup over the activities of the q-range [ql, qh] (lambda = q/(1-q), increasing)."""
    ql, qh = F(ql), F(qh)
    return hand_sup(ql / (1 - ql), qh / (1 - qh))


if __name__ == "__main__":
    assert hand_sup(F(13, 10), F(263, 200)) == F(6, 5)
    assert hand_sup(F(13, 10), F(27, 20)) == F(7, 5)
    assert hand_sup(F(3, 2), F(3, 2)) == F(7, 5)
    assert hand_sup(F(3, 2), F(8, 5)) == F(8, 5)
    assert hand_sup(F(7, 4), F(19, 10)) == F(9, 5)
    assert hand_sup(F(19, 10), F(2)) == F(9, 5)
    assert hand_sup(F(19, 10), F(41, 20)) == F(21, 10)
    print("handcap self-test ok")
