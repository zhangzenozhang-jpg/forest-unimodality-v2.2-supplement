#!/usr/bin/python3
"""Stage 2: an exact obstruction to the MGF criterion at one point of a rectangle R_iota (PROVED once verified).

At (q, mu) = (q(lam), mu) with the caps theta, D and the Laplace constraints (1 - q + q tau_r, e^{-l_r mu}) (r < 5) of the
subinterval, a probability mixture with
    E M = mu,  E delta = 0,  E delta^2 <= theta q(1-q) mu  (delta = j - qM, j = k - K_C),
    Var M <= D mu,  E (1 - q + q tau_r)^M <= e^{-l_r mu}  (r < 5),
and a valley at k  (E f_L(M, j) <= 0 and E f_R(M, j) <= 0)
shows that the parameters are NOT valley-free (Definition p2:def:mgf2).  By Theorem p2:thm:mgf2 no MGF certificate
exists there, and by Theorem apC:thm:mgfbox no box containing (q, mu) can pass the box test with these parameters:
no covering of R_iota at these caps exists, at any resolution.

Search: floating-point LP (scipy HiGHS) with every inequality tightened by a small slack; then exact repair:
the weights are rationalized and the three equalities (mass 1, mean mu, E delta = 0) are restored exactly by a
3 x 3 rational solve on three support atoms; every condition is then verified in exact rational arithmetic, with
e^{-x} bounded below by the exact rational 1/(sum_{i<=K} x^i/i! + x^(K+1)/(K+1)! * 1/(1 - x/(K+2))).
Usage: primal_witness.py OUTJSON piece lam mu D [theta]
   (lam, mu, D exact rationals, e.g. 103/100 1421/206 6/5; theta defaults to Lean's theta44)
"""
import sys, json, math, time
from fractions import Fraction as F
from math import comb
import numpy as np
from scipy.special import gammaln
from scipy.optimize import linprog
from lean_mgf_data import n44_tables

TAUS = [F(0), F(1, 20), F(1, 10), F(1, 5), F(3, 10)]


def exp_neg_lower(x, K=80):
    """exact rational lower bound of e^{-x}, x >= 0 rational, x < K + 2"""
    x = F(x)
    assert 0 <= x < K + 2
    s = F(1); t = F(1)
    for i in range(1, K + 1):
        t = t * x / i
        s += t
    tail = t * x / (K + 1) / (1 - x / (K + 2))      # sum_{i>K} x^i/i! <= x^{K+1}/(K+1)! * sum_l (x/(K+2))^l
    return 1 / (s + tail)


def lp(qf, mf, Df, rates, eps, Mextra=35):
    v = qf * (1 - qf)
    Mmax = int(3 * mf + Mextra)
    Ms = np.concatenate([np.full(M + 9, M, dtype=float) for M in range(Mmax + 1)])
    Js = np.concatenate([np.arange(-4, M + 5, dtype=float) for M in range(Mmax + 1)])

    def binom(j):
        ok = (j >= 0) & (j <= Ms)
        jj = np.where(ok, j, 0)
        z = np.exp(gammaln(Ms + 1) - gammaln(jj + 1) - gammaln(Ms - jj + 1) + jj * np.log(qf) + (Ms - jj) * np.log1p(-qf))
        return np.where(ok, z, 0)
    b0, bm, bp = binom(Js), binom(Js - 1), binom(Js + 1)
    fL = (1 - qf) * b0 - qf * bm
    fR = qf * b0 - (1 - qf) * bp
    delta = Js - qf * Ms
    rows = [fL, fR, (Ms - mf) ** 2]
    rhs = [-eps, -eps, Df * mf - eps]
    for t, ell in zip(TAUS, rates):
        s = 1 - qf + qf * float(t)
        rows.append(s ** Ms); rhs.append(math.exp(-ell * mf) * (1 - 1e-7))
    res = linprog(delta ** 2 / (v * mf), A_ub=np.array(rows), b_ub=rhs,
                  A_eq=np.array([np.ones_like(Ms), Ms, delta]), b_eq=[1.0, mf, 0.0], bounds=(0, None), method='highs')
    assert res.success, res.message
    return float(res.fun), Ms, Js, res.x


def bq(M, j, q):
    if 0 <= j <= M:
        return comb(M, j) * q ** j * (1 - q) ** (M - j)
    return F(0)


def solve3(A, b):
    """exact 3x3 solve (Cramer)"""
    def det(m):
        return (m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1]) - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0])
                + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]))
    d = det(A)
    assert d != 0
    out = []
    for c in range(3):
        m = [row[:] for row in A]
        for r in range(3):
            m[r][c] = b[r]
        out.append(det(m) / d)
    return out


def verify(atoms, q, mu, theta, D, rates):
    """exact verification; atoms: list of (M, j, w) with w rational."""
    W = sum(w for _, _, w in atoms)
    EM = sum(w * M for M, _, w in atoms)
    Ed = sum(w * (j - q * M) for M, j, w in atoms)
    Ed2 = sum(w * (j - q * M) ** 2 for M, j, w in atoms)
    VarM = sum(w * (M - mu) ** 2 for M, _, w in atoms)
    EfL = sum(w * ((1 - q) * bq(M, j, q) - q * bq(M, j - 1, q)) for M, j, w in atoms)
    EfR = sum(w * (q * bq(M, j, q) - (1 - q) * bq(M, j + 1, q)) for M, j, w in atoms)
    lap = []
    for t, ell in zip(TAUS, rates):
        s = 1 - q + q * t
        Es = sum(w * s ** M for M, _, w in atoms)
        lo = exp_neg_lower(ell * mu)
        lap.append(dict(tau=str(t), ell=str(ell), E_s_M=float(Es), exp_lower=float(lo), slack=float(lo - Es), ok=Es <= lo))
    budget = theta * q * (1 - q) * mu
    checks = dict(nonneg=all(w >= 0 for _, _, w in atoms), mass_one=(W == 1), mean_mu=(EM == mu), mean_delta_zero=(Ed == 0),
                  delta2_le_budget=(Ed2 <= budget), varM_le_Dmu=(VarM <= D * mu), valley_left=(EfL <= 0), valley_right=(EfR <= 0),
                  laplace_all=all(x['ok'] for x in lap))
    return dict(ok=all(checks.values()), checks=checks,
                E_delta2_over_qq1mu=float(Ed2 / (q * (1 - q) * mu)), theta=float(theta),
                VarM_over_mu=float(VarM / mu), D=float(D), E_fL=float(EfL), E_fR=float(EfR), laplace=lap,
                exact=dict(E_delta2=str(Ed2), budget=str(budget), VarM=str(VarM), Dmu=str(D * mu), E_fL=str(EfL), E_fR=str(EfR)))


def main():
    out = sys.argv[1]; p = int(sys.argv[2]); lam = F(sys.argv[3]); mu = F(sys.argv[4]); D = F(sys.argv[5])
    T = n44_tables()
    theta = F(sys.argv[6]) if len(sys.argv) > 6 else T['theta44'][p]
    rates = T['rates44'][p]
    assert T['pieceLo'][p] <= lam <= T['pieceHi'][p]
    q = lam / (1 + lam)
    t0 = time.time()
    res = None
    for eps in (1e-9, 1e-8, 1e-7):
        val, Ms, Js, x = lp(float(q), float(mu), float(D), [float(r) for r in rates], eps)
        supp = [i for i in np.argsort(-x) if x[i] > 1e-13]
        den = 10 ** 18
        atoms = [[int(Ms[i]), int(Js[i]), F(round(x[i] * den), den)] for i in supp]
        atoms = [a for a in atoms if a[2] > 0]
        # restore the three equalities exactly on the three heaviest atoms with independent rows
        best = None
        for trip in [(0, 1, 2), (0, 1, 3), (0, 2, 3), (1, 2, 3), (0, 1, 4), (0, 2, 4)]:
            if max(trip) >= len(atoms):
                continue
            Arows = [[F(1)] * 3, [F(atoms[t][0]) for t in trip], [atoms[t][1] - q * atoms[t][0] for t in trip]]
            try:
                corr = solve3(Arows, [F(1) - sum(a[2] for a in atoms), mu - sum(a[2] * a[0] for a in atoms),
                                      -sum(a[2] * (a[1] - q * a[0]) for a in atoms)])
            except AssertionError:
                continue
            best = (trip, corr)
            break
        assert best is not None
        trip, corr = best
        for t, c in zip(trip, corr):
            atoms[t][2] += c
        ver = verify([(a[0], a[1], a[2]) for a in atoms], q, mu, theta, D, rates)
        res = dict(piece=p, lam=str(lam), q=str(q), mu=str(mu), mu_dec=float(mu), theta=str(theta), D=str(D),
                   rates=[str(r) for r in rates], lp_theta_star=val, lp_eps=eps, support=len(atoms),
                   k_valley='k = max j over the support (so every K_C = k - j is a nonnegative integer)',
                   atoms=[dict(M=a[0], j=a[1], w=str(a[2]), w_dec=float(a[2])) for a in atoms],
                   verification=ver, seconds=round(time.time() - t0, 2),
                   label=('PROVED (exact rational verification)' if ver['ok'] else 'NOT VERIFIED'))
        if ver['ok']:
            break
    json.dump(res, open(out, 'w'), indent=1)
    v = res['verification']
    print('piece %d lam %s mu %s (%.4f) D %s: LP theta* %.5f; witness %s with %d atoms; E delta^2/(q(1-q)mu) = %.6f vs theta %s; '
          'Var M/mu = %.6f vs D %s; E f_L = %.3e, E f_R = %.3e; Laplace min slack %.3e; checks %s' % (
              p, lam, mu, float(mu), D, res['lp_theta_star'], res['label'], res['support'], v['E_delta2_over_qq1mu'], theta,
              v['VarM_over_mu'], D, v['E_fL'], v['E_fR'], min(x['slack'] for x in v['laplace']),
              {k: bool(b) for k, b in v['checks'].items() if not b} or 'all true'), flush=True)


if __name__ == '__main__':
    main()
