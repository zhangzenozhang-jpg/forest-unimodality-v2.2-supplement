#!/usr/bin/python3
"""Parse (read-only) the Lean data modules and check statements of the 178 lower-tail coverings.

Reads ONLY data: Atlas/Params.lean, Atlas/Data/{L,U}NN.lean, N52|N48|N45|N44/Data/*.lean (data lists and the
parameter definitions in Data/Params.lean), and the one-line statements of the check theorems in */Checks/*.lean.
Writes a pickle of all coverings (exact rationals as (num, den) Python ints) and a parameter table.
"""
import re, os, sys, pickle, glob, json
from fractions import Fraction as F

LEAN = "/Users/kvallier/Desktop/Erdos993-Lean-FiberFloor/Erdos993Lean/Analytic"
OUT = sys.argv[1]

RTOK = re.compile(r"R \((-?\d+)\) (\d+)")

def mkrat(n, d):
    n = int(n); d = int(d)
    return F(0) if d == 0 else F(n, d)   # Lean mkRat n 0 = 0

def strip_comments(s):
    s = re.sub(r"/-.*?-/", "", s, flags=re.S)
    s = re.sub(r"--[^\n]*", "", s)
    return s

def list_after(text, name):
    """Return the bracketed text of `def name ... := [ ... ]` (matching brackets)."""
    m = re.search(r"def " + re.escape(name) + r"\b[^\n]*:=", text)
    if not m:
        raise KeyError(name)
    i = text.index("[", m.end())
    depth = 0
    for k in range(i, len(text)):
        if text[k] == "[":
            depth += 1
        elif text[k] == "]":
            depth -= 1
            if depth == 0:
                return text[i:k + 1]
    raise ValueError(name)

def rat_list(s):
    return [mkrat(a, b) for a, b in RTOK.findall(s)]

def nat_list(s):
    return [int(x) for x in re.findall(r"\d+", s)]

def ratlist_list(s):
    inner = s.strip()[1:-1]
    return [rat_list(x) for x in re.findall(r"\[[^\[\]]*\]", inner)]

def parse_tokens(body):
    """Tokenise the body of an anonymous-constructor ⟨...⟩: rationals, '[', ']', naturals."""
    toks = []
    pos = 0
    pat = re.compile(r"R \((-?\d+)\) (\d+)|(\[)|(\])|(\d+)")
    for m in pat.finditer(body):
        if m.group(1) is not None:
            toks.append(("R", mkrat(m.group(1), m.group(2))))
        elif m.group(3):
            toks.append(("[", None))
        elif m.group(4):
            toks.append(("]", None))
        else:
            toks.append(("N", int(m.group(5))))
    return toks

def parse_box(body):
    t = parse_tokens(body)
    vals = []
    k = 0
    for _ in range(10):
        assert t[k][0] == "R", t[k]; vals.append(t[k][1]); k += 1
    assert t[k][0] == "["; k += 1
    z = []
    while t[k][0] != "]":
        assert t[k][0] == "R"; z.append(t[k][1]); k += 1
    k += 1
    assert t[k][0] == "N" and t[k + 1][0] == "N" and k + 2 == len(t), t[k:]
    N, cm = t[k][1], t[k + 1][1]
    names = ["ql", "qh", "ml", "mh", "m0", "mu", "c", "alpha", "beta", "gamma"]
    b = dict(zip(names, vals)); b["z"] = z; b["N"] = N; b["cm"] = cm
    return b

def angle_bodies(text, start):
    """Bodies of the top-level ⟨...⟩ in text[start:] up to the closing ']' of the list starting at start."""
    pass

def parse_module(path):
    raw = open(path, encoding="utf-8").read()
    text = strip_comments(raw)
    boxes = {}
    for m in re.finditer(r"def (box\w+) : Box :=\s*⟨(.*?)⟩", text, flags=re.S):
        boxes[m.group(1)] = parse_box(m.group(2))
    lists = re.findall(r"def (boxes\w+) : List Box := \[(.*?)\]", text, flags=re.S)
    assert len(lists) == 1, path
    lname, lbody = lists[0]
    order = [x.strip() for x in lbody.split(",") if x.strip()]
    blist = [boxes[nm] for nm in order]
    assert len(set(order)) == len(order) and len(order) == len(boxes), (path, len(order), len(boxes))
    sl = re.findall(r"def (slabs\w+) : List Slab := \[(.*)\]", text, flags=re.S)
    assert len(sl) == 1
    slabs = []
    for m in re.finditer(r"⟨\s*R \((-?\d+)\) (\d+),\s*R \((-?\d+)\) (\d+),\s*\[([\d,\s]*)\]\s*⟩", sl[0][1]):
        slabs.append({"lo": mkrat(m.group(1), m.group(2)), "hi": mkrat(m.group(3), m.group(4)),
                      "chain": nat_list(m.group(5))})
    nslab_tokens = sl[0][1].count("⟨")
    assert nslab_tokens == len(slabs), (path, nslab_tokens, len(slabs))
    return {"boxes": blist, "slabs": slabs, "boxes_name": lname, "slabs_name": sl[0][0],
            "box_names": order}

# ---------- parameters ----------
P = strip_comments(open(f"{LEAN}/Atlas/Params.lean", encoding="utf-8").read())
bp = list_after(P, "bandParams")
bands = []
for m in re.finditer(r"⟨(.*?)⟩", bp, flags=re.S):
    toks = parse_tokens(m.group(1))
    vals = [v for (k, v) in toks if k == "R"]
    assert len(vals) == 10, vals
    bands.append({"D": vals[0], "theta": vals[1], "ell": vals[2:7], "lamLo": vals[7], "lamHi": vals[8], "mmin": vals[9]})
assert len(bands) == 30

def bandAt(i):
    return dict(bands[i]) if i < len(bands) else {"D": F(0), "theta": F(0), "ell": [], "lamLo": F(0), "lamHi": F(0), "mmin": F(0)}

def getD(lst, i, d):
    return lst[i] if 0 <= i < len(lst) else d

T52 = strip_comments(open(f"{LEAN}/N52/Data/Params.lean", encoding="utf-8").read())
stripFloor = rat_list(list_after(T52, "stripFloor"))
T48 = strip_comments(open(f"{LEAN}/N48/Data/Params.lean", encoding="utf-8").read())
p48 = {k: rat_list(list_after(T48, k)) for k in ["pieceLo", "pieceHi", "newEll", "newA", "mmin48"]}
p48["pieceParent"] = nat_list(list_after(T48, "pieceParent"))
p48["rates48"] = ratlist_list(list_after(T48, "rates48"))
T45 = strip_comments(open(f"{LEAN}/N45/Data/Params.lean", encoding="utf-8").read())
p45 = {k: rat_list(list_after(T45, k)) for k in ["pieceLo", "pieceHi", "theta45", "D45", "mmin45"]}
for k in ["pieceParent", "pieceUp"]:
    p45[k] = nat_list(list_after(T45, k))
p45["rates45"] = ratlist_list(list_after(T45, "rates45"))
T44 = strip_comments(open(f"{LEAN}/N44/Data/Params.lean", encoding="utf-8").read())
p44 = {k: rat_list(list_after(T44, k)) for k in ["pieceLo", "pieceHi", "theta44", "D44", "mmin44"]}
for k in ["pieceParent", "pieceUp"]:
    p44[k] = nat_list(list_after(T44, k))
p44["rates44"] = ratlist_list(list_after(T44, "rates44"))

def stripBand(i):
    b = bandAt(i); b["mmin"] = getD(stripFloor, i, F(0)); return b
def stripCap(i):
    return bandAt(i)["mmin"]
def piece48Band(p):
    b = bandAt(getD(p48["pieceParent"], p, 0))
    b["ell"] = getD(p48["rates48"], p, []); b["lamLo"] = getD(p48["pieceLo"], p, F(0))
    b["lamHi"] = getD(p48["pieceHi"], p, F(0)); b["mmin"] = getD(p48["mmin48"], p, F(0)); return b
def piece48Cap(p):
    return getD(stripFloor, getD(p48["pieceParent"], p, 0), F(0))
def piece45Band(p):
    b = bandAt(getD(p45["pieceParent"], p, 0))
    b["D"] = getD(p45["D45"], p, F(0)); b["theta"] = getD(p45["theta45"], p, F(0))
    b["ell"] = getD(p45["rates45"], p, []); b["lamLo"] = getD(p45["pieceLo"], p, F(0))
    b["lamHi"] = getD(p45["pieceHi"], p, F(0)); b["mmin"] = getD(p45["mmin45"], p, F(0)); return b
def piece45Cap(p):
    return getD(p48["mmin48"], getD(p45["pieceUp"], p, 0), F(0))
def piece44Band(p):
    b = bandAt(getD(p44["pieceParent"], p, 0))
    b["D"] = getD(p44["D44"], p, F(0)); b["theta"] = getD(p44["theta44"], p, F(0))
    b["ell"] = getD(p44["rates44"], p, []); b["lamLo"] = getD(p44["pieceLo"], p, F(0))
    b["lamHi"] = getD(p44["pieceHi"], p, F(0)); b["mmin"] = getD(p44["mmin44"], p, F(0)); return b
def piece44Cap(p):
    return getD(p45["mmin45"], getD(p44["pieceUp"], p, 0), F(0))

# ---------- check statements ----------
def stmt(path):
    t = strip_comments(open(path, encoding="utf-8").read())
    m = re.search(r"theorem (\w+)\s*:\s*(bandOK.*?)=\s*true", t, flags=re.S)
    assert m, path
    return m.group(1), " ".join(m.group(2).split())

coverings = []
fam_specs = [
    ("coarse_lower", "Atlas", "L"), ("coarse_upper", "Atlas", "U"), ("above_m52", "N52", "S"),
    ("above_m48", "N48", "P"), ("above_m45", "N45", "P"), ("above_m44", "N44", "P")]
for fam, d, pre in fam_specs:
    for path in sorted(glob.glob(f"{LEAN}/{d}/Checks/{pre}*.lean")):
        nm = os.path.basename(path)[:-5]
        thm, s = stmt(path)
        if fam == "coarse_lower":
            m = re.fullmatch(r"bandOK \(bandAt (\d+)\) \(fun _ => \(bandAt (\d+)\)\.lamHi\) (\d+) (boxes\w+) (slabs\w+)", s.strip())
            i = int(m.group(1)); assert int(m.group(2)) == i
            band = bandAt(i); tail = ("const", band["lamHi"]); cap = F(int(m.group(3)))
        elif fam == "coarse_upper":
            m = re.fullmatch(r"bandOK \{ bandAt (\d+) with mmin := (\d+) \} \(fun _ => \(bandAt (\d+)\)\.lamHi\) (\d+) (boxes\w+) (slabs\w+)", s.strip())
            i = int(m.group(1)); assert int(m.group(3)) == i
            band = bandAt(i); band["mmin"] = F(int(m.group(2))); tail = ("const", bandAt(i)["lamHi"]); cap = F(int(m.group(4)))
        else:
            fn = {"above_m52": ("stripBand", "stripCap"), "above_m48": ("piece48Band", "piece48Cap"),
                  "above_m45": ("piece45Band", "piece45Cap"), "above_m44": ("piece44Band", "piece44Cap")}[fam]
            m = re.fullmatch(r"bandOK \(" + fn[0] + r" (\d+)\) lamBox \(" + fn[1] + r" (\d+)\) (boxes\w+) (slabs\w+)", s.strip())
            assert m, (path, s)
            i = int(m.group(1)); assert int(m.group(2)) == i
            band = {"stripBand": stripBand, "piece48Band": piece48Band, "piece45Band": piece45Band, "piece44Band": piece44Band}[fn[0]](i)
            cap = {"stripCap": stripCap, "piece48Cap": piece48Cap, "piece45Cap": piece45Cap, "piece44Cap": piece44Cap}[fn[1]](i)
            tail = ("lamBox", None)
        bx, sb = m.group(m.lastindex - 1), m.group(m.lastindex)
        dpath = f"{LEAN}/{d}/Data/{nm}.lean"
        mod = parse_module(dpath)
        assert mod["boxes_name"] == bx and mod["slabs_name"] == sb, (dpath, bx, sb)
        coverings.append({"family": fam, "name": f"{d}/{nm}", "theorem": thm, "statement": s, "index": i,
                          "band": band, "tail": tail, "cap": cap, "boxes": mod["boxes"], "slabs": mod["slabs"],
                          "box_names": mod["box_names"], "data_file": dpath})

with open(OUT, "wb") as f:
    pickle.dump(coverings, f)

# parameter table
def fs(x):
    return f"{x.numerator}/{x.denominator}" if x.denominator != 1 else f"{x.numerator}"
rows = []
for c in coverings:
    b = c["band"]
    rows.append({"covering": c["name"], "family": c["family"], "statement": c["statement"],
                 "D": fs(b["D"]), "theta": fs(b["theta"]), "ell": [fs(x) for x in b["ell"]],
                 "lamLo": fs(b["lamLo"]), "lamHi": fs(b["lamHi"]), "mmin": fs(b["mmin"]), "cap": fs(c["cap"]),
                 "tail_base": ("lamHi=" + fs(c["tail"][1])) if c["tail"][0] == "const" else "lamBox(b)=qh/(1-qh) per box",
                 "boxes": len(c["boxes"]), "slabs": len(c["slabs"])})
json.dump(rows, open(OUT.replace(".pkl", "_params.json"), "w"), indent=1)
from collections import Counter
cnt = Counter(); nb = Counter()
for c in coverings:
    cnt[c["family"]] += 1; nb[c["family"]] += len(c["boxes"])
print("coverings per family:", dict(cnt), "total", sum(cnt.values()))
print("entries per family:", dict(nb), "total", sum(nb.values()))
