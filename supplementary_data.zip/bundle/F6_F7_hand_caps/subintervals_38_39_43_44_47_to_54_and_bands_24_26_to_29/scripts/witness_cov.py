#!/usr/bin/python3
"""upper_d_test Stage 2: explicit obstruction mixtures for the lower-tail criterion at the hand-proved cap, on the
coverings whose fine-box limit fails (survey_hand.py), and the largest cap that would pass there (DIAGNOSTIC).

For a covering (Lean's band parameters: theta, the five rates, the activity range, the strip [mmin, cap]) the worst
point (lam, mu) of a 3 x 4 grid (lam in {lo, mid, hi}, mu = mmin + (cap - mmin) k/3) for th*_kappa at the hand cap is
taken (exact rationals); there an LP solution of the 'kappa' problem (t1_point_lp.py) is rounded to exact rational
weights, the three equalities (mass, mean, E delta = 0) are restored exactly, and every hypothesis is verified in
exact rational arithmetic (t1_point_lp.verify, exponentials bounded below):  E M = mu, E delta = 0,
E delta^2 <= theta q(1-q) mu, Var M <= Dhat mu, P(M <= M') <= T(M') for M' <= ceil(mu) (tail base lam), E kappa <= 0.
Such a mixture excludes every lower-tail certificate at (q, mu) (sum the certificate's pointwise inequality against it,
as in the proof of the lower-tail criterion), hence every box of the band test containing (q, mu), at any resolution.
D*: bisection of the largest D with th*_kappa >= theta at that point (DIAGNOSTIC).
Usage: witness_cov.py OUTDIR name[,name...]
"""
import sys, os, json, pickle, time
from fractions import Fraction as F
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import t1_point_lp as T1
from handcap import hand_sup

PKL = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'outputs', 'stage1', 'coverings.pkl')


def witness_at(lam, mu, D, theta, ell):
    q = lam / (1 + lam)
    out = None
    for eps, tsh in ((1e-9, 1e-7), (1e-8, 1e-6), (1e-7, 1e-5), (1e-6, 1e-4)):
        val, sol = T1.lp(float(q), float(mu), float(D), ell, 'kappa', eps=eps, tshrink=tsh)
        if sol is None:
            return dict(label='LP infeasible', lp=val)
        Ms, Js, x = sol
        supp = [i for i in np.argsort(-x) if x[i] > 1e-13]
        den = 10 ** 18
        atoms = [[int(Ms[i]), int(Js[i]), F(round(x[i] * den), den)] for i in supp]
        atoms = [a for a in atoms if a[2] > 0]
        done = False
        for trip in [(0, 1, 2), (0, 1, 3), (0, 2, 3), (1, 2, 3), (0, 1, 4), (0, 2, 4), (1, 2, 4), (0, 3, 4)]:
            if max(trip) >= len(atoms):
                continue
            A = [[F(1)] * 3, [F(atoms[t][0]) for t in trip], [atoms[t][1] - q * atoms[t][0] for t in trip]]
            try:
                corr = T1.solve3(A, [F(1) - sum(a[2] for a in atoms), mu - sum(a[2] * a[0] for a in atoms),
                                     -sum(a[2] * (a[1] - q * a[0]) for a in atoms)])
            except ZeroDivisionError:
                continue
            for t, c in zip(trip, corr):
                atoms[t][2] += c
            done = True
            break
        if not done:
            continue
        ver = T1.verify([(a[0], a[1], a[2]) for a in atoms], lam, q, mu, theta, D, ell, 'kappa')
        out = dict(lam=str(lam), q=str(q), mu=str(mu), mu_dec=float(mu), theta=str(theta), D=str(D), rates=[str(x) for x in ell],
                   kernel='kappa', lp_theta_star=val, eps=eps, support=len(atoms),
                   atoms=[dict(M=a[0], j=a[1], w=str(a[2]), w_dec=float(a[2])) for a in atoms], verification=ver,
                   label='PROVED (exact rational verification)' if ver['ok'] else 'NOT VERIFIED')
        if ver['ok']:
            return out
    return out


def main():
    outdir = sys.argv[1]; os.makedirs(outdir, exist_ok=True)
    covs = {c['name']: c for c in pickle.load(open(PKL, 'rb'))}
    summary = []
    for name in sys.argv[2].split(','):
        t0 = time.time()
        c = covs[name]; b = c['band']
        lo, hi = F(b['lamLo']), F(b['lamHi']); theta = F(b['theta']); ell = [F(x) for x in b['ell']]
        mlo, mhi = F(b['mmin']), F(c['cap'])
        best = None
        for i in range(3):
            lam = lo + (hi - lo) * F(i, 2)
            D = hand_sup(max(lo, lam - F(1, 10 ** 9)), min(hi, lam + F(1, 10 ** 9)))
            for k in range(4):
                mu = mlo + (mhi - mlo) * F(k, 3)
                tk, _ = T1.lp(float(lam / (1 + lam)), float(mu), float(D), ell, 'kappa')
                if best is None or tk < best[0]:
                    best = (tk, lam, mu, D)
        tk, lam, mu, D = best
        res = dict(covering=name, theta=str(theta), worst_point=dict(lam=str(lam), mu=str(mu), D_hand=str(D), th_kappa=tk))
        if tk < float(theta):
            # the hand cap at lam itself (a box at lam = lo meets activities just above lo: take the right limit there)
            w = witness_at(lam, mu, D, theta, ell)
            res['witness'] = w
            fn = os.path.join(outdir, 'witness_%s.json' % name.replace('/', '_'))
            json.dump(dict(covering=name, family=c['family'], **w), open(fn, 'w'), indent=1)
            res['file'] = fn
        q = float(lam / (1 + lam))
        a, bb = 1.0, 2.6
        while bb - a > 1e-3:
            m_ = (a + bb) / 2
            t, _ = T1.lp(q, float(mu), m_, ell, 'kappa')
            if t >= float(theta):
                a = m_
            else:
                bb = m_
        res['D_star_kappa_at_point'] = a
        summary.append(res)
        w = res.get('witness', {})
        print('%s: worst lam %s mu %s (%.4f) D_hand %s th*_kappa %.5f vs theta %s; witness %s (support %s, E d^2 ratio %.5f, '
              'Var/mu %.5f); D* %.4f; %.0fs' % (name, lam, mu, float(mu), D, tk, theta, w.get('label', 'none needed'), w.get('support'),
                                                w.get('verification', {}).get('E_delta2_over_qq1mu', float('nan')),
                                                w.get('verification', {}).get('VarM_over_mu', float('nan')), a, time.time() - t0), flush=True)
        json.dump(summary, open(os.path.join(outdir, 'SUMMARY.json'), 'w'), indent=1)


if __name__ == '__main__':
    main()
