#!/usr/bin/python3
"""act1_test (generalized by upper_d_test to N45/N48 intervals and the hand-proved caps): second, independently written verification of the obstruction mixtures (witness JSON files).

Reads each witness (atoms (M, j, w) with exact rational weights) and re-derives every condition from scratch:
the caps and rates are re-read from Lean's N44/Data/Params.lean by this file's own parser; binomial values by
integer arithmetic (gmpy2); exponentials e^{-x} as python-flint arb balls (outward rounding, 200 bits), a condition
"E <= e^{-x}" being accepted only if E is below the LOWER end of the ball.
Kinds: 'mgf' (MGF criterion: valley + Laplace constraints (1-q+q tau_r)^M), 't1' (lower-tail criterion: E kappa <= 0 +
distribution-function bounds P(M <= M') <= T(M') for M' <= ceil(mu)).
Usage: witness_recheck.py OUT.json kind:FAM/piece:file [...]   (FAM in N44, N45, N48)
"""
import sys, json, re
from math import ceil
import gmpy2
from gmpy2 import mpq, mpz
from flint import arb, fmpq, ctx

ctx.prec = 200
PARAMS = '/Users/kvallier/Desktop/Erdos993-Lean-FiberFloor/Erdos993Lean/Analytic/N44/Data/Params.lean'
TAU = [mpq(0), mpq(1, 20), mpq(1, 10), mpq(1, 5), mpq(3, 10)]


LEAN = '/Users/kvallier/Desktop/Erdos993-Lean-FiberFloor/Erdos993Lean/Analytic'


def lean_list(name, path=PARAMS):
    txt = open(path, encoding='utf-8').read()
    i = txt.index('def %s ' % name)
    i = txt.index(':=', i) + 2
    depth = 0; start = None
    for k in range(i, len(txt)):
        ch = txt[k]
        if ch == '[':
            depth += 1
            if start is None:
                start = k
        elif ch == ']':
            depth -= 1
            if depth == 0:
                return txt[start:k + 1]
    raise ValueError(name)


def rats(s):
    return [mpq(int(a), int(b)) for a, b in re.findall(r'R \((-?\d+)\) (\d+)', s)]


def nats(s):
    return [int(x) for x in re.findall(r'\d+', s)]


def family_params(fam):
    """upper_d_test: (theta, rates, lo, hi) per piece of N44 / N45 / N48, by this file's own parser."""
    if fam == 'N44':
        P = PARAMS
        th = rats(lean_list('theta44', P)); rt = [rats(x) for x in re.findall(r'\[([^\[\]]*)\]', lean_list('rates44', P)[1:-1])]
    elif fam == 'N45':
        P = LEAN + '/N45/Data/Params.lean'
        th = rats(lean_list('theta45', P)); rt = [rats(x) for x in re.findall(r'\[([^\[\]]*)\]', lean_list('rates45', P)[1:-1])]
    else:
        P = LEAN + '/N48/Data/Params.lean'
        rt = [rats(x) for x in re.findall(r'\[([^\[\]]*)\]', lean_list('rates48', P)[1:-1])]
        par = nats(lean_list('pieceParent', P))
        bp = lean_list('bandParams', LEAN + '/Atlas/Params.lean')
        bands = [rats(x) for x in re.findall(r'⟨(.*?)⟩', bp, flags=re.S)]
        th = [bands[i][1] for i in par]        # bandParams fields: D, theta, l0..l4, lamLo, lamHi, mmin
    lo, hi = rats(lean_list('pieceLo', P)), rats(lean_list('pieceHi', P))
    return th, rt, lo, hi


# the hand-proved caps (p2_hand.tex (I2)), typed in again here: (a, b, D) for the pieces (a, b] ([1/3, 263/200] first)
HAND = [(mpq(1, 3), mpq(263, 200), mpq(6, 5)), (mpq(263, 200), mpq(3, 2), mpq(7, 5)), (mpq(3, 2), mpq(7, 4), mpq(8, 5)),
        (mpq(7, 4), mpq(2), mpq(9, 5)), (mpq(2), mpq(7, 3), mpq(21, 10))]


def hand_right(lam, hi):
    """the hand cap that a box of positive width containing lam must use: the right limit at lam (lam < hi), else at lam"""
    for a, b_, d in HAND:
        if (a < lam < b_) or (lam == a and lam < hi and a != mpq(1, 3)) or (lam == b_ and lam == hi):
            return d
        if lam == b_ and lam < hi:
            continue
    return HAND[0][2] if lam <= HAND[0][1] else None


THETA = rats(lean_list('theta44'))
RATES = [rats(x) for x in re.findall(r'\[([^\[\]]*)\]', lean_list('rates44')[1:-1])]
LO, HI = rats(lean_list('pieceLo')), rats(lean_list('pieceHi'))
assert len(THETA) == 55 and len(RATES) == 55 and all(len(r) == 5 for r in RATES)


def b(M, j, q):
    if j < 0 or j > M:
        return mpq(0)
    return gmpy2.comb(M, j) * q ** j * (1 - q) ** (M - j)


def exp_neg_ball(x):
    return (-arb(fmpq(int(x.numerator), int(x.denominator)))).exp()


def le_ball_lower(E, ball):
    """E <= lower end of the ball (E exact rational)"""
    return arb(fmpq(int(E.numerator), int(E.denominator))) < ball or arb(fmpq(int(E.numerator), int(E.denominator))) <= ball


def check(kind, p, path, fam='N44'):
    W = json.load(open(path))
    lam, mu, D = mpq(W['lam']), mpq(W['mu']), mpq(W['D'])
    q = lam / (1 + lam)
    assert mpq(W['q']) == q
    th_, rt_, lo_, hi_ = family_params(fam)
    assert lo_[p] <= lam <= hi_[p], 'activity outside the interval'
    theta = th_[p]; ell = rt_[p]
    hd = hand_right(lam, hi_[p])
    assert D == hd, ('D is not the hand cap of a box containing lam', D, hd)
    atoms = [(int(a['M']), int(a['j']), mpq(a['w'])) for a in W['atoms']]
    S1 = sum(w for _, _, w in atoms); SM = sum(w * M for M, _, w in atoms)
    Sd = sum(w * (j - q * M) for M, j, w in atoms); Sd2 = sum(w * (j - q * M) ** 2 for M, j, w in atoms)
    SV = sum(w * (M - mu) ** 2 for M, _, w in atoms)
    EL = sum(w * ((1 - q) * b(M, j, q) - q * b(M, j - 1, q)) for M, j, w in atoms)
    ER = sum(w * (q * b(M, j, q) - (1 - q) * b(M, j + 1, q)) for M, j, w in atoms)
    c = dict(weights_nonneg=all(w >= 0 for _, _, w in atoms), total_mass_1=(S1 == 1), mean_M_eq_mu=(SM == mu),
             mean_delta_0=(Sd == 0), delta2_le_theta_budget=(Sd2 <= theta * q * (1 - q) * mu), var_M_le_D_mu=(SV <= D * mu))
    extra = {}
    if kind == 'mgf':
        c['valley_left'] = EL <= 0
        c['valley_right'] = ER <= 0
        lap_ok = True; slacks = []
        for t, l in zip(TAU, ell):
            s = 1 - q + q * t
            E = sum(w * s ** M for M, _, w in atoms)
            ball = exp_neg_ball(l * mu)
            ok = arb(fmpq(int(E.numerator), int(E.denominator))) < ball
            lap_ok &= bool(ok)
            slacks.append(float(ball.mid()) - float(E))
        c['laplace_5_tilts'] = lap_ok
        extra['laplace_slacks'] = slacks
    else:
        c['E_kappa_le_0'] = EL / q + ER / (1 - q) <= 0
        ok_all = True; slacks = []
        for Mp in range(0, ceil(mu) + 1):           # M' < M_1 = ceil(mu) + 1
            Fv = sum(w for M, _, w in atoms if M <= Mp)
            Fa = arb(fmpq(int(Fv.numerator), int(Fv.denominator)))
            ok = Fv <= 1
            mids = []
            for t, l in zip(TAU, ell):
                base = (1 + lam) / (1 + lam * t)
                ball = exp_neg_ball(l * mu) * arb(fmpq(int(base.numerator), int(base.denominator))) ** Mp
                ok = ok and bool(Fa < ball)            # F(M') below the lower end of every candidate's ball
                mids.append(float(ball.mid()))
            ok_all = ok_all and ok
            slacks.append(min([1.0] + mids) - float(Fv))
        c['cdf_le_T_for_M_le_ceil_mu'] = ok_all
        extra['cdf_min_slack'] = min(slacks)
    return dict(kind=kind, piece=p, file=path, lam=str(lam), mu=str(mu), D=str(D), theta=str(theta), atoms=len(atoms),
                ratio_delta2=float(Sd2 / (q * (1 - q) * mu)), ratio_var=float(SV / mu), checks=c, ok=all(c.values()), **extra)


def main():
    out = []
    for spec in sys.argv[2:]:
        kind, fp, path = spec.split(':', 2)
        fam, p = (fp.split('/') + [None])[:2] if '/' in fp else ('N44', fp)
        r = check(kind, int(p), path, fam)
        r['family'] = fam
        out.append(r)
        print('%s piece %d (lam %s, mu %s, D %s): %s; E delta^2/(q(1-q)mu) %.6f < theta %s; Var M/mu %.6f; failed: %s' % (
            kind, r['piece'], r['lam'], r['mu'], r['D'], 'VERIFIED' if r['ok'] else 'NOT VERIFIED', r['ratio_delta2'], r['theta'],
            r['ratio_var'], [k for k, v in r['checks'].items() if not v]), flush=True)
    json.dump(out, open(sys.argv[1], 'w'), indent=1)


if __name__ == '__main__':
    main()
