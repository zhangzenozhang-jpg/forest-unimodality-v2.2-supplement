#!/usr/bin/python3
"""Stage 0 (exact): inventory of the 934,904 variance-bound cells on [13/10, 7/3] by subinterval and hand-cap piece.

Reads ONLY the Lean data strings (read-only) of the four certified coverings whose caps serve the subintervals 38-54:
  Ladder/O1/TrieR2.lean   [13/10, 7/5]  D = 13/10   71,868 cells  (D(38), D(39); N45/P29, P30)
  Reserve/Cert/Compute/Trie3.lean [13/10, 8/5] D = 7/5 107,872 cells (D(40..43); bands 22-24; N48/P22-25, N45/P31-33)
  Ladder/O1/TrieR1.lean   [8/5, 33/20]  D = 7/5    85,150 cells  (D(44); N44/P44, N45/P35)
  Reserve/UpperCert/Compute/Piece0..8.lean [8/5, 7/3] D = 8/5 670,014 cells (D(45..54); bands 25-29; ...)
Walks each preorder trie ('0','1','2' split lambda, T, r at the midpoint, lower half first; 'L' a leaf) with the
checker's own fixed-point lambda coordinates (2^64 fractional bits: root [floor(lo 2^64), ceil(hi 2^64)], midpoint
(a+b) div 2, as in Cert/Compute/Cell.lean rootCell/midI), so every cell's lambda-range [a/2^64, b/2^64] is exact.
Each cell is assigned to the subinterval piece containing its lambda-range; the hand-cap breakpoints are 263/200,
3/2, 7/4, 2 (only 263/200 lies inside a subinterval, 38). A cell whose interior contains a breakpoint is a straddler.
A cell is REMOVABLE WITH NO TEST if the hand cap <= the covering's cap at every lambda of the cell.
Usage: cell_inventory.py OUTJSON
"""
import re, sys, json, hashlib
from fractions import Fraction as F

LEAN = "/Users/kvallier/Desktop/Erdos993-Lean-FiberFloor/Erdos993Lean/Analytic"
ONE = 1 << 64


def trie_string(path, name):
    raw = open(path, encoding="utf-8").read()
    m = re.search(r"def " + name + r" : String :=\s*\"(.*?)\"", raw, flags=re.S)
    s = m.group(1).replace("\\\n", "").replace("\n", "").replace(" ", "")
    assert set(s) <= set("012L"), set(s)
    return s


def flo(x):
    x = F(x); return (x.numerator * ONE) // x.denominator


def cei(x):
    x = F(x); return -((-x.numerator * ONE) // x.denominator)


def walk(s, a0, a1):
    """Return the list of (a, b) fixed-point lambda ranges of the leaves, in preorder."""
    out = []
    stack = [(a0, a1)]   # boxes to process in preorder
    i = 0
    n = len(s)
    while stack:
        a, b = stack.pop()
        c = s[i]; i += 1
        if c == "L":
            out.append((a, b))
        elif c == "0":
            m = (a + b) // 2
            stack.append((m, b)); stack.append((a, m))
        else:   # T or r split: lambda range unchanged
            stack.append((a, b)); stack.append((a, b))
    assert i == n, (i, n)
    return out


# subintervals 38..54 (Table apA:tab:pieces) and the certified caps D(iota) (Table p2:tab:caps)
LAM = [F(13, 10), F(27, 20), F(7, 5), F(57, 40), F(29, 20), F(3, 2), F(8, 5), F(33, 20), F(17, 10), F(7, 4),
       F(9, 5), F(37, 20), F(19, 10), F(39, 20), F(2), F(41, 20), F(9, 4), F(7, 3)]
SUB = {38 + i: (LAM[i], LAM[i + 1]) for i in range(17)}
DCERT = {38: F(13, 10), 39: F(13, 10), 40: F(7, 5), 41: F(7, 5), 42: F(7, 5), 43: F(7, 5), 44: F(7, 5)}
for i in range(45, 55):
    DCERT[i] = F(8, 5)
# hand caps (p2_hand.tex (I2)): 6/5 on [1/3,263/200], 7/5 on (263/200,3/2], 8/5 on (3/2,7/4], 9/5 on (7/4,2], 21/10 on (2,7/3]
HB = [(F(1, 3), F(263, 200), F(6, 5)), (F(263, 200), F(3, 2), F(7, 5)), (F(3, 2), F(7, 4), F(8, 5)),
      (F(7, 4), F(2), F(9, 5)), (F(2), F(7, 3), F(21, 10))]


def hand_sup(lo, hi):
    """sup of the hand cap over the closed interval [lo, hi] (the left-closed first piece, right-closed others)."""
    best = None
    for a, b, d in HB:
        # piece is (a, b] except the first [a, b]
        lo_ok = (hi > a) or (a == F(1, 3) and hi >= a)
        if lo_ok and lo <= b:
            best = d if best is None or d > best else best
    return best


# pieces = subintervals, with 38 split at 263/200
PIECES = []
for i in range(38, 55):
    lo, hi = SUB[i]
    if i == 38:
        PIECES.append(("38a", lo, F(263, 200)))
        PIECES.append(("38b", F(263, 200), hi))
    else:
        PIECES.append((str(i), lo, hi))
BREAKS = sorted(set([p[1] for p in PIECES] + [p[2] for p in PIECES]))

COVS = [
    ("R2 [13/10,7/5] D=13/10", F(13, 10), [(f"{LEAN}/Ladder/O1/TrieR2.lean", "trieR2", F(13, 10), F(7, 5))], 71868),
    ("Trie3 [13/10,8/5] D=7/5", F(7, 5), [(f"{LEAN}/Reserve/Cert/Compute/Trie3.lean", "trie3", F(13, 10), F(8, 5))], 107872),
    ("R1 [8/5,33/20] D=7/5", F(7, 5), [(f"{LEAN}/Ladder/O1/TrieR1.lean", "trieR1", F(8, 5), F(33, 20))], 85150),
]


def upper_pieces():
    r0, r1 = flo(F(8, 5)), cei(F(7, 3))
    c1 = (r0 + r1) // 2
    c2 = (c1 + r1) // 2
    rng = {0: (r0, c1), 1: (r0, c1), 2: (r0, c1), 3: (c1, c2), 4: (c2, r1), 5: (c2, r1), 6: (c2, r1),
           7: (c1, r1), 8: (c1, r1)}
    return [(f"{LEAN}/Reserve/UpperCert/Compute/Piece{k}.lean", f"piece{k}", rng[k]) for k in range(9)]


def main():
    out = sys.argv[1]
    res = {"pieces": [(p[0], str(p[1]), str(p[2])) for p in PIECES], "coverings": []}
    grand = 0
    allrows = []
    specs = []
    for name, D, files, expect in COVS:
        specs.append((name, D, [(p, nm, (flo(lo), cei(hi))) for p, nm, lo, hi in files], expect))
    specs.append(("Upper [8/5,7/3] D=8/5", F(8, 5), upper_pieces(), 670014))
    for name, D, files, expect in specs:
        leaves = []
        shas = []
        for path, nm, (a0, a1) in files:
            s = trie_string(path, nm)
            shas.append((path.split("Analytic/")[1], hashlib.sha256(s.encode()).hexdigest(), len(s)))
            leaves += walk(s, a0, a1)
        assert len(leaves) == expect, (name, len(leaves), expect)
        cnt = {p[0]: 0 for p in PIECES}
        rem = {p[0]: 0 for p in PIECES}
        strad = {}
        nrem = 0
        for a, b in leaves:
            lo, hi = F(a, ONE), F(b, ONE)
            # piece containing the cell
            # fixed-point slivers: a breakpoint within EPS of a cell end is not counted as straddled (the
            # checker's root is [floor(lo 2^64), ceil(hi 2^64)] and its midpoints are rounded down, so cells
            # overhang the exact rational ends by a few units of 2^-64); removability is decided on the exact range.
            EPS = F(1, 1 << 48)
            home = [p for p in PIECES if p[1] <= lo + EPS and hi - EPS <= p[2]]
            hs = hand_sup(lo, hi)
            removable = hs <= D
            if home:
                cnt[home[0][0]] += 1
                if removable:
                    rem[home[0][0]] += 1
            else:
                inner = [str(x) for x in BREAKS if lo + EPS < x < hi - EPS]
                key = "straddles " + ",".join(inner)
                st = strad.setdefault(key, [0, 0])
                st[0] += 1
                if removable:
                    st[1] += 1
            nrem += removable
        tot = sum(cnt.values()) + sum(v[0] for v in strad.values())
        assert tot == expect
        grand += tot
        res["coverings"].append(dict(covering=name, cap=str(D), cells=tot, removable_no_test=nrem,
                                     per_piece={k: v for k, v in cnt.items() if v}, removable_per_piece={k: v for k, v in rem.items() if v},
                                     straddlers={k: v for k, v in strad.items()}, trie_sha256=shas))
        print(name, "cells", tot, "removable with no test", nrem)
        for k, v in cnt.items():
            if v:
                print("   piece %-4s cells %7d  removable %7d" % (k, v, rem[k]))
        for k, v in strad.items():
            print("   %s: %d cells (%d removable)" % (k, v[0], v[1]))
    res["grand_total"] = grand
    print("GRAND TOTAL", grand)
    json.dump(res, open(out, "w"), indent=1)


if __name__ == "__main__":
    main()
