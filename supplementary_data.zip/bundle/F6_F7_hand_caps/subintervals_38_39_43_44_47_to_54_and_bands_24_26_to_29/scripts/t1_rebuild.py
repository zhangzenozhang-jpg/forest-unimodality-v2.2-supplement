#!/usr/bin/python3
"""upper_d_test Stage 2: new lower-tail boxes at the hand-proved cap where the existing boxes fail (Mg).

build COV : for every box of the Lean covering COV that fails the band test at the hand cap (Stage 1 / tail lamBox run),
            construct new boxes over its rectangle with the R4X constructor's certify_box (copy; candidate LP + Arb pass)
            and its adaptive splitting; D = hand cap (sup over the rectangle's activities), theta and the five rates =
            Lean's band parameters of COV; tail base per box lamBox = qh/(1-qh).  Writes box_*.json under
            outputs/stage2/t1_hand/<COV>/.
assemble OUT.pkl COV[,COV]: the new covering = the Lean boxes of COV that pass at the hand cap + the new boxes; q-slabs
            between consecutive box q-edges, each with a greedy chain in m (as build_t1_cov.py); tail ('lamBox'); band D =
            the hand cap sup over the band (the checkers take the per-box hand cap with --handcap).
Usage: t1_rebuild.py build COV FAILCSV | assemble OUT.pkl FAILCSV COV[,COV...]
"""
import sys, os, json, glob, pickle, time, csv
from fractions import Fraction as F
from math import ceil

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE); sys.path.insert(0, os.path.join(HERE, 't1_producer'))
PKL = os.path.join(HERE, '..', 'outputs', 'stage1', 'coverings.pkl')
CONST = os.environ.get('UPPER_D_TAILCONST') == '1'   # keep the coarse coverings' constant tail base (separate output folder)
OUT = os.path.join(HERE, '..', 'outputs', 'stage2', 't1_hand_const' if CONST else 't1_hand')
from handcap import hand_sup_q, hand_sup
TAUS = ['0', '1/20', '1/10', '1/5', '3/10']


def failing(csvpath, cov):
    out = []
    for r in csv.DictReader(open(csvpath)):
        base = r['covering'].replace('_lamBox', '')
        if base == cov and r['ok'] != 'True':
            out.append(int(r['box_index']))
    return out


def build(cov, csvpath):
    import atlas_arb_r4x_mod as P
    covs = {c['name']: c for c in pickle.load(open(PKL, 'rb'))}
    c = covs[cov]; b = c['band']
    rates = [dict(t=t, ell=str(e)) for t, e in zip(TAUS, b['ell'])]
    if CONST and c['tail'][0] == 'const':   # keep the Lean statement's tail base (the band's top activity)
        lt = F(c['tail'][1]); P.TAIL_Q = lt / (1 + lt)
    folder = os.path.join(OUT, cov.replace('/', '_')); os.makedirs(folder, exist_ok=True)
    assert not glob.glob(os.path.join(folder, 'box_*.json')), 'boxes exist; never overwrite'
    fails = failing(csvpath, cov)
    t0 = time.time(); nbox = 0; tries = 0; info = []
    for bi in fails:
        bx = c['boxes'][bi]
        ql, qh, ml, mh = F(bx['ql']), F(bx['qh']), F(bx['ml']), F(bx['mh'])
        D = hand_sup_q(ql, qh)
        band = dict(D=str(D), theta=str(b['theta']), lambda_band=[str(ql / (1 - ql)), str(qh / (1 - qh))], m_min=str(ml),
                    rates=rates)
        pending = [(ql, qh, ml, mh, 0)]; k = 0; ok = True
        while pending:
            lo, hi, low, high, depth = pending.pop()
            row = P.certify_box(lo, hi, low, high, band); tries += 1
            if F(row['margin_lower']) > 0:
                row['parent_box'] = bi; row['covering'] = cov; row['D_hand'] = str(D)
                with open(os.path.join(folder, 'box_%03d_%04d.json' % (bi, k)), 'w') as f:
                    f.write(json.dumps(row, indent=1) + '\n')
                k += 1; nbox += 1
            elif depth >= 24:
                ok = False; print('%s box %d: subdivision budget exhausted at q [%s,%s] m [%s,%s]' % (cov, bi, lo, hi, low, high), flush=True)
                break
            elif 4 * (hi - lo) * ((low + high) / 2) ** 2 >= high - low:
                mid = (lo + hi) / 2; pending.extend([(lo, mid, low, high, depth + 1), (mid, hi, low, high, depth + 1)])
            else:
                mid = (low + high) / 2; pending.extend([(lo, hi, low, mid, depth + 1), (lo, hi, mid, high, depth + 1)])
        info.append(dict(box=bi, q=[str(ql), str(qh)], m=[str(ml), str(mh)], D=str(D), new_boxes=k, ok=ok))
        print('%s box %d q [%.6f,%.6f] m [%.3f,%.3f] D %s: %d new boxes %s (%.0fs)' % (cov, bi, float(ql), float(qh), float(ml), float(mh),
                                                                              D, k, 'OK' if ok else 'INCOMPLETE', time.time() - t0), flush=True)
    json.dump(dict(covering=cov, failing_boxes=fails, rebuilt=info, new_boxes=nbox, tries=tries, seconds=round(time.time() - t0, 1)),
              open(os.path.join(folder, 'BUILD.json'), 'w'), indent=1)
    print('%s: %d failing boxes rebuilt by %d new boxes in %d tries, %.0fs' % (cov, len(fails), nbox, tries, time.time() - t0), flush=True)


def cutoff(b):
    ql, qh = b['ql'], b['qh']
    v = min(ql * (1 - ql), qh * (1 - qh))
    m0 = b['m0']
    N = ceil(F(25) / v)
    while True:
        u = v * N; x = N - m0
        psi = b['alpha'] + b['beta'] * x - b['gamma'] * x * x
        if u >= 25 and psi <= -(1 / (20 * u) + 1 / (u * u)) - b['c'] * b['c'] / (4 * b['mu']) and b['beta'] - 2 * b['gamma'] * (N - m0) <= 0:
            return N
        N += 1


def chain_for(boxes, lo, hi, mlo, mhi):
    cand = [k for k, b in enumerate(boxes) if b['ql'] <= lo and hi <= b['qh']]
    s = mlo; chain = []
    while True:
        best = None
        for k in cand:
            b = boxes[k]
            if b['ml'] <= s and (best is None or b['mh'] > boxes[best]['mh']):
                best = k
        if best is None:
            raise RuntimeError(('gap', float(lo), float(hi), float(s)))
        chain.append(best)
        if boxes[best]['mh'] >= mhi:
            return chain
        if boxes[best]['mh'] <= s:
            raise RuntimeError(('stuck', float(lo), float(hi), float(s)))
        s = boxes[best]['mh']


def assemble(outpkl, csvpath, names):
    covs = {c['name']: c for c in pickle.load(open(PKL, 'rb'))}
    res = []
    for cov in names:
        c = covs[cov]; band = dict(c['band'])
        lo, hi = F(band['lamLo']), F(band['lamHi'])
        qlo, qhi = lo / (1 + lo), hi / (1 + hi)
        mlo, mhi = F(band['mmin']), F(c['cap'])
        fails = set(failing(csvpath, cov))
        keep = []
        for i, b in enumerate(c['boxes']):
            if i not in fails:
                bb = {k: (F(v) if k in ('ql', 'qh', 'ml', 'mh', 'm0', 'mu', 'c', 'alpha', 'beta', 'gamma') else v) for k, v in b.items()}
                bb['z'] = [F(x) for x in b['z']]; bb['file'] = 'lean:%s#%d' % (cov, i)
                keep.append(bb)
        new = []
        folder = os.path.join(OUT, cov.replace('/', '_'))
        for path in sorted(glob.glob(os.path.join(folder, 'box_*.json'))):
            r = json.load(open(path)); d = r['dual']
            b = dict(ql=F(r['q'][0]), qh=F(r['q'][1]), ml=F(r['m'][0]), mh=F(r['m'][1]), mu=F(d['mu']), c=F(d['c']),
                     alpha=F(d['alpha']), beta=F(d['beta']), gamma=F(d['gamma']), z=[F(x) for x in d['z']], file=os.path.basename(path))
            b['m0'] = (b['ml'] + b['mh']) / 2
            b['N'] = cutoff(b); b['cm'] = ceil(b['ml'])
            new.append(b)
        allb = keep + new
        qe = sorted(set([qlo, qhi] + [b['ql'] for b in allb] + [b['qh'] for b in allb]))
        qe = [x for x in qe if qlo <= x <= qhi]
        slabs = [dict(lo=a, hi=b_, chain=chain_for(allb, a, b_, mlo, mhi)) for a, b_ in zip(qe, qe[1:])]
        used = sorted(set(k for s in slabs for k in s['chain']))
        remap = {k: i for i, k in enumerate(used)}
        boxes = [allb[k] for k in used]
        slabs = [dict(lo=s['lo'], hi=s['hi'], chain=[remap[k] for k in s['chain']]) for s in slabs]
        band['D'] = hand_sup(lo, hi)
        res.append(dict(family=c['family'] + '_hand', name=cov + '_hand', theorem='upper_d_test new covering', index=c['index'],
                        band=band, tail=(c['tail'] if CONST else ('lamBox', None)), cap=mhi, boxes=boxes, slabs=slabs, box_names=[b['file'] for b in boxes],
                        data_file=folder, kept_lean=sum(1 for k in used if k < len(keep)), new=sum(1 for k in used if k >= len(keep))))
        print('%s: %d Lean boxes kept + %d new = %d boxes on %d slabs (band D for the record %s)' % (
            cov, res[-1]['kept_lean'], res[-1]['new'], len(boxes), len(slabs), band['D']), flush=True)
    pickle.dump(res, open(outpkl, 'wb'))


if __name__ == '__main__':
    if sys.argv[1] == 'build':
        build(sys.argv[2], sys.argv[3])
    else:
        assemble(sys.argv[2], sys.argv[3], sys.argv[4].split(','))
