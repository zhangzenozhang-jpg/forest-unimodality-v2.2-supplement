"""Referee R1: an INDEPENDENT exact checker for the MGF + two-sided atlas, written from the paper theorem
(LEAN/atlas_mgf/ATLAS_MGF_PROOF.md, Theorems A-C and Lemmas 1-11), NOT from replay_mgf.py.

Differences of implementation from M30's replay (deliberate, for independence):
  * binomial values by math.comb and exact Fraction powers (no Pascal rows); the kernel at q0 is computed BOTH by
    Lemma 1's factorization W(q)P(q) AND by the direct definition a f_L/q + b f_R/(1-q), and the two must agree
    (a numerical check of Lemma 1 on every evaluated atom);
  * EVERY integer atom j in [-1, M+1] of every fibre M < N is examined (no enumeration window): an atom passes by the
    exact skip test of Lemma 10 (min over the box's delta-interval of nu (delta - vtx)^2 >= lev(M)), or by the
    first-order bound, or by the second-order bound of Lemma 9;
  * Lean's Params.lean and the six records are parsed line-wise (own parser); the floor rule is re-implemented;
  * optional dense-q DIAGNOSTIC: the pointwise inequality (P) itself, with the TRUE rows s_k(q)^M, evaluated exactly
    at K rational q's of the box on every atom (a direct test of the statement the q-uniform bounds certify);
  * optional --perturb to try to break a box (alpha, beta, nu, c, z1, a, b, cutoff).
Exact rational arithmetic only (fractions.Fraction); no floats except in printed decimals.
Usage:
  python3 indep_check_mgf.py --rung 40 --strip 20 [--root ../rung_40] [--dense 7] [--perturb alpha:+1e-6]
  Output: review/indep/<root-name>/strip_XX.json and a one-line summary.
"""
from fractions import Fraction as F
from math import comb, isqrt
from pathlib import Path
import argparse, json, re, sys, time, hashlib

HERE = Path(__file__).resolve().parent            # .../atlas_mgf/review
ATLAS = HERE.parent                                # .../atlas_mgf
LEAN = Path('/Users/kvallier/Desktop/Erdos993-Lean-FiberFloor/Erdos993Lean/Analytic')   # act1_test: FiberFloor at aa8ba75 (read only)
OUTROOT = Path(__file__).resolve().parent.parent / 'outputs'     # act1_test: every output goes under certfree/act1_test/outputs
PARAMS = LEAN / 'N44' / 'Data' / 'Params.lean'
RECORD_FILES = [LEAN / 'Density' / 'Records.lean', LEAN / 'N51' / 'Records.lean', LEAN / 'N48' / 'Records.lean',
                LEAN / 'N44' / 'Records.lean']
SIX = ['rec1', 'rec11', 'rec5750', 'rec75', 'rec2325', 'rec85']
TVALS = [F(0), F(1, 20), F(1, 10), F(1, 5), F(3, 10)]


# ------------------------------------------------------------------ exact helpers
def floor_q(x):
    x = F(x)
    return x.numerator // x.denominator


def ceil_q(x):
    return -floor_q(-F(x))


def isqrt_ceil(v):
    """least integer k >= 0 with k*k >= v (v >= 0 rational)"""
    v = F(v)
    if v <= 0:
        return 0
    k = isqrt(v.numerator // v.denominator)          # floor(sqrt(floor(v))) <= sqrt(v)
    while F(k * k) < v:
        k += 1
    return k


def qof(lam):
    lam = F(lam)
    return lam / (1 + lam)


def exp_neg_upper(x, K=120):
    """U = 1/sum_{i=0}^{K} x^i/i!  >= e^{-x} for x >= 0 (Lemma 5)."""
    x = F(x)
    assert x >= 0
    s = F(1); t = F(1)
    for i in range(1, K + 1):
        t = t * x / i
        s += t
    return 1 / s


def quad(nu, c, x):
    return nu * x * x + c * x


def quad_min_on(nu, c, lo=None, hi=None):
    """min of nu x^2 + c x on [lo, hi] (None = unbounded), nu > 0: the clamp of the vertex (Lemma 3)."""
    v = -c / (2 * nu)
    if lo is not None and v < lo:
        v = lo
    if hi is not None and v > hi:
        v = hi
    return quad(nu, c, v)


def dist_to_interval(v, lo, hi):
    if v < lo:
        return lo - v
    if v > hi:
        return v - hi
    return F(0)


# ------------------------------------------------------------------ Lean tables (own line-wise parser)
def lean_block(name, text):
    """the lines of `def name : List ... :=` up to the first non-indented line"""
    lines = text.split('\n')
    for i, ln in enumerate(lines):
        if re.match(r'def %s : List ' % re.escape(name), ln):
            kind = ln.split(': List ')[1].split(':=')[0].strip()
            body = []
            for ln2 in lines[i + 1:]:
                if ln2.startswith('  '):
                    body.append(ln2)
                else:
                    break
            return kind, '\n'.join(body)
    raise KeyError(name)


def rats(s):
    return [F(int(n), int(d)) for n, d in re.findall(r'R \((-?\d+)\) (\d+)', s)]


def lean_tables():
    text = PARAMS.read_text()
    T = {}
    for name in ('pieceLo', 'pieceHi', 'theta44', 'D44', 'mmin44', 'newEll'):
        kind, body = lean_block(name, text)
        assert kind == 'Rat', (name, kind)
        T[name] = rats(body)
    for name in ('pieceParent', 'kmin44'):
        kind, body = lean_block(name, text)
        assert kind == 'Nat', (name, kind)
        T[name] = [int(x) for x in re.findall(r'\d+', body)]
    kind, body = lean_block('rates44', text)
    assert kind == '(List Rat)'
    inner = body.strip().lstrip('[').rstrip(']')
    rows = [rats(r) for r in inner.split('],')]
    T['rates44'] = rows
    for k, v in T.items():
        assert len(v) == 55, (k, len(v))
    assert all(len(r) == 5 for r in T['rates44'])
    return T


def lean_records():
    recs = {}
    for path in RECORD_FILES:
        text = path.read_text()
        for m in re.finditer(r'def (rec\w+) : Record where\n((?:  \w+ := .*\n)+)', text):
            name, body = m.group(1), m.group(2)
            fields = {}
            for ln in body.strip().split('\n'):
                k, v = ln.strip().split(' := ')
                v = v.strip()
                fields[k] = F(int(v.split('/')[0]), int(v.split('/')[1])) if '/' in v else F(int(v))
            recs[name] = dict(x=fields['x'], r=fields['r'], h=fields['h'], file=path.name)
    assert set(SIX) <= set(recs), sorted(recs)
    return {k: recs[k] for k in SIX}


def floor_rule(N, lo, hi, recs):
    """Lean's N44/Density rule with N in place of 44: k = max(ceil(N/4)+1, max over records x <= lo of the least
    integer k with k^2 >= (q(lo)/q(x)) (N r + h)^2), m = k / (2 q(hi)).  Returns (k, m, witness)."""
    k, wit = -(-N // 4) + 1, 'rank'
    for name, R in recs.items():
        if R['x'] <= lo:
            L = N * R['r'] + R['h']
            kk = isqrt_ceil(qof(lo) / qof(R['x']) * L * L)
            if kk > k:
                k, wit = kk, name
    return k, F(k) / (2 * qof(hi)), wit


# act1_test PATCH (1 Oct 2026): the cap D of a piece is Lean's D44, or the value given by --D (e.g. 6/5) on the
# pieces of --D-pieces; with --cert-D the certified rung-21 caps are used instead (21/20 on 24, 23/20 on 27), for control.
D_OVERRIDE = {}

def piece_inputs(p, rung, T, recs):
    lo, hi = T['pieceLo'][p], T['pieceHi'][p]
    k44, m44, w44 = floor_rule(44, lo, hi, recs)
    assert (k44, m44) == (T['kmin44'][p], T['mmin44'][p]), ('floor rule fails to reproduce Lean at 44', p, k44, m44)
    kN, mN, wN = floor_rule(rung, lo, hi, recs)
    Dp = T['D44'][p]
    if p in D_OVERRIDE:  # act1_test: the cap under test
        Dp = D_OVERRIDE[p]
    return dict(lam=(lo, hi), q=(qof(lo), qof(hi)), theta=T['theta44'][p], D=Dp,
                tilts=[(t, e) for t, e in zip(TVALS, T['rates44'][p])], floor_N=(kN, mN, wN), floor_44=(k44, m44, w44),
                band=T['pieceParent'][p] + 1)


# ------------------------------------------------------------------ one box (Theorem B)
def kernel_direct(a, b, q, M, j, bin_):
    """a f_L/q + b f_R/(1-q) from the definition, bin_(i) = b_M(i; q) (0 off 0..M)."""
    fL = (1 - q) * bin_(j) - q * bin_(j - 1)
    fR = q * bin_(j) - (1 - q) * bin_(j + 1)
    return a * fL / q + b * fR / (1 - q)


def check_box(box, inp, rung, strip_ml, strip_mh, opts):
    """Returns a dict with ok, failures, statistics (all exact)."""
    fails = []
    d = box['dual']
    ql, qh = F(box['q'][0]), F(box['q'][1]); ml, mh = F(box['m'][0]), F(box['m'][1]); m0 = F(box['m0'])
    nu, c, alpha, beta, gamma = (F(d[k]) for k in ('nu', 'c', 'alpha', 'beta', 'gamma'))
    a, b = F(d['a']), F(d['b']); z = [F(x) for x in d['z']]
    N = int(box['cutoff'])
    theta, D = F(box['theta']), F(box['D'])
    tilts = [(F(t), F(e)) for t, e in box['tilts']]
    # ---- perturbation (break test)
    for key, val in opts.get('perturb', []):
        val = F(val)
        if key == 'alpha': alpha += val
        elif key == 'beta': beta += val
        elif key == 'nu': nu += val
        elif key == 'c': c += val
        elif key == 'gamma': gamma += val
        elif key == 'z1': z[0] += val
        elif key == 'a': a = val
        elif key == 'b': b = val
        elif key == 'cutoff': N += int(val)
        elif key == 'theta': theta += val
        else: raise ValueError(key)
    # ---- inputs (transport from Lean's piece)
    if theta != inp['theta']: fails.append('theta %s differs from Lean theta44 %s' % (theta, inp['theta']))
    if D != inp['D']: fails.append('D %s differs from Lean D44 %s' % (D, inp['D']))
    if tilts != inp['tilts']: fails.append('tilts differ from Lean rates44: %s vs %s' % (tilts, inp['tilts']))
    if int(box['rung']) < rung: fails.append('rung field %s < %d' % (box['rung'], rung))  # LEAD RELAXATION 2026-09-29: reused rung-27 boxes carry rung 27; the m-interval test below binds each box to [floor_N, floor_44]
    if not (inp['q'][0] <= ql < qh <= inp['q'][1]): fails.append('q-interval [%s, %s] not inside the piece' % (ql, qh))
    if not (strip_ml <= ml <= mh <= strip_mh): fails.append('m-interval [%s, %s] not inside [floor_N, floor_44] = [%s, %s]' % (ml, mh, strip_ml, strip_mh))
    # ---- (S)
    if not (0 < ql < qh < 1): fails.append('(S) q order')
    if not (0 < ml <= mh): fails.append('(S) m order')
    if not (nu > 0): fails.append('(S) nu <= 0')
    if not (gamma > 0): fails.append('(S) gamma <= 0')
    if not (a >= 0 and b >= 0 and max(a, b) > 0): fails.append('(S) a, b')
    if not (len(z) == len(tilts) and all(x >= 0 for x in z)): fails.append('(S) z')
    if m0 != (ml + mh) / 2: fails.append('(S) m0 != (ml+mh)/2 (convention)')
    if not all(0 <= t < 1 and e > 0 for t, e in tilts): fails.append('(S) tilts range')
    if not (theta >= 0 and D >= 0): fails.append('(S) theta, D >= 0')
    if fails:
        return dict(ok=False, failures=fails)
    B = max(a, b)
    pi = lambda M: alpha + beta * (M - m0) - gamma * (M - m0) ** 2
    vtx = -c / (2 * nu)
    cc = c * c / (4 * nu)
    # ---- (T)
    if not (pi(N) <= -B - cc): fails.append('(T) pi(N) > -B - c^2/(4nu) at N = %d' % N)
    if not (beta - 2 * gamma * (N - m0) <= 0): fails.append('(T) pi not nonincreasing from N = %d' % N)
    # ---- (Mg)
    U = [exp_neg_upper(e * ml) for _, e in tilts]
    vmax = F(1, 4) if ql <= F(1, 2) <= qh else max(ql * (1 - ql), qh * (1 - qh))
    dmax = max((ml - m0) ** 2, (mh - m0) ** 2)
    margin = alpha + min(beta * (ml - m0), beta * (mh - m0)) - gamma * (D * mh + dmax) - nu * theta * vmax * mh \
        - sum(zk * u for zk, u in zip(z, U))
    if not margin > 0: fails.append('(Mg) margin = %s <= 0' % float(margin))
    # ---- (F)
    q0 = (ql + qh) / 2; rad = (qh - ql) / 2
    s_h = [1 - qh + qh * t for t, _ in tilts]
    n_skip = n_first = n_second = n_eval = 0
    worst = None            # (slack, M, j, kind)
    lemma1_mismatch = 0
    for M in range(0 if opts.get('skip_F') else N):
        rhs = pi(M) - sum(zk * s ** M for zk, s in zip(z, s_h))
        # (F1) half-lines
        if not (quad_min_on(nu, c, hi=-2 - ql * M) >= rhs): fails.append('(F1) left half-line M = %d' % M)
        if not (quad_min_on(nu, c, lo=M + 2 - qh * M) >= rhs): fails.append('(F1) right half-line M = %d' % M)
        lev = rhs + B + cc
        # binomial rows at ql, q0, qh (direct)
        pw = {}
        for name, q in (('l', ql), ('0', q0), ('h', qh)):
            pq = [F(1)]; p1 = [F(1)]
            for i in range(M):
                pq.append(pq[-1] * q); p1.append(p1[-1] * (1 - q))
            pw[name] = (q, pq, p1)

        def bin_at(name, i):
            q, pq, p1 = pw[name]
            if 0 <= i <= M:
                return comb(M, i) * pq[i] * p1[M - i]
            return F(0)
        for j in range(-1, M + 2):
            dlo, dhi = j - qh * M, j - ql * M        # delta-range of the atom on the box
            # exact skip (Lemma 10, pointwise): nu (delta - vtx)^2 >= lev for every q of the box
            if lev <= 0:
                n_skip += 1; continue
            dd = dist_to_interval(vtx, dlo, dhi)
            if nu * dd * dd >= lev:
                n_skip += 1; continue
            n_eval += 1
            d0 = j - q0 * M
            if j == -1:
                ker0 = -b * pw['0'][2][M]
                K1 = b * M * pw['l'][2][M - 1] if M >= 1 else F(0)
                K2 = b * M * (M - 1) * pw['l'][2][M - 2] if M >= 2 else F(0)
                kap1 = b * M * pw['0'][2][M - 1] if M >= 1 else F(0)
            elif j == M + 1:
                ker0 = -a * pw['0'][1][M]
                K1 = a * M * pw['h'][1][M - 1] if M >= 1 else F(0)
                K2 = a * M * (M - 1) * pw['h'][1][M - 2] if M >= 2 else F(0)
                kap1 = -a * M * pw['0'][1][M - 1] if M >= 1 else F(0)
            else:
                A = F(M + 1 - 2 * j, M - j + 1); Bc = F(2 * j + 1 - M, j + 1)
                Ap, Bp = a * A, b * Bc
                C = comb(M, j)

                def W(name):
                    q, pq, p1 = pw[name]
                    return C * pq[j] * p1[M - j] / (q * (1 - q))
                Wc = [W('l'), W('h')]
                if M != 2:
                    qs = F(j - 1, M - 2)
                    if ql < qs < qh:
                        Wc.append(C * qs ** j * (1 - qs) ** (M - j) / (qs * (1 - qs)))
                Wmax = max(Wc)
                P = lambda x: Ap * (1 - x) ** 2 + Bp * x ** 2
                dP = lambda x: -2 * Ap * (1 - x) + 2 * Bp * x
                Pc = [abs(P(ql)), abs(P(qh))]
                if Ap + Bp != 0:
                    qv = Ap / (Ap + Bp)
                    if ql < qv < qh: Pc.append(abs(P(qv)))
                Pmax = max(Pc)
                dPmax = max(abs(dP(ql)), abs(dP(qh)))
                Lmax = max(abs(F(j - 1) / u - F(M - j - 1) / (1 - v)) for u in (ql, qh) for v in (ql, qh))
                Lpmax = abs(F(j - 1)) / ql ** 2 + abs(F(M - j - 1)) / (1 - qh) ** 2
                K1 = Wmax * (dPmax + Lmax * Pmax)
                K2 = Wmax * (abs(2 * (Ap + Bp)) + 2 * Lmax * dPmax + (Lmax ** 2 + Lpmax) * Pmax)
                W0 = W('0'); L0 = F(j - 1) / q0 - F(M - j - 1) / (1 - q0)
                ker0 = W0 * P(q0)
                kap1 = W0 * (dP(q0) + L0 * P(q0))
                # Lemma 1 numerically: factorized kernel == direct kernel
                if ker0 != kernel_direct(a, b, q0, M, j, lambda i: bin_at('0', i)):
                    lemma1_mismatch += 1
            s1 = ker0 - rad * K1 + quad_min_on(nu, c, dlo, dhi) - rhs
            h1 = kap1 - M * (c + 2 * nu * d0)
            s2 = ker0 + quad(nu, c, d0) - rad * abs(h1) - rad * rad * (K2 + 2 * nu * M * M) / 2 - rhs
            if s1 >= 0: n_first += 1
            elif s2 >= 0: n_second += 1
            s = max(s1, s2)
            if worst is None or s < worst[0]:
                worst = (s, M, j, 'first' if s1 >= s2 else 'second')
            if s < 0:
                fails.append('(F2) atom (M=%d, j=%d): slack %.3e' % (M, j, float(s)))
                if len(fails) > 25:
                    break
        if len(fails) > 25:
            break
    if lemma1_mismatch:
        fails.append('Lemma 1 factorization mismatch on %d atoms' % lemma1_mismatch)
    out = dict(ok=not fails, failures=fails, F_checked=(not opts.get('skip_F')), margin=str(margin), margin_dec=float(margin), cutoff=N,
               atoms_total=sum(M + 3 for M in range(N)), atoms_skipped=n_skip, atoms_evaluated=n_eval,
               by_first=n_first, by_second=n_second,
               worst_atom=(dict(slack=str(worst[0]), dec=float(worst[0]), M=worst[1], j=worst[2], kind=worst[3]) if worst else None),
               U_matches_file=(all(F(u) == uu for u, uu in zip(box.get('U', []), U)) if box.get('U') else None),
               margin_matches_file=(F(box['margin_lower']) == margin if 'margin_lower' in box and not opts.get('perturb') else None))
    # ---- dense-q DIAGNOSTIC: the pointwise inequality (P) with the TRUE rows at K rational q's
    K = opts.get('dense', 0)
    if K and not fails:
        qs = [ql + (qh - ql) * F(i, K - 1) for i in range(K)]
        dmin = None
        for q in qs:
            s_q = [1 - q + q * t for t, _ in tilts]
            for M in range(N):
                rhsq = pi(M) - sum(zk * s ** M for zk, s in zip(z, s_q))
                pq = [F(1)]; p1 = [F(1)]
                for i in range(M):
                    pq.append(pq[-1] * q); p1.append(p1[-1] * (1 - q))
                bq = lambda i: comb(M, i) * pq[i] * p1[M - i] if 0 <= i <= M else F(0)
                for j in range(-1, M + 2):
                    dl = j - q * M
                    val = kernel_direct(a, b, q, M, j, bq) + c * dl + nu * dl * dl - rhsq
                    if dmin is None or val < dmin[0]:
                        dmin = (val, str(q), M, j)
        out['dense_q_min_slack'] = dict(value=str(dmin[0]), dec=float(dmin[0]), q=dmin[1], M=dmin[2], j=dmin[3], samples=K,
                                        label='DIAGNOSTIC (sampled q; the certificate is the uniform bound above)')
        if dmin[0] < 0:
            out['failures'].append('DENSE-Q: pointwise (P) violated at q = %s, atom (%d, %d)' % (dmin[1], dmin[2], dmin[3]))
            out['ok'] = False
    return out


# ------------------------------------------------------------------ the cover (Theorem C)
def check_cover(cover, boxes, q_lo, q_hi, ml, mh):
    fails = []
    if ml >= mh:
        return ['empty strip: boxes present'] if boxes else []
    if cover.get('empty_strip'):
        return ['empty_strip declared but floor_N < floor_44']
    slabs = cover.get('slabs', [])
    if not slabs:
        return ['no slabs']
    if F(slabs[0]['lo']) != q_lo: fails.append('first slab starts at %s != q(lam_lo) = %s' % (slabs[0]['lo'], q_lo))
    if F(slabs[-1]['hi']) != q_hi: fails.append('last slab ends at %s != q(lam_hi) = %s' % (slabs[-1]['hi'], q_hi))
    for s1, s2 in zip(slabs, slabs[1:]):
        if F(s1['hi']) != F(s2['lo']): fails.append('slabs not consecutive at %s' % s1['hi'])
    for sl in slabs:
        lo, hi = F(sl['lo']), F(sl['hi'])
        if not lo < hi: fails.append('degenerate slab'); continue
        top = ml
        for i in sl['chain']:
            bx = boxes[i]
            bql, bqh, bml, bmh = F(bx['q'][0]), F(bx['q'][1]), F(bx['m'][0]), F(bx['m'][1])
            if not (bql <= lo and hi <= bqh): fails.append('box %d does not contain slab [%s, %s] in q' % (i, lo, hi))
            if not (bml <= top): fails.append('m-gap in slab [%s, %s]: box %d starts at %s > %s' % (lo, hi, i, bml, top))
            top = max(top, bmh)
        if top < mh: fails.append('slab [%s, %s] reaches only m = %s < floor_44 = %s' % (lo, hi, top, mh))
    return fails


def lean_boxes(p, inp, rung):
    """act1_test: the boxes and slabs of R21Sxx from the Lean data module, in this checker's JSON shape."""
    sys.path.insert(0, str(HERE))
    from lean_mgf_data import mgf_strip
    S = mgf_strip(p)
    boxes = []
    for b in S['boxes']:
        boxes.append(dict(q=[str(b['ql']), str(b['qh'])], m=[str(b['ml']), str(b['mh'])], m0=str(b['m0']),
                          dual=dict(nu=str(b['nu']), c=str(b['c']), alpha=str(b['alpha']), beta=str(b['beta']),
                                    gamma=str(b['gamma']), a=str(b['a']), b=str(b['b']), z=[str(x) for x in b['z']]),
                          cutoff=b['N'], theta=str(inp['theta']), D=str(inp['D']),
                          tilts=[[str(t), str(e)] for t, e in inp['tilts']], rung=rung))
    q_lo, q_hi = inp['q']
    cover = dict(q=[str(q_lo), str(q_hi)], m=[str(S['mlo']), str(inp['floor_44'][1])],
                 slabs=[dict(lo=str(sl['lo']), hi=str(sl['hi']), chain=sl['chain']) for sl in S['slabs']])
    assert S['mlo'] == inp['floor_N'][1], ('Lean mlo differs from the floor rule', p, S['mlo'], inp['floor_N'])
    return boxes, cover


def check_strip(rung, p, root, opts):
    t0 = time.time()
    T = lean_tables(); recs = lean_records()
    inp = piece_inputs(p, rung, T, recs)
    folder = Path(root) / f'strip_{p:02d}'
    q_lo, q_hi = inp['q']; strip_ml, strip_mh = inp['floor_N'][1], inp['floor_44'][1]
    cover_as = opts.get('cover_as')          # cover-as-rung T: the boxes are rung S's; the rectangle is rung T's
    if cover_as:
        inpT = piece_inputs(p, cover_as, T, recs)
        cover_ml = inpT['floor_N'][1]
        assert cover_ml >= strip_ml, 'cover-as-rung needs floor_T >= floor_S'
    else:
        cover_ml = strip_ml
    if opts.get('lean_data'):
        boxes, cover = lean_boxes(p, inp, rung)
    else:
        paths = sorted(folder.glob('box_*.json'))
        boxes = [json.loads(x.read_text()) for x in paths]
        cover = json.loads((folder / 'COVER.json').read_text())
        for bx in boxes:          # act1_test: the boxes are tested at the cap under test, not the cap they record
            bx['D'] = str(inp['D'])
    fails = []
    if (F(cover['q'][0]), F(cover['q'][1])) != (q_lo, q_hi): fails.append('COVER q-rectangle differs from Lean edges')
    if (F(cover['m'][0]), F(cover['m'][1])) != (strip_ml, strip_mh): fails.append('COVER m-rectangle %s differs from my floors [%s, %s]' % (cover['m'], strip_ml, strip_mh))
    src = json.loads((folder / 'SOURCE.json').read_text()) if (not opts.get('lean_data') and (folder / 'SOURCE.json').exists()) else None
    if src is not None and 'floor_N' in src and src['floor_N'].get('k') is None:
        src = None
    if src and (F(src['floor_N']['m']) != strip_ml or F(src['floor_44']['m']) != strip_mh or src['floor_N']['k'] != inp['floor_N'][0]):
        fails.append('SOURCE floors differ from my floor rule')
    per_box = []; min_margin = None; min_slack = None
    only = opts.get('only_boxes')
    for i, bx in enumerate(boxes):
        if only is not None and i not in only:
            continue
        r = check_box(bx, inp, rung, strip_ml, strip_mh, opts)
        per_box.append(dict(box=i, **r))
        if not r['ok']:
            fails.append('box %d: %s' % (i, '; '.join(r['failures'][:4])))
        else:
            if min_margin is None or F(r['margin']) < F(min_margin[0]): min_margin = (r['margin'], i)
            if r['worst_atom'] and (min_slack is None or F(r['worst_atom']['slack']) < F(min_slack[0])):
                min_slack = (r['worst_atom']['slack'], i, r['worst_atom']['M'], r['worst_atom']['j'])
    if only is None:
        fails += check_cover(cover, boxes, q_lo, q_hi, cover_ml, strip_mh)
        if cover_ml < strip_mh and not boxes: fails.append('no boxes on a non-empty strip')
    res = dict(referee='R1 independent checker', referee_verdict=None, rung=rung, strip=p, root=str(root),
               result='PASS' if not fails else 'FAIL', lam=[str(x) for x in inp['lam']], q=[str(q_lo), str(q_hi)],
               m=[str(strip_ml), str(strip_mh)], floor_N=dict(k=inp['floor_N'][0], m=str(strip_ml), witness=inp['floor_N'][2]),
               floor_44=dict(k=inp['floor_44'][0], m=str(strip_mh), witness=inp['floor_44'][2]),
               theta=str(inp['theta']), D=str(inp['D']), tilts=[[str(t), str(e)] for t, e in inp['tilts']],
               boxes=len(boxes), empty_strip=(strip_ml >= strip_mh),
               min_margin=(dict(value=min_margin[0], dec=float(F(min_margin[0])), box=min_margin[1]) if min_margin else None),
               min_slack=(dict(value=min_slack[0], dec=float(F(min_slack[0])), box=min_slack[1], M=min_slack[2], j=min_slack[3]) if min_slack else None),
               perturb=[[k, str(v)] for k, v in opts.get('perturb', [])], dense=opts.get('dense', 0),
               failures=fails, per_box=per_box, seconds=round(time.time() - t0, 1),
               params_sha256=hashlib.sha256(PARAMS.read_bytes()).hexdigest(),
               checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    outdir = OUTROOT / opts.get('outsub', 'indep') / (('lean_R21') if opts.get('lean_data') else Path(root).name)
    outdir.mkdir(parents=True, exist_ok=True)
    tag = ('_perturb_' + '_'.join(k + str(v).replace('/', 'o') for k, v in opts.get('perturb', []))) if opts.get('perturb') else ''
    tag += '_light' if opts.get('skip_F') else ''
    tag += ('_cover_as_%d' % cover_as) if cover_as else ''
    res['mode'] = 'light (no atom checks)' if opts.get('skip_F') else 'full'
    if cover_as:
        res['cover_as_rung'] = dict(T=cover_as, m_rect=[str(cover_ml), str(strip_mh)], empty=(cover_ml >= strip_mh))
    (outdir / f'strip_{p:02d}{tag}.json').write_text(json.dumps(res, indent=1) + '\n')
    print('INDEP rung %d strip %2d %s boxes %d min margin %s min slack %s %s %.1fs %s' % (
        rung, p, res['result'], len(boxes), ('%.3e' % res['min_margin']['dec']) if res['min_margin'] else '-',
        ('%.3e (box %d, M %d, j %d)' % (res['min_slack']['dec'], res['min_slack']['box'], res['min_slack']['M'], res['min_slack']['j'])) if res['min_slack'] else '-',
        ('dense-q min %.3e' % min(pb['dense_q_min_slack']['dec'] for pb in per_box if 'dense_q_min_slack' in pb)) if any('dense_q_min_slack' in pb for pb in per_box) else '',
        res['seconds'], ('; '.join(fails[:3]) if fails else '')), flush=True)
    return not fails


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--rung', type=int, required=True)
    ap.add_argument('--strip', required=True, help='index, comma list, or lo-hi')
    ap.add_argument('--root', help='folder holding strip_XX/ (default ../rung_<N>)')
    ap.add_argument('--dense', type=int, default=0, help='K rational q-samples for the DIAGNOSTIC pointwise test')
    ap.add_argument('--perturb', action='append', default=[], help='key:value, e.g. alpha:1/1000000 (added), a:0 (set)')
    ap.add_argument('--boxes', help='comma list of box indices to check (skips the cover)')
    ap.add_argument('--skip-F', action='store_true', help='light mode: inputs, (S), (T), (Mg), cover only (no atoms)')
    ap.add_argument('--cover-as', type=int, default=0, help='check the cover against rung T\'s rectangle [floor_T, floor_44]')
    ap.add_argument('--D', default='6/5', help='act1_test: the cap D under test')
    ap.add_argument('--D-pieces', default='', help='act1_test: comma list of pieces that take --D')
    ap.add_argument('--cert-D', action='store_true', help='act1_test: control run at the certified rung-21 caps')
    ap.add_argument('--lean-data', action='store_true', help='act1_test: read the boxes and slabs from the Lean data modules R21Sxx')
    ap.add_argument('--outsub', default='indep', help='act1_test: subfolder of outputs/')
    args = ap.parse_args()
    strips = list(range(*map(int, args.strip.split('-')))) + [int(args.strip.split('-')[1])] if '-' in args.strip else [int(x) for x in args.strip.split(',')]
    root = Path(args.root) if args.root else ATLAS / f'rung_{args.rung}'
    for pp in (args.D_pieces.split(',') if args.D_pieces else []):
        D_OVERRIDE[int(pp)] = F(args.D)
    if args.cert_D:
        D_OVERRIDE.update({24: F(21, 20), 27: F(23, 20)})
    opts = dict(dense=args.dense, perturb=[(kv.split(':')[0], F(kv.split(':')[1])) for kv in args.perturb],
                only_boxes=([int(x) for x in args.boxes.split(',')] if args.boxes else None), skip_F=args.skip_F,
                cover_as=args.cover_as, lean_data=args.lean_data, outsub=args.outsub)
    ok = True
    for p in strips:
        ok &= check_strip(args.rung, p, root, opts)
    sys.exit(0 if ok else 1)


if __name__ == '__main__':
    main()
