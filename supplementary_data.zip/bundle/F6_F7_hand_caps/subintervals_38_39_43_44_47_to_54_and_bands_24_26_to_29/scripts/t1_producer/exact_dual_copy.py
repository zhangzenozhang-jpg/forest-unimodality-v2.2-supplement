"""Independent rational no-valley dual verifier; scipy ONLY searches candidates.

The verifier uses Python's arbitrary-precision integer/Fraction arithmetic.
All input/output is local to this file's directory. No author code is executed.
"""
from fractions import Fraction as F
from math import comb, ceil, floor, gcd, exp
from pathlib import Path
import json, time, hashlib, sys

HERE = Path(__file__).resolve().parent

def frac(x):
    return x if isinstance(x,F) else F(str(x))

def rationalize(x, den=10**12):
    return F(round(float(x)*den),den)

def exp_negative_upper(x, terms=120):
    """For x>=0, 1/sum_{i=0}^terms x^i/i! >= exp(-x)."""
    assert x >= 0
    s = term = F(1)
    for i in range(1,terms+1):
        term *= x/i
        s += term
    return 1/s

def candidate(q,m,D,Dt,tail_values=None):
    import numpy as np
    from scipy.special import gammaln
    from scipy.optimize import linprog
    q,m,D,Dt=map(float,(q,m,D,Dt))
    v=q*(1-q)
    Mmax=int(3*m+35)
    Ms=np.concatenate([np.full(M+9,M,dtype=float) for M in range(Mmax+1)])
    Js=np.concatenate([np.arange(-4,M+5,dtype=float) for M in range(Mmax+1)])
    def binom(j):
        ok=(j>=0)&(j<=Ms)
        jj=np.where(ok,j,0)
        z=np.exp(gammaln(Ms+1)-gammaln(jj+1)-gammaln(Ms-jj+1)+jj*np.log(q)+(Ms-jj)*np.log1p(-q))
        return np.where(ok,z,0)
    K=((1-q)/q+q/(1-q))*binom(Js)-binom(Js-1)-binom(Js+1)
    scale=np.abs(K).max()
    delta=Js-q*Ms
    cuts=list(range(ceil(m)))
    Aub=[K/scale,(Ms-m)**2]+[(Ms<=r).astype(float) for r in cuts]
    bub=[0,D*m]+([float(x) for x in tail_values] if tail_values is not None else [exp(-(m-r)**2/(2*Dt*m)) for r in cuts])
    res=linprog(delta**2/(v*m),A_ub=np.array(Aub),b_ub=bub,
       A_eq=np.array([np.ones_like(Ms),Ms,delta]),b_eq=[1,m,0],
       bounds=(0,None),method='highs')
    assert res.success, res.message
    w=-res.ineqlin.marginals[0]/scale
    assert w>0
    return dict(mu=rationalize(1/(w*v*m)),c=rationalize(-res.eqlin.marginals[2]/w),
       alpha=rationalize((res.eqlin.marginals[0]+res.eqlin.marginals[1]*m)/w)-F(1,10**8),
       beta=rationalize(res.eqlin.marginals[1]/w),gamma=max(F(0),rationalize(-res.ineqlin.marginals[1]/w)),
       z=[max(F(0),rationalize(-z/w)) for z in res.ineqlin.marginals[2:]],
       numerical_optimum=float(res.fun))

def pi(M,m,cert):
    x=M-m
    return cert['alpha']+cert['beta']*x-cert['gamma']*x*x

def tail_cutoff(m,cert,q=None):
    mu,c,g=cert['mu'],cert['c'],cert['gamma']
    assert mu>0 and g>0
    lower=-1-c*c/(4*mu)
    N=max(ceil(m)+1,len(cert['z']))
    def bound(N):
        # Optional sharper tail from LARGE_MEAN_PROOF, Fourier estimate (F):
        # kappa>=fC>=-1/(v*M)^(3/2)>=-1/(4*v*M), when v*M>=16.
        v=q*(1-q) if q is not None else None
        return -F(1,4)/(v*N)-c*c/(4*mu) if v is not None and v*N>=16 else lower
    while pi(N,m,cert)>bound(N) or cert['beta']-2*g*(N-m)>0:
        N*=2
    return N,bound(N)

def lcm(a,b):
    return a//gcd(a,b)*b

def exact_min_slack(q,m,cert,N):
    """Check every j for 0<=M<N, all remaining M by tail_cutoff.

    j in [-1,M+1] includes every nonzero kernel. Outside it the kernel
    is zero and the minimum of mu*delta^2+c*delta is at a boundary or
    one of the two integers next to its real vertex.
    """
    mu,c=cert['mu'],cert['c']
    p,r=q.numerator,q.denominator
    A=(r-p)**2+p*p
    worst=F(0); witness=None; checks=0
    # lcm for polynomial in d=r*j-p*M, separately from kappa denominator.
    q2=mu/(r*r); q1=c/r
    for M in range(N):
        rhs=pi(M,m,cert)-sum(cert['z'][M:],F(0))
        cd=lcm(lcm(q2.denominator,q1.denominator),rhs.denominator)
        a2=q2.numerator*(cd//q2.denominator)
        a1=q1.numerator*(cd//q1.denominator)
        a0=-rhs.numerator*(cd//rhs.denominator)
        nums=[comb(M,j)*p**j*(r-p)**(M-j) for j in range(M+1)]
        kd=p*(r-p)*r**M
        nn=lambda j: nums[j] if 0<=j<=M else 0
        vertex=q*M-c/(2*mu)
        js=set(range(-1,M+2))
        for j in [floor(vertex),ceil(vertex),-2,M+2]:
            if j<=-2 or j>=M+2:js.add(j)
        for j in js:
            d=r*j-p*M
            kn=A*nn(j)-p*(r-p)*(nn(j-1)+nn(j+1))
            numerator=kn*cd+(a2*d*d+a1*d+a0)*kd
            checks+=1
            if numerator<0:
                slack=F(numerator,kd*cd)
                if slack<worst:worst,witness=slack,[M,j]
    return worst,witness,checks

def certify(q,m,D,Dt,target,tag,tail_values=None):
    q,m,D,Dt,target=map(frac,(q,m,D,Dt,target))
    cert=candidate(q,m,D,Dt,tail_values)
    N,lower=tail_cutoff(m,cert,q)
    negative,witness,checks=exact_min_slack(q,m,cert,N)
    if negative<0:
        cert['alpha']+=negative-F(1,10**10)
        # This only lowers every right-hand side, including the infinite tail.
    T=tail_values if tail_values is not None else [exp_negative_upper((m-r)**2/(2*Dt*m)) for r in range(len(cert['z']))]
    numerator=cert['alpha']-cert['gamma']*D*m-sum((z*t for z,t in zip(cert['z'],T)),F(0))
    threshold=numerator/(cert['mu']*q*(1-q)*m)
    assert threshold>target,(tag,float(threshold),float(target))
    result=dict(tag=tag,claim_label='CERTIFIED',referee_verdict=None,q=str(q),m=str(m),
        D=str(D),Dt=str(Dt),target=str(target),dual={k:([str(x) for x in v] if isinstance(v,list) else str(v)) for k,v in cert.items()},
        tail_cutoff=N,tail_lower=str(lower),integer_states_checked=checks,
        pre_adjustment_negative_slack=str(negative),negative_witness=witness,
        threshold_lower=str(threshold),threshold_decimal=float(threshold),
        strict_margin=float(threshold-target))
    if tail_values is not None:result['tail_values']=[str(x) for x in tail_values]
    return result

def verify_saved(row):
    q,m,D,Dt,target=map(F,(row['q'],row['m'],row['D'],row['Dt'],row['target']))
    cert={k:([F(x) for x in v] if isinstance(v,list) else F(v)) for k,v in row['dual'].items() if k!='numerical_optimum'}
    assert 0<q<1 and m>0 and D>=0 and Dt>0
    assert cert['mu']>0 and cert['gamma']>0 and all(z>=0 for z in cert['z'])
    assert len(cert['z'])<=ceil(m)
    N,lower=tail_cutoff(m,cert,q)
    worst,witness,checks=exact_min_slack(q,m,cert,N)
    assert worst==0,(row['tag'],worst,witness)
    T=[F(x) for x in row['tail_values']] if 'tail_values' in row else [exp_negative_upper((m-r)**2/(2*Dt*m)) for r in range(len(cert['z']))]
    assert len(T)==len(cert['z']) and all(0<=t<=1 for t in T)
    bound=(cert['alpha']-cert['gamma']*D*m-sum((z*t for z,t in zip(cert['z'],T)),F(0)))/(cert['mu']*q*(1-q)*m)
    assert bound>target and bound==F(row['threshold_lower'])
    return checks

if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='verify':
        data=json.loads((HERE/'certificates.json').read_text())
        checks=sum(verify_saved(row) for row in data)
        print(json.dumps(dict(claim_label='CERTIFIED',referee_verdict=None,certificates=len(data),integer_states=checks,all_M='closed quadratic tail',result='PASS')))
    else:
        specs=[('A',F(4,5),F(6,5),F(6,5),F(3,5)),('A',F(1),F(6,5),F(6,5),F(3,5)),
            ('A',F(26,25),F(6,5),F(6,5),F(3,5)),('A',F(13,10),F(6,5),F(6,5),F(3,5)),
            ('B',F(3,5),F(7,5),F(13,10),F(7,10)),('B',F(8,5),F(7,5),F(13,10),F(7,10)),
            ('C1',F(1,3),F(8,5),F(19,10),F(1)),('C1',F(3,5),F(8,5),F(19,10),F(1)),
            ('C2',F(8,5),F(8,5),F(13,10),F(1)),('C2',F(9,4),F(8,5),F(13,10),F(1)),
            ('C2',F(7,3),F(8,5),F(13,10),F(1))]
        out=[]
        for band,lam,D,Dt,target in specs:
            q=lam/(1+lam)
            m=max(17/(2*q),61/(2*(1+2*q)))
            started=time.time()
            row=certify(q,m,D,Dt,target,f'{band}:lambda={lam}')
            out.append(row)
            (HERE/'certificates.json').write_text(json.dumps(out,indent=2)+'\n')
            print(row['tag'],'m',float(m),'threshold',row['threshold_decimal'],'N',row['tail_cutoff'],'time',round(time.time()-started,2),flush=True)
