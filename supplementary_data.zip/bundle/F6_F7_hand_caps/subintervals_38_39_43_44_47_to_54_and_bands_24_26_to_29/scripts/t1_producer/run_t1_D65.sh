#!/bin/zsh
# act1_test Stage 2: the R4X lower-tail constructor (copy) at D = 6/5 on the four order-44 strips of subintervals 15-18.
cd "$(dirname "$0")"
O="/Users/kvallier/Desktop/Erdos 993/ProofRuns/2026-09-28_analytic_large_n/LEAN/certfree/act1_test/outputs/stage2/t1_D65"
nice -n 10 python3 atlas_arb_r4x_mod.py --band 13 --sub 22-25_89-100 --cap 312/23 --root-dir "$O" --N 44 --kind plus > "$O/P15.log" 2>&1
nice -n 10 python3 atlas_arb_r4x_mod.py --band 13 --sub 89-100_91-100 --cap 312/23 --root-dir "$O" --N 44 --kind plus > "$O/P16.log" 2>&1
nice -n 10 python3 atlas_arb_r4x_mod.py --band 13 --sub 91-100_23-25 --cap 312/23 --root-dir "$O" --N 44 --kind plus > "$O/P17.log" 2>&1
nice -n 10 python3 atlas_arb_r4x_mod.py --band 14 --sub 23-25_93-100 --cap 637/48 --root-dir "$O" --N 44 --kind plus > "$O/P18.log" 2>&1
echo done > "$O/ALL_DONE"
