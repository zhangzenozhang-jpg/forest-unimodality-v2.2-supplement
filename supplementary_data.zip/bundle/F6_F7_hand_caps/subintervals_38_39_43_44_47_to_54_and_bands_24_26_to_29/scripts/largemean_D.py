#!/usr/bin/python3
"""upper_d_test (exact): the large-mean theorem (appendix_C_inputs.tex, Theorem apC:thm:largemean) with the cap D raised
from 8/5 to 21/10.  Its proof uses D only through eps = D/mu_M (Var M/mu^2 <= eps); for D <= 8/5, mu >= 400 the paper
takes eps <= 1/250.  With D <= 21/10 and mu >= 400, eps <= 21/4000.  Every other bound of the proof (sigma >= 8,
sigma^2 >= 75, a_G in (6/25, 1/4), 2 e^{-mu/30} sigma^3 <= 1/250, |1-2q| <= 1/4 resp. 1/2) does not involve D.
The two final inequalities, with the paper's own bounding steps, become (exact rationals):
  central (3/8 <= q <= 8/13, theta <= 7/10):
     (6/25)(1 - 7/10 - 20 eps) - (2/3)(1/4)(1 + 15 eps)/8 - (1 + 30 eps)/75 - 1/250 > 0
  outer (q <= 3/8 or q >= 8/13, theta <= 1):
     -(1/4)(20 eps) - (2/3)(1/2)(1 + 15 eps)/8 - (1 + 30 eps)/75 - 1/250 + (9/1600) 75 (1 - 4 eps - 2/3) > 0
(the paper's values at eps = 1/250: 707/60000 and 2031/40000, recomputed here as a control).  Also: the largest eps
(hence the largest D at mu = 400) for which each inequality holds (exact, the expressions are affine in eps).
"""
from fractions import Fraction as F


def central(e):
    return F(6, 25) * (1 - F(7, 10) - 20 * e) - F(2, 3) * F(1, 4) * (1 + 15 * e) / 8 - (1 + 30 * e) / 75 - F(1, 250)


def outer(e):
    return -F(1, 4) * (20 * e) - F(2, 3) * F(1, 2) * (1 + 15 * e) / 8 - (1 + 30 * e) / 75 - F(1, 250) \
        + F(9, 1600) * 75 * (1 - 4 * e - F(2, 3))


for nm, f in (('central', central), ('outer', outer)):
    e0 = F(1, 250); e1 = F(21, 4000)
    a, b = f(F(0)), f(F(1)) - f(F(0))      # affine: f(e) = a + b e
    emax = -a / b
    print('%-7s eps=1/250: %s (= %.6f)   eps=21/4000 (D=21/10, mu>=400): %s (= %.6f) %s   root eps* = %s, D* at mu=400: %s (= %.4f)' % (
        nm, f(e0), float(f(e0)), f(e1), float(f(e1)), 'POSITIVE' if f(e1) > 0 else 'NOT POSITIVE', emax, 400 * emax, float(400 * emax)))
assert central(F(1, 250)) == F(707, 60000) and outer(F(1, 250)) == F(2031, 40000)
assert central(F(21, 4000)) > 0 and outer(F(21, 4000)) > 0
print('PROVED: with D <= 21/10 the proof of the large-mean theorem goes through verbatim for mu_M >= 400 (eps <= 21/4000).')
