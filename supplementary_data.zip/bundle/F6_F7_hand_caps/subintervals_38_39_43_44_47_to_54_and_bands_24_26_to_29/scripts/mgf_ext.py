#!/usr/bin/python3
"""act1_test Stage 2 (the nearby principle for subintervals 16 and 18): the MGF criterion on the order-44 strips
[q(lam_lo), q(lam_hi)] x [m_44(iota), m_45] at D = 6/5 (theta44, rates44 of the subinterval), i.e. the rectangle R_iota
extended from m_44 to the next lower bound m_45 (piece44Cap), so that part (b) starts at m_45 on these subintervals.

build:  boxes by the producer's certify_box (copy of lane M30's constructor, candidate LP + Arb pass), adaptive splitting
        as in its run_strip; writes box_*.json and COVER.json under outputs/stage2/mgf_ext_D65/strip_XX/.
check:  (1) the producer's exact replay check_box/check_cover (replay_mgf.py copy), (2) the independent checker
        check_box/check_cover (indep_mgf_check.py, lane R1's program), both against the rectangle [m_44, m_45].
Usage: mgf_ext.py build|check piece[,piece]
"""
import sys, os, json, time, pickle
from fractions import Fraction as F
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE)); sys.path.insert(0, str(HERE / 'mgf_producer'))
OUT = HERE.parent / 'outputs' / 'stage2' / 'mgf_ext_D65'
from lean_mgf_data import n44_tables, qof

T = n44_tables()
COVS = {c['name']: c for c in pickle.load(open(HERE.parent / 'outputs' / 'stage1' / 't1' / 'coverings.pkl', 'rb'))}


def rect(p):
    c = COVS['N44/P%02d' % p]
    assert F(c['band']['mmin']) == T['mmin44'][p]
    return T['pieceLo'][p], T['pieceHi'][p], T['mmin44'][p], F(c['cap'])


def build(p):
    import atlas_mgf as A
    lo, hi, ml, mh = rect(p)
    pieces = json.loads((HERE / 'mgf_producer' / 'pieces_N44.json').read_text())
    caps = json.loads((HERE / 'mgf_producer' / 'CAPS_D65.json').read_text())
    piece = dict(pieces['pieces'][p]); cp = caps['pieces'][p]
    assert cp['piece'] == p and F(cp['D']) == F(6, 5)
    piece.update(theta=cp['theta'], D=cp['D'], tilts=cp['tilts'])
    ql, qh = qof(lo), qof(hi)
    folder = OUT / ('strip_%02d' % p); folder.mkdir(parents=True, exist_ok=True)
    assert not list(folder.glob('box_*.json')), 'boxes exist; never overwrite'
    pending = [(ql, qh, ml, mh, 0)]; rows = []; tries = 0; t0 = time.time(); holes = []
    while pending:
        lo_, hi_, low, high, depth = pending.pop()
        row = A.certify_box(lo_, hi_, low, high, piece, 44); tries += 1
        if F(row['margin_lower']) > 0:
            (folder / ('box_%06d.json' % len(rows))).write_text(json.dumps(row, indent=1) + '\n'); rows.append(row)
        elif depth >= 30 or (hi_ - lo_ <= F(1, 5000) and high - low <= F(1, 32)):
            holes.append([str(lo_), str(hi_), str(low), str(high)])
        elif row['constructor']['margin_before_q_repair'] <= 0 and high - low > F(1, 64):
            mid = (low + high) / 2; pending.extend([(lo_, hi_, low, mid, depth + 1), (lo_, hi_, mid, high, depth + 1)])
        elif 4 * (hi_ - lo_) * ((low + high) / 2) ** 2 >= (high - low) or high - low <= F(1, 64):
            mid = (lo_ + hi_) / 2; pending.extend([(lo_, mid, low, high, depth + 1), (mid, hi_, low, high, depth + 1)])
        else:
            mid = (low + high) / 2; pending.extend([(lo_, hi_, low, mid, depth + 1), (lo_, hi_, mid, high, depth + 1)])
    slabs, gaps = A.build_cover(rows, ql, qh, ml, mh)
    cover = dict(claim_label='data (act1_test; verified by mgf_ext.py check)', piece=p, lam=[str(lo), str(hi)],
                 q=[str(ql), str(qh)], m=[str(ml), str(mh)], D='6/5', boxes=len(rows), slabs=slabs, gaps=gaps, holes=holes,
                 full_cover=(not gaps and not holes))
    (folder / 'COVER.json').write_text(json.dumps(cover, indent=1) + '\n')
    print('ext strip %d [%s,%s] x [%.4f,%.4f] D=6/5: %d boxes, %d tries, holes %d, gaps %d, %.1fs' % (
        p, lo, hi, float(ml), float(mh), len(rows), tries, len(holes), len(gaps), time.time() - t0), flush=True)


def check(p):
    lo, hi, ml, mh = rect(p)
    folder = OUT / ('strip_%02d' % p)
    rows = [json.loads(x.read_text()) for x in sorted(folder.glob('box_*.json'))]
    cover = json.loads((folder / 'COVER.json').read_text())
    # (1) the producer's exact replay
    import replay_mgf as R
    inp = R.strip_inputs(p, 21, 'CAPS_D65.json')
    assert inp['D'] == F(6, 5)
    f1 = []; mm1 = None
    for i, r in enumerate(rows):
        res = R.check_box(R.Box(r), inp, 44, ml, mh)
        if not res[0]:
            f1.append('box %d: %s' % (i, res[3][:3]))
        else:
            mm1 = res[4] if mm1 is None else min(mm1, res[4])
    f1 += R.check_cover(cover, [R.Box(r) for r in rows], qof(lo), qof(hi), ml, mh)
    # (2) the independent checker
    import indep_mgf_check as I
    I.D_OVERRIDE[p] = F(6, 5)
    Tl = I.lean_tables(); recs = I.lean_records()
    inp2 = I.piece_inputs(p, 21, Tl, recs)
    f2 = []; mm2 = None
    for i, r in enumerate(rows):
        r = dict(r); r['D'] = str(inp2['D'])
        res = I.check_box(r, inp2, 21, ml, mh, {})
        if not res['ok']:
            f2.append('box %d: %s' % (i, res['failures'][:3]))
        else:
            mm2 = F(res['margin']) if mm2 is None else min(mm2, F(res['margin']))
    f2 += I.check_cover(cover, rows, qof(lo), qof(hi), ml, mh)
    out = dict(piece=p, rect=dict(lam=[str(lo), str(hi)], m=[str(ml), str(mh)]), D='6/5', boxes=len(rows),
               replay=dict(result='PASS' if not f1 else 'FAIL', failures=f1[:10], min_margin=float(mm1) if mm1 else None),
               independent=dict(result='PASS' if not f2 else 'FAIL', failures=f2[:10], min_margin=float(mm2) if mm2 else None))
    (folder / 'VERIFIED_act1.json').write_text(json.dumps(out, indent=1) + '\n')
    print('ext strip %d: %d boxes; producer replay %s (min margin %s); independent %s (min margin %s) %s' % (
        p, len(rows), out['replay']['result'], out['replay']['min_margin'], out['independent']['result'],
        out['independent']['min_margin'], (f1 + f2)[:2]), flush=True)


if __name__ == '__main__':
    mode = sys.argv[1]
    for p in [int(x) for x in sys.argv[2].split(',')]:
        (build if mode == 'build' else check)(p)
