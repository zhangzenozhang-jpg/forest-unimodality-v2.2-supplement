"""Lane M30: the INDEPENDENT exact replay of an MGF + two-sided atlas strip (LEAN/atlas_mgf/ATLAS_MGF_PROOF.md, SPEC v2).

A separate code path from the constructor atlas_mgf.py: written from the paper theorem, not from the seed; exact
rational arithmetic throughout (fractions.Fraction and Python integers; binomial rows as integer Pascal rows
N_M(j) = C(M,j) p^j (r-p)^{M-j} for q = p/r); no floating point and no Arb anywhere; the exponentials enter only
through the exact rational upper bounds U_k = 1/sum_{i<=120} x^i/i! >= e^{-x}.  The strip constants (theta, D, the
five rates, the edges) are re-read from Lean's N44/Data/Params.lean with this file's own parser, and the floors are
recomputed from the six Lean records with this file's own implementation of Lean's floor rule; the boxes' declared
inputs must agree with them.

For every box (checks (S), (T), (F), (Mg) of the paper theorem):
  (S)  0 < ql < qh < 1, ml <= mh, nu > 0, gamma > 0, a, b >= 0, max(a, b) > 0, z_k >= 0, m0 = (ml + mh)/2;
  (T)  the cutoff N: pi(N) <= -max(a, b) - c^2/(4 nu) and beta - 2 gamma (N - m0) <= 0;
  (F)  every fibre M < N: rhs(M) = pi(M) - sum_k z_k s_k(qh)^M; the two half-lines of vanishing kernel; every integer
       j in [-1, M+1] either skips (nu (delta - vtx)^2 >= rhs + max(a,b) + c^2/(4 nu) for every q of the box, by the
       integer range) or passes the first-order or the second-order q-uniform bound;
  (Mg) alpha + min(beta (ml - m0), beta (mh - m0)) - gamma (D mh + max d^2) - nu theta vmax mh - sum_k z_k U_k > 0.
Then the cover: the slabs of COVER.json partition [q(lam_lo), q(lam_hi)] and each slab's chain of boxes contains the
slab and covers [floor_N, floor_44] in m without a gap.
Usage: python3 replay_mgf.py --rung 40 --strip 22 [--root rung_40]   -> <root>/strip_22/VERIFIED.json
"""
from fractions import Fraction as F
from math import comb, isqrt
from pathlib import Path
import argparse, hashlib, json, re, sys, time

HERE = Path(__file__).resolve().parent
LEAN = Path('/Users/kvallier/Desktop/Erdos993-Lean-FiberFloor/Erdos993Lean/Analytic')   # act1_test: aa8ba75, read only
PARAMS = LEAN / 'N44' / 'Data' / 'Params.lean'
RECORDS = [('rec1', LEAN / 'Density' / 'Records.lean'), ('rec11', LEAN / 'Density' / 'Records.lean'),
           ('rec5750', LEAN / 'N51' / 'Records.lean'), ('rec75', LEAN / 'N51' / 'Records.lean'),
           ('rec2325', LEAN / 'N48' / 'Records.lean'), ('rec85', LEAN / 'N44' / 'Records.lean')]
TVALS = [F(0), F(1, 20), F(1, 10), F(1, 5), F(3, 10)]


# ---------------------------------------------------------------- exact helpers

def fl(x):
    """floor of a rational"""
    return F(x).numerator // F(x).denominator


def cl(x):
    return -((-F(x)).numerator // F(x).denominator)


def ceil_sqrt(v):
    """smallest integer k >= 0 with k^2 >= v (v >= 0 rational)"""
    v = F(v)
    k = isqrt(cl(v))
    while k * k < v:
        k += 1
    while k > 0 and (k - 1) * (k - 1) >= v:
        k -= 1
    return k


def exp_upper(x, terms=120):
    x = F(x)
    assert x >= 0
    s = t = F(1)
    for i in range(1, terms + 1):
        t = t * x / i
        s += t
    return 1 / s


def qmin_interval(nu, c, lo, hi):
    v = -c / (2 * nu)
    x = lo if v < lo else (hi if v > hi else v)
    return nu * x * x + c * x


def qmin_left(nu, c, a):        # (-inf, a]
    v = -c / (2 * nu)
    x = a if a < v else v
    return nu * x * x + c * x


def qmin_right(nu, c, a):       # [a, inf)
    v = -c / (2 * nu)
    x = a if v < a else v
    return nu * x * x + c * x


# ---------------------------------------------------------------- Lean tables (own parser) and floors (own code)

def lean_lists(text):
    """Every `def NAME : List ... := [ ... ]` of Params.lean as a list of tokens `R (n) d` -> Fraction, or integers."""
    out = {}
    for m in re.finditer(r'def (\w+) : List ([^\n]*?) :=\n', text):
        name = m.group(1)
        i = text.index('[', m.end())
        depth = 0; j = i
        while True:
            if text[j] == '[': depth += 1
            elif text[j] == ']':
                depth -= 1
                if depth == 0: break
            j += 1
        body = text[i:j + 1]
        kind = m.group(2).strip()
        if kind == 'Rat':
            out[name] = [F(int(a), int(b)) for a, b in re.findall(r'R \((-?\d+)\) (\d+)', body)]
        elif kind == '(List Rat)':
            out[name] = [[F(int(a), int(b)) for a, b in re.findall(r'R \((-?\d+)\) (\d+)', inner)]
                         for inner in re.findall(r'\[([^\[\]]*)\]', body)]
        else:
            assert kind == 'Nat', (name, kind)
            out[name] = [int(x) for x in re.findall(r'\d+', body)]
    return out


def lean_records():
    recs = []
    for name, path in RECORDS:
        text = path.read_text()
        i = text.index('def %s : Record where' % name)
        block = text[i:i + 600]
        vals = {}
        for key in ('x', 'r', 'h'):
            mm = re.search(r'\n  %s := ([0-9]+)(?: / ([0-9]+))?' % key, block)
            vals[key] = F(int(mm.group(1)), int(mm.group(2) or 1))
        recs.append((name, vals['x'], vals['r'], vals['h']))
    return recs


def lean_floor(N, lo, hi, recs):
    k = cl(F(N, 4)) + 1
    for name, x, r, h in recs:
        if x <= lo:
            L = N * r + h
            kk = ceil_sqrt((lo / (1 + lo)) / (x / (1 + x)) * L * L)
            k = max(k, kk)
    return k, F(k) / (2 * (hi / (1 + hi)))


CAMPAIGN = HERE.parents[1]
_CAPS_CACHE = {}


def cert_header(path):
    """The small fields of a (possibly huge) certificate JSON without loading its cells: claim_label, D, activity."""
    head = path.read_bytes()[:8192].decode('utf-8', 'replace')
    lab = re.search(r'"claim_label":\s*"([^"]+)"', head).group(1)
    D = re.search(r'"D":\s*"([^"]+)"', head).group(1)
    act = re.search(r'"activity":\s*\[\s*"([^"]+)",\s*"([^"]+)"\s*\]', head)
    return lab, F(D), (F(act.group(1)), F(act.group(2)))


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as fh:
        for chunk in iter(lambda: fh.read(1 << 24), b''):
            h.update(chunk)
    return h.hexdigest()


def verified_caps(caps_rel, T):
    """Load a caps table and verify it: theta and tilts are Lean's; D is Lean's except on the pieces whose override
    is backed by a CERTIFIED O1 certificate file (recorded sha256; D equal; activity interval containing the piece)."""
    if caps_rel in _CAPS_CACHE:
        return _CAPS_CACHE[caps_rel]
    ct = json.loads((HERE / caps_rel).read_text())
    certs = {c['piece']: c for c in ct['certificates']}
    for c in ct['certificates']:
        path = CAMPAIGN / c['file']
        assert sha256_file(path) == c['sha256'], 'certificate sha256 mismatch: %s' % c['file']
        lab, D, (a0, a1) = cert_header(path)
        assert lab == 'CERTIFIED' and D == F(c['D']), (c['file'], lab, D)
        lo, hi = T['pieceLo'][c['piece']], T['pieceHi'][c['piece']]
        assert a0 <= lo and hi <= a1, 'certificate %s does not cover piece %d' % (c['file'], c['piece'])
    out = {}
    for cp in ct['pieces']:
        p = cp['piece']
        assert F(cp['theta']) == T['theta44'][p], ('theta', p)
        assert [(F(t), F(e)) for t, e in cp['tilts']] == list(zip(TVALS, T['rates44'][p])), ('tilts', p)
        if p in certs:
            assert F(cp['D']) == F(certs[p]['D']), ('D override', p)
        elif p in ct.get('hand_pieces', []):      # act1_test: the hand-proved cap 6/5 (no certificate file)
            assert F(cp['D']) == F(ct['hand_D']) == F(6, 5), ('hand D', p)
        else:
            assert F(cp['D']) == T['D44'][p], ('D', p)
        out[p] = dict(theta=F(cp['theta']), D=F(cp['D']), tilts=[(F(t), F(e)) for t, e in cp['tilts']],
                      D_source=cp.get('D_source'))
    _CAPS_CACHE[caps_rel] = (out, hashlib.sha256((HERE / caps_rel).read_bytes()).hexdigest())
    return _CAPS_CACHE[caps_rel]


def strip_inputs(p, rung, caps=None):
    T = lean_lists(PARAMS.read_text())
    recs = lean_records()
    lo, hi = T['pieceLo'][p], T['pieceHi'][p]
    k44, m44 = lean_floor(44, lo, hi, recs)
    assert k44 == T['kmin44'][p] and m44 == T['mmin44'][p], 'Lean floor rule does not reproduce mmin44 on piece %d' % p
    kN, mN = lean_floor(rung, lo, hi, recs)
    inp = dict(lam=(lo, hi), q=(lo / (1 + lo), hi / (1 + hi)), theta=T['theta44'][p], D=T['D44'][p],
               tilts=list(zip(TVALS, T['rates44'][p])), floor_N=(kN, mN), floor_44=(k44, m44), caps=None)
    if caps:
        table, csha = verified_caps(caps, T)
        inp.update(theta=table[p]['theta'], D=table[p]['D'], tilts=table[p]['tilts'],
                   caps=dict(file=caps, sha256=csha, D_source=table[p]['D_source']))
    return inp


# ---------------------------------------------------------------- one box

class Box:
    def __init__(self, d):
        self.raw = d
        self.ql, self.qh = map(F, d['q']); self.ml, self.mh = map(F, d['m']); self.m0 = F(d['m0'])
        du = d['dual']
        self.nu, self.c, self.alpha, self.beta, self.gamma = (F(du[k]) for k in ('nu', 'c', 'alpha', 'beta', 'gamma'))
        self.a, self.b = F(du['a']), F(du['b']); self.z = [F(x) for x in du['z']]
        self.N = int(d['cutoff']); self.theta, self.D = F(d['theta']), F(d['D'])
        self.tilts = [(F(t), F(e)) for t, e in d['tilts']]


def pi_of(bx, M):
    x = F(M) - bx.m0
    return bx.alpha + bx.beta * x - bx.gamma * x * x


def check_box(bx, inp, rung, strip_ml, strip_mh):
    fails = []
    ql, qh, ml, mh, m0 = bx.ql, bx.qh, bx.ml, bx.mh, bx.m0
    nu, c, a, b, gamma = bx.nu, bx.c, bx.a, bx.b, bx.gamma
    # inputs are the piece's (transport)
    if bx.theta != inp['theta'] or bx.D != inp['D'] or bx.tilts != inp['tilts']:
        fails.append('inputs differ from Lean piece table')
    if not (inp['q'][0] <= ql < qh <= inp['q'][1]):
        fails.append('q-interval not inside the piece')
    if not (strip_ml <= ml <= mh <= strip_mh):
        fails.append('m-interval not inside the strip')
    # (S)
    if not (0 < ql < qh < 1 and ml <= mh and nu > 0 and gamma > 0 and a >= 0 and b >= 0 and max(a, b) > 0
            and all(z >= 0 for z in bx.z) and len(bx.z) == 5 and m0 == (ml + mh) / 2):
        fails.append('sanity (S)')
    if fails:
        return False, 0, None, fails
    B = max(a, b)
    # (T)
    N = bx.N
    if not (pi_of(bx, N) <= -B - c * c / (4 * nu) and bx.beta - 2 * gamma * (N - m0) <= 0):
        fails.append('cutoff (T) at N = %d' % N)
    # (Mg)
    U = [exp_upper(ell * ml) for _, ell in bx.tilts]
    vmax = F(1, 4) if ql <= F(1, 2) <= qh else max(ql * (1 - ql), qh * (1 - qh))
    dmax = max((ml - m0) ** 2, (mh - m0) ** 2)
    margin = (bx.alpha + min(bx.beta * (ml - m0), bx.beta * (mh - m0)) - gamma * (bx.D * mh + dmax)
              - nu * bx.theta * vmax * mh - sum((z * u for z, u in zip(bx.z, U)), F(0)))
    if not margin > 0:
        fails.append('margin (Mg) = %s' % float(margin))
    # (F): integer rows at ql, q0, qh
    q0 = (ql + qh) / 2; rad = (qh - ql) / 2
    sks = [1 - qh + qh * t for t, _ in bx.tilts]
    vtx = -c / (2 * nu)
    lev_const = B + c * c / (4 * nu)
    rows = {}
    for name, q in (('l', ql), ('0', q0), ('h', qh)):
        rows[name] = (q.numerator, q.denominator - q.numerator, q.denominator, [1], 1)   # p, s, r, row, r^M
    states = 0; worst = None
    cL, cR = (1 - q0) / q0, q0 / (1 - q0)
    W0den = q0 * (1 - q0)
    for M in range(N):
        rhs = pi_of(bx, M) - sum((z * s ** M for z, s in zip(bx.z, sks)), F(0))
        # the vanishing-kernel half-lines
        if not (qmin_left(nu, c, -2 - ql * M) >= rhs and qmin_right(nu, c, M + 2 - qh * M) >= rhs):
            fails.append('half-line at M = %d' % M)
        states += 2
        lev = rhs + lev_const
        if lev > 0:
            R = ceil_sqrt(lev / nu) + 1
            jlo = max(-1, fl(ql * M + vtx) - R); jhi = min(M + 1, cl(qh * M + vtx) + R)
            bl = [F(x, rows['l'][4]) for x in rows['l'][3]]
            b0 = [F(x, rows['0'][4]) for x in rows['0'][3]]
            bh = [F(x, rows['h'][4]) for x in rows['h'][3]]
            for j in range(jlo, jhi + 1):
                d0 = j - q0 * M
                if j == -1:
                    ker = -b * (1 - q0) ** M
                    K1 = b * M * (1 - ql) ** (M - 1) if M >= 1 else F(0)
                    h1 = b * M * (1 - q0) ** (M - 1) if M >= 1 else F(0)
                    K2 = b * M * (M - 1) * (1 - ql) ** (M - 2) if M >= 2 else F(0)
                elif j == M + 1:
                    ker = -a * q0 ** M
                    K1 = a * M * qh ** (M - 1) if M >= 1 else F(0)
                    h1 = -a * M * q0 ** (M - 1) if M >= 1 else F(0)
                    K2 = a * M * (M - 1) * qh ** (M - 2) if M >= 2 else F(0)
                else:
                    ker = a * (cL * b0[j] - (b0[j - 1] if j > 0 else 0)) + b * (cR * b0[j] - (b0[j + 1] if j < M else 0))
                    Ap = a * F(M + 1 - 2 * j, M - j + 1); Bp = b * F(2 * j + 1 - M, j + 1)
                    W = [bl[j] / (ql * (1 - ql)), bh[j] / (qh * (1 - qh))]
                    if M != 2:
                        qs = F(j - 1, M - 2)
                        if ql < qs < qh:
                            W.append(comb(M, j) * qs ** j * (1 - qs) ** (M - j) / (qs * (1 - qs)))
                    Wmax = max(W)
                    P = lambda x: Ap * (1 - x) ** 2 + Bp * x * x
                    dP = lambda x: -2 * Ap + 2 * (Ap + Bp) * x
                    pts = [ql, qh]
                    if Ap + Bp != 0:
                        v = Ap / (Ap + Bp)
                        if ql < v < qh: pts.append(v)
                    Pmax = max(abs(P(x)) for x in pts)
                    dPmax = max(abs(dP(ql)), abs(dP(qh)))
                    Lmax = max(abs(F(j - 1) / u - F(M - j - 1) / (1 - v)) for u in (ql, qh) for v in (ql, qh))
                    Lpmax = abs(F(j - 1)) / (ql * ql) + abs(F(M - j - 1)) / ((1 - qh) * (1 - qh))
                    K1 = Wmax * (dPmax + Lmax * Pmax)
                    L0 = F(j - 1) / q0 - F(M - j - 1) / (1 - q0)
                    h1 = (b0[j] / W0den) * (dP(q0) + L0 * P(q0))
                    K2 = Wmax * (abs(2 * (Ap + Bp)) + 2 * Lmax * dPmax + (Lmax * Lmax + Lpmax) * Pmax)
                s1 = ker - rad * K1 + qmin_interval(nu, c, j - qh * M, j - ql * M) - rhs
                dh = h1 - M * (c + 2 * nu * d0)
                s2 = ker + nu * d0 * d0 + c * d0 - rad * abs(dh) - rad * rad * (K2 + 2 * nu * M * M) / 2 - rhs
                s = max(s1, s2); states += 1
                if worst is None or s < worst[0]:
                    worst = (s, M, j)
                if s < 0:
                    fails.append('atom (%d, %d): slack %s' % (M, j, float(s)))
                    if len(fails) > 20:
                        return False, states, worst, fails
        # advance the integer rows to M + 1
        for name in rows:
            p, s_, r, row, rM = rows[name]
            new = [s_ * row[0]] + [s_ * row[i] + p * row[i - 1] for i in range(1, len(row))] + [p * row[-1]]
            rows[name] = (p, s_, r, new, rM * r)
    return not fails, states, worst, fails, margin


# ---------------------------------------------------------------- the cover

def check_cover(cover, boxes, q_lo, q_hi, ml, mh):
    fails = []
    slabs = cover['slabs']
    if cover.get('empty_strip'):
        return ['empty strip declared with boxes present'] if boxes else []
    if not slabs:
        return ['no slabs']
    if F(slabs[0]['lo']) != q_lo or F(slabs[-1]['hi']) != q_hi:
        fails.append('slabs do not span the strip in q')
    for s1, s2 in zip(slabs, slabs[1:]):
        if F(s1['hi']) != F(s2['lo']):
            fails.append('slab gap at %s' % s1['hi'])
    for sl in slabs:
        lo, hi = F(sl['lo']), F(sl['hi'])
        if not lo < hi:
            fails.append('degenerate slab'); continue
        tip = ml
        for i in sl['chain']:
            bx = boxes[i]
            if not (bx.ql <= lo and hi <= bx.qh):
                fails.append('box %d does not contain slab [%s, %s]' % (i, lo, hi))
            if not bx.ml <= tip:
                fails.append('m-gap in slab [%s, %s] before box %d' % (lo, hi, i))
            tip = max(tip, bx.mh)
        if tip < mh:
            fails.append('slab [%s, %s] stops at m = %s < %s' % (lo, hi, tip, mh))
    return fails


def replay_strip(rung, p, root, caps=None):
    t0 = time.time()
    folder = HERE / root / f'strip_{p:02d}'
    inp = strip_inputs(p, rung, caps)
    cover = json.loads((folder / 'COVER.json').read_text())
    q_lo, q_hi = inp['q']
    strip_ml, strip_mh = inp['floor_N'][1], inp['floor_44'][1]
    fails = []
    if (F(cover['q'][0]), F(cover['q'][1])) != (q_lo, q_hi) or (F(cover['m'][0]), F(cover['m'][1])) != (strip_ml, strip_mh):
        fails.append('COVER.json strip rectangle differs from Lean floors/edges: cover %s x %s, Lean %s x %s' % (
            cover['q'], cover['m'], [str(q_lo), str(q_hi)], [str(strip_ml), str(strip_mh)]))
    paths = sorted(folder.glob('box_*.json'))
    boxes = [Box(json.loads(pth.read_text())) for pth in paths]
    # reused boxes (another rung's adopted certificates): each file must be byte-identical to its recorded source
    source = json.loads((folder / 'SOURCE.json').read_text()) if (folder / 'SOURCE.json').exists() else {}
    reused = source.get('reused_boxes') or []
    for rb in reused:
        here = folder / rb['file']; src = HERE / rb['source']
        if not (here.exists() and src.exists() and hashlib.sha256(here.read_bytes()).hexdigest() == rb['sha256']
                == hashlib.sha256(src.read_bytes()).hexdigest()):
            fails.append('reused box %s is not byte-identical to %s' % (rb['file'], rb['source']))
    states = 0; min_slack = None; min_margin = None; per_box = []
    empty = strip_ml >= strip_mh
    if empty and boxes:
        fails.append('boxes present on an empty strip')
    if not empty and not boxes:
        fails.append('no boxes')
    for i, bx in enumerate(boxes):
        res = check_box(bx, inp, rung, strip_ml, strip_mh)
        ok, st, worst = res[0], res[1], res[2]
        states += st
        if not ok:
            fails.append('box %d: %s' % (i, '; '.join(res[3][:5])))
        else:
            margin = res[4]
            if worst is not None and (min_slack is None or worst[0] < min_slack[0]):
                min_slack = (worst[0], i, worst[1], worst[2])
            if min_margin is None or margin < min_margin[0]:
                min_margin = (margin, i)
        per_box.append(dict(box=i, ok=ok, states=st, worst_slack=(str(worst[0]) if worst else None)))
    fails += check_cover(cover, boxes, q_lo, q_hi, strip_ml, strip_mh)
    passed = not fails
    out = dict(claim_label='CERTIFIED' if passed else 'DIAGNOSTIC', referee_verdict=None, lane='M30',
               result='PASS' if passed else 'FAIL', full_cover=str(passed), rung=rung, strip=p, piece=p,
               lam=[str(x) for x in inp['lam']], q=[str(q_lo), str(q_hi)], m=[str(strip_ml), str(strip_mh)],
               floor_N=dict(k=inp['floor_N'][0], m=str(strip_ml)), floor_44=dict(k=inp['floor_44'][0], m=str(strip_mh)),
               theta=str(inp['theta']), D=str(inp['D']), tilts=[[str(t), str(e)] for t, e in inp['tilts']], caps=inp['caps'],
               empty_strip=empty, boxes=len(boxes), reused_boxes=len(reused), new_boxes=len(boxes) - len(reused),
               box_rungs=sorted(set(b.raw['rung'] for b in boxes)), slabs=len(cover['slabs']), integer_states=states,
               min_slack=(dict(value=str(min_slack[0]), decimal=float(min_slack[0]), box=min_slack[1], M=min_slack[2], j=min_slack[3]) if min_slack else None),
               min_margin=(dict(value=str(min_margin[0]), decimal=float(min_margin[0]), box=min_margin[1]) if min_margin else None),
               arithmetic='exact rational (fractions.Fraction, integer Pascal rows); no floating point; U_k = 1/sum_{i<=120} x^i/i!',
               inputs=('theta, D, rates, edges re-read from Lean N44/Data/Params.lean; floors recomputed from the six Lean records' if not caps else 'theta, rates, edges from Lean N44/Data/Params.lean; D from the verified caps table (Lean D44 except the pieces backed by the listed CERTIFIED O1 certificates); floors from the six Lean records'),
               lean_params_sha256=hashlib.sha256(PARAMS.read_bytes()).hexdigest(),
               replay_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               seconds=round(time.time() - t0, 1), failures=fails, per_box=per_box)
    (folder / 'VERIFIED.json').write_text(json.dumps(out, indent=1) + '\n')
    print('rung %d strip %2d %s boxes %d states %d min slack %s min margin %s %.1fs %s' % (
        rung, p, out['result'], len(boxes), states, (('%.2e' % min_slack[0]) if min_slack else '-'),
        (('%.2e' % min_margin[0]) if min_margin else '-'), out['seconds'], ('; '.join(fails[:3]) if fails else '')), flush=True)
    return passed


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--rung', type=int, required=True)
    ap.add_argument('--strip', type=str, required=True)
    ap.add_argument('--root')
    ap.add_argument('--caps', help='caps table to check the boxes against (verified against Lean and the certificate files)')
    args = ap.parse_args()
    if '-' in args.strip:
        a, b = args.strip.split('-'); strips = list(range(int(a), int(b) + 1))
    else:
        strips = [int(x) for x in args.strip.split(',')]
    root = args.root or f'rung_{args.rung}'
    allok = True
    for p in strips:
        allok &= replay_strip(args.rung, p, root, args.caps)
    sys.exit(0 if allok else 1)


if __name__ == '__main__':
    main()
