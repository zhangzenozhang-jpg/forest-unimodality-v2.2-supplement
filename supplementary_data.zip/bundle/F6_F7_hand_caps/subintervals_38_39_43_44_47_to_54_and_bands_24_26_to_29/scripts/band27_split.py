#!/usr/bin/python3
"""upper_d_test, after the referee (F4): band 27 = [19/10, 41/20] straddles lambda = 2, where the hand cap jumps from 9/5
to 21/10, and the band test (and Lean's bandOK) carries one D per band.  Split the band at lambda = 2 into
[19/10, 2] with D = 9/5 and [2, 41/20] with D = 21/10, keeping the band's floors (m_52, m_61, 50, 400; the lower half's
own floors are higher, so these remain valid lower ends) and its tail rule (box top in the strip S28; the sub-band's top
activity, 2 resp. 41/20, in the coarse coverings L28, U28).  The SAME boxes are used: every final box meeting a half
(a box across q(2) = 2/3 serves both halves; it passed at 21/10, hence at 9/5).  Each half gets its own exact cover
(q-slabs from its own ends, greedy chains in m).  Checked with ONE cap per covering (no per-box cap) by both checkers.
Usage: band27_split.py OUT.pkl
"""
import sys, os, pickle
from fractions import Fraction as F
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from t1_rebuild import chain_for

HERE = os.path.dirname(os.path.abspath(__file__))
P1 = os.path.join(HERE, '..', 'outputs', 'stage2', 't1_hand', 'cov_hand.pkl')
P2 = os.path.join(HERE, '..', 'outputs', 'stage2', 't1_hand_const', 'cov_hand_const.pkl')


def main():
    out = sys.argv[1]
    final = {c['name']: c for c in pickle.load(open(P1, 'rb')) if c['name'] == 'N52/S28_hand'}
    final.update({c['name']: c for c in pickle.load(open(P2, 'rb')) if c['name'] in ('Atlas/L28_hand', 'Atlas/U28_hand')})
    assert len(final) == 3
    q2 = F(2, 3)
    res = []
    for name, c in final.items():
        b = c['band']
        assert F(b['lamLo']) == F(19, 10) and F(b['lamHi']) == F(41, 20)
        mlo, mhi = F(b['mmin']), F(c['cap'])
        for half, (lo, hi, D) in (('lo', (F(19, 10), F(2), F(9, 5))), ('hi', (F(2), F(41, 20), F(21, 10)))):
            qlo, qhi = lo / (1 + lo), hi / (1 + hi)
            boxes = [x for x in c['boxes'] if x['ql'] < qhi and x['qh'] > qlo]
            qe = sorted(set([qlo, qhi] + [x['ql'] for x in boxes] + [x['qh'] for x in boxes]))
            qe = [x for x in qe if qlo <= x <= qhi]
            slabs = [dict(lo=a, hi=bb, chain=chain_for(boxes, a, bb, mlo, mhi)) for a, bb in zip(qe, qe[1:])]
            used = sorted(set(k for s in slabs for k in s['chain']))
            remap = {k: i for i, k in enumerate(used)}
            bx = [boxes[k] for k in used]
            slabs = [dict(lo=s['lo'], hi=s['hi'], chain=[remap[k] for k in s['chain']]) for s in slabs]
            band = dict(b); band['lamLo'] = lo; band['lamHi'] = hi; band['D'] = D
            tail = ('const', hi) if c['tail'][0] == 'const' else c['tail']
            res.append(dict(family=c['family'], name='%s_%s' % (name, half), theorem='upper_d_test band 27 split at lambda = 2',
                            index=c['index'], band=band, tail=tail, cap=mhi, boxes=bx, slabs=slabs,
                            box_names=[x.get('file', '') for x in bx], data_file=c.get('data_file'),
                            straddling=sum(1 for x in bx if x['ql'] < q2 < x['qh'])))
            print('%s_%s: lambda [%s,%s] D %s tail %s: %d of the %d final boxes used (%d across q(2)), %d slabs' % (
                name, half, lo, hi, D, tail[0], len(bx), len(c['boxes']), res[-1]['straddling'], len(slabs)), flush=True)
    pickle.dump(res, open(out, 'wb'))


if __name__ == '__main__':
    main()
