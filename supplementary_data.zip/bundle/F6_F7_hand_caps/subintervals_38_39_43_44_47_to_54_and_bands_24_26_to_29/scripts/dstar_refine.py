#!/usr/bin/python3
"""DIAGNOSTIC (float LP): the largest D at which the fine-box MGF criterion closes on R_iota near its failing corner,
and a grid test of candidate hand caps (e.g. 13/12, 11/10 on 24; 7/6, 23/20 on 27).
Usage: dstar_refine.py OUTJSON piece cand1,cand2,..."""
import sys, json, time
from fractions import Fraction as F
from survey_point_lp import theta_star
from lean_mgf_data import n44_tables, mgf_strip, qof
out, p = sys.argv[1], int(sys.argv[2]); cands = [F(x) for x in sys.argv[3].split(",")]
T = n44_tables(); lo, hi = T["pieceLo"][p], T["pieceHi"][p]; theta = float(T["theta44"][p]); rates = [float(x) for x in T["rates44"][p]]
mlo, mhi = mgf_strip(p)["mlo"], T["mmin44"][p]
def dstar(q, m, a=0.9, b=1.4, tol=1e-5):
    while b - a > tol:
        c = (a + b) / 2
        if theta_star(q, m, c, rates) >= theta: a = c
        else: b = c
    return a
t0 = time.time()
corner = dict(lam=str(hi), m=str(mlo), D_star=dstar(float(qof(hi)), float(mlo)))
# fine grid on the lower part of the rectangle (where the hand cap fails), the whole lambda range
lams = [lo + (hi - lo) * F(i, 24) for i in range(25)]
ms = [mlo + (F(3, 2)) * F(i, 30) for i in range(31)]
res = dict(piece=p, lam=[str(lo), str(hi)], m_lo=str(mlo), theta=theta, corner=corner, candidates={})
for D in cands:
    worst = None; nf = 0
    for lam in lams:
        q = float(qof(lam))
        for m in ms:
            t = theta_star(q, float(m), float(D), rates)
            if not (t >= theta): nf += 1
            if worst is None or t - theta < worst[0]: worst = (t - theta, float(lam), float(m))
    res["candidates"][str(D)] = dict(points=len(lams) * len(ms), fail=nf, worst_slack=worst[0], at_lam=worst[1], at_m=worst[2])
    print("piece %d D %s: %d points on [lam] x [m_21, m_21 + 3/2], fail %d, worst theta*-theta %+.5f at lam %.4f m %.4f" % (
        p, D, len(lams) * len(ms), nf, worst[0], worst[1], worst[2]), flush=True)
print("piece %d corner (lam %s, m %s): D* = %.5f; %.0fs" % (p, hi, mlo, corner["D_star"], time.time() - t0), flush=True)
json.dump(res, open(out, "w"), indent=1)
