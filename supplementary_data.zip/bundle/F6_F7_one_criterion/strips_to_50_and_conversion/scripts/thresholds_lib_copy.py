"""NOTATION (revised section, 30 Sep 2026): rho = the cut t_*, u0 = V_*, m = mu_M, mL = m_L, atom = elementary interval,
d = |1-2q| (dmax, dmin = chi_max, chi_min), vmin/vmax = v_q^-/v_q^+, beta = Psi_mass, Cb = C_mass, H = a_N(theta),
Km, Kc = K_mass, K_curv, r = ell_cut, piece = subinterval hat I_iota; the code is unchanged in substance.
thresholds_lib.py (functions of thresholds.py, no main loop);\nthresholds.py -- per-band threshold of the re-derived large-mean theorem (Theorem lm:main of
large_mean_section.tex) with the certificate-free inputs:
  theta(lambda): 31 bands, o2 Theorem B (NOTE_FOR_TONG_WEI Table o2:tab:bands);
  D(lambda): multiplier_curve staircase 6/5, 7/5, 8/5, 9/5, 21/10 (under review);
  ell(lambda) = q(a_i) kappa_i on the 55 pieces (tail_var/outputs/tail_kappa.json).
Atoms = common refinement of the three partitions. For each atom and each design pair (rho, u0) the margin
Psi(m) (eq. (lm:Psi)) is bounded below uniformly over the atom; the least integer m_L with Psi(m_L) > 0 is found
by bisection in floating point and then CERTIFIED by interval arithmetic (mpmath.iv, 40 digits) at m_L, together
with the three monotonicity conditions (rho*vmin*m_L >= u0, r*m_L >= 3/2, beta increasing), which make Psi > 0 for
all m >= m_L. n_L = 4*ceil(2*q_hi*m_L) - 7 (from m >= k/(2q), k >= ceil(n/4)+1).
Outputs: ../outputs/thresholds.json, ../outputs/thresholds_table.tex. Run: python3 thresholds.py"""
import json, math, sys
from fractions import Fraction as Fr
from mpmath import iv, mp
iv.dps = 40
BASE = "/Users/kvallier/Desktop/Erdos 993/ProofRuns/2026-09-28_analytic_large_n/LEAN/certfree/"
LC = json.load(open("../outputs/lemma_constants.json")); assert LC["all_ok"]
# theta(lambda) read from the certified band file (theta = gamma_theta - 1; every row PASS)
_o2 = json.load(open(BASE + "o2/outputs/bands/FINAL_bands_v2.json"))
assert len(_o2) == 31 and all(x["PASS"] for x in _o2)
bands = [(x["a"], x["b"], str(Fr(x["gamma"]) - 1)) for x in _o2]
bands = [(Fr(a), Fr(b), Fr(t)) for a, b, t in bands]
# cross-check theta column against the o2 band table (gamma_theta - 1)
tk = json.load(open(BASE + "tail_var/outputs/tail_kappa.json"))
pieces = [(Fr(p["lo"]), Fr(p["hi"]), Fr(p["rate"])) for p in tk["pieces"]]
Dst = [(Fr(1,3), Fr(263,200), Fr(6,5)), (Fr(263,200), Fr(3,2), Fr(7,5)), (Fr(3,2), Fr(7,4), Fr(8,5)),
       (Fr(7,4), Fr(2), Fr(9,5)), (Fr(2), Fr(7,3), Fr(21,10))]
bps = sorted(set([x for b in bands for x in b[:2]] + [x for p in pieces for x in p[:2]] + [x for d in Dst for x in d[:2]]))
atoms = []
for a, b in zip(bps[:-1], bps[1:]):
    mid = (a + b) / 2
    pick = lambda L: [x for x in L if x[0] <= mid <= x[1]][0]
    bi = [i for i, x in enumerate(bands) if x[0] <= mid <= x[1]][0]
    atoms.append(dict(lo=a, hi=b, band=bi, theta=pick(bands)[2], ell=pick(pieces)[2], D=pick(Dst)[2]))
RHOS = [Fr(r) for r in LC["envelope_Gamma"]]
U0S = [5.5, 6, 7, 8, 9, 10, 11, 12, 14, 16, 20, 25]  # u0 >= 5.44 needed (monotonicity of u^(5/2) e^(-0.4596u))
def consts(rho):
    I = LC["inverse_powers"][str(rho)]
    return dict(GE=Fr(LC["envelope_Gamma"][str(rho)]), G1=Fr(I["1"]), G32=Fr(I["3/2"]), G2=Fr(I["2"]), G52=Fr(I["5/2"]), k=Fr(I["k"]))
def fourier(u0, X):
    """K_m, K_c, a1, a3 for u >= u0 (X = math module or iv)."""
    pi = X.pi; sq = X.sqrt(pi); u0 = X.mpf(u0) if X is iv else float(u0)
    c = (X.mpf(43) / 96 if X is iv else 43 / 96) * (1 - 1 / (4 * u0))
    a1 = 1 / (12 * pi * c**2); a3 = 1 / (6 * pi * c**3)
    a2 = 15 / (768 * sq) * c**(-2.5 if X is math else -X.mpf(5)/2)
    a4 = 75 / (1536 * sq) * c**(-3.5 if X is math else -X.mpf(7)/2) + 15 / (384 * sq) * c**(-2.5 if X is math else -X.mpf(5)/2)
    t1 = (X.mpf('0.6817') if X is iv else 0.6817); t2 = (X.mpf('0.6268') if X is iv else 0.6268); kp = (X.mpf('0.4596') if X is iv else 0.4596)
    Km = a2 + u0**1.5 * (t1 * X.exp(-kp * u0) + X.exp(-u0 / 2) / (pi * u0))
    Kc = a4 + u0**2.5 * (t2 * X.exp(-kp * u0) + X.exp(-u0 / 2) * (1 + 1 / u0) / (pi * u0))
    return Km, Kc, a1, a3
def Psi(at, m, rho, u0, X=math, detail=False):
    C = consts(rho)
    F = (lambda fr: X.mpf(fr.numerator) / fr.denominator) if X is iv else (lambda fr: float(fr))
    la, lb = F(at["lo"]), F(at["hi"])
    qa, qb = la / (1 + la), lb / (1 + lb)
    half_in = at["lo"] <= 1 <= at["hi"]
    # exact rational d and v bounds
    qa_r, qb_r = at["lo"] / (1 + at["lo"]), at["hi"] / (1 + at["hi"])
    dmax_r = max(abs(1 - 2 * qa_r), abs(1 - 2 * qb_r)); dmin_r = Fr(0) if half_in else min(abs(1 - 2 * qa_r), abs(1 - 2 * qb_r))
    vs = [qa_r * (1 - qa_r), qb_r * (1 - qb_r)] + ([Fr(1, 4)] if half_in else [])
    vmin_r, vmax_r = min(vs), max(vs)
    dmax, dmin, vmin, vmax = F(dmax_r), F(dmin_r), F(vmin_r), F(vmax_r)
    th, D, ell = F(at["theta"]), F(at["D"]), F(at["ell"])
    GE, G1, G32, G2, G52, k = [F(C[x]) for x in ("GE", "G1", "G32", "G2", "G52", "k")]
    m = F(Fr(m)); rh = F(rho)
    if not (float(rho * vmin_r) * float(m) >= u0): return None
    r = ell - rh * X.log(1 + lb)
    if (float(r.a) if X is iv else r) <= 0: return None
    Km, Kc, a1, a3 = fourier(u0, X)
    eps = D / m; s2 = vmin * m; s = X.sqrt(s2)
    aG = X.exp(-X.mpf(1) / 2 if X is iv else -0.5) / X.sqrt(2 * X.pi)
    curv = aG * (1 - th - GE * eps) - a3 * dmax / s * (1 + G2 * eps) - Kc / s2 * (1 + G52 * eps)
    H = X.exp(-th / 2) / X.sqrt(2 * X.pi)
    beta = H * (1 - (X.mpf(3) / 2 if X is iv else 1.5) * k * eps) - a1 * dmax / s * (1 + G1 * eps) - Km / s2 * (1 + G32 * eps)
    # margin = Psi_C - sb^3 P + (d^2 m (beta - C_b P))^+ , bounded below uniformly over the atom
    Cb = H * max(F(Fr(3, 2)), 1 + th / 2) if X is math else H * (1 + th / 2 if at["theta"] >= 1 else X.mpf(3) / 2)
    tail1 = (vmax * m)**(1.5 if X is math else X.mpf(3) / 2) * X.exp(-r * m)
    if dmin_r > 0:
        g = dmin**2 * m * beta - tail1 * (dmax**2 / vmin) * Cb / s   # lower bound of d^2 m (beta - C_b P)
        gl = float(g.a) if X is iv else g
        mass = g if gl > 0 else 0
    else:
        g = None; mass = 0
    tail = tail1
    val = curv + mass - tail1
    if detail: return dict(curv=curv, mass=mass, tail=tail, r=r, beta=beta, val=val)
    return val
def lowest_m(at, rho, u0):
    lo, hi = 1, 100000
    f = lambda m: (Psi(at, m, rho, u0) or -1) > 0
    if not f(hi): return None
    while hi - lo > 1:
        mid = (lo + hi) // 2
        if f(mid): hi = mid
        else: lo = mid
    return hi
def certify(at, m, rho, u0):
    d = Psi(at, m, rho, u0, X=iv, detail=True)
    ok1 = d["val"].a > 0
    ok2 = float((d["r"] * m).a) >= 1.5
    ok3 = True  # beta, 1-G*eps terms increase with m by construction; u0 condition checked inside Psi
    return bool(ok1 and ok2 and ok3), d
