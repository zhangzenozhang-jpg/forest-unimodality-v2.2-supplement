#!/usr/bin/python3
"""Stage 1 check of the LP truncation (DIAGNOSTIC): theta* at the global least point and at large means with a wider
state window (R = 12 standard deviations, M up to mu + 20 sqrt(D mu) + 60) against the grid's window (R = 7)."""
import sys, json
from pathlib import Path
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from point_lp import theta_star
import math
pts = [  # (iota, q, mu, theta, D, ells)
    (24, 1.0 / (1 + 1.0) * 0 + 1 / (1 + 1 / 1.03), 12.8107, 0.6, 1.2, None),
]
from lean_mgf_data import n44_tables
from handcap import hand_sup
T = n44_tables()
out = []
for i, lamend, mu in [(24, 'hi', 12.8107), (23, 'hi', 113.0), (23, 'hi', 399.0), (0, 'hi', 59.0), (54, 'lo', 81.0)]:
    lam = T['pieceHi'][i] if lamend == 'hi' else T['pieceLo'][i]
    q = float(lam / (1 + lam)); th = float(T['theta44'][i]); D = float(hand_sup(T['pieceLo'][i], T['pieceHi'][i]))
    ells = [float(e) for e in T['rates44'][i]]
    a = theta_star(q, mu, th, D, ells, 'two', R=7.0)
    b = theta_star(q, mu, th, D, ells, 'two', R=12.0, mmax=math.ceil(mu + 20 * math.sqrt(D * mu) + 60))
    c = theta_star(q, mu, th, D, ells, 'kappa', R=7.0)
    rec = dict(iota=i, q=q, mu=mu, theta=th, grid_window=a['theta_star'], wide_window=b['theta_star'],
               kappa_only=c['theta_star'], states=[a['n_states'], b['n_states']])
    out.append(rec); print(rec, flush=True)
(HERE.parent / 'outputs' / 'stage1' / 'sensitivity.json').write_text(json.dumps(out, indent=1) + '\n')
