#!/usr/bin/python3
"""one_criterion_test Stage 2: the MGF criterion on the rectangles [q(lam_lo), q(lam_hi)] x [m_lo, m_hi] of a subinterval
above m_*(iota), with the route's inputs (theta(iota) = Lean theta44, rates ell_r(iota) = Lean rates44, D = the hand cap
D(iota) = sup of D-hat over the subinterval), i.e. R_iota extended upward into the range now covered by the lower-tail
criterion.  Same machinery as upper_d_test/scripts/mgf_hand.py (refereed):
build:  boxes by the producer's certify_box (copy of lane M30's constructor: candidate LP + Arb pass), adaptive splitting;
        writes box_*.json and COVER.json under outputs/stage2/mgf_one/<tag>/strip_XX/ (never overwrites).
check:  (1) the producer's exact replay check_box/check_cover (replay_mgf.py), (2) the independent checker
        check_box/check_cover (indep_mgf_check.py, lane R1's program), both against the rectangle; writes VERIFIED.json.
probe:  one box only (DIAGNOSTIC cost ladder): prints cutoff N, integer states, seconds and margin.
Usage: one_mgf.py build|check tag piece[,piece] m_lo_mode m_hi     (m_lo_mode: 'mstar' or a rational; m_hi: a rational)
       one_mgf.py probe piece q_lo q_hi m_lo m_hi
"""
import sys, os, json, time
from fractions import Fraction as F
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE)); sys.path.insert(0, str(HERE / 'mgf_producer'))
OUT = HERE.parent / 'outputs' / 'stage2' / 'mgf_one'
from lean_mgf_data import n44_tables, qof
from handcap import hand_sup

T = n44_tables()
INV = {x['iota']: x for x in json.loads((HERE.parent / 'outputs' / 'stage0' / 'inventory.json').read_text())['subintervals']}


def hand_D(p):
    return hand_sup(T['pieceLo'][p], T['pieceHi'][p])


def piece_data(p):
    pieces = json.loads((HERE / 'mgf_producer' / 'pieces_N44.json').read_text())
    piece = dict(pieces['pieces'][p])
    assert piece['piece'] == p and [F(x) for x in piece['lam']] == [T['pieceLo'][p], T['pieceHi'][p]]
    assert F(piece['theta']) == T['theta44'][p]
    assert [(F(t), F(e)) for t, e in piece['tilts']] == [(F(t), e) for t, e in zip(['0', '1/20', '1/10', '1/5', '3/10'], T['rates44'][p])]
    piece.update(D=str(hand_D(p)))
    return piece


def rect(p, mlo_mode, mhi):
    ml = F(INV[p]['mstar']) if mlo_mode == 'mstar' else F(mlo_mode)
    return T['pieceLo'][p], T['pieceHi'][p], ml, F(mhi)


def build(tag, p, mlo_mode, mhi, time_budget=1e9):
    import atlas_mgf as A
    lo, hi, ml, mh = rect(p, mlo_mode, mhi)
    piece = piece_data(p)
    ql, qh = qof(lo), qof(hi)
    folder = OUT / tag / ('strip_%02d' % p); folder.mkdir(parents=True, exist_ok=True)
    assert not list(folder.glob('box_*.json')), 'boxes exist; never overwrite'
    pending = [(ql, qh, ml, mh, 0)]; rows = []; tries = 0; t0 = time.time(); holes = []; unfinished = []
    while pending:
        if time.time() - t0 > time_budget:
            unfinished = [[str(a), str(b), str(c), str(d)] for a, b, c, d, e in pending]; break
        lo_, hi_, low, high, depth = pending.pop()
        row = A.certify_box(lo_, hi_, low, high, piece, 44); tries += 1
        c = row['constructor']
        print('  strip %d try %d q [%.5f,%.5f] m [%.3f,%.3f] margin %+.2e N %s states %s %.1fs' % (
            p, tries, float(lo_), float(hi_), float(low), float(high), row['margin_decimal'], row['cutoff'],
            c.get('integer_states'), c.get('seconds', 0)), flush=True)
        if F(row['margin_lower']) > 0:
            (folder / ('box_%06d.json' % len(rows))).write_text(json.dumps(row, indent=1) + '\n'); rows.append(row)
        elif depth >= 30 or (hi_ - lo_ <= F(1, 5000) and high - low <= F(1, 32)):
            holes.append([str(lo_), str(hi_), str(low), str(high)])
        elif c['margin_before_q_repair'] <= 0 and high - low > F(1, 64):
            mid = (low + high) / 2; pending.extend([(lo_, hi_, low, mid, depth + 1), (lo_, hi_, mid, high, depth + 1)])
        elif 4 * (hi_ - lo_) * ((low + high) / 2) ** 2 >= (high - low) or high - low <= F(1, 64):
            mid = (lo_ + hi_) / 2; pending.extend([(lo_, mid, low, high, depth + 1), (mid, hi_, low, high, depth + 1)])
        else:
            mid = (low + high) / 2; pending.extend([(lo_, hi_, low, mid, depth + 1), (lo_, hi_, mid, high, depth + 1)])
    slabs, gaps = A.build_cover(rows, ql, qh, ml, mh)
    cover = dict(claim_label='data (one_criterion_test; verified by one_mgf.py check)', piece=p, lam=[str(lo), str(hi)],
                 q=[str(ql), str(qh)], m=[str(ml), str(mh)], D=str(hand_D(p)), boxes=len(rows), slabs=slabs, gaps=gaps,
                 holes=holes, unfinished=unfinished, full_cover=(not gaps and not holes and not unfinished))
    (folder / 'COVER.json').write_text(json.dumps(cover, indent=1) + '\n')
    print('BUILD %s strip %d [%s,%s] x [%.4f,%.4f] D=%s: %d boxes, %d tries, holes %d, gaps %d, unfinished %d, min margin %s, %.1fs' % (
        tag, p, lo, hi, float(ml), float(mh), hand_D(p), len(rows), tries, len(holes), len(gaps), len(unfinished),
        ('%.2e' % min(r['margin_decimal'] for r in rows)) if rows else '-', time.time() - t0), flush=True)


def checkers(p, D):
    import replay_mgf as R
    import indep_mgf_check as I
    inp = R.strip_inputs(p, 21)
    inp['D'] = D
    I.D_OVERRIDE[p] = D
    Tl = I.lean_tables(); recs = I.lean_records()
    inp2 = I.piece_inputs(p, 21, Tl, recs)
    assert inp2['D'] == D and inp['theta'] == inp2['theta'] == T['theta44'][p]
    return R, I, inp, inp2


def check(tag, p, mlo_mode, mhi):
    lo, hi, ml, mh = rect(p, mlo_mode, mhi)
    D = hand_D(p)
    folder = OUT / tag / ('strip_%02d' % p)
    rows = [json.loads(x.read_text()) for x in sorted(folder.glob('box_*.json'))]
    cover = json.loads((folder / 'COVER.json').read_text())
    assert [F(x) for x in cover['m']] == [ml, mh]
    R, I, inp, inp2 = checkers(p, D)
    t0 = time.time()
    f1 = []; mm1 = None; st1 = 0
    for i, r in enumerate(rows):
        res = R.check_box(R.Box(r), inp, 44, ml, mh)
        if not res[0]:
            f1.append('box %d: %s' % (i, res[3][:3]))
        else:
            mm1 = res[4] if mm1 is None else min(mm1, res[4]); st1 += res[1]
    f1 += R.check_cover(cover, [R.Box(r) for r in rows], qof(lo), qof(hi), ml, mh)
    t1 = time.time()
    f2 = []; mm2 = None
    # time box: if scripts/CHECK_MODE says 'replay', the independent checker is deferred to mode 'check_indep'
    deferred = (HERE / 'CHECK_MODE').exists() and (HERE / 'CHECK_MODE').read_text().strip() == 'replay'
    for i, r in enumerate([] if deferred else rows):
        r = dict(r); r['D'] = str(inp2['D'])
        res = I.check_box(r, inp2, 21, ml, mh, {})
        if not res['ok']:
            f2.append('box %d: %s' % (i, res['failures'][:3]))
        else:
            mm2 = F(res['margin']) if mm2 is None else min(mm2, F(res['margin']))
    if not deferred:
        f2 += I.check_cover(cover, rows, qof(lo), qof(hi), ml, mh)
    out = dict(tag=tag, piece=p, rect=dict(lam=[str(lo), str(hi)], m=[str(ml), str(mh)]), D=str(D), boxes=len(rows),
               full_cover=cover['full_cover'],
               replay=dict(result='PASS' if not f1 else 'FAIL', failures=f1[:10], min_margin=float(mm1) if mm1 else None,
                           integer_states=st1, seconds=round(t1 - t0, 1)),
               independent=dict(result=('DEFERRED' if deferred else ('PASS' if not f2 else 'FAIL')), failures=f2[:10],
                                min_margin=float(mm2) if mm2 else None, seconds=round(time.time() - t1, 1)))
    (folder / ('VERIFIED.json' if not deferred else 'VERIFIED_replay.json')).write_text(json.dumps(out, indent=1) + '\n')
    print('CHECK %s strip %d [%.4f,%.4f] D=%s: %d boxes; replay %s (min margin %s, %d states, %.0fs); independent %s (min margin %s, %.0fs) %s' % (
        tag, p, float(ml), float(mh), D, len(rows), out['replay']['result'], out['replay']['min_margin'], st1, t1 - t0,
        out['independent']['result'], out['independent']['min_margin'], time.time() - t1, (f1 + f2)[:2]), flush=True)
    return out


def check_indep(tag, p, mlo_mode, mhi):
    lo, hi, ml, mh = rect(p, mlo_mode, mhi)
    D = hand_D(p)
    folder = OUT / tag / ('strip_%02d' % p)
    rows = [json.loads(x.read_text()) for x in sorted(folder.glob('box_*.json'))]
    cover = json.loads((folder / 'COVER.json').read_text())
    assert [F(x) for x in cover['m']] == [ml, mh]
    R, I, inp, inp2 = checkers(p, D)
    t1 = time.time(); f2 = []; mm2 = None
    for i, r in enumerate(rows):
        r = dict(r); r['D'] = str(inp2['D'])
        res = I.check_box(r, inp2, 21, ml, mh, {})
        if not res['ok']:
            f2.append('box %d: %s' % (i, res['failures'][:3]))
        else:
            mm2 = F(res['margin']) if mm2 is None else min(mm2, F(res['margin']))
    f2 += I.check_cover(cover, rows, qof(lo), qof(hi), ml, mh)
    out = dict(tag=tag, piece=p, rect=dict(lam=[str(lo), str(hi)], m=[str(ml), str(mh)]), D=str(D), boxes=len(rows),
               independent=dict(result='PASS' if not f2 else 'FAIL', failures=f2[:10], min_margin=float(mm2) if mm2 else None,
                                seconds=round(time.time() - t1, 1)))
    (folder / 'VERIFIED_indep.json').write_text(json.dumps(out, indent=1) + '\n')
    print('INDEP %s strip %d [%.4f,%.4f] D=%s: %d boxes; independent %s (min margin %s, %.0fs) %s' % (
        tag, p, float(ml), float(mh), D, len(rows), out['independent']['result'], out['independent']['min_margin'],
        time.time() - t1, f2[:2]), flush=True)
    return out


def probe(p, ql, qh, ml, mh):
    import atlas_mgf as A
    piece = piece_data(p)
    row = A.certify_box(F(ql), F(qh), F(ml), F(mh), piece, 44)
    c = row['constructor']
    print('PROBE strip %d q [%s,%s] m [%s,%s]: margin %+.3e (pre-q %+.3e, LP th* %.4f) N %s states %s %.1fs gamma %s nu %s a %s b %s' % (
        p, ql, qh, ml, mh, row['margin_decimal'], c['margin_before_q_repair'], c['lp_theta_star'], row['cutoff'],
        c['integer_states'], c['seconds'], (row['dual'] or {}).get('gamma', '-')[:12], (row['dual'] or {}).get('nu', '-')[:12],
        (row['dual'] or {}).get('a', '-')[:8], (row['dual'] or {}).get('b', '-')[:8]), flush=True)
    return row


if __name__ == '__main__':
    mode = sys.argv[1]
    if mode == 'probe':
        probe(int(sys.argv[2]), *sys.argv[3:7])
    else:
        tag = sys.argv[2]
        budget = float(sys.argv[6]) if len(sys.argv) > 6 else 1e9
        for p in [int(x) for x in sys.argv[3].split(',')]:
            if mode == 'build':
                build(tag, p, sys.argv[4], sys.argv[5], budget)
            elif mode == 'check_indep':
                check_indep(tag, p, sys.argv[4], sys.argv[5])
            else:
                check(tag, p, sys.argv[4], sys.argv[5])
