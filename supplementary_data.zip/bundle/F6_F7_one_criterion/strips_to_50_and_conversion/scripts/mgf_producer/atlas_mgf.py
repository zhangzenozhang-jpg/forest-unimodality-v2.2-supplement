"""Lane M30 (referee_verdict: null): the MGF + two-sided atlas CONSTRUCTOR (candidate duals by LP, Arb certification,
adaptive box splitting, exact cover).  A modified copy of LEAN/r3x/r3x_atlas_mgf.py (lane R3X's seed, itself
SOUL/O4/atlas_arb.py with the tail rows in MGF form).  The box theorem it realizes is LEAN/atlas_mgf/ATLAS_MGF_PROOF.md
(SPEC.md v2).  Every accepted box is INDEPENDENTLY replayed by replay_mgf.py in exact rational arithmetic; a box is
CERTIFIED only through that replay (this file's Arb pass and its SUMMARY.json are DIAGNOSTIC).

Changes from the seed:
  * kernel a f_L/q + b f_R/(1-q), a, b >= 0 per box (the exact weak-valley condition), instead of kappa (a = b = 1);
    for 0 <= j <= M it is W(q) P_ab(q) with P_ab = aA(1-q)^2 + bB q^2 (A, B Soul's coefficients), so Soul's q-uniform
    machinery applies with (A, B) -> (aA, bB); at j = -1 the kernel is -b(1-q)^M, at j = M+1 it is -a q^M, else 0;
  * the elementary bound kernel >= -max(a, b) replaces the Fourier bound everywhere (skip radius and infinite tail);
  * per atom the better of Soul's first-order bound (with the exact delta minimum) and Soul's second-order Taylor bound
    (Lean's Atlas/Taylor.lean) is used;
  * the candidate LP is box-aware: E M in [ml, mh], variance rhs D mh + max d^2, MGF rows at s_k(qh) with U_k(ml),
    objective delta^2/(vmax mh); its dual is the box dual up to the q-uniform loss, repaired by lowering alpha;
  * the margin (2') is computed exactly (Fractions), with U_k = 1/sum_{i<=120} x^i/i! >= e^{-x}, x = ell_k ml.
Usage:
  python3 atlas_mgf.py --rung 40 --strip 22 [--ml 12.061 --mh 13.066] [--out rung_40]
  (the strip's m-interval defaults to [floor_N, floor_44] of pieces_N44.json)
"""
from fractions import Fraction as F
from math import comb, ceil, floor, isqrt
from pathlib import Path
import json, time, hashlib, sys, argparse
from flint import arb, ctx

HERE = Path(__file__).resolve().parent
ctx.prec = 128
import os
# one_criterion_test: the floor of gamma in the candidate (1/10^5 in lane M30's constructor) is a parameter, env GAMMA_FLOOR
# (a candidate choice only; the box theorem and the checkers are unchanged).
GAMMA_FLOOR = F(os.environ.get('GAMMA_FLOOR', '1/100000'))


def rationalize(x, den=10 ** 12):
    return F(round(float(x) * den), den)


def exp_negative_upper(x, terms=120):
    """For x >= 0: 1/sum_{i<=terms} x^i/i! >= exp(-x) (an exact rational upper bound of e^{-x})."""
    x = F(x)
    assert x >= 0
    s = term = F(1)
    for i in range(1, terms + 1):
        term *= x / i
        s += term
    return 1 / s


def A(x):
    x = F(x)
    return arb(x.numerator) / arb(x.denominator)


def exact_endpoint(x, upper=False):
    z = x.upper() if upper else x.lower()
    n, e = z.man_exp()
    return F(int(n)) * (F(2) ** int(e))


def amax(values):
    return max(x.upper() for x in values)


def binrow(M, q):
    r = [(1 - q) ** M]
    for j in range(M):
        r.append(r[-1] * (M - j) / (j + 1) * q / (1 - q))
    return r


def quadratic_min(nu, c, lo, hi):
    x = max(lo, min(hi, -c / (2 * nu)))
    return nu * x * x + c * x


def pi_of(M, m0, cert):
    x = M - m0
    return cert['alpha'] + cert['beta'] * x - cert['gamma'] * x * x


def s_of(q, t):
    return 1 - q + q * t


# ----------------------------------------------------------------------------------------------------------------
# candidate search (floating point; chooses, never certifies)

def candidate_two(ql, qh, ml, mh, D, tilts, U):
    """The box-aware LP at (q0, m0) with the two-sided kernel; returns a rational candidate dual."""
    import numpy as np
    from scipy.special import gammaln
    from scipy.optimize import linprog
    q0 = (ql + qh) / 2; m0 = (ml + mh) / 2
    vmax = F(1, 4) if ql <= F(1, 2) <= qh else max(ql * (1 - ql), qh * (1 - qh))
    qf, mlf, mhf, m0f, Df, vmf = map(float, (q0, ml, mh, m0, D, vmax))
    Mmax = int(3 * mhf + 35)
    Ms = np.concatenate([np.full(M + 9, M, dtype=float) for M in range(Mmax + 1)])
    Js = np.concatenate([np.arange(-4, M + 5, dtype=float) for M in range(Mmax + 1)])

    def binom(j):
        ok = (j >= 0) & (j <= Ms)
        jj = np.where(ok, j, 0)
        z = np.exp(gammaln(Ms + 1) - gammaln(jj + 1) - gammaln(Ms - jj + 1) + jj * np.log(qf) + (Ms - jj) * np.log1p(-qf))
        return np.where(ok, z, 0)
    b0, bm, bp = binom(Js), binom(Js - 1), binom(Js + 1)
    fL = ((1 - qf) * b0 - qf * bm) / qf
    fR = (qf * b0 - (1 - qf) * bp) / (1 - qf)
    sL, sR = np.abs(fL).max(), np.abs(fR).max()
    delta = Js - qf * Ms
    dmax = max((mlf - m0f) ** 2, (mhf - m0f) ** 2)
    Aub = [fL / sL, fR / sR, (Ms - m0f) ** 2, Ms, -Ms]
    bub = [0.0, 0.0, Df * mhf + dmax, mhf, -mlf]
    for (t, ell), u in zip(tilts, U):
        s = float(s_of(qh, t))
        Aub.append(s ** Ms); bub.append(float(u))
    res = linprog(delta ** 2 / (vmf * mhf), A_ub=np.array(Aub), b_ub=bub,
                  A_eq=np.array([np.ones_like(Ms), delta]), b_eq=[1.0, 0.0], bounds=(0, None), method='highs')
    assert res.success, res.message
    y = -res.ineqlin.marginals            # >= 0
    yL, yR, yvar, yplus, yminus = y[0] / sL, y[1] / sR, y[2], y[3], y[4]
    yk = list(y[5:])
    lam0, lamd = res.eqlin.marginals
    w = max(yL, yR)
    assert w > 0, 'kernel rows inactive'
    beta_raw = yminus - yplus
    cert = dict(nu=rationalize(1 / (w * vmf * mhf)), c=rationalize(-lamd / w),
                alpha=rationalize((lam0 + beta_raw * m0f) / w) - F(1, 10 ** 8),
                beta=rationalize(beta_raw / w), gamma=max(GAMMA_FLOOR, rationalize(yvar / w)),
                a=min(F(1), max(F(0), rationalize(yL / w))), b=min(F(1), max(F(0), rationalize(yR / w))),
                z=[max(F(0), rationalize(zz / w)) for zz in yk])
    if cert['a'] < cert['b']:
        cert['b'] = F(1)
    else:
        cert['a'] = F(1)
    return cert, float(res.fun)


def point_theta(q, m, D, tilts, kernel='two'):
    """DIAGNOSTIC: the fine-box LP value theta*(q, m) with the MGF rows at (q, m) and the chosen kernel (float)."""
    import numpy as np
    from scipy.special import gammaln
    from scipy.optimize import linprog
    qf, mf, Df = map(float, (q, m, D)); v = qf * (1 - qf)
    Mmax = int(3 * mf + 35)
    Ms = np.concatenate([np.full(M + 9, M, dtype=float) for M in range(Mmax + 1)])
    Js = np.concatenate([np.arange(-4, M + 5, dtype=float) for M in range(Mmax + 1)])

    def binom(j):
        ok = (j >= 0) & (j <= Ms)
        jj = np.where(ok, j, 0)
        z = np.exp(gammaln(Ms + 1) - gammaln(jj + 1) - gammaln(Ms - jj + 1) + jj * np.log(qf) + (Ms - jj) * np.log1p(-qf))
        return np.where(ok, z, 0)
    b0, bm, bp = binom(Js), binom(Js - 1), binom(Js + 1)
    fL = ((1 - qf) * b0 - qf * bm) / qf; fR = (qf * b0 - (1 - qf) * bp) / (1 - qf)
    delta = Js - qf * Ms
    rows = ([fL / np.abs(fL).max(), fR / np.abs(fR).max()] if kernel == 'two' else [(fL + fR) / np.abs(fL + fR).max()])
    rhs = [0.0] * len(rows)
    rows.append((Ms - mf) ** 2); rhs.append(Df * mf)
    import math
    for t, ell in tilts:
        s = float(s_of(F(q), F(t))); rows.append(s ** Ms); rhs.append(math.exp(-float(ell) * mf))
    res = linprog(delta ** 2 / (v * mf), A_ub=np.array(rows), b_ub=rhs, A_eq=np.array([np.ones_like(Ms), Ms, delta]),
                  b_eq=[1.0, mf, 0.0], bounds=(0, None), method='highs')
    return float(res.fun) if res.success else float('nan')


# ----------------------------------------------------------------------------------------------------------------
# the Arb pass: the pointwise inequality (P) uniformly in q on [ql, qh] (DIAGNOSTIC; the exact replay certifies)

def cutoff(m0, cert, Bab):
    N = ceil(m0) + 1
    while pi_of(N, m0, cert) > -Bab - cert['c'] ** 2 / (4 * cert['nu']) or cert['beta'] - 2 * cert['gamma'] * (N - m0) > 0:
        N *= 2
        assert N < 10 ** 6, 'cutoff runaway (gamma too small)'
    return N


def uniform_slack_two(ql, qh, m0, cert, tilts):
    nu, c, gamma, a, b = cert['nu'], cert['c'], cert['gamma'], cert['a'], cert['b']
    assert nu > 0 and gamma > 0 and a >= 0 and b >= 0 and max(a, b) > 0 and all(z >= 0 for z in cert['z'])
    Bab = max(a, b)
    q0 = (ql + qh) / 2; rad = (qh - ql) / 2; arad = A(rad)
    alo, aq, ahi = map(A, (ql, q0, qh))
    sks = [s_of(qh, F(t)) for t, _ in tilts]
    N = cutoff(m0, cert, Bab)
    worst = arb(0); witness = None; checks = 0; used = [0, 0]
    aa_, bb_ = A(a), A(b)
    coefL = (1 - aq) / aq; coefR = aq / (1 - aq)
    W0den = aq * (1 - aq)
    for M in range(N):
        rhs_fraction = pi_of(M, m0, cert) - sum((z * sk ** M for z, sk in zip(cert['z'], sks)), F(0))
        rhs = A(rhs_fraction)
        # outside atoms j <= -2 and j >= M + 2: the kernel vanishes
        for low, high in [(None, F(-2) - ql * M), (F(M + 2) - qh * M, None)]:
            at = -c / (2 * nu)
            if low is not None: at = max(at, low)
            if high is not None: at = min(at, high)
            slack = (A(nu * at * at + c * at) - rhs).lower(); checks += 1
            if slack < worst: worst, witness = slack, [M, 'outside']
        radius2 = (rhs_fraction + Bab + c * c / (4 * nu)) / nu
        if radius2 <= 0:
            continue
        radius_int = isqrt(ceil(radius2)) + 1
        center = -c / (2 * nu)
        jlo = max(-1, floor(ql * M + center - radius_int))
        jhi = min(M + 1, ceil(qh * M + center + radius_int))
        if jlo > jhi:
            continue
        rlo, r0, rhi = [binrow(M, qq) for qq in [alo, aq, ahi]]
        for j in range(jlo, jhi + 1):
            d0 = F(j) - q0 * M
            if j == -1:
                kap = -bb_ * r0[0]
                K1 = bb_ * M * (1 - alo) ** (M - 1) if M else arb(0)
                h1 = bb_ * M * (1 - aq) ** (M - 1) if M else arb(0)          # d/dq of -b(1-q)^M
                K2 = bb_ * M * (M - 1) * (1 - alo) ** (M - 2) if M >= 2 else arb(0)
            elif j == M + 1:
                kap = -aa_ * r0[M]
                K1 = aa_ * M * ahi ** (M - 1) if M else arb(0)
                h1 = -aa_ * M * aq ** (M - 1) if M else arb(0)               # d/dq of -a q^M
                K2 = aa_ * M * (M - 1) * ahi ** (M - 2) if M >= 2 else arb(0)
            else:
                kap = aa_ * (coefL * r0[j] - (r0[j - 1] if j else 0)) + bb_ * (coefR * r0[j] - (r0[j + 1] if j < M else 0))
                Ap = a * F(M + 1 - 2 * j, M - j + 1); Bp = b * F(2 * j + 1 - M, j + 1)
                wvalues = [rlo[j] / (alo * (1 - alo)), rhi[j] / (ahi * (1 - ahi))]
                if M != 2:
                    star = F(j - 1, M - 2)
                    if ql < star < qh:
                        astar = A(star)
                        wvalues.append(comb(M, j) * astar ** j * (1 - astar) ** (M - j) / (astar * (1 - astar)))
                wmax = amax(wvalues)
                ps = [Ap * (1 - qq) ** 2 + Bp * qq ** 2 for qq in [ql, qh]]
                if Ap + Bp:
                    vertex = Ap / (Ap + Bp)
                    if ql < vertex < qh: ps.append(Ap * (1 - vertex) ** 2 + Bp * vertex ** 2)
                pabs = A(max(map(abs, ps)))
                dpabs = A(max(abs(-2 * Ap + 2 * (Ap + Bp) * qq) for qq in [ql, qh]))
                labs = A(max(abs(F(j - 1) / u - F(M - j - 1) / (1 - v)) for u in [ql, qh] for v in [ql, qh]))
                lpabs = A(abs(F(j - 1)) / (ql * ql) + abs(F(M - j - 1)) / ((1 - qh) * (1 - qh)))
                K1 = wmax * (dpabs + labs * pabs)
                W0 = r0[j] / W0den
                P0 = A(Ap * (1 - q0) ** 2 + Bp * q0 ** 2); dP0 = A(-2 * Ap + 2 * (Ap + Bp) * q0)
                L0 = A(F(j - 1) / q0 - F(M - j - 1) / (1 - q0))
                h1 = W0 * (dP0 + L0 * P0)
                K2 = wmax * (A(abs(2 * (Ap + Bp))) + 2 * labs * dpabs + (labs * labs + lpabs) * pabs)
            # first order: kernel(q) >= kernel(q0) - rad K1, plus the exact minimum of nu d^2 + c d over the box
            qmin = quadratic_min(nu, c, F(j) - qh * M, F(j) - ql * M)
            s1 = (kap - arad * K1 + A(qmin) - rhs).lower()
            # second order on h = kernel + c d + nu d^2: h(q0) - rad |h'(q0)| - rad^2/2 (K2 + 2 nu M^2)
            hq0 = kap + A(nu * d0 * d0 + c * d0)
            dh = h1 - A(M * (c + 2 * nu * d0))
            s2 = (hq0 - arad * abs(dh) - arad * arad * (K2 + A(2 * nu * M * M)) / 2 - rhs).lower()
            slack = max(s1, s2); checks += 1
            used[0 if s1 >= s2 else 1] += 1
            if slack < worst: worst, witness = slack, [M, j]
    return exact_endpoint(worst), witness, N, checks, used


def margin_exact(ql, qh, ml, mh, cert, theta, D, tilts):
    m0 = (ml + mh) / 2
    U = [exp_negative_upper(F(ell) * ml) for _, ell in tilts]
    dmax = max((ml - m0) ** 2, (mh - m0) ** 2)
    bterm = min(cert['beta'] * (ml - m0), cert['beta'] * (mh - m0))
    vmax = F(1, 4) if ql <= F(1, 2) <= qh else max(ql * (1 - ql), qh * (1 - qh))
    margin = cert['alpha'] + bterm - cert['gamma'] * (D * mh + dmax) - cert['nu'] * theta * vmax * mh
    margin -= sum((z * u for z, u in zip(cert['z'], U)), F(0))
    return margin, U


def certify_box(ql, qh, ml, mh, piece, rung):
    theta, D = F(piece['theta']), F(piece['D'])
    tilts = [(F(t), F(e)) for t, e in piece['tilts']]
    m0 = (ml + mh) / 2
    U = [exp_negative_upper(ell * ml) for _, ell in tilts]
    t0 = time.time()
    try:
        cert, opt = candidate_two(ql, qh, ml, mh, D, tilts, U)
    except (AssertionError, ValueError) as err:
        return dict(claim_label='DIAGNOSTIC', referee_verdict=None, rung=rung, strip=piece['piece'], piece=piece['piece'],
                    band=piece['band'], lam=piece['lam'], q=[str(ql), str(qh)], m=[str(ml), str(mh)], m0=str(m0),
                    theta=str(theta), D=str(D), tilts=[[str(t), str(e)] for t, e in tilts], dual=None, cutoff=None, U=None,
                    margin_lower='-1', margin_decimal=-1.0,
                    constructor=dict(error='candidate LP failed: %s' % err, margin_before_q_repair=-1.0, lp_theta_star=float('nan'),
                                     integer_states=0, seconds=round(time.time() - t0, 2)))
    margin0, _ = margin_exact(ql, qh, ml, mh, cert, theta, D, tilts)
    # Easy boxes (theta* far above the cap) leave the variance row inactive and gamma at its floor, which pushes the
    # cutoff N and the state count up.  Spend at most a quarter of the margin on gamma: the box theorem is unchanged.
    dmax = max((ml - m0) ** 2, (mh - m0) ** 2)
    gamma_min = margin0 / (4 * (D * mh + dmax)) if margin0 > 0 else F(0)
    if cert['gamma'] < gamma_min:
        cert['gamma'] = rationalize(gamma_min)
        margin0, _ = margin_exact(ql, qh, ml, mh, cert, theta, D, tilts)
    worst, witness, N, checks, used = uniform_slack_two(ql, qh, m0, cert, tilts)
    alpha_change = F(0)
    if worst < 0:
        alpha_change = worst - F(1, 10 ** 12)
        cert['alpha'] += alpha_change
    N = cutoff(m0, cert, max(cert['a'], cert['b']))
    margin, U = margin_exact(ql, qh, ml, mh, cert, theta, D, tilts)
    return dict(claim_label='DIAGNOSTIC (constructor pass; CERTIFIED only through replay_mgf.py)', referee_verdict=None,
                rung=rung, strip=piece['piece'], piece=piece['piece'], band=piece['band'], lam=piece['lam'],
                q=[str(ql), str(qh)], m=[str(ml), str(mh)], m0=str(m0), theta=str(theta), D=str(D),
                tilts=[[str(t), str(e)] for t, e in tilts],
                dual={k: ([str(x) for x in v] if isinstance(v, list) else str(v)) for k, v in cert.items()},
                cutoff=N, U=[str(u) for u in U], margin_lower=str(margin), margin_decimal=float(margin),
                constructor=dict(arb_precision=128, integer_states=checks, worst_atom=witness,
                                 raw_worst_slack=str(worst), alpha_adjustment=str(alpha_change),
                                 margin_before_q_repair=float(margin0), lp_theta_star=opt,
                                 bounds_used=dict(first=used[0], second=used[1]), seconds=round(time.time() - t0, 2)))


# ----------------------------------------------------------------------------------------------------------------
# cover

def build_cover(rows, ql, qh, ml, mh):
    """Slabs between consecutive q-edges; per slab a greedy chain of boxes containing the slab covering [ml, mh]."""
    qe = sorted(set([ql, qh] + [F(x) for row in rows for x in row['q']]))
    assert qe[0] == ql and qe[-1] == qh
    slabs = []; gaps = []
    for left, right in zip(qe, qe[1:]):
        cand = sorted(((F(row['m'][0]), F(row['m'][1]), i) for i, row in enumerate(rows)
                       if F(row['q'][0]) <= left and right <= F(row['q'][1])))
        chain = []; tip = ml
        while tip < mh:
            best = None
            for a, b, i in cand:
                if a <= tip and b > tip and (best is None or b > best[1]):
                    best = (a, b, i)
            if best is None:
                nxt = min([a for a, b, i in cand if a > tip] + [mh])
                gaps.append(dict(q=[str(left), str(right)], m=[str(tip), str(nxt)]))
                tip = nxt
                continue
            chain.append(best[2]); tip = best[1]
        slabs.append(dict(lo=str(left), hi=str(right), chain=chain))
    return slabs, gaps


# ----------------------------------------------------------------------------------------------------------------
# driver

def run_strip(rung, p, out_root, ml=None, mh=None, max_depth=40, time_budget=3600, reuse=None, caps=None,
              min_qw=F(1, 5000), min_mw=F(1, 32), fill=False):
    pieces = json.loads((HERE / 'pieces_N44.json').read_text())
    piece = pieces['pieces'][p]
    caps_info = None
    if caps:
        # a caps table (theta, D, tilts per piece) replacing Lean's N44 table where a rung has new certified rows
        ct = json.loads((HERE / caps).read_text()); cp = ct['pieces'][p]
        assert cp['piece'] == p and cp['lam'] == piece['lam']
        piece = dict(piece, theta=cp['theta'], D=cp['D'], tilts=cp['tilts'])
        caps_info = dict(caps_file=str(caps), caps_sha256=hashlib.sha256((HERE / caps).read_bytes()).hexdigest(),
                         D_source=cp.get('D_source'))
    lo, hi = map(F, piece['lam']); ql, qh = lo / (1 + lo), hi / (1 + hi)
    floorN = F(piece['floors'][str(rung)]['m']); floor44 = F(piece['floors']['44']['m'])
    strip_ml, strip_mh = floorN, floor44                      # the rung's rectangle in m
    folder = HERE / out_root / f'strip_{p:02d}'
    folder.mkdir(parents=True, exist_ok=True)
    if list(folder.glob('box_*.json')) and not fill:
        raise RuntimeError('boxes already exist in %s; choose another --out (this lane never deletes files)' % folder)
    reused = []; rows = []
    if fill:
        # hole filling: keep every existing box, construct only over the holes of FAILED.json with finer minimum sizes
        failed = json.loads((folder / 'FAILED.json').read_text())
        src = json.loads((folder / 'SOURCE.json').read_text())
        reused = src.get('reused_boxes') or []
        rows = [json.loads(pth.read_text()) for pth in sorted(folder.glob('box_*.json'))]
        holes0 = failed['holes'] + [dict(q=g['q'], m=g['m']) for g in failed.get('gaps', []) if not any(
            F(h['q'][0]) <= F(g['q'][0]) and F(g['q'][1]) <= F(h['q'][1]) and F(h['m'][0]) <= F(g['m'][0]) and F(g['m'][1]) <= F(h['m'][1]) for h in failed['holes'])]
        assert not failed.get('unfinished'), 'unfinished boxes present; rerun the strip'
        pending = [(F(h['q'][0]), F(h['q'][1]), F(h['m'][0]), F(h['m'][1]), 0) for h in holes0]
        src.update(fill_of=dict(holes=holes0, min_qw=str(min_qw), min_mw=str(min_mw)))
        (folder / 'SOURCE.json').write_text(json.dumps(src, indent=1) + '\n')
        ml, mh = strip_ml, strip_mh
    elif reuse:
        # reuse an adopted rung's boxes UNCHANGED (byte-identical copies, same file names); new boxes only below them
        src_dir = HERE / reuse / f'strip_{p:02d}'
        src_cover = json.loads((src_dir / 'COVER.json').read_text())
        src_ver = json.loads((src_dir / 'VERIFIED.json').read_text())
        assert src_ver['result'] == 'PASS' and src_cover['full_cover'] and not src_cover.get('empty_strip'), (reuse, p)
        src_ml, src_mh = map(F, src_cover['m'])
        assert src_mh == floor44 and src_ml >= strip_ml, (p, src_ml, strip_ml)
        for pth in sorted(src_dir.glob('box_*.json')):
            data = pth.read_bytes(); (folder / pth.name).write_bytes(data)
            reused.append(dict(file=pth.name, source=str(pth.relative_to(HERE)), sha256=hashlib.sha256(data).hexdigest()))
            rows.append(json.loads(data))
        ml = strip_ml if ml is None else F(ml); mh = src_ml if mh is None else F(mh)     # the new range
    else:
        ml = floorN if ml is None else F(ml); mh = floor44 if mh is None else F(mh)
    if not fill:
        src = dict(claim_label='data', referee_verdict=None, lane='M30', rung=rung, strip=p, piece=p, band=piece['band'],
                   lam=piece['lam'], q=[str(ql), str(qh)], m=[str(strip_ml), str(strip_mh)], floor_N=piece['floors'][str(rung)],
                   floor_44=piece['floors']['44'], theta=piece['theta'], D=piece['D'], tilts=piece['tilts'],
                   pieces_sha256=hashlib.sha256((HERE / 'pieces_N44.json').read_bytes()).hexdigest(),
                   reused_from=(reuse and str(Path(reuse) / f'strip_{p:02d}')), reused_boxes=reused,
                   new_range=[str(ml), str(mh)], caps=caps_info)
        (folder / 'SOURCE.json').write_text(json.dumps(src, indent=1) + '\n')
    if reuse and ml >= mh and not fill:
        slabs, gaps = build_cover(rows, ql, qh, strip_ml, strip_mh)
        assert not gaps, gaps
        cover = dict(claim_label='data (exact rational edges; verified by replay_mgf.py)', referee_verdict=None, rung=rung,
                     strip=p, piece=p, band=piece['band'], lam=piece['lam'], q=[str(ql), str(qh)], m=[str(strip_ml), str(strip_mh)],
                     boxes=len(rows), reused_boxes=len(reused), new_boxes=0, slabs=slabs, full_cover=True, empty_strip=False, gaps=[])
        (folder / 'COVER.json').write_text(json.dumps(cover, indent=1) + '\n')
        summary = dict(claim_label='DIAGNOSTIC', referee_verdict=None, rung=rung, strip=p, boxes=len(rows), reused_boxes=len(reused),
                       new_boxes=0, tries=0, slabs=len(slabs), integer_states=sum(r['constructor']['integer_states'] for r in rows),
                       min_margin=min(r['margin_decimal'] for r in rows), seconds=0.0, full_cover=True, holes=0, unfinished=0,
                       constructor_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), needs_exact_replay=True)
        (folder / 'SUMMARY.json').write_text(json.dumps(summary, indent=1) + '\n')
        print('strip %2d REUSED %d boxes of %s (floor_%d = floor of the reused rung: no new boxes)' % (p, len(rows), reuse, rung), flush=True)
        return
    if ml >= mh and not fill:
        cover = dict(claim_label='data', referee_verdict=None, rung=rung, strip=p, piece=p, lam=piece['lam'],
                     q=[str(ql), str(qh)], m=[str(ml), str(mh)], boxes=0, slabs=[], full_cover=True,
                     empty_strip=True, note='floor_%d >= floor_44: the N44 route applies from floor_%d; no boxes needed' % (rung, rung))
        (folder / 'COVER.json').write_text(json.dumps(cover, indent=1) + '\n')
        print('strip', p, 'empty (floor_%d = %s >= floor_44 = %s)' % (rung, ml, mh), flush=True)
        return
    if not fill:
        pending = [(ql, qh, ml, mh, 0)]
    tries = 0; start = time.time(); holes = []; unfinished = []
    while pending:
        if time.time() - start > time_budget:
            unfinished = [dict(q=[str(a), str(b)], m=[str(c_), str(d_)], depth=e) for a, b, c_, d_, e in pending]
            print('strip %d: time budget exhausted with %d pending boxes' % (p, len(pending)), flush=True)
            break
        lo_, hi_, low, high, depth = pending.pop()
        row = certify_box(lo_, hi_, low, high, piece, rung); tries += 1
        ok = F(row['margin_lower']) > 0
        if ok:
            (folder / f'box_{len(rows):06d}.json').write_text(json.dumps(row, indent=1) + '\n'); rows.append(row)
        elif depth >= max_depth or (hi_ - lo_ <= min_qw and high - low <= min_mw):
            # a hole: the fine-box limit itself (or the budget) fails here; diagnose and leave it uncovered
            q0 = (lo_ + hi_) / 2; m0 = (low + high) / 2
            th = F(piece['theta']); Dp = F(piece['D']); tl = [(F(t), F(e)) for t, e in piece['tilts']]
            two = point_theta(q0, m0, Dp, tl, 'two'); kap = point_theta(q0, m0, Dp, tl, 'kappa')
            holes.append(dict(q=[str(lo_), str(hi_)], m=[str(low), str(high)], lam=[str(lo_ / (1 - lo_)), str(hi_ / (1 - hi_))],
                              theta_cap=str(th), theta_star_two_sided=two, theta_star_kappa=kap, deficit=float(th) - two,
                              lever=('two-sided kernel closes it in the fine-box limit (box loss only)' if two > float(th) else
                                     ('MGF rows alone would not close; two-sided kernel insufficient by %.4f in theta' % (float(th) - two))),
                              box_margin=row['margin_decimal'], depth=depth))
            print('strip %d HOLE q [%.6f, %.6f] m [%.4f, %.4f]: theta* two %.4f kappa %.4f cap %s' % (
                p, float(lo_), float(hi_), float(low), float(high), two, kap, th), flush=True)
        elif row['constructor']['margin_before_q_repair'] <= 0 and high - low > F(1, 64):
            mid = (low + high) / 2; pending.extend([(lo_, hi_, low, mid, depth + 1), (lo_, hi_, mid, high, depth + 1)])
        elif 4 * (hi_ - lo_) * ((low + high) / 2) ** 2 >= (high - low) or high - low <= F(1, 64):
            mid = (lo_ + hi_) / 2; pending.extend([(lo_, mid, low, high, depth + 1), (mid, hi_, low, high, depth + 1)])
        else:
            mid = (low + high) / 2; pending.extend([(lo_, hi_, low, mid, depth + 1), (lo_, hi_, mid, high, depth + 1)])
        c = row['constructor']
        print('strip %2d try %3d acc %3d pend %2d q [%.6f, %.6f] m [%.4f, %.4f] margin %+.2e (pre-q %+.2e, LP th* %.4f, a %s b %s) states %d N %s %.1fs' % (
            p, tries, len(rows), len(pending), float(lo_), float(hi_), float(low), float(high), row['margin_decimal'],
            c['margin_before_q_repair'], c['lp_theta_star'], (row['dual'] or {}).get('a', '-')[:6], (row['dual'] or {}).get('b', '-')[:6], c['integer_states'], row['cutoff'], time.time() - start), flush=True)
    slabs, gaps = build_cover(rows, ql, qh, strip_ml, strip_mh)
    full = not gaps and not holes and not unfinished
    cover = dict(claim_label='data (exact rational edges; verified by replay_mgf.py)', referee_verdict=None, rung=rung,
                 strip=p, piece=p, band=piece['band'], lam=piece['lam'], q=[str(ql), str(qh)], m=[str(strip_ml), str(strip_mh)],
                 boxes=len(rows), reused_boxes=len(reused), new_boxes=len(rows) - len(reused), slabs=slabs, full_cover=full,
                 empty_strip=False, gaps=gaps)
    (folder / 'COVER.json').write_text(json.dumps(cover, indent=1) + '\n')
    if not full or fill:
        (folder / 'FAILED.json').write_text(json.dumps(dict(claim_label='DIAGNOSTIC', referee_verdict=None, rung=rung, strip=p,
                                                            piece=p, lam=piece['lam'], theta=piece['theta'], D=piece['D'],
                                                            holes=holes, unfinished=unfinished, gaps=gaps,
                                                            filled=(json.loads((folder / 'SOURCE.json').read_text()).get('fill_of') if fill else None),
                                                            note=('holes of the first pass filled with finer boxes; none remain' if fill and full else None)), indent=1) + '\n')
    summary = dict(claim_label='DIAGNOSTIC', referee_verdict=None, rung=rung, strip=p, boxes=len(rows), reused_boxes=len(reused),
                   new_boxes=len(rows) - len(reused), tries=tries,
                   slabs=len(slabs), integer_states=sum(r['constructor']['integer_states'] for r in rows),
                   min_margin=(min(r['margin_decimal'] for r in rows) if rows else None), seconds=round(time.time() - start, 1),
                   full_cover=full, holes=len(holes), unfinished=len(unfinished),
                   constructor_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                   seed_sha256=None,   # act1_test copy: the seed file is not copied
                   needs_exact_replay=True)
    (folder / 'SUMMARY.json').write_text(json.dumps(summary, indent=1) + '\n')
    print('strip %2d %s boxes %d slabs %d tries %d states %d min margin %s holes %d unfinished %d %.1fs' % (
        p, 'DONE' if full else 'INCOMPLETE', len(rows), len(slabs), tries, summary['integer_states'],
        ('%.2e' % summary['min_margin']) if rows else '-', len(holes), len(unfinished), summary['seconds']), flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--rung', type=int, required=True)
    ap.add_argument('--strip', type=str, required=True, help='index, or a comma list, or lo-hi')
    ap.add_argument('--ml'); ap.add_argument('--mh'); ap.add_argument('--out')
    ap.add_argument('--reuse', help='root of an adopted rung whose boxes are reused unchanged (e.g. rung_27)')
    ap.add_argument('--caps', help='caps table (theta, D, tilts per piece) overriding Lean\'s N44 table, e.g. rung_21/CAPS_N21.json')
    ap.add_argument('--no-reuse-for', default='', help='comma list of strips built over their whole rectangle even with --reuse (their caps changed)')
    ap.add_argument('--fill-holes', action='store_true', help='keep the existing boxes; construct only over FAILED.json holes with finer minimum sizes')
    ap.add_argument('--min-qw', default='1/5000'); ap.add_argument('--min-mw', default='1/32')
    args = ap.parse_args()
    if '-' in args.strip:
        a, b = args.strip.split('-'); strips = list(range(int(a), int(b) + 1))
    else:
        strips = [int(x) for x in args.strip.split(',')]
    out = args.out or f'rung_{args.rung}'
    for p in strips:
        no_reuse = {int(x) for x in args.no_reuse_for.split(',') if x}
        run_strip(args.rung, p, out, args.ml, args.mh, reuse=(None if p in no_reuse else args.reuse), caps=args.caps,
                  min_qw=F(args.min_qw), min_mw=F(args.min_mw), fill=args.fill_holes)


if __name__ == '__main__':
    main()
