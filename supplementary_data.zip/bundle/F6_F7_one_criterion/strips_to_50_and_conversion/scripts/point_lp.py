#!/usr/bin/python3
"""one_criterion_test Stage 1 (DIAGNOSTIC, floating point): the pointwise LP of the MGF criterion.
theta*(q, mu) = min E delta^2/(q(1-q) mu) over probability mixtures on states (M, j) with E M = mu, E delta = 0,
E (M-mu)^2 <= D mu, E s_r^M <= exp(-ell_r mu) (s_r = 1-q+q tau_r, r < 5), and a valley at k:
  kernel 'two'  : E f_L <= 0 and E f_R <= 0   (the exact valley; the MGF criterion with free w_L, w_R)
  kernel 'kappa': E (f_L/q + f_R/(1-q)) <= 0  (the sum only; MGF certificates with w_L = w_R, as the lower-tail criterion
                  and the large-mean theorem use).
The MGF criterion at (q, mu, theta, D, ell) has a certificate (in the fine-box limit) iff theta*(q, mu) > theta (LP duality;
the primal of the MGF certificate).  States: 0 <= M <= Mmax = mu + 12 sqrt(D mu) + 30, j within q M +- (R sqrt(qM(1-q)) + 6)
clipped to [-1, M+1] (other states have kernel ~0 and cost delta^2).  Returns theta* and the optimal mixture's support size.
"""
import numpy as np, math, sys, json, time
from scipy.special import gammaln
from scipy.optimize import linprog

TAUS = [0.0, 0.05, 0.1, 0.2, 0.3]


def states(q, mu, D, R=8.0, mmax=None):
    v = q * (1 - q)
    Mmax = int(mmax if mmax is not None else math.ceil(mu + 12 * math.sqrt(D * mu) + 30))
    Ms, Js = [], []
    for M in range(Mmax + 1):
        rad = R * math.sqrt(max(M * v, 1.0)) + 6
        lo = max(-1, int(math.floor(q * M - rad))); hi = min(M + 1, int(math.ceil(q * M + rad)))
        js = np.arange(lo, hi + 1)
        Ms.append(np.full(js.size, M)); Js.append(js)
    return np.concatenate(Ms).astype(float), np.concatenate(Js).astype(float)


def binom(Ms, j, q):
    ok = (j >= 0) & (j <= Ms)
    jj = np.where(ok, j, 0)
    z = np.exp(gammaln(Ms + 1) - gammaln(jj + 1) - gammaln(Ms - jj + 1) + jj * math.log(q) + (Ms - jj) * math.log1p(-q))
    return np.where(ok, z, 0.0)


def theta_star(q, mu, theta_cap, D, ells, kernel='two', R=8.0, mmax=None, want_mixture=False):
    Ms, Js = states(q, mu, D, R, mmax)
    b0, bm, bp = binom(Ms, Js, q), binom(Ms, Js - 1, q), binom(Ms, Js + 1, q)
    fL = ((1 - q) * b0 - q * bm) / q
    fR = (q * b0 - (1 - q) * bp) / (1 - q)
    delta = Js - q * Ms
    v = q * (1 - q)
    if kernel == 'two':
        rows = [fL / np.abs(fL).max(), fR / np.abs(fR).max()]
    else:
        k = fL + fR; rows = [k / np.abs(k).max()]
    rhs = [0.0] * len(rows)
    rows.append((Ms - mu) ** 2 / (D * mu)); rhs.append(1.0)
    for t, ell in zip(TAUS, ells):
        s = 1 - q + q * t
        # row: sum_w s^M exp(ell mu) <= 1; coefficients clipped to [1e-9, 1e6] (above: lowered; below: set to 0).
        # Both clips RELAX the primal (allow more mixtures), so theta* is only lowered: a pass stays a pass.
        c = np.exp(np.minimum(Ms * math.log(s) + ell * mu, math.log(1e6)))
        c[c < 1e-9] = 0.0
        rows.append(c); rhs.append(1.0)
    A_eq = np.array([np.ones_like(Ms), (Ms - mu) / mu, delta / math.sqrt(v * mu)])
    res = linprog(delta ** 2 / (v * mu), A_ub=np.array(rows), b_ub=rhs, A_eq=A_eq, b_eq=[1.0, 0.0, 0.0],
                  bounds=(0, None), method='highs')
    if not res.success:
        return dict(theta_star=float('nan'), status=res.message, n_states=int(Ms.size))
    out = dict(theta_star=float(res.fun), n_states=int(Ms.size), support=int((res.x > 1e-12).sum()),
               ratio=float(res.fun) / float(theta_cap))
    if want_mixture:
        idx = np.nonzero(res.x > 1e-12)[0]
        out['mixture'] = [[int(Ms[i]), int(Js[i]), float(res.x[i])] for i in idx]
        out['duals'] = dict(ineq=[float(x) for x in res.ineqlin.marginals], eq=[float(x) for x in res.eqlin.marginals])
    return out


if __name__ == '__main__':
    q, mu, th, D = float(sys.argv[1]), float(sys.argv[2]), float(sys.argv[3]), float(sys.argv[4])
    ells = [float(x) for x in sys.argv[5].split(',')]
    for ker in ['two', 'kappa']:
        t0 = time.time(); r = theta_star(q, mu, th, D, ells, ker)
        print(ker, r, '%.1fs' % (time.time() - t0))
