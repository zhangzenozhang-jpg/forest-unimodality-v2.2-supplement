#!/bin/bash
# one_criterion_test Stage 2, second pass: the independent exact checker (lane R1) on the strips of one shard (nice 10).
cd "$(dirname "$0")"
k=$1
for p in $(python3 -c "import json; print(' '.join(map(str, json.load(open('shards_to50.json'))[$k])))"); do
  nice -n 10 python3 one_mgf.py check_indep to50 $p mstar 50 >> ../outputs/stage2/indep_to50_shard$k.log 2>&1
done
echo "indep shard $k done $(date)" >> ../outputs/stage2/indep_to50_shard$k.log
