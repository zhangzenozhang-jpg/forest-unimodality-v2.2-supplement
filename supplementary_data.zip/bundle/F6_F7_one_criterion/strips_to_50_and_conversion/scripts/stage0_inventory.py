#!/usr/bin/python3
"""one_criterion_test Stage 0: per subinterval iota of v2.0, the mean range now assigned to the lower-tail criterion
(T1), [m_*(iota), 400), and the T1 coverings that serve it (orders 44, 45, 48, 52, 61, coarse [m_61,50], [50,400]).
Reads: v2.0 apx_tables.tex (m_25, m_*, theta, D, ell_0 per subinterval), Lean data via lean_mgf_data (read only), and
upper_d_test's parsed coverings.pkl (the 178 Lean coverings).  Writes outputs/stage0/inventory.json and a text table."""
import re, json, pickle, sys
from fractions import Fraction as F
from pathlib import Path
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from lean_mgf_data import n44_tables
from handcap import hand_sup
LEAN = HERE.parents[2]
V20 = LEAN / 'for_tong' / 'TWIN_v2.0' / 'apx_tables.tex'
COV = LEAN / 'certfree' / 'upper_d_test' / 'outputs' / 'stage1' / 'coverings.pkl'
OUT = HERE.parent / 'outputs' / 'stage0'


def frac(s):
    s = s.strip().strip('$').replace('\\,', '')
    if '/' in s:
        a, b = s.split('/'); return F(int(a), int(b))
    return F(int(s))


def v20_table():
    t = V20.read_text()
    i = t.index('\\label{apA:tab:extra}'); t2 = t[i:]
    rows = {}
    for line in t2.splitlines():
        m = re.match(r'^(\d+) & (\d+) & \$\[(.*?),\\,(.*?)\]\$ & \$(.*?)\$ & \$(.*?)\$ & \$(.*?)\$ & \$(.*?)\$ & \$(.*?)\$ & (\d+) & (\d+) &\s*(\d*)\s*\\\\', line)
        if m:
            g = m.groups()
            rows[int(g[0])] = dict(band=int(g[1]), lam=[frac(g[2]), frac(g[3])], theta=frac(g[4]), D=frac(g[5]),
                                   ell0=frac(g[6]), m25=frac(g[7]), mstar=frac(g[8]), boxes=int(g[9]), slabs=int(g[10]),
                                   add=(int(g[11]) if g[11] else None))
    assert sorted(rows) == list(range(55)), sorted(rows)
    return rows


def main():
    T = n44_tables(); R = v20_table()
    covs = pickle.load(open(COV, 'rb'))
    # consistency of the v2.0 table with the Lean data
    for i in range(55):
        r = R[i]
        assert r['lam'] == [T['pieceLo'][i], T['pieceHi'][i]], i
        assert r['theta'] == T['theta44'][i], i
        assert r['D'] == hand_sup(*r['lam']), i
        assert r['ell0'] == T['rates44'][i][0], i
        assert r['m25'] == 8 / (2 * (r['lam'][1] / (1 + r['lam'][1]))), i
    fam_order = {'N44': 44, 'N45': 45, 'N48': 48, 'N52': 52, 'Atlas/L': 61, 'Atlas/U': 50}
    inv = []
    used = {}
    for i in range(55):
        lo, hi = R[i]['lam']; ms = R[i]['mstar']
        layers = []
        for c in covs:
            b = c['band']
            if not (F(b['lamLo']) <= lo and hi <= F(b['lamHi'])):
                continue
            mlo, mhi = F(b['mmin']), F(c['cap'])
            if mhi <= ms:      # below m_*(iota): not used by T1 on this subinterval (MGF covers there)
                continue
            layers.append(dict(covering=c['name'], m=[str(mlo), str(mhi)], m_float=[float(mlo), float(mhi)], boxes=(len(c['boxes']) if isinstance(c['boxes'], list) else c['boxes']),
                               theta=str(b['theta']), D_lean=str(b['D'])))
            used.setdefault(c['name'], set()).add(i)
        layers.sort(key=lambda x: F(x['m'][0]))
        # contiguity of the T1 chain from m_* to 400
        tip = ms; ok = True
        for L in layers:
            if F(L['m'][0]) > tip: ok = False
            tip = max(tip, F(L['m'][1]))
        ok = ok and tip >= 400
        inv.append(dict(iota=i, band=R[i]['band'], lam=[str(lo), str(hi)], theta=str(R[i]['theta']), D=str(R[i]['D']),
                        m25=str(R[i]['m25']), mstar=str(ms), mstar_float=float(ms), T1_range=[str(ms), '400'],
                        layers=layers, chain_contiguous_to_400=ok))
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / 'inventory.json').write_text(json.dumps(dict(subintervals=inv, coverings_used=sorted(used),
                                                       n_coverings_used=len(used),
                                                       entries_used_lean_counts=sum((len(c['boxes']) if isinstance(c['boxes'], list) else c['boxes']) for c in covs if c['name'] in used)),
                                                  indent=1) + '\n')
    lines = ['iota band lambda            theta  D     m25     m*      T1 layers (covering [m_lo,m_hi] boxes)']
    for x in inv:
        lines.append('%2d %2d [%s,%s] %s %s %6.3f %7.3f  %s %s' % (
            x['iota'], x['band'], x['lam'][0], x['lam'][1], x['theta'], x['D'], float(F(x['m25'])), x['mstar_float'],
            ' | '.join('%s [%.2f,%.2f] %d' % (L['covering'], L['m_float'][0], L['m_float'][1], L['boxes']) for L in x['layers']),
            '' if x['chain_contiguous_to_400'] else 'CHAIN-GAP'))
    lines.append('coverings used (Lean data, before the v2.0 rebuilds): %d' % len(used))
    (OUT / 'inventory.txt').write_text('\n'.join(lines) + '\n')
    print('\n'.join(lines))


if __name__ == '__main__':
    main()
