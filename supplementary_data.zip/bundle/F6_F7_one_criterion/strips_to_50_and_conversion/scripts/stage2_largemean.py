#!/usr/bin/python3
"""one_criterion_test, the alternative: the threshold m_L(iota) from which the large-mean theorem WITH EXPLICIT PARAMETERS
(certfree/large_mean/, refereed: Theorem lm:main, margin Psi_LM) applies on each subinterval, with the ROUTE's inputs of
v2.0: theta(iota) (certified variance-ratio caps, Lean theta44), D(iota) = sup of the hand cap, ell = ell_0(iota)
(zero-tilt rate, Lean rates44[0]).  Uses the refereed library certfree/large_mean/scripts/thresholds_lib.py unchanged
(imported from its own folder, read only; a byte copy is kept here as thresholds_lib_copy.py): Psi in floating point
for the bisection, then CERTIFIED in interval arithmetic (mpmath.iv, 40 digits) at m_L with the design (cut t_*, V_*),
as thresholds.py does.  Output outputs/stage2/largemean_route.json."""
import sys, os, json, math
from fractions import Fraction as Fr
from pathlib import Path
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from lean_mgf_data import n44_tables
from handcap import hand_sup
LM = HERE.parents[1] / 'large_mean' / 'scripts'
os.chdir(LM); sys.path.insert(0, str(LM))
import thresholds_lib as L
T = n44_tables()
INV = {x['iota']: x for x in json.loads((HERE.parent / 'outputs' / 'stage0' / 'inventory.json').read_text())['subintervals']}
out = []
for i in range(55):
    lo, hi = T['pieceLo'][i], T['pieceHi'][i]
    at = dict(lo=lo, hi=hi, theta=T['theta44'][i], D=hand_sup(lo, hi), ell=T['rates44'][i][0])
    best = None
    for rho in L.RHOS:
        for u0 in L.U0S:
            m = L.lowest_m(at, rho, u0)
            if m is not None and (best is None or m < best[0]):
                best = (m, rho, u0)
    rec = dict(iota=i, lam=[str(lo), str(hi)], theta=str(at['theta']), D=str(at['D']), ell0=str(at['ell']),
               mstar=INV[i]['mstar_float'])
    if best is None:
        rec.update(mL=None, certified=False)
    else:
        m, rho, u0 = best
        ok, d = L.certify(at, m, rho, u0)
        # if the float bisection's m fails the interval check, step up until it certifies
        while not ok and m < best[0] + 50:
            m += 1; ok, d = L.certify(at, m, rho, u0)
        rec.update(mL=m, cut=str(rho), V_star=u0, certified=bool(ok), Psi_lower=float(d['val'].a))
    out.append(rec)
    print(i, rec.get('mL'), rec.get('cut'), rec.get('V_star'), rec.get('certified'), flush=True)
dst = HERE.parent / 'outputs' / 'stage2'; dst.mkdir(parents=True, exist_ok=True)
(dst / 'largemean_route.json').write_text(json.dumps(out, indent=1) + '\n')
print('max m_L', max((r['mL'] or 1e9) for r in out), 'all certified', all(r['certified'] for r in out))
