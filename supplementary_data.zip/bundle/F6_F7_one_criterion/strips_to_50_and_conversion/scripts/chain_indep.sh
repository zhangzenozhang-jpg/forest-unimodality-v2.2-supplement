#!/bin/bash
# waits (no compute) until shard $1's first pass is done, then runs its independent-checker pass
cd "$(dirname "$0")"
k=$1
until grep -q "shard $k done" ../outputs/stage2/check_to50_shard$k.log 2>/dev/null; do sleep 15; done
./run_shard_indep.sh $k
