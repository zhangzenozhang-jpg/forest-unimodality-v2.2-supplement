#!/bin/bash
# one_criterion_test: when the independent pass of shard $1 is done, run the extra jobs of that slot (nice 10).
cd "$(dirname "$0")"
k=$1; shift
until grep -q "indep shard $k done" ../outputs/stage2/indep_to50_shard$k.log 2>/dev/null; do sleep 10; done
for job in "$@"; do
  if [ "$job" = "sens" ]; then
    nice -n 10 python3 stage1_sensitivity.py > ../outputs/stage1/sensitivity.log 2>&1
  else
    ./run_routeB_demo.sh "$job"
  fi
done
echo "slot $k extra jobs done $(date)" >> ../outputs/stage2/after_indep.log
