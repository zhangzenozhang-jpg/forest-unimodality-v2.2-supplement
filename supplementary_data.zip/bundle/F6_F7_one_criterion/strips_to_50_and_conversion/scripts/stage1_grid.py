#!/usr/bin/python3
"""one_criterion_test Stage 1 (DIAGNOSTIC): theta*(q, mu) of the MGF criterion (point_lp.py) on a grid over the T1 range
[m_*(iota), 400) of every subinterval, at both q-ends, with the route's inputs: theta(iota), D(iota) (sup of the hand
cap), ell_r(iota) (Lean rates44 = v2.0 Appendix A).  Usage: stage1_grid.py shard nshards"""
import sys, json, time, math
from fractions import Fraction as F
from pathlib import Path
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from lean_mgf_data import n44_tables
from handcap import hand_sup
from point_lp import theta_star
OUT = HERE.parent / 'outputs' / 'stage1'
INV = json.loads((HERE.parent / 'outputs' / 'stage0' / 'inventory.json').read_text())['subintervals']
BIG = {0, 2, 5, 6, 10, 15, 20, 23, 24, 27, 30, 37, 38, 42, 43, 44, 46, 47, 50, 52, 54}


def jobs():
    T = n44_tables(); out = []
    for x in INV:
        i = x['iota']; ms = float(F(x['mstar']))
        lo, hi = T['pieceLo'][i], T['pieceHi'][i]
        grid = sorted(set([round(ms * f, 4) for f in (1, 1.15, 1.3, 1.5, 1.75, 2, 2.5, 3, 4)] + [60.0, 80.0, 120.0] +
                          ([180.0, 270.0, 399.0] if i in BIG else [])))
        grid = [g for g in grid if ms <= g < 400]
        for lam in (lo, hi):
            q = float(lam / (1 + lam))
            for mu in grid:
                out.append(dict(iota=i, lam=str(lam), q=q, mu=mu, theta=float(T['theta44'][i]), D=float(hand_sup(lo, hi)),
                                ells=[float(e) for e in T['rates44'][i]]))
    return out


if __name__ == '__main__':
    shard, n = int(sys.argv[1]), int(sys.argv[2])
    J = jobs()
    mine = J[shard::n]
    OUT.mkdir(parents=True, exist_ok=True)
    f = open(OUT / ('grid_shard%d.jsonl' % shard), 'a')
    t0 = time.time()
    for k, jb in enumerate(sorted(mine, key=lambda z: z['mu'])):
        t1 = time.time()
        r = theta_star(jb['q'], jb['mu'], jb['theta'], jb['D'], jb['ells'], 'two', R=7.0)
        jb.update(kernel='two', **r, seconds=round(time.time() - t1, 2))
        f.write(json.dumps(jb) + '\n'); f.flush()
    print('shard %d done: %d jobs, %.0fs' % (shard, len(mine), time.time() - t0), flush=True)
