#!/bin/bash
# one_criterion_test Stage 2: build then check [m_*(iota), 50] for the subintervals of one shard (sequential; nice 10).
cd "$(dirname "$0")"
k=$1
for p in $(python3 -c "import json; print(' '.join(map(str, json.load(open('shards_to50.json'))[$k])))"); do
  nice -n 10 python3 one_mgf.py build to50 $p mstar 50 900 >> ../outputs/stage2/build_to50_shard$k.log 2>&1
  nice -n 10 python3 one_mgf.py check to50 $p mstar 50 >> ../outputs/stage2/check_to50_shard$k.log 2>&1
done
echo "shard $k done $(date)" >> ../outputs/stage2/check_to50_shard$k.log
