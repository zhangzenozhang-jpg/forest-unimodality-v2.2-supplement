#!/usr/bin/python3
"""Summarize the Stage 1 grid (DIAGNOSTIC): per subinterval the least ratio theta*/theta(iota) over its grid, where, and
the least ratio per mean band."""
import json, glob, collections
from pathlib import Path
HERE = Path(__file__).resolve().parent
R = [json.loads(l) for f in sorted(glob.glob(str(HERE.parent / 'outputs' / 'stage1' / 'grid_shard*.jsonl'))) for l in open(f)]
bad = [r for r in R if not (r['theta_star'] == r['theta_star'])]
per = collections.defaultdict(list)
for r in R:
    per[r['iota']].append(r)
lines = ['Stage 1 (DIAGNOSTIC): %d LP points, %d failed LPs' % (len(R), len(bad)),
         'iota theta  least theta*/theta at (q, mu)       ratio at mu>=50 (min)   ratio at mu>=150 (min)  points']
tab = []
for i in sorted(per):
    rs = per[i]; m = min(rs, key=lambda r: r['ratio'])
    big = [r['ratio'] for r in rs if r['mu'] >= 50]; huge = [r['ratio'] for r in rs if r['mu'] >= 150]
    tab.append(dict(iota=i, theta=rs[0]['theta'], min_ratio=m['ratio'], at=[m['q'], m['mu']],
                    min_ratio_mu50=min(big) if big else None, min_ratio_mu150=min(huge) if huge else None, points=len(rs)))
    lines.append('%2d  %.3f  %.4f at (%.4f, %7.3f)          %s                %s            %d' % (
        i, rs[0]['theta'], m['ratio'], m['q'], m['mu'], ('%.3f' % min(big)) if big else '-', ('%.3f' % min(huge)) if huge else '-', len(rs)))
bands = [(0, 15), (15, 20), (20, 30), (30, 50), (50, 100), (100, 200), (200, 400)]
lines.append('least ratio by mean range: ' + '; '.join('[%d,%d): %.3f' % (a, b, min(r['ratio'] for r in R if a <= r['mu'] < b)) for a, b in bands))
g = min(R, key=lambda r: r['ratio'])
lines.append('global least ratio %.4f at iota %d, q %.4f, mu %.3f (theta* %.4f, cap %.3f)' % (g['ratio'], g['iota'], g['q'], g['mu'], g['theta_star'], g['theta']))
(HERE.parent / 'outputs' / 'stage1' / 'summary.txt').write_text('\n'.join(lines) + '\n')
(HERE.parent / 'outputs' / 'stage1' / 'summary.json').write_text(json.dumps(tab, indent=1) + '\n')
print('\n'.join(lines))
