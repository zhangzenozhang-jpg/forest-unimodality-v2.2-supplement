#!/bin/bash
# one_criterion_test, the alternative route: MGF strips [50, m_L(iota)] (m_L from the explicit large-mean theorem with the
# route's inputs, outputs/stage2/largemean_route.json) on a few subintervals; build, exact replay, independent checker.
cd "$(dirname "$0")"
for pm in "$@"; do
  p=${pm%:*}; mL=${pm#*:}
  nice -n 10 python3 one_mgf.py build toML $p 50 $mL 600 >> ../outputs/stage2/build_toML.log 2>&1
  nice -n 10 python3 one_mgf.py check_indep toML $p 50 $mL >> ../outputs/stage2/check_toML.log 2>&1
  nice -n 10 python3 one_mgf.py check toML $p 50 $mL >> ../outputs/stage2/check_toML.log 2>&1
done
echo "routeB done $(date)" >> ../outputs/stage2/check_toML.log
