#!/usr/bin/python3
"""Sanity tests of o3_unit_check.py (not part of the proof): (1) every cell bound is <= U sampled at random
points of the cell (U evaluated in mpmath at 40 digits directly from the paper's display); (2) cases with
the rate ell increased by 1% are rejected."""
import sys, os, json, random
from fractions import Fraction as F
import mpmath as mp
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import o3_unit_check as M
mp.mp.dps = 40
def mf(x):
    x = F(x) if not isinstance(x, (mp.mpf,)) else x
    return x if isinstance(x, mp.mpf) else mp.mpf(x.numerator) / x.denominator
random.seed(12345)

def U(lam, tau, a, l, YA, YC, p):
    lam, tau, a, l, YA, YC = map(mf, (lam, tau, a, l, YA, YC)); p = p if isinstance(p, mp.mpf) else mf(p)
    q = lam / (1 + lam); L = lambda x: -mp.log(1 - x); Y = lambda x: mp.log(lam * (1 - x) / x)
    Yh = lambda t: mp.log(lam) - t - mp.log(1 - mp.exp(-t)); Yhp = lambda t: max(Yh(t), 0)
    om = 1 - 2 / (1 + mp.sqrt(1 + 4 * lam)); rho = mp.log((1 + lam) / (1 + lam * tau)) / mp.log(1 + lam)
    msg = lambda t: lam * mp.exp(-t) / (1 + lam * mp.exp(-t)); pimin = lambda x: x / (1 + lam * (1 - x))
    lstar = lambda t: (l / q) * (1 - pimin(msg(t))); pbar = msg(YA + YC)
    v = -mp.log(pbar + (1 - pbar) * mp.exp(-rho * YA)) + a * (1 - om) * YC - a * L(pbar)
    if YC > 0: v += a * om * Yhp(YC)
    num = a * Y(p) - a * om * L(p) - lstar(YA + YC) * p
    if p < q: num += a * om * Yhp(Y(p))
    return v + YA * num / L(p)

def sample_min(lam0, lam1, tau, a, l, A0, A1, C0, C1, n=60):
    best = None
    for k in range(n):
        lam = lam0 + (lam1 - lam0) * F(random.random()) if k % 3 else (lam0 if k % 2 else lam1)
        YA = A0 + (A1 - A0) * F(random.random()) if k % 5 else (A0 if A0 > 0 else A1)
        YC = (C0 + (C1 - C0) * F(random.random()) if C1 is not None else C0 + F(random.expovariate(0.2))) if k % 4 else C0
        q = lam / (1 + lam); cap = min(mf(q), 1 - mp.exp(-mf(YA)))
        for p in [cap, cap * mp.mpf(random.random()), cap * (1 - mp.mpf(10) ** (-random.randint(2, 8)))]:
            if p <= 0: continue
            v = U(lam, tau, a, l, YA, YC, p)
            if best is None or v < best: best = v
    return best

cases = {c["id"]: c for c in json.load(open(os.path.join(M.OUT, "cases.json")))}
bad = 0; tested = 0
ALL = sorted(cases)
for cid in ALL:
    NCELL = 150 if cid in ("band00_t4", "band29_t0", "extra05", "band15_t2") else 6
    c = cases[cid]; lo, hi, tau, a, l = (F(c[k]) for k in ("lo", "hi", "tau", "a", "ell"))
    pg = M.PGrid(hi / (1 + hi)); lc = M.LamCell(lo, hi, tau, a, l, pg)
    for t in range(NCELL):
        A0 = (F(random.choice([0.05, 0.2, 0.25, 0.29, 0.4, 0.5, 1.0, 3.0, 10.0])) + F(random.random()) / 8) if NCELL > 6 else F(random.uniform(0.15, 0.7))
        A1 = A0 + F(random.choice([1e-4, 1e-3, 1e-2, 0.1]))
        C0 = F(random.choice([0, 0, 0.001, 0.05, 0.3, 1.0, 5.0])) if NCELL > 6 else F(random.choice([0, 0, 0.002]))
        C1 = None if random.random() < 0.05 else C0 + F(random.choice([1e-3, 1e-2, 0.1, 1.0]))
        b = M.cell_bound(lc, A0, A1, C0, C1)
        m = sample_min(lo, hi, tau, a, l, A0, A1, C0, C1)
        tested += 1
        if True:
            if not (mf(F(*[int(z) for z in [b.lower().man_exp()[0]]], 1) * F(2) ** int(b.lower().man_exp()[1])) <= m):
                bad += 1; print("VIOLATION", cid, float(A0), float(A1), float(C0), C1, b, m)
    # small-YA bound
    for C0, C1 in [(F(0), F(32)), (F(32), None)]:
        b = M.small_YA_bound(lc, M.EPS_A, C0, C1)
        m = sample_min(lo, hi, tau, a, l, F(0), M.EPS_A, C0, C1)
        tested += 1
        if not (mf(F(*[int(z) for z in [b.lower().man_exp()[0]]], 1) * F(2) ** int(b.lower().man_exp()[1])) <= m): bad += 1; print("VIOLATION small", cid, b, m)
    sl, v = M.large_YA_bound(lc)
    for YA in [32, 40, 100]:
        m = sample_min(lo, hi, tau, a, l, F(YA), F(YA), F(0), None)
        bound = sl * YA - (1 + lc.L1a).log()
        tested += 1
        if not (mp.mpf(float(bound.lower().mid())) - mp.mpf(1e-12) <= m): bad += 1; print("VIOLATION large", cid, YA, bound, m)
    if NCELL > 6 or cid == ALL[-1]: print(cid, "tested so far", tested, "violations", bad, flush=True)
# (2) perturbed cases must be rejected
for cid in ["band00_t4", "extra05"]:
    c = dict(cases[cid]); c["ell"] = str(F(c["ell"]) * F(103, 100))
    pg = M.PGrid(F(c["hi"]) / (1 + F(c["hi"])))
    r = M.check_case(c, pg, budget=20000, min_lam_frac=F(1, 2 ** 6))
    print("perturbed ell*1.03", cid, "->", "PASS (unexpected)" if r["ok"] else "rejected", r["why"][:120])
print("TOTAL tested", tested, "violations", bad)
