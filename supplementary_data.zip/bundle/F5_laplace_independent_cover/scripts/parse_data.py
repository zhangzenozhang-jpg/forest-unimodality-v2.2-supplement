#!/usr/bin/python3
"""Parse the data of the O3 unit-inequality family (Lemma apC:lem:O3box) from the Lean
repository (data modules and check-theorem statements only) and from the paper's tables,
cross-check them, and write outputs/cases.json + outputs/data_crosscheck.txt.

Read-only on every source.  Exact rationals (fractions.Fraction) throughout.
"""
import json, os, re, sys
from fractions import Fraction as F

LEAN = "/Users/kvallier/Desktop/Erdos993-Lean-FiberFloor/Erdos993Lean/Analytic"
PAPER = "/Users/kvallier/Desktop/Erdos 993/ProofRuns/2026-09-28_analytic_large_n/LEAN/for_tong/TWIN_v1.5"
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "outputs")

def rat(s):
    s = s.strip().strip("()").replace(" ", "")
    if "/" in s:
        n, d = s.split("/")
        return F(int(n.strip("()")), int(d.strip("()")))
    return F(int(s))

def lean_list_block(path, name):
    txt = open(path).read()
    m = re.search(r"def\s+" + re.escape(name) + r"\s*:\s*List[^=]*:=\s*", txt)
    if not m:
        raise SystemExit("no def %s in %s" % (name, path))
    i = m.end()
    assert txt[i] == "["
    depth = 0
    for k in range(i, len(txt)):
        if txt[k] == "[": depth += 1
        elif txt[k] == "]":
            depth -= 1
            if depth == 0:
                return txt[i:k + 1]
    raise SystemExit("unterminated list")

def parse_flat(block):
    inner = block.strip()[1:-1]
    if "R (" in inner:   # Rows.lean: R (n) d  ==  n/d
        return [F(int(n), int(d)) for n, d in re.findall(r"R\s*\((-?\d+)\)\s*(\d+)", inner)]
    return [rat(x) for x in inner.split(",") if x.strip()]

def parse_nested(block):
    rows = re.findall(r"\[([^\[\]]*)\]", block.strip()[1:-1])
    return [[rat(x) for x in r.split(",") if x.strip()] for r in rows]

def check_theorem_args(path, thmname):
    txt = open(path).read()
    m = re.search(r"theorem\s+" + re.escape(thmname) + r"\s*:\s*TailCert\.Compute\.checkBand\s+(.*?)\s*=\s*true", txt)
    if not m:
        raise SystemExit("no theorem %s in %s" % (thmname, path))
    args = re.findall(r"\(([^()]*)\)|(\S+)", m.group(1))
    vals = [rat(a or b) for a, b in args]
    assert len(vals) == 5, (path, vals)
    return vals   # lo hi a ell tau

def paper_rows(path, first, last):
    lines = open(path).read().split("\n")[first - 1:last]
    out = []
    for ln in lines:
        nums = re.findall(r"\$(-?\d+)/(\d+)\$|\$(\d+)\$", ln)
        out.append((ln, nums))
    return lines

def frac_tokens(s):
    return [F(int(n), int(d)) for n, d in re.findall(r"(\d+)/(\d+)", s)]

def main():
    rep = []
    mism = []
    def note(s):
        rep.append(s)
    # ---------- Lean data ----------
    p30 = os.path.join(LEAN, "Profile30.lean")
    glue = os.path.join(LEAN, "TailCert/Glue.lean")
    bands = os.path.join(LEAN, "TailCert/Compute/Bands.lean")
    rowsf = os.path.join(LEAN, "Ladder/O3/Rows.lean")
    edges = parse_flat(lean_list_block(p30, "edges"))
    tvals = parse_flat(lean_list_block(p30, "tvals"))
    rates = parse_nested(lean_list_block(p30, "rates"))
    aTab = parse_nested(lean_list_block(glue, "aTab"))
    edgesC = parse_flat(lean_list_block(bands, "edgesC"))
    tvalsC = parse_flat(lean_list_block(bands, "tvalsC"))
    ratesC = parse_nested(lean_list_block(bands, "ratesC"))
    aTabC = parse_nested(lean_list_block(bands, "aTabC"))
    note("Profile30.edges: %d entries; tvals %s; rates %dx%s; Glue.aTab %dx%s" % (
        len(edges), [str(t) for t in tvals], len(rates), sorted(set(len(r) for r in rates)), len(aTab), sorted(set(len(r) for r in aTab))))
    for nm, x, y in [("edges", edges, edgesC), ("tvals", tvals, tvalsC), ("rates", rates, ratesC), ("aTab", aTab, aTabC)]:
        if x != y:
            mism.append("Lean copy mismatch: %s (Profile30/Glue) != %sC (Bands.lean)" % (nm, nm))
        else:
            note("Bands.lean copy %sC == %s: OK" % (nm, nm))
    assert len(edges) == 31 and len(rates) == 30 and len(aTab) == 30
    if tvals != [F(0), F(1, 20), F(1, 10), F(1, 5), F(3, 10)]:
        mism.append("tvals differ from the paper's tau_r = (0,1/20,1/10,1/5,3/10): %s" % tvals)
    rowLo = parse_flat(lean_list_block(rowsf, "rowLo"))
    rowHi = parse_flat(lean_list_block(rowsf, "rowHi"))
    rowA = parse_flat(lean_list_block(rowsf, "rowA"))
    rowEll = parse_flat(lean_list_block(rowsf, "rowEll"))
    note("Rows.lean: rowLo/rowHi/rowA/rowEll lengths %d %d %d %d" % (len(rowLo), len(rowHi), len(rowA), len(rowEll)))
    # rowDataNN theorems in Rows.lean
    rtxt = open(rowsf).read()
    for m in re.finditer(r"theorem rowData(\d+) : rowLo.getD \d+ 0 = (\S+) ∧ rowHi.getD \d+ 0 = (\S+) ∧ rowA.getD \d+ 0 = (\S+) ∧ rowEll.getD \d+ 0 = (\S+) :=", rtxt):
        i = int(m.group(1))
        v = [rat(m.group(k)) for k in range(2, 6)]
        if v != [rowLo[i], rowHi[i], rowA[i], rowEll[i]]:
            mism.append("Rows.lean rowData%02d disagrees with the lists: %s" % (i, v))
    # per-row check theorems
    thm = {}
    for k in range(5, 27):
        thm[k] = check_theorem_args(os.path.join(LEAN, "Ladder/O3/Row%02d.lean" % k), "row%02d" % k)
    for k, P in zip(range(1, 5), ["P22", "P26", "P27", "P28"]):
        thm[k] = check_theorem_args(os.path.join(LEAN, "N48/TailChecks/%s.lean" % P), "row%s" % P)
    for k in range(1, 27):
        lst = [rowLo[k - 1], rowHi[k - 1], rowA[k - 1], rowEll[k - 1], F(0)]
        if thm[k] != lst:
            mism.append("interval %d: check theorem args %s != Rows.lean lists %s" % (k, thm[k], lst))
    note("26 interval check theorems (Row05..Row26, P22/P26/P27/P28) parsed; compared with Rows.lean lists")
    # band check theorems: statement checkRow i = true
    for i in range(30):
        t = open(os.path.join(LEAN, "TailCert/Checks/Band%02d.lean" % i)).read()
        if not re.search(r"theorem band_%02d : Compute\.checkRow %d = true" % (i, i), t):
            mism.append("Band%02d.lean: statement is not `checkRow %d = true`" % (i, i))
    note("30 band check theorems `checkRow i = true` (i=0..29) found; checkRow i = AND_j checkBand edges[i] edges[i+1] aTab[i][j] rates[i][j] tvals[j] (Bands.lean)")
    # ---------- paper tables ----------
    ap = open(os.path.join(PAPER, "appendix_A_pieces.tex")).read().split("\n")
    # rates table: rows "i & $(x,\,y]$ & ... \\"
    prates, pedges = {}, {}
    pa = {}
    pextra = {}
    def tbl(label):
        # find the tabular preceding \label{label}
        li = [k for k, s in enumerate(ap) if "\\label{%s}" % label in s][0]
        st = max(k for k in range(li) if "\\begin{tabular}" in ap[k])
        return ap[st:li]
    for s in tbl("apA:tab:rates"):
        m = re.match(r"\s*(\d+)\s*&\s*\$\((\d+/\d+|\d+),\\,(\d+/\d+|\d+)\]\$(.*)\\\\", s)
        if m:
            i = int(m.group(1)); pedges[i] = (rat(m.group(2)), rat(m.group(3)))
            prates[i] = frac_tokens(m.group(4))
    for s in tbl("apA:tab:a"):
        m = re.match(r"\s*(\d+)\s*&(.*)\\\\", s)
        if m and "$" in s:
            pa[int(m.group(1))] = frac_tokens(m.group(2))
    for s in tbl("apA:tab:extra"):
        if not re.match(r"\s*\d+\s*&", s):
            continue
        cells = [c.strip() for c in s.replace("\\\\", "").split("&")]
        for h in range(0, len(cells) - 4, 5):
            no = int(cells[h]); iv = frac_tokens(cells[h + 1].replace("[1,", "[1/1,").replace(",\\,1]", ",\\,1/1]"))
            pextra[no] = (iv[0], iv[1], frac_tokens(cells[h + 2])[0] if "/" in cells[h + 2] else rat(cells[h + 2].strip("$")),
                          frac_tokens(cells[h + 3])[0], int(cells[h + 4]))
    note("paper: rates table %d rows, a table %d rows, extra table %d entries" % (len(prates), len(pa), len(pextra)))
    for i in range(30):
        if pedges.get(i) != (edges[i], edges[i + 1]):
            mism.append("band %d edges: paper %s vs Lean (%s,%s)" % (i, pedges.get(i), edges[i], edges[i + 1]))
        if prates.get(i) != rates[i]:
            mism.append("band %d rates: paper %s vs Lean %s" % (i, prates.get(i), rates[i]))
        if pa.get(i) != aTab[i]:
            mism.append("band %d a_U: paper %s vs Lean %s" % (i, pa.get(i), aTab[i]))
    for k in range(1, 27):
        e = pextra.get(k)
        lst = (rowLo[k - 1], rowHi[k - 1], rowA[k - 1], rowEll[k - 1])
        if e is None or e[:4] != lst:
            mism.append("additional interval %d: paper %s vs Lean %s" % (k, e, lst))
    # ---------- cases ----------
    cases = []
    for i in range(30):
        for r in range(5):
            cases.append(dict(id="band%02d_t%d" % (i, r), lo=str(edges[i]), hi=str(edges[i + 1]),
                              tau=str(tvals[r]), a=str(aTab[i][r]), ell=str(rates[i][r]),
                              source="Bands.lean checkIJ %d %d (Band%02d.lean)" % (i, r, i)))
    for k in range(1, 27):
        lo, hi, a, ell, tau = thm[k]
        src = ("Ladder/O3/Row%02d.lean" % k) if k >= 5 else ("N48/TailChecks/%s.lean" % ["P22", "P26", "P27", "P28"][k - 1])
        cases.append(dict(id="extra%02d" % k, lo=str(lo), hi=str(hi), tau=str(tau), a=str(a), ell=str(ell), source=src))
    # side hypotheses
    for c in cases:
        lo, hi, tau, a, ell = (F(c[x]) for x in ("lo", "hi", "tau", "a", "ell"))
        ok = (0 < lo <= hi <= 6) and (0 <= tau <= 1) and a >= 0 and ell >= 0
        c["side_hyp_ok"] = ok
        if not ok:
            mism.append("side hypotheses fail for %s" % c["id"])
    os.makedirs(OUT, exist_ok=True)
    json.dump(cases, open(os.path.join(OUT, "cases.json"), "w"), indent=1)
    with open(os.path.join(OUT, "data_crosscheck.txt"), "w") as f:
        for s in rep: f.write(s + "\n")
        f.write("cases: %d (150 band certificates + 26 additional intervals)\n" % len(cases))
        f.write("side hypotheses 0<lo<=hi<=6, 0<=tau<=1, a>=0, ell>=0: %s\n" % all(c["side_hyp_ok"] for c in cases))
        f.write("MISMATCHES: %d\n" % len(mism))
        for s in mism: f.write("  " + s + "\n")
    print(open(os.path.join(OUT, "data_crosscheck.txt")).read())

if __name__ == "__main__":
    main()
