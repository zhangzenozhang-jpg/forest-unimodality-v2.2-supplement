#!/usr/bin/python3
"""Slack measurement (supplementary; the pass/fail verdict is o3_unit_check.py with delta=0).
For each case: the first delta in (0.75,0.5,0.25,0.1)*(float estimate), then 1e-5, for which the cover proves U > delta everywhere on the case
(rigorous, same bounds; lambda may be bisected down to 1/32 of the interval; 8 s per attempt), and a
plain-float ESTIMATE (non-rigorous, information only) of min U over lambda in {lo,mid,hi}, YC=0, YA in (0,3]."""
import sys, os, json, time
from fractions import Fraction as F
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import o3_unit_check as M
LADDER = [F(1, 1000), F(3, 10000), F(1, 10000), F(3, 100000), F(1, 100000)]

def float_min(lam, tau, a, l):
    q = lam / (1 + lam); om = 1 - 2 / (1 + np.sqrt(1 + 4 * lam)); rho = np.log((1 + lam) / (1 + lam * tau)) / np.log(1 + lam)
    best = (np.inf, None)
    for YA in np.linspace(0.02, 3.0, 700):
        u = lam * np.exp(-YA); E = np.exp(-rho * YA); B = (1 - a) * np.log1p(u) - np.log(u + E)
        s = l * (1 + lam) ** 2 / (lam * (1 + lam + u)); cap = min(q, -np.expm1(-YA))
        p = cap * np.linspace(1e-3, 1, 1200); L = -np.log1p(-p); Y = np.log(lam * (1 - p) / p)
        with np.errstate(all="ignore"):
            Yh = np.where(p < q * (1 - 1e-12), np.log(lam * p / (lam - (1 + lam) * p)), 0.0)
        Phi = (a * Y + a * om * np.maximum(Yh, 0)) / L - a * om - s * p / L
        v = B + YA * Phi.min()
        if v < best[0]: best = (v, YA)
    return best

def main():
    cases = json.load(open(os.path.join(M.OUT, "cases.json")))
    if len(sys.argv) > 1 and sys.argv[1] != "all":
        ids = set(sys.argv[1].split(",")); cases = [c for c in cases if c["id"] in ids]
    qmax = max(F(c["hi"]) / (1 + F(c["hi"])) for c in cases)
    pg = M.PGrid(qmax)
    out = os.path.join(M.OUT, "slack_ladder.csv")
    with open(out, "w") as f:
        f.write("id,certified_delta,cells_at_delta,lambda_cells_at_delta,float_estimate_minU,float_argmin_lambda,float_argmin_YA,seconds\n")
        for c in cases:
            t0 = time.time()
            lo, hi, tau, a, l = (float(F(c[k])) for k in ("lo", "hi", "tau", "a", "ell"))
            fm = min((float_min(lam, tau, a, l) + (lam,) for lam in (lo, (lo + hi) / 2, hi)), key=lambda z: z[0])
            cert = None; info = None
            # proposals only: fractions of the float estimate, then fixed small values; first success is reported
            props = [F(fm[0]).limit_denominator(10 ** 9) * F(k, 100) for k in (75, 50, 25, 10)] if fm[0] > 0 else []
            props = [d for d in props if d > 0] + [F(1, 100000)]
            for d in props:
                r = M.check_case(c, pg, budget=40000, min_lam_frac=F(1, 32), delta=d, tlimit=8)
                if r["ok"]:
                    cert, info = d, r; break
            f.write("%s,%s,%s,%s,%.4e,%.6g,%.4g,%.1f\n" % (c["id"], "<1e-5 (not certified at ladder)" if cert is None else "%.4e" % float(cert),
                    "" if info is None else info["cells"], "" if info is None else info["lamcells"], fm[0], fm[2], fm[1], time.time() - t0))
            f.flush()
            print(c["id"], cert, fm[0], "%.1fs" % (time.time() - t0), flush=True)

if __name__ == "__main__":
    main()
