#!/usr/bin/python3
"""Independent replay (outside Lean) of Lemma apC:lem:O3box: the unit inequality U(lambda,tau,a,l) >= 0
for every lambda in [lo,hi], for the 176 cases of outputs/cases.json (written by parse_data.py).

Written from the paper's statement (part2_body.tex, proof of Theorem p2:thm:O3).  Notation:
  q = lam/(1+lam), L(p) = -log(1-p), Y(p) = log(lam(1-p)/p), Yh(t) = log lam - t - log(1-e^{-t}),
  omega = 1 - 2/(1+sqrt(1+4 lam)), rho = log((1+lam)/(1+lam tau))/log(1+lam),
  msg(t) = lam e^{-t}/(1+lam e^{-t}), pimin(p) = p/(1+lam(1-p)), lstar(t) = (l/q)(1-pimin(msg(t))),
  pbar = msg(YA+YC).
  U = -log(pbar+(1-pbar)e^{-rho YA}) + a(1-omega)YC + [YC>0] a omega Yh_+(YC) - a L(pbar)
      + YA*( a Y(p) + [p<q] a omega Yh_+(Y(p)) - a omega L(p) - lstar(YA+YC) p )/L(p)
  for YA>0, YC>=0, 0<p<=min(q,1-e^{-YA}).
FACTS USED, WITH PROOFS (lam>0, 0<=tau<=1, 0<=a<1, l>=0; all checked cases satisfy these):
 F1  pbar + (1-pbar)E = (u+E)/(1+u) with u = lam e^{-(YA+YC)}, E = e^{-rho YA}, and L(pbar) = log(1+u); hence
     G - a L(pbar) = (1-a)log(1+u) - log(u+E) =: B(u,E).  dB/dE = -1/(u+E) < 0; dB/du = (1-a)/(1+u) - 1/(u+E) <= 0
     because E <= 1 (rho >= 0, YA > 0).  So B is decreasing in u and in E.
 F2  1 - pimin(msg(t)) = (1+lam)/(1+lam+lam x), x = e^{-t}, so lstar(t) = s(lam,x) = l(1+lam)^2/(lam(1+lam+lam x)):
     decreasing in x (increasing in t); d/dlam log s = (lam-1)/(lam(1+lam)) - (1+x)/(1+lam(1+x)) < 0 (lam<=1: both
     terms <= 0, the second < 0; lam>1: (1+x)/(1+lam(1+x)) >= 1/(1+lam), total <= -1/(lam(1+lam))).  So s is
     maximal at (lam_lo of the cell, smallest x).
 F3  Y(p) = log lam + log((1-p)/p): decreasing in p, increasing in lam, >= 0 iff p <= q.  For p < q:
     Yh(Y(p)) = log(lam p/(lam-(1+lam)p)) = log p - log(1-p-p/lam): increasing in p, decreasing in lam; it is > 0 iff
     p > lam/(1+2lam).  Yh(t) = log lam - t - log(1-e^{-t}) has derivative -1/(1-e^{-t}) < 0 in t, increasing in lam.
 F4  p/L(p) is decreasing on (0,1) and < 1 (L(p)/p = sum_k p^{k-1}/k).  omega increasing in lam (sqrt increasing).
     rho = 1 - f, f(lam) = log(1+tau lam)/log(1+lam); f' >= 0 iff tau(1+lam)log(1+lam) >= (1+tau lam)log(1+tau lam),
     which is convexity of phi(x) = (1+x)log(1+x) with phi(0)=0: phi(tau lam) <= tau phi(lam).  So rho is decreasing.
 CELL BOUND (lam in [l0,l1], YA in [A0,A1], A0>0, YC in [C0,C1], C1 possibly infinite):
     U >= B(l1 e^{-(A0+C0)}, e^{-rho(l1) A0}) + a(1-omega(l1))C0 + [C0>0] a omega(l0) max(0, Yh(C1; l0))
          + (A0 phi if phi >= 0 else A1 phi),
     phi <= inf{ Phi(p) : admissible p, s <= s(l0, e^{-(A1+C1)}), cap <= min(q(l1), 1-e^{-A1}) },
     Phi(p) = [a Y(p) + [p<q] a omega Yh_+(Y(p))]/L(p) - a omega - s p/L(p) (decreasing in s since p/L(p) > 0).
   p-table (per lambda-cell; dyadic grid g_0 = 2^-10 < g_1 < ... ; step <= g/64 below 2^-6, 2^-12 above):
     on [g_{j-1}, g_j]:  Phi >= [a max(0, log l0 + log((1-g_j)/g_j)) + a omega(l0) max(0, Yh(Y(g_{j-1})) at l1)]/L(g_j)
                               - a omega(l1) - s g_{j-1}/L(g_{j-1}),
     the credit term only when g_j < q(l0) (then p < q(lam) for every lam of the cell); otherwise it is dropped (>= 0),
     which also covers the point p = q (no credit there).  Tail (0, 2^-10]: Phi >= a Y(2^-10; l0)/L(2^-10) - a omega(l1) - s.
     Admissible p <= cap lie in the tail or in cells with g_{j-1} <= cap.  Table entries are stored as exact integers
     (floor/ceil of arb enclosures times 2^32), the query G*2^20 - ceil(s 2^20) H is exact integer arithmetic.
 SMALL YA (0 < YA <= eps = 2^-10): since p <= 1-e^{-YA}, L(p) <= YA and Y(p) >= 0, so YA*aY(p)/L(p) >= aY(p) >=
     a Y(1-e^{-YA}) = a(log lam - log(e^{YA}-1)) >= a(log l0 - log(e^eps - 1)); credit >= 0; -s YA p/L(p) >= -s eps:
     U >= B(l1 e^{-C0}, 1) + C-term + a(log l0 - log(e^eps-1)) - (a omega(l1) + s_max) eps.
 LARGE YA (YA >= 32 > log(1+lam), so cap = q): u + E <= l1 e^{-YA} + e^{-rho_min YA} <= (1+l1) e^{-rho_min YA}
     (rho_min <= 1), (1-a)log(1+u) >= 0, C-term >= 0, s <= l(1+l0)/l0:  U >= (rho_min + phi_inf) YA - log(1+l1),
     which is >= (rho_min + phi_inf)*32 - log(1+l1) > 0 once the slope is >= 0 (checked).
 YC unbounded: the top cells [32, inf) use the same cell bound with x = e^{-inf} = 0 and no YC credit.
 YC = 0: the cells [0, C1] use C-term >= 0 (exact at YC = 0, where the indicator vanishes).
All decisions: arb interval arithmetic (python-flint, outward rounding, prec 96) and exact integer/rational arithmetic.
Plain floats are used only to choose the next subdivision (and float(arb.upper()) rounded up for a table index).
"""
import sys, os, json, time, bisect
from fractions import Fraction as F
import numpy as np
from flint import arb, ctx

ctx.prec = 96
HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "outputs")

def A(x):
    """arb enclosure of an exact rational (Fraction or int)."""
    x = F(x)
    if x.denominator == 1:
        return arb(x.numerator)
    return arb(x.numerator) / arb(x.denominator)

def fl_sc(x, k):
    """floor(lower(x) * 2^k) as a Python int (exact)."""
    m, e = x.lower().man_exp(); m = int(m); e = int(e) + k
    return m << e if e >= 0 else m >> (-e)

def ce_sc(x, k):
    """ceil(upper(x) * 2^k) as a Python int (exact)."""
    m, e = x.upper().man_exp(); m = int(m); e = int(e) + k
    return m << e if e >= 0 else -((-m) >> (-e))

def up_float(x):
    """a Python float >= every point of the arb x (exact comparison through Fractions)."""
    m, e = x.upper().man_exp(); v = F(int(m)) * (F(2) ** int(e))
    f = float(v)
    while F(f) < v:
        f = np.nextafter(f, np.inf)
    return float(f)

# ---------------------------------------------------------------- the p-grid (lambda-independent)
PMIN = F(1, 2 ** 10)          # tail (0, PMIN] handled by one inequality
STEP_U = F(1, 2 ** 12)        # uniform step beyond 2^-6

def make_pgrid(qmax):
    g = [PMIN]
    p = PMIN
    while p < F(1, 64):
        e = p.numerator.bit_length() - p.denominator.bit_length()  # ~ log2 p
        st = F(2) ** (e - 7)  # <= p/64
        p = p + st; g.append(p)
    while p < qmax:
        p = p + STEP_U; g.append(p)
    return g

class PGrid:
    def __init__(self, qmax):
        self.g = make_pgrid(qmax)
        self.gf = [float(x) for x in self.g]          # exact (dyadic) floats
        for x, y in zip(self.g, self.gf):
            assert F(y) == x
        self.n = len(self.g)
        self.l1_lo = []   # floor(log((1-p)/p) * 2^40)
        self.L_hi = []    # ceil(L(p) * 2^40)
        self.h_hi = []    # ceil(p/L(p) * 2^32)
        self.parb = []
        for x in self.g:
            pa = A(x); self.parb.append(pa)
            l1 = ((1 - pa) / pa).log()
            L = -((1 - pa).log())
            self.l1_lo.append(fl_sc(l1, 40))
            self.L_hi.append(ce_sc(L, 40))
            self.h_hi.append(ce_sc(pa / L, 32))
        self.H = np.array(self.h_hi, dtype=np.int64)

# ---------------------------------------------------------------- per lambda-cell constants and p-table
class LamCell:
    def __init__(self, lam0, lam1, tau, a, l, pg):
        self.lam0, self.lam1 = lam0, lam1
        L0, L1 = A(lam0), A(lam1)
        self.L0a, self.L1a = L0, L1
        self.q0, self.q1 = lam0 / (1 + lam0), lam1 / (1 + lam1)
        self.q1a = A(self.q1)
        self.a = a; self.aa = A(a); self.la = A(l)
        om = lambda La: 1 - 2 / (1 + (1 + 4 * La).sqrt())
        self.om0 = om(L0).lower()    # omega increasing in lam
        self.om1 = om(L1).upper()
        if tau == 0:
            self.rhomin = arb(1); self.rhomax = arb(1)
        else:
            ta = A(tau)
            rho = lambda La: ((1 + La) / (1 + La * ta)).log() / (1 + La).log()
            self.rhomin = rho(L1).lower()   # rho decreasing in lam
            self.rhomax = rho(L0).upper()
        self.logL0 = L0.log()
        # s(lam,t) = l(1+lam)^2/(lam(1+lam+lam x)), x=e^{-t}: max over the lambda-cell at lam0
        self.s_num = self.la * (1 + L0) ** 2
        self.s_c1 = (1 + L0) * L0
        self.s_c2 = L0 * L0
        self.s_inf = (self.s_num / self.s_c1).upper()
        # ---- p-table, scaled integers: value_j >= G_j/2^32 - s * H_j/2^32 on cell j (index 0 = tail)
        aw1 = ce_sc(self.aa * self.om1, 32)
        self.aw1 = aw1
        an, ad = a.numerator, a.denominator
        g = pg.g
        lam_l1 = fl_sc(self.logL0, 40)
        w0 = fl_sc(self.om0, 40)
        G = [0] * pg.n   # G[0] tail; G[j] for cell [g[j-1], g[j]] (j>=1)
        # tail: p in (0,PMIN]: Phi >= a Y(PMIN)/L(PMIN) - a omega - s * 1
        Ylo = lam_l1 + pg.l1_lo[0]
        assert Ylo >= 0
        G[0] = (an * Ylo * (1 << 32)) // (ad * pg.L_hi[0]) - aw1
        Hl = [1 << 32] + pg.h_hi[:-1]    # cell j>=1 : h(p) <= h(g[j-1])
        thr = lam1 / (1 + 2 * lam1)      # credit Yh(Y(p)) > 0 only for p > lam/(1+2lam)
        L1a = L1
        for j in range(1, pg.n):
            plo, phi_ = g[j - 1], g[j]
            Yl = lam_l1 + pg.l1_lo[j]          # Y(p) >= log lam0 + log((1-phi)/phi)
            if Yl < 0: Yl = 0                  # admissible p <= q(lam) => Y(p) >= 0
            num = Yl << 40
            if phi_ < self.q0 and plo > thr:   # credit only if p < q(lam) for all lam in the cell
                pa = pg.parb[j - 1]
                yh = (L1a * pa).log() - (L1a - (1 + L1a) * pa).log()   # Yh(Y(p)) >= value at (plo, lam1)
                yl = fl_sc(yh, 40)
                if yl > 0:
                    num += w0 * yl
            Gj = (an * num) // (ad * pg.L_hi[j] * (1 << 8)) - aw1   # a*(num/2^80)/(L/2^40) scaled 2^32
            G[j] = min(Gj, 1 << 42)
        G[0] = min(G[0], 1 << 42)
        self.G = np.array(G, dtype=np.int64)
        self.Hs = np.array(Hl, dtype=np.int64)
        self.pg = pg
        # prefix count: cells j>=1 with g[j-1] <= cap  -> number of cells = bisect_right(gf, cap)
        self.q1f = up_float(self.q1a)

    def phi_lo(self, s_hi, cap_up_float):
        """exact lower bound (as int, scale 2^52) of inf over admissible p of Phi(p) at any s <= s_hi."""
        J = bisect.bisect_right(self.pg.gf, min(cap_up_float, self.q1f))   # cells 1..J have g[j-1] <= cap
        si = ce_sc(s_hi, 20)
        v = (self.G[:J + 1] << 20) - si * self.Hs[:J + 1]
        return int(v.min())

    def s_hi(self, x_lo):
        """upper bound of lstar(t) for lam in the cell and e^{-t} >= x_lo (x_lo an arb >= 0, lower used)."""
        return (self.s_num / (self.s_c1 + self.s_c2 * x_lo.lower())).upper()

# ---------------------------------------------------------------- cell bounds
TWO52 = arb(2) ** (-52)
EPS_A = F(1, 2 ** 10)
AMAX = F(32)
CMAX = F(32)

def B_lo(lc, A0, C0):
    """lower bound of (1-a)log(1+u) - log(u+E) at worst point of the cell: u_hi = lam1 e^{-(A0+C0)}, E_hi = e^{-rhomin A0}."""
    u = lc.L1a * (-(A(A0 + C0))).exp()
    E = (-(lc.rhomin * A(A0))).exp()
    return ((1 - lc.aa) * u.log1p() - (u + E).log())

def C_lo(lc, C0, C1):
    v = lc.aa * (1 - lc.om1) * A(C0)
    if C0 > 0 and C1 is not None:
        ca = A(C1)
        yh = lc.logL0 - ca - (1 - (-ca).exp()).log()     # Yh(C1; lam0) lower bound of Yh on the cell
        if yh > 0:
            v = v + lc.aa * lc.om0 * yh
    return v

def cell_bound(lc, A0, A1, C0, C1):
    """rigorous lower bound (arb) of U on lam in lc, YA in [A0,A1] (A0>0), YC in [C0,C1] (C1=None: infinity)."""
    b = B_lo(lc, A0, C0) + C_lo(lc, C0, C1)
    if C1 is None:
        xlo = arb(0)
    else:
        xlo = (-(A(A1 + C1))).exp()
    s = lc.s_hi(xlo)
    cap = up_float(1 - (-(A(A1))).exp())
    ph = lc.phi_lo(s, cap)
    if ph >= 0:
        y = A(A0) * arb(ph) * TWO52
    else:
        y = A(A1) * arb(ph) * TWO52
    return b + y

def small_YA_bound(lc, eps, C0, C1):
    """YA in (0,eps]: U >= B_lo(A0=0) + C_lo + a(log lam0 - log(e^eps-1)) - (a omega1 + s_hi) eps."""
    b = B_lo(lc, F(0), C0) + C_lo(lc, C0, C1)
    xlo = arb(0) if C1 is None else (-(A(eps + C1))).exp()
    s = lc.s_hi(xlo)
    ea = A(eps)
    return b + lc.aa * (lc.logL0 - (ea.exp() - 1).log()) - (lc.aa * lc.om1 + s) * ea

def large_YA_bound(lc):
    """YA >= AMAX, any YC: U >= (rhomin + phi_inf) YA - log(1+lam1) (valid if rhomin+phi_inf >= 0)."""
    ph = arb(lc.phi_lo(arb(lc.s_inf), lc.q1f)) * TWO52
    slope = lc.rhomin + ph
    if not (slope >= 0):
        return slope, None
    return slope, slope * A(AMAX) - (1 + lc.L1a).log()

# ---------------------------------------------------------------- cover of one lambda-cell
class Abort(Exception):
    pass

def cover(lc, budget, stats, delta=F(0)):
    """cover (0,inf)x[0,inf) for the lambda-cell; every cell must have a rigorous lower bound > delta."""
    dA = A(delta)
    cells = 0
    worst = None
    # unbounded YA
    slope, v = large_YA_bound(lc)
    if v is None or not (v > dA):
        raise Abort(("largeYA", float(slope.mid())))
    worst = (float(v.lower().mid()), "YA>=32 (linear)")
    # small YA cells
    stack = []
    for (c0, c1) in [(F(0), CMAX), (CMAX, None)]:
        vb = small_YA_bound(lc, EPS_A, c0, c1)
        cells += 1
        if not (vb > dA):
            raise Abort(("smallYA", c0))
        w = float(vb.lower().mid())
        if w < worst[0]:
            worst = (w, "YA in (0,%s] YC in [%s,%s]" % (EPS_A, c0, c1))
    a0 = EPS_A
    top = []
    while a0 < AMAX:
        a1 = a0 * 2
        top.append((a0, a1, F(0), CMAX))
        top.append((a0, a1, CMAX, None))
        a0 = a1
    # push far-from-critical cells first so that YA in [1/8,1], YC in [0,32] is processed first (efficiency only)
    pri = lambda c: (c[3] is not None, -abs(float(c[0]) - 0.25))
    for c in sorted(top, key=pri):
        stack.append(c)
    while stack:
        A0, A1, C0, C1 = stack.pop()
        v = cell_bound(lc, A0, A1, C0, C1)
        cells += 1
        if v > dA:
            w = float(v.lower().mid())
            if w < worst[0]:
                worst = (w, "YA in [%.9g,%.9g] YC in [%.9g,%s]" % (A0, A1, C0, "inf" if C1 is None else "%.9g" % C1))
            continue
        if cells > budget:
            raise Abort(("budget", float(A0), float(C0)))
        # point test at (A_mid, C0): if it fails, refining (YA,YC) cannot help -> split lambda
        Am = (A0 + A1) / 2
        pv = cell_bound(lc, Am, Am, C0, C0 if C1 is not None else C0)
        cells += 1
        if not (pv > dA):
            raise Abort(("point", float(Am), float(C0), float(pv.mid())))
        if A1 - A0 < F(1, 2 ** 40):
            raise Abort(("tiny", float(A0), float(C0)))
        if C1 is None:
            stack.append((A0, Am, C0, C1)); stack.append((Am, A1, C0, C1))
        elif (C1 - C0) / 16 > (A1 - A0):
            Cm = (C0 + C1) / 2
            stack.append((A0, A1, C0, Cm)); stack.append((A0, A1, Cm, C1))
        else:
            stack.append((A0, Am, C0, C1)); stack.append((Am, A1, C0, C1))
    stats["cells"] += cells
    return worst

def check_case(case, pg, budget=60000, min_lam_frac=F(1, 2 ** 14), delta=F(0), tlimit=None):
    lo, hi, tau, a, l = (F(case[k]) for k in ("lo", "hi", "tau", "a", "ell"))
    assert 0 < lo <= hi <= 6 and 0 <= tau <= 1 and a >= 0 and l >= 0
    assert a < 1
    stats = {"cells": 0, "lamcells": 0, "aborts": 0}
    worst = (float("inf"), "")
    todo = [(lo, hi)]
    width0 = hi - lo
    t0 = time.time()
    while todo:
        l0, l1 = todo.pop()
        lc = LamCell(l0, l1, tau, a, l, pg)
        try:
            if tlimit is not None and time.time() - t0 > tlimit:
                return dict(ok=False, why="time limit", cells=stats["cells"], lamcells=stats["lamcells"], aborts=stats["aborts"], margin=None, where=None, secs=time.time() - t0)
            w = cover(lc, budget, stats, delta)
            stats["lamcells"] += 1
            if w[0] < worst[0]:
                worst = (w[0], "lam in [%s,%s]: %s" % (l0, l1, w[1]))
        except Abort as e:
            stats["aborts"] += 1
            if (l1 - l0) <= width0 * min_lam_frac:
                return dict(ok=False, why="lambda cell [%s,%s] still fails: %s" % (l0, l1, e.args[0]),
                            cells=stats["cells"], lamcells=stats["lamcells"], aborts=stats["aborts"],
                            margin=None, where=None, secs=time.time() - t0)
            m = (l0 + l1) / 2
            todo.append((m, l1)); todo.append((l0, m))
    return dict(ok=True, why="", cells=stats["cells"], lamcells=stats["lamcells"], aborts=stats["aborts"],
                margin=worst[0], where=worst[1], secs=time.time() - t0)

def main():
    cases = json.load(open(os.path.join(OUT, "cases.json")))
    sel = sys.argv[1] if len(sys.argv) > 1 else "all"
    tag = sys.argv[2] if len(sys.argv) > 2 else "run"
    if sel != "all":
        ids = set(sel.split(","))
        cases = [c for c in cases if c["id"] in ids]
    qmax = max(F(c["hi"]) / (1 + F(c["hi"])) for c in cases)
    pg = PGrid(qmax)
    csvp = os.path.join(OUT, "results_%s.csv" % tag)
    logp = os.path.join(OUT, "log_%s.txt" % tag)
    T0 = time.time()
    with open(csvp, "w") as fc, open(logp, "w") as fl:
        fc.write("id,lo,hi,tau,a,ell,pass,cells,lambda_cells,lambda_aborts,margin_lower_bound,margin_location,seconds,why\n")
        fl.write("start %s; p-grid %d points (PMIN=2^-10, uniform step 2^-12 beyond 2^-6, up to %.6f); prec %d\n" % (
            time.strftime("%Y-%m-%d %H:%M:%S"), pg.n, float(pg.g[-1]), ctx.prec))
        for c in cases:
            r = check_case(c, pg)
            row = [c["id"], c["lo"], c["hi"], c["tau"], c["a"], c["ell"], "PASS" if r["ok"] else "FAIL",
                   str(r["cells"]), str(r["lamcells"]), str(r["aborts"]),
                   "" if r["margin"] is None else "%.6e" % r["margin"], '"%s"' % (r["where"] or ""),
                   "%.1f" % r["secs"], '"%s"' % r["why"]]
            fc.write(",".join(row) + "\n"); fc.flush()
            msg = "%s %s cells=%d lamcells=%d aborts=%d margin=%s at %s (%.1fs) %s" % (
                c["id"], "PASS" if r["ok"] else "FAIL", r["cells"], r["lamcells"], r["aborts"],
                r["margin"], r["where"], r["secs"], r["why"])
            fl.write(msg + "\n"); fl.flush()
            print(msg, flush=True)
        fl.write("end %s total %.1fs\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), time.time() - T0))

if __name__ == "__main__":
    main()
