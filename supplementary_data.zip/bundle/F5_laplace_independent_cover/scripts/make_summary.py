#!/usr/bin/python3
"""Summarize outputs/results_final.csv and outputs/slack_ladder.csv into outputs/summary.txt."""
import csv, os
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "outputs")
rows = list(csv.DictReader(open(os.path.join(OUT, "results_final.csv"))))
lines = []
P = lambda s: lines.append(s)
P("O3 unit inequality (Lemma apC:lem:O3box), independent replay outside Lean")
P("cases: %d  PASS: %d  FAIL: %d" % (len(rows), sum(r["pass"] == "PASS" for r in rows), sum(r["pass"] != "PASS" for r in rows)))
for grp, pre in (("band certificates", "band"), ("additional intervals", "extra")):
    g = [r for r in rows if r["id"].startswith(pre)]
    P("  %s: %d cases, %d PASS, cells %d (min %d, max %d), lambda-cells per case max %d" % (
        grp, len(g), sum(r["pass"] == "PASS" for r in g), sum(int(r["cells"]) for r in g),
        min(int(r["cells"]) for r in g), max(int(r["cells"]) for r in g), max(int(r["lambda_cells"]) for r in g)))
P("total cells %d; total runtime %.1f s" % (sum(int(r["cells"]) for r in rows), sum(float(r["seconds"]) for r in rows)))
m = min(rows, key=lambda r: float(r["margin_lower_bound"]))
P("least final-cell lower bound: %s on %s at %s" % (m["margin_lower_bound"], m["id"], m["margin_location"]))
sp = os.path.join(OUT, "slack_ladder.csv")
if os.path.exists(sp):
    s = list(csv.DictReader(open(sp)))
    cert = [(float(r["certified_delta"]), r["id"]) for r in s if not r["certified_delta"].startswith("<")]
    P("slack ladder (supplementary): %d cases; certified U > delta for %d of them" % (len(s), len(cert)))
    if cert:
        P("  smallest certified delta: %.4e (%s); largest: %.4e (%s)" % (min(cert) + max(cert)))
    fe = [(float(r["float_estimate_minU"]), r["id"]) for r in s]
    P("  float estimate (non-rigorous) of min U: smallest %.4e (%s), largest %.4e (%s)" % (min(fe) + max(fe)))
P("files: results_final.csv + log_final.txt = the verdict run (scripts/o3_unit_check.py as archived);")
P("  results_full.csv/log_full.txt and results_test1.csv/log_test1.txt = earlier runs of a previous revision")
P("  (same bounds, before the delta option, cell ordering and docstring were added; identical cell counts);")
P("  validation_log.txt = validate_bounds.py (sampled mpmath check of 2512 cell bounds; perturbed cases rejected);")
P("  slack_ladder.csv = slack_ladder.py (supplementary certified U > delta); cases.json, data_crosscheck.txt = parse_data.py.")
open(os.path.join(OUT, "summary.txt"), "w").write("\n".join(lines) + "\n")
print("\n".join(lines))
