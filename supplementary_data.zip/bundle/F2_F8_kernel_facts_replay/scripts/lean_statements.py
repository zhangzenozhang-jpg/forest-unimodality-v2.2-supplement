"""Extract (statement only, not proof) the Lean kernel theorems that the replays correspond to, at aa8ba75, and
write them next to the paper's wording, for the statement comparison in the report.  Read-only (git show)."""
import os
import re
import sys

sys.path.insert(0, os.path.dirname(__file__))
from common import OUT, lean_file, strip_lean_comments

TARGETS = [
    ("1(a)", "N44/Records.lean", "rec85_valid"),
    ("1(a)", "N51/Records.lean", "rec75_valid"),
    ("1(a)", "Density/Records.lean", "rec1_valid"),
    ("1(b)", "MGF/N21/Density.lean", "band_checks21"),
    ("1(c)", "MGF/N21/Density.lean", "kmin21_low"),
    ("1(c)", "MGF/N21/Density.lean", "mmin21_eq"),
    ("2(a)", "TailCert/Glue.lean", "band_facts"),
    ("2(b)", "N44/Tail.lean", "newRows_facts"),
    ("3", "Atlas/Hyps.lean", "third_mean_rational"),
    ("4", "Erdos993Lean/Ceiling/Occupation/Arith.lean", "check3_all"),
    ("4", "Erdos993Lean/Ceiling/Occupation/Arith.lean", "check5_all"),
    ("4", "Erdos993Lean/Ceiling/Occupation/Arith.lean", "card_cases"),
    ("4", "Erdos993Lean/Ceiling/Occupation/Arith.lean", "check3_sound"),
    ("4", "Erdos993Lean/Ceiling/Occupation/Arith.lean", "check5_sound"),
]
out = []
for item, rel, name in TARGETS:
    src = strip_lean_comments(lean_file(rel))
    m = re.search(r"theorem\s+" + name + r"\b(.*?):=", src, re.S)
    stmt = " ".join(m.group(1).split()) if m else "NOT FOUND"
    out.append("[%s] %s (%s):\n    %s\n" % (item, name, rel, stmt))
with open(OUT + "/lean_statements.txt", "w") as f:
    f.write("Lean kernel-theorem statements at aa8ba75 (statements only; proofs not read)\n\n" + "\n".join(out))
print("\n".join(out))
