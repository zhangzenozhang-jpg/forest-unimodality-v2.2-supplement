#!/bin/bash
# Runs every kernel_facts replay, one process at a time, through the slot wrapper (slot C), and writes
# outputs/RUN_LOG.txt (timestamps from `date`, wall-clock per script, exit codes).
K="/Users/kvallier/Desktop/Erdos 993/ProofRuns/2026-09-28_analytic_large_n/LEAN/replay_outside_lean/kernel_facts"
SLOT="$K/../scripts/run_slot.sh"
PY=/usr/bin/python3
LOG="$K/outputs/RUN_LOG.txt"
{
  echo "kernel_facts replay run"
  echo "start: $(date)"
  echo "python: $($PY --version 2>&1); flint $($PY -c 'import flint; print(flint.__version__)'); networkx $($PY -c 'import networkx; print(networkx.__version__)')"
  echo "Lean data: $(git -C /Users/kvallier/Desktop/Erdos993-Lean-FiberFloor rev-parse aa8ba75) (read with git show, read-only)"
  echo "paper: /Users/kvallier/Desktop/Erdos 993/ProofRuns/2026-09-28_analytic_large_n/LEAN/for_tong/TWIN_v1.5 (read-only)"
} > "$LOG"
run () {
  local name="$1"; shift
  local t0=$($PY -c 'import time; print(time.time())')
  echo "--- $name: start $(date)" >> "$LOG"
  "$SLOT" C "$PY" "$K/scripts/$name" "$@" > "$K/outputs/${name%.py}.stdout" 2>&1
  local rc=$?
  local t1=$($PY -c 'import time; print(time.time())')
  echo "--- $name $*: exit $rc, wall $($PY -c "print(round($t1-$t0,2))") s, end $(date)" >> "$LOG"
}
run item1_density.py
run item23_isolated_thirdmean.py
run item4_cases.py
run extra1_semantic.py 2000 16
run lean_statements.py
echo "end: $(date)" >> "$LOG"
