"""Extra (beyond the kernel facts) for item 1: semantic sanity checks of the three density certificates.

(i)  Path tail, exactly: x I'(Pi_j;x) >= (rbar j + h8) I(Pi_j;x) for N0-2 <= j <= JMAX (the range that the finite
     conditions leave to the closed-form tail argument), exact rationals.
(ii) Tail-argument ingredients with the TRUE sqrt(1+4x) (python-flint arb balls): rbar_inf - rbar >= 0,
     K0 (h_inf - h8) sqrt(1+4x) >= 1, h_inf - h8 > 0 (the gap), r_+ >= 2|r_-| (x <= 2).
(iii) Census of the conclusions of the induction in Theorem apC:thm:records on all trees with n <= NMAX vertices
     (networkx nonisomorphic_trees): Theta_{g1} >= 0; Theta_{g3} >= 0 (n >= 3); Theta_{g*} >= 0 (a vertex of degree
     >= 3); Theta_{h8} >= 0 (n >= 8), i.e. mu_T(x) >= rbar n + const.  Exact rationals.
These are NOT part of Lemma apC:lem:density; they test the consequences the kernel facts are used for.
"""
import json
import os
import sys
import time
from fractions import Fraction as Q

sys.path.insert(0, os.path.dirname(__file__))
from common import OUT, paper_file, parse_tex_rat
import flint
import networkx as nx

flint.ctx.prec = 300
T0 = time.time()
JMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 600
NMAX = int(sys.argv[2]) if len(sys.argv) > 2 else 15
LOG = []


def log(*a):
    s = " ".join(str(x) for x in a)
    print(s, flush=True)
    LOG.append(s)


# certificates from the paper's table (parsed and compared with Lean in item1_density.py)
sys.argv = sys.argv[:1]
CERTS = {
    "8/5": dict(x=Q(8, 5), rbar=Q(156321839, 500000000), g1=Q(717241381, 5250000000),
                g3=Q(192396110281, 1000000000000), gstar=Q(45646574327, 200000000000), h8=Q(1999, 10000),
                sH=Q(27203, 10000), sL=Q(13601, 5000), K0=Q(6400), N0=17),
    "7/5": dict(x=Q(7, 5), rbar=Q(303496503, 1000000000), g1=Q(1233566443, 9500000000),
                g3=Q(7081585161, 40000000000), gstar=Q(103381134257, 500000000000), h8=Q(93, 500),
                sH=Q(25691, 10000), sL=Q(2569, 1000), K0=Q(1600), N0=15),
    "1": dict(x=Q(1), rbar=Q(138196601, 500000000), g1=Q(85410197, 750000000), g3=Q(18053399, 125000000),
              gstar=Q(582468521, 3500000000), h8=Q(104837389, 687500000), sH=Q(22361, 10000), sL=Q(559, 250),
              K0=Q(1600), N0=15),
}
# the hard-coded parameters must equal the paper's Table apC:tab:certs (parsed again here)
_src = paper_file("appendix_C_inputs.tex")
_tab = _src[_src.rindex("\\begin{table}", 0, _src.index("\\label{apC:tab:certs}")):_src.index("\\label{apC:tab:certs}")]
_sym = {"$\\bar r$": "rbar", "$g_1$": "g1", "$g_3$": "g3", "$g_\\ast$": "gstar", "$h_8$": "h8",
        "$s_H$": "sH", "$s_L$": "sL", "$K_0$": "K0", "$N_0$": "N0"}
_n = 0
for _line in _tab.splitlines():
    _cells = [_c.strip() for _c in _line.strip().rstrip("\\").split("&")]
    if _cells[0] in _sym:
        for _k, _cell in zip(["8/5", "7/5", "1"], _cells[1:]):
            assert parse_tex_rat(_cell) == CERTS[_k][_sym[_cells[0]]], (_k, _cells[0])
            _n += 1
assert _n == 27, _n
res = {"JMAX": JMAX, "NMAX": NMAX, "path_tail": {}, "tail_ingredients": {}, "census": {}}

for key, c in CERTS.items():
    x, r, h8, K0, N0 = c["x"], c["rbar"], c["h8"], c["K0"], c["N0"]
    # (i) exact path bound on N0-2..JMAX
    I0, I1, D0, D1 = Q(1), 1 + x, Q(0), x
    worst = None
    okp = True
    Ij, Dj = [I0, I1], [D0, D1]
    for j in range(2, JMAX + 1):
        I2 = I1 + x * I0
        D2 = D1 + x * (I0 + D0)
        I0, I1, D0, D1 = I1, I2, D1, D2
        if j >= N0 - 2:
            m = D2 / I2 - (r * j + h8)  # mu(Pi_j) - (rbar j + h8)
            if m < 0:
                okp = False
            if worst is None or m < worst[0]:
                worst = (m, j)
    res["path_tail"][key] = {"range": [N0 - 2, JMAX], "pass": okp, "least_margin_mu_minus_bound": float(worst[0]),
                             "at_j": worst[1]}
    log("cert x=%s (i) path bound exact for %d <= j <= %d: %s; least mu(Pi_j)-(rbar j+h8) = %.6e at j=%d" % (
        key, N0 - 2, JMAX, okp, float(worst[0]), worst[1]))
    # (ii) ingredients with the true sqrt
    s = (flint.arb((1 + 4 * x).numerator) / (1 + 4 * x).denominator).sqrt()
    xr = flint.arb(x.numerator) / x.denominator
    rr = flint.arb(r.numerator) / r.denominator
    hr = flint.arb(h8.numerator) / h8.denominator
    rbar_inf = (s - 1) / (2 * s)
    h_inf = (1 + 2 * xr - s) / (1 + 4 * xr)
    a1 = rbar_inf - rr
    a2 = flint.arb(int(K0)) * (h_inf - hr) * s - 1
    a3 = h_inf - hr
    a4 = (1 + s) / 2 - 2 * (s - 1) / 2
    ing = {"rbar_inf_minus_rbar": [float(a1.lower()), float(a1.upper()), bool(a1 >= 0)],
           "K0(h_inf-h8)sqrt-1": [float(a2.lower()), float(a2.upper()), bool(a2 >= 0)],
           "h_inf_minus_h8 (gap)": [float(a3.lower()), float(a3.upper()), bool(a3 > 0)],
           "r_plus-2|r_minus|": [float(a4.lower()), float(a4.upper()), bool(a4 >= 0)]}
    res["tail_ingredients"][key] = ing
    log("cert x=%s (ii) %s" % (key, "; ".join("%s in [%.6e, %.6e] ok=%s" % (k, *v) for k, v in ing.items())))


# (iii) census on trees
def tree_poly(G, x):
    """(I(T;x), x I'(T;x)) for a tree G, rooted DP with the product rule for D = x d/dx."""
    root = 0
    order, parent = [], {root: None}
    stack = [root]
    while stack:
        v = stack.pop()
        order.append(v)
        for w in G[v]:
            if w not in parent:
                parent[w] = v
                stack.append(w)
    ex, ein = {}, {}  # (value, Dvalue) for v excluded / v included
    for v in reversed(order):
        e0, de0 = Q(1), Q(0)  # product over children of (I_child) for v excluded
        e1, de1 = x, x  # x * product over children of (excl_child)
        for w in G[v]:
            if parent.get(w) == v:
                iw = ex[w][0] + ein[w][0]
                diw = ex[w][1] + ein[w][1]
                e0, de0 = e0 * iw, de0 * iw + e0 * diw
                e1, de1 = e1 * ex[w][0], de1 * ex[w][0] + e1 * ex[w][1]
        ex[v], ein[v] = (e0, de0), (e1, de1)
    return ex[root][0] + ein[root][0], ex[root][1] + ein[root][1]


cens = {k: {"g1": None, "g3": None, "gstar": None, "h8": None, "fails": 0} for k in CERTS}
ntrees = 0
for n in range(1, NMAX + 1):
    gens = [nx.empty_graph(1)] if n == 1 else nx.nonisomorphic_trees(n)
    cnt = 0
    for G in gens:
        cnt += 1
        maxdeg = max((d for _, d in G.degree()), default=0)
        for key, c in CERTS.items():
            I, D = tree_poly(G, c["x"])
            mu = D / I
            base = c["rbar"] * n
            for name, const, applies in [("g1", c["g1"], True), ("g3", c["g3"], n >= 3),
                                         ("gstar", c["gstar"], maxdeg >= 3), ("h8", c["h8"], n >= 8)]:
                if not applies:
                    continue
                m = mu - base - const
                if m < 0:
                    cens[key]["fails"] += 1
                cur = cens[key][name]
                if cur is None or m < cur[0]:
                    cens[key][name] = (m, n, sorted((d for _, d in G.degree()), reverse=True))
    ntrees += cnt
    log("census n=%d: %d trees (elapsed %.1f s)" % (n, cnt, time.time() - T0))
for key in CERTS:
    out = {"fails": cens[key]["fails"]}
    for name in ("g1", "g3", "gstar", "h8"):
        m, n, ds = cens[key][name]
        out[name] = {"least_margin": float(m), "exact": str(m), "n": n, "degree_seq": ds}
    res["census"][key] = out
    log("cert x=%s (iii) trees n<=%d: violations %d; least margins: %s" % (
        key, NMAX, out["fails"], "; ".join("%s %.6e (n=%d, degs %s)" % (nm, out[nm]["least_margin"], out[nm]["n"],
                                                                         out[nm]["degree_seq"][:6])
                                           for nm in ("g1", "g3", "gstar", "h8"))))
res["trees"] = ntrees
res["runtime_s"] = round(time.time() - T0, 2)
log("trees checked: %d; runtime %.1f s" % (ntrees, res["runtime_s"]))
with open(OUT + "/extra1_semantic.json", "w") as f:
    json.dump(res, f, indent=1, default=str)
with open(OUT + "/extra1_semantic.log", "w") as f:
    f.write("\n".join(LOG) + "\n")
