"""Item 4: Lemma apC:lem:cases (appendix_C_inputs.tex lines 84-95), outside Lean, exact rationals.

From the paper: Upsilon(j) = 1 + (7/3)(3/10)^j;  num_3(P) = (726k-740)P + 1736 - 2499k + 714D;
num_5(P) = (1567k-1749)P + 5082 - 5880k + 1680D;  for k >= 2, D >= 0 write D = k a + s (0 <= s < k) and
P*(k, D) = Upsilon(a)^(k-s) Upsilon(a+1)^s.  Claim: num_3(P*) > 0 for the pairs 2<=k<=12, D>=0, 714D < 1773k-996
(paper: 181 pairs) and num_5(P*) > 0 for 2<=k<=14, D>=0, 1680D < 4313k-3333 (paper: 247 pairs).
Also checked (own addition, from the proof of Theorem apC:thm:B5): on the complementary boundary regime
(1773k <= 714D + 996, resp. 4313k <= 1680D + 3333) num(1) >= 0, i.e. the lemma's pair set is exactly the complement
of the "constant terms dominate" regime for k <= 12 (resp. 14).
"""
import json
import os
import sys
import time
from fractions import Fraction as Q

sys.path.insert(0, os.path.dirname(__file__))
from common import OUT

T0 = time.time()
LOG = []


def log(*a):
    s = " ".join(str(x) for x in a)
    print(s)
    LOG.append(s)


def ups(j):
    return 1 + Q(7, 3) * Q(3, 10) ** j


def pstar(k, D):
    a, s = divmod(D, k)
    return ups(a) ** (k - s) * ups(a + 1) ** s


def num3(k, D, P):
    return (726 * k - 740) * P + 1736 - 2499 * k + 714 * D


def num5(k, D, P):
    return (1567 * k - 1749) * P + 5082 - 5880 * k + 1680 * D


res = {}
rows = []
for name, kmax, cond, num in [("num3", 12, lambda k, D: 714 * D < 1773 * k - 996, num3),
                              ("num5", 14, lambda k, D: 1680 * D < 4313 * k - 3333, num5)]:
    pairs = []
    for k in range(2, kmax + 1):
        D = 0
        while cond(k, D):
            pairs.append((k, D))
            D += 1
        # sanity: cond is monotone in D, so the loop found all D >= 0
    fails = []
    vals = []
    for k, D in pairs:
        P = pstar(k, D)
        v = num(k, D, P)
        # normalised margin: value relative to the size of the terms, and also the value with denominators cleared
        vals.append((v, k, D))
        rows.append((name, k, D, P, v))
        if not v > 0:
            fails.append((k, D, v))
    vmin = min(vals)
    # relative margin: v / ((|coef| P) + |const|)
    def relm(v, k, D):
        if name == "num3":
            c, d = 726 * k - 740, 1736 - 2499 * k + 714 * D
        else:
            c, d = 1567 * k - 1749, 5082 - 5880 * k + 1680 * D
        return v / (abs(c) * pstar(k, D) + abs(d))
    rel = min((relm(v, k, D), k, D) for v, k, D in vals)
    # boundary regime check (own addition)
    bfails = []
    for k in range(2, kmax + 1):
        for D in range(0, 200):
            if not cond(k, D):
                if num(k, D, Q(1)) < 0:
                    bfails.append((k, D))
    per_k = {}
    for k, D in pairs:
        per_k[k] = per_k.get(k, 0) + 1
    log("%s: pairs %d (per k: %s); positive: %d/%d; least value %s (~%.6e) at (k,D)=(%d,%d); least relative margin "
        "%.6e at (k,D)=(%d,%d); boundary regime num(1)>=0 on all k<=%d, D<200 outside the set: %s" % (
            name, len(pairs), per_k, len(pairs) - len(fails), len(pairs), vmin[0], float(vmin[0]), vmin[1], vmin[2],
            float(rel[0]), rel[1], rel[2], kmax, not bfails))
    res[name] = {"pairs": len(pairs), "per_k": per_k, "fails": [(k, D, str(v)) for k, D, v in fails],
                 "least_value": str(vmin[0]), "least_value_float": float(vmin[0]), "least_at": vmin[1:],
                 "least_rel": float(rel[0]), "least_rel_at": rel[1:], "boundary_regime_ok": not bfails}
res["total_pairs"] = res["num3"]["pairs"] + res["num5"]["pairs"]
res["pass"] = (not res["num3"]["fails"]) and (not res["num5"]["fails"]) and res["num3"]["pairs"] == 181 and \
    res["num5"]["pairs"] == 247
log("total pairs %d (paper 181+247=428); pass: %s" % (res["total_pairs"], res["pass"]))
with open(OUT + "/item4_cases.csv", "w") as f:
    f.write("which,k,D,Pstar_exact,num_exact,num_float\n")
    for name, k, D, P, v in rows:
        f.write("%s,%d,%d,%s,%s,%.12e\n" % (name, k, D, P, v, float(v)))
res["runtime_s"] = round(time.time() - T0, 2)
log("runtime %.2f s" % res["runtime_s"])
with open(OUT + "/item4_cases.json", "w") as f:
    json.dump(res, f, indent=1, default=str)
with open(OUT + "/item4_cases.log", "w") as f:
    f.write("\n".join(LOG) + "\n")
