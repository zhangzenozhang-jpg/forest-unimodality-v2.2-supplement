"""Shared helpers for the kernel_facts replays (outside Lean).

Read-only access: Lean data are read with `git show aa8ba75:<path>` (pinned commit, no checkout);
the paper is read from the TWIN_v1.5 folder.  Exact arithmetic only (fractions.Fraction).
"""
import os
import re
import subprocess
from fractions import Fraction as Q

LEAN_REPO = "/Users/kvallier/Desktop/Erdos993-Lean-FiberFloor"
LEAN_COMMIT = "aa8ba75"
PAPER = "/Users/kvallier/Desktop/Erdos 993/ProofRuns/2026-09-28_analytic_large_n/LEAN/for_tong/TWIN_v1.5"
OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "outputs")


def lean_file(rel):
    """Contents of Erdos993Lean/Analytic/<rel> (or a repo-relative path) at the pinned commit."""
    path = rel if rel.startswith("Erdos993Lean/") else "Erdos993Lean/Analytic/" + rel
    return subprocess.run(["git", "-C", LEAN_REPO, "show", f"{LEAN_COMMIT}:{path}"],
                          check=True, capture_output=True, text=True).stdout


def paper_file(name):
    with open(os.path.join(PAPER, name), encoding="utf-8") as f:
        return f.read()


def strip_lean_comments(src):
    src = re.sub(r"/-.*?-/", " ", src, flags=re.S)
    return re.sub(r"--[^\n]*", " ", src)


def lean_def_body(src, name):
    """Text of `def name ... :=` up to the matching close of its first bracket list."""
    src = strip_lean_comments(src)
    m = re.search(r"\bdef\s+" + re.escape(name) + r"\b[^:]*:[^=]*:=", src)
    if not m:
        raise KeyError(name)
    i = src.index("[", m.end())
    depth = 0
    for j in range(i, len(src)):
        if src[j] == "[":
            depth += 1
        elif src[j] == "]":
            depth -= 1
            if depth == 0:
                return src[i:j + 1]
    raise ValueError("unbalanced " + name)


_num = r"-?\s*\d+"


def parse_lean_rat(tok):
    """One Lean rational literal: `R (n) d`, `mkRat n d`, `n / d`, `(n / d : ℚ)`, `n`, `-n/d`, `(-n) / d`."""
    t = tok.strip()
    t = re.sub(r":\s*(ℚ|Rat)\s*", "", t)
    t = t.replace("(", " ").replace(")", " ").strip()
    m = re.fullmatch(r"(?:R|mkRat)\s+(" + _num + r")\s+(\d+)", t)
    if m:
        d = int(m.group(2))
        return Q(int(m.group(1).replace(" ", "")), d) if d else Q(0)
    m = re.fullmatch(r"(" + _num + r")\s*/\s*(\d+)", t)
    if m:
        return Q(int(m.group(1).replace(" ", "")), int(m.group(2)))
    m = re.fullmatch(_num, t)
    if m:
        return Q(int(t.replace(" ", "")))
    raise ValueError("cannot parse rational: %r" % tok)


def split_top(s):
    """Split the inside of a bracket list at top-level commas."""
    out, depth, cur = [], 0, ""
    for ch in s:
        if ch in "[(":
            depth += 1
        elif ch in "])":
            depth -= 1
        if ch == "," and depth == 0:
            out.append(cur)
            cur = ""
        else:
            cur += ch
    if cur.strip():
        out.append(cur)
    return out


def parse_list(body, conv=parse_lean_rat):
    """Parse `[a, b, ...]` or nested `[[...], [...]]`."""
    body = body.strip()
    assert body[0] == "[" and body[-1] == "]", body[:40]
    items = split_top(body[1:-1])
    res = []
    for it in items:
        it = it.strip()
        if it.startswith("["):
            res.append(parse_list(it, conv))
        else:
            res.append(conv(it))
    return res


def lean_rat_list(rel, name):
    return parse_list(lean_def_body(lean_file(rel), name))


def lean_nat_list(rel, name):
    return parse_list(lean_def_body(lean_file(rel), name), conv=lambda t: int(t.strip()))


# ---------------- LaTeX numbers ----------------
def parse_tex_rat(s):
    """A rational printed in the paper: 1/3, \\frac{a}{b}, \\tfrac{a}{b}, 6, -3/5, 0.25 (exact decimal)."""
    t = s.strip().strip("$").strip()
    t = t.replace("\\,", "").replace("{,}", "").replace(" ", "")
    t = re.sub(r"\\(?:d|t)?frac\{(-?\d+)\}\{(\d+)\}", r"\1/\2", t)
    t = re.sub(r"\\(?:d|t)?frac(\d)(\d)", r"\1/\2", t)
    t = t.replace("{", "").replace("}", "")
    if t.startswith("-") or t.startswith("−"):
        return -parse_tex_rat(t[1:])
    if "/" in t:
        a, b = t.split("/")
        return Q(int(a), int(b))
    if "." in t:
        return Q(t)
    return Q(int(t))


def fmt(q):
    return str(q) if isinstance(q, Q) else repr(q)
