"""Item 1: Lemma apC:lem:density (a), (b), (c), replayed outside Lean in exact rational arithmetic.

(a) validity conditions of a density certificate, implemented from the paper's text (appendix_C_inputs.tex, the
    paragraph "Density certificates" before Theorem apC:thm:records); the certificate parameters are parsed from
    the paper's Table apC:tab:certs AND from the Lean data (N44/Records.lean, N51/Records.lean,
    Density/Records.lean); both are compared.
(b) the four rational checks for subintervals 51..54.
(c) k_iota = 7 (iota <= 50), m21(iota) = k_iota / (2 q(lamhat_{iota+1})) for iota < 55, vs Lean data and the paper's
    Table apA:tab:pieces.
"""
import json
import math
import re
import sys
import time
from fractions import Fraction as Q

sys.path.insert(0, __import__("os").path.dirname(__file__))
from common import (OUT, lean_file, lean_rat_list, lean_nat_list, paper_file, parse_tex_rat,
                    strip_lean_comments)

T0 = time.time()
log_lines = []


def log(*a):
    s = " ".join(str(x) for x in a)
    print(s)
    log_lines.append(s)


# ------------------------------------------------------------------ data
PAPER_KEYS = ["x", "rbar", "g1", "g3", "gstar", "h8", "sH", "sL", "K0", "N0"]
# Lean Record field -> paper symbol (from the field docstrings of `structure Record`):
LEAN_TO_PAPER = {"x": "x", "r": "rbar", "s0": "g1", "g": "g3", "B0": "gstar", "h": "h8",
                 "sH": "sH", "sL": "sL", "K": "K0", "N0": "N0"}


def lean_record(rel, name):
    src = strip_lean_comments(lean_file(rel))
    m = re.search(r"def\s+" + name + r"\s*:\s*Record\s+where(.*?)(?=\n\s*(?:def|theorem|lemma|end|/--)\b|\Z)", src, re.S)
    body = m.group(1)
    rec = {}
    for fm in re.finditer(r"(\w+)\s*:=\s*([^\n]+)", body):
        k, v = fm.group(1), fm.group(2).strip()
        v = v.replace("(", "").replace(")", "")
        if "/" in v:
            a, b = v.split("/")
            val = Q(int(a.strip()), int(b.strip()))
        else:
            val = Q(int(v))
        rec[LEAN_TO_PAPER[k]] = val
    rec["N0"] = int(rec["N0"])
    return rec


def paper_certs():
    src = paper_file("appendix_C_inputs.tex")
    i = src.index("\\label{apC:tab:certs}")
    j = src.rindex("\\begin{table}", 0, i)
    tab = src[j:i]
    rows = {}
    sym = {"$\\bar r$": "rbar", "$g_1$": "g1", "$g_3$": "g3", "$g_\\ast$": "gstar", "$h_8$": "h8",
           "$s_H$": "sH", "$s_L$": "sL", "$K_0$": "K0", "$N_0$": "N0"}
    for line in tab.splitlines():
        line = line.strip()
        if not line.endswith("\\\\"):
            continue
        cells = [c.strip() for c in line[:-2].split("&")]
        if cells[0] in sym:
            rows[sym[cells[0]]] = [parse_tex_rat(c) for c in cells[1:]]
    certs = []
    for col, x in enumerate([Q(8, 5), Q(7, 5), Q(1)]):
        c = {"x": x}
        for k, v in rows.items():
            c[k] = v[col]
        c["N0"] = int(c["N0"])
        certs.append(c)
    return certs


# ------------------------------------------------------------------ the paper's definitions
def path_polys(x, jmax):
    """(I(Pi_j;x), x I'(Pi_j;x)) for j = 0..jmax, by the recursions printed in the paper."""
    I = [Q(1), 1 + x]
    D = [Q(0), x]
    for j in range(2, jmax + 1):
        I.append(I[j - 1] + x * I[j - 2])
        D.append(D[j - 1] + x * (I[j - 2] + D[j - 2]))
    return I, D


def type_bounds(c):
    x, r = c["x"], c["rbar"]
    I, D = path_polys(x, 3)
    mu = [D[j] / I[j] for j in range(4)]
    alpha = [mu[1] - r, mu[2] - 2 * r, mu[3] - 3 * r, mu[3] - 3 * r, c["g3"]]
    beta = [mu[0], mu[1] - r, mu[2] - 2 * r, 2 * mu[1] - 2 * r, c["g3"]]
    lo = [I[0] / I[1], I[1] / I[2], I[2] / I[3], I[1] ** 2 / I[3], 1 / (1 + x)]
    hi = [I[0] / I[1], I[1] / I[2], I[2] / I[3], I[1] ** 2 / I[3], Q(1)]
    return alpha, beta, lo, hi


def validity(c):
    """List of (group, fact label, slack, strict) with slack = larger side - smaller side (exact)."""
    x, r, g1, g3, gs, h8 = c["x"], c["rbar"], c["g1"], c["g3"], c["gstar"], c["h8"]
    sH, sL, K0, N0 = c["sH"], c["sL"], c["K0"], c["N0"]
    F = []

    def add(group, label, slack, strict=False):
        F.append((group, label, slack, strict))

    add("0<x", "0 < x", x, True)
    add("x<=2", "x <= 2", 2 - x)
    add("0<=rbar", "0 <= rbar", r)
    add("2rbar<1", "2 rbar < 1", 1 - 2 * r, True)
    add("(1-2rbar)^2(1+4x)>=1", "(1-2rbar)^2(1+4x) >= 1", (1 - 2 * r) ** 2 * (1 + 4 * x) - 1)
    add("0<=g1", "0 <= g1", g1)
    add("g1<=g3", "g1 <= g3", g3 - g1)
    add("g3<=h8", "g3 <= h8", h8 - g3)
    add("h8<=g*", "h8 <= g*", gs - h8)
    add("h8<=2g1", "h8 <= 2 g1", 2 * g1 - h8)
    add("g*+rbar<=4g1", "g* + rbar <= 4 g1", 4 * g1 - gs - r)
    add("0<=sL", "0 <= sL", sL)
    add("sL<=sqrt(1+4x)", "sL^2 <= 1+4x", 1 + 4 * x - sL ** 2)
    add("0<=sH", "0 <= sH (needed for sqrt(1+4x) <= sH)", sH)
    add("sqrt(1+4x)<=sH", "1+4x <= sH^2", sH ** 2 - (1 + 4 * x))
    add("K0>=0", "K0 >= 0", K0)
    add("K0-path", "K0((1+2x-sH)/(1+4x)-h8) sL >= 1", K0 * ((1 + 2 * x - sH) / (1 + 4 * x) - h8) * sL - 1)
    add("N0>=10", "N0 >= 10", Q(N0 - 10))
    add("K0N0+1<=2^N0", "K0 N0 + 1 <= 2^N0", Q(2) ** N0 - (K0 * N0 + 1))
    I, D = path_polys(x, max(N0, 8))
    for j in range(1, N0 - 3 + 1):
        g = g1 if j <= 2 else (g3 if j <= 7 else h8)
        add("path", "x I'(Pi_%d) >= (rbar*%d + %s) I(Pi_%d)" % (j, j, "g1" if j <= 2 else ("g3" if j <= 7 else "h8"), j),
            D[j] - (r * j + g) * I[j])
    alpha, beta, lo, hi = type_bounds(c)
    for t in range(5):
        add("lo>=0", "lo_%d >= 0" % t, lo[t])
    for t in range(5):
        add("gains", "alpha_%d >= 0" % t, alpha[t])
        add("gains", "alpha_%d + x hi_%d (beta_%d - rbar) >= 0" % (t, t, t), alpha[t] + x * hi[t] * (beta[t] - r))
    for d in (3, 4):
        grp = "deg%d" % d
        for tup in __import__("itertools").product(range(5), repeat=d):
            c0 = sum(alpha[t] for t in tup) - r - gs
            c1 = 1 - (d + 1) * r + sum(beta[t] for t in tup) - gs
            plo = x
            phi = x
            for t in tup:
                plo *= lo[t]
                phi *= hi[t]
            add(grp, "%s lo-end" % (tup,), c0 + c1 * plo)
            add(grp, "%s hi-end" % (tup,), c0 + c1 * phi)
    return F


def ok(slack, strict):
    return slack > 0 if strict else slack >= 0


# ------------------------------------------------------------------ (a)
res = {"item": "1", "lemma": "apC:lem:density"}
log("== Item 1(a): validity of the three density certificates (paper's conditions) ==")
pcerts = paper_certs()
lean_recs = {"8/5": lean_record("N44/Records.lean", "rec85"),
             "7/5": lean_record("N51/Records.lean", "rec75"),
             "1": lean_record("Density/Records.lean", "rec1")}
res["a"] = {}
all_a = True
for pc, (key, lc) in zip(pcerts, lean_recs.items()):
    diffs = [k for k in PAPER_KEYS if pc[k] != lc[k]]
    log("cert x=%s: paper table vs Lean data: %s" % (key, "identical (10 parameters)" if not diffs else "DIFFER in %s" % diffs))
    F = validity(pc)
    groups = []
    for g in [f[0] for f in F]:
        if g not in groups:
            groups.append(g)
    per_group = {}
    for g in groups:
        fs = [f for f in F if f[0] == g]
        okall = all(ok(f[2], f[3]) for f in fs)
        mn = min(fs, key=lambda f: f[2])
        per_group[g] = {"facts": len(fs), "pass": okall, "min_slack": str(mn[2]),
                        "min_slack_float": float(mn[2]), "argmin": mn[1]}
    npass = sum(1 for f in F if ok(f[2], f[3]))
    allok = npass == len(F)
    all_a &= allok and not diffs
    overall_min = min(F, key=lambda f: f[2])
    log("  facts: %d (groups: %d); pass: %d/%d; least slack %.6e at [%s] %s" % (
        len(F), len(groups), npass, len(F), float(overall_min[2]), overall_min[0], overall_min[1]))
    for g in groups:
        pg = per_group[g]
        log("    %-22s n=%-5d %s  min slack %.6e  (%s)" % (g, pg["facts"], "PASS" if pg["pass"] else "FAIL",
                                                        pg["min_slack_float"], pg["argmin"]))
    res["a"][key] = {"paper_vs_lean_param_diffs": diffs, "facts": len(F), "groups": len(groups),
                     "passed": npass, "pass": allok, "least_slack": str(overall_min[2]),
                     "least_slack_float": float(overall_min[2]), "least_slack_at": overall_min[1],
                     "per_group": per_group}
    # per-fact CSV
    with open("%s/item1a_facts_x%s.csv" % (OUT, key.replace("/", "_")), "w") as f:
        f.write("group,fact,slack_exact,slack_float,strict,pass\n")
        for g, lab, s, st in F:
            f.write('%s,"%s",%s,%.12e,%s,%s\n' % (g, lab, s, float(s), st, ok(s, st)))
res["a"]["pass_all"] = all_a

# ------------------------------------------------------------------ (b), (c)
log("== Item 1(b): the four rational checks on subintervals 51..54 ==")
lo_l = lean_rat_list("N44/Data/Params.lean", "pieceLo")
hi_l = lean_rat_list("N44/Data/Params.lean", "pieceHi")
assert len(lo_l) == 55 and len(hi_l) == 55
contig = all(hi_l[i] == lo_l[i + 1] for i in range(54)) and lo_l[0] == Q(1, 3) and hi_l[54] == Q(7, 3)
log("Lean pieceLo/pieceHi: 55 subintervals, contiguous from 1/3 to 7/3: %s" % contig)
lam = lo_l + [hi_l[54]]  # lamhat_0..lamhat_55


def q(l):
    return l / (1 + l)


cert_of = {51: pcerts[0], 52: pcerts[1], 53: pcerts[1], 54: pcerts[2]}
printed = {51: "49.1648968", 52: "49.1726592", 53: "49.5757138", 54: "49.1300953"}
printed_sqrt = {51: "7.011768451", 52: "7.012321958", 53: "7.041002331", 54: "7.009286362"}
printed_ratio = {51: Q(507, 472), 52: Q(8, 7), 53: Q(492, 427), 54: Q(18, 13)}
printed_lin = {51: Q(3382708619, 500000000), 52: Q(6559426563, 1000000000), 53: Q(6559426563, 1000000000),
               54: Q(32762113943, 5500000000)}
printed_I = {51: (Q(39, 20), Q(2)), 52: (Q(2), Q(41, 20)), 53: (Q(41, 20), Q(9, 4)), 54: (Q(9, 4), Q(7, 3))}


def trunc_dec(v, k):
    """floor(v * 10^k) as a decimal string with k places (v > 0 rational)."""
    n = (v.numerator * 10 ** k) // v.denominator
    s = str(n)
    return s[:-k] + "." + s[-k:]


def sqrt_dec(v, k):
    n = math.isqrt((v.numerator * 10 ** (2 * k)) // v.denominator)  # = floor(sqrt(v) 10^k)
    s = str(n)
    return s[:-k] + "." + s[-k:], n


res["b"] = {}
all_b = True
k_lean = lean_nat_list("MGF/N21/Data.lean", "kmin21")
m_lean = lean_rat_list("MGF/N21/Data.lean", "mmin21")
for i in range(51, 55):
    c = cert_of[i]
    x, r, h8 = c["x"], c["rbar"], c["h8"]
    k = 8
    ratio = q(lam[i]) / q(x)
    lin = 21 * r + h8
    rhs = ratio * lin ** 2
    c1 = x <= lam[i]
    c2 = (k - 1) ** 2 < rhs
    t7 = trunc_dec(rhs, 7)
    sq9, sqn = sqrt_dec(rhs, 9)
    sq_round9 = (sqn + (1 if sqrt_dec(rhs, 10)[1] % 10 >= 5 else 0))
    sq_round9 = str(sq_round9)[:-9] + "." + str(sq_round9)[-9:]
    matches = {"interval": printed_I[i] == (lam[i], lam[i + 1]), "ratio": printed_ratio[i] == ratio,
               "21r+h8": printed_lin[i] == lin, "rhs_digits": t7 == printed[i],
               "sqrt_digits(trunc or round)": printed_sqrt[i] in (sq9, sq_round9),
               "lean_k": k_lean[i] == 8, "between_49_64": 49 < rhs <= 64}
    passed = c1 and c2 and all(matches.values())
    all_b &= passed
    log("iota=%d  I=[%s,%s] x=%s  x<=lamhat: %s  q-ratio=%s  21r+h8=%s  RHS=%s... (printed %s...)  "
        "margin RHS-49=%.9f  sqrt=%s (printed %s)  table-matches=%s" % (
            i, lam[i], lam[i + 1], x, c1, ratio, lin, trunc_dec(rhs, 10), printed[i], float(rhs - 49), sq9,
            printed_sqrt[i], all(matches.values())))
    res["b"][str(i)] = {"x": str(x), "lamhat": str(lam[i]), "x_le_lamhat": c1, "x_slack": str(lam[i] - x),
                        "rhs_exact": str(rhs), "rhs_trunc10": trunc_dec(rhs, 10), "printed": printed[i],
                        "rhs_gt_49": c2, "margin_rhs_minus_49": float(rhs - 49), "sqrt_trunc9": sq9,
                        "sqrt_round9": sq_round9, "printed_sqrt": printed_sqrt[i], "matches": matches,
                        "pass": passed}
res["b"]["pass_all"] = all_b

log("== Item 1(c): k_iota and m21(iota) ==")
paper_A = paper_file("appendix_A_pieces.tex")
i0 = paper_A.index("\\begin{tabular}", paper_A.index("\\begin{table}[p]"))
i1 = paper_A.index("\\end{tabular}", i0)
rows = []
for line in paper_A[i0:i1].splitlines():
    line = line.strip()
    if re.match(r"^\d+\s*&", line):
        cells = [cc.strip() for cc in line.rstrip("\\").rstrip().rstrip("\\").split("&")]
        rows.append(cells)
assert len(rows) == 55, len(rows)
res["c"] = {"rows": []}
all_c = True
disc = []
for i in range(55):
    cells = rows[i]
    assert int(cells[0]) == i
    m = re.match(r"\$\[(.*),\\,(.*)\]\$", cells[2])
    pa, pb = parse_tex_rat(m.group(1)), parse_tex_rat(m.group(2))
    pk = int(cells[6].strip("$"))
    pm = parse_tex_rat(cells[8])
    k = 7 if i <= 50 else 8
    m21 = Q(k) / (2 * q(lam[i + 1]))
    checks = {"k_rule_vs_lean": k_lean[i] == k, "k_paper": pk == k, "m21_lean": m_lean[i] == m21,
              "m21_paper": pm == m21, "endpoints_paper": (pa, pb) == (lam[i], lam[i + 1])}
    if not all(checks.values()):
        disc.append((i, checks, str(m21), str(m_lean[i]), str(pm)))
    all_c &= all(checks.values())
    res["c"]["rows"].append({"iota": i, "k": k, "m21": str(m21), "lean_m21": str(m_lean[i]), "paper_m21": str(pm),
                             "checks": checks})
vals = [Q(r_["m21"]) for r_ in res["c"]["rows"]]
imin = min(range(55), key=lambda i: vals[i])
imax = max(range(55), key=lambda i: vals[i])
log("lists: Lean kmin21 len %d, mmin21 len %d; k rule (7 for iota<=50, 8 for 51..54) vs Lean: %s" % (
    len(k_lean), len(m_lean), all(r_["checks"]["k_rule_vs_lean"] for r_ in res["c"]["rows"])))
log("m21 = k/(2q(lamhat_{iota+1})): equals Lean mmin21 on all 55: %s; equals paper column m21 on all 55: %s; "
    "paper k column: %s; paper endpoints = Lean endpoints: %s" % (
        all(r_["checks"]["m21_lean"] for r_ in res["c"]["rows"]),
        all(r_["checks"]["m21_paper"] for r_ in res["c"]["rows"]),
        all(r_["checks"]["k_paper"] for r_ in res["c"]["rows"]),
        all(r_["checks"]["endpoints_paper"] for r_ in res["c"]["rows"])))
log("smallest m21 = %s at iota=%d (paper: 413/78 at 50); largest = %s at iota=%d (paper: 119/9 at 0)" % (
    vals[imin], imin, vals[imax], imax))
res["c"]["min"] = [str(vals[imin]), imin]
res["c"]["max"] = [str(vals[imax]), imax]
res["c"]["min_max_match_paper"] = (vals[imin], imin, vals[imax], imax) == (Q(413, 78), 50, Q(119, 9), 0)
res["c"]["discrepancies"] = disc
res["c"]["pass_all"] = all_c and res["c"]["min_max_match_paper"] and contig
for d in disc:
    log("DISCREPANCY (c):", d)

# ------------------------------------------------------------------ comparison with Lean `Valid` (after the fact)
log("== Comparison of my condition groups with the fields of Lean `Record.Valid` (read only after the checks) ==")
src = strip_lean_comments(lean_file("Density/Record.lean"))
vs = src[src.index("structure Valid"):]
vs = vs[:vs.index("\n\n")] if "\n\n" in vs else vs
fields = re.findall(r"^\s{2}(\w+)\s*:", vs, re.M)
log("Lean Valid fields (%d): %s" % (len(fields), ", ".join(fields)))
mine = list(res["a"]["8/5"]["per_group"].keys())
log("my groups (%d): %s" % (len(mine), ", ".join(mine)))
res["lean_valid_fields"] = fields
res["my_groups"] = mine
res["runtime_s"] = round(time.time() - T0, 2)
log("runtime %.2f s" % res["runtime_s"])
with open(OUT + "/item1_density.json", "w") as f:
    json.dump(res, f, indent=1, default=str)
with open(OUT + "/item1_density.log", "w") as f:
    f.write("\n".join(log_lines) + "\n")
