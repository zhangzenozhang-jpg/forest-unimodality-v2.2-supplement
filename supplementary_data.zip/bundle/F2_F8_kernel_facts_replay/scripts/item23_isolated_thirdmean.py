"""Items 2 and 3: Lemma cs:lem:isolated (a), (b) and Lemma cs:lem:thirdmean, outside Lean.

Own argument for 2(a): for 0 <= tau <= 1 the map lam -> (1+lam)/(1+lam*tau) is nondecreasing on lam >= 0
(derivative (1-tau)/(1+lam*tau)^2 >= 0), so ell <= log((1+lam)/(1+lam*tau)) for all lam >= lam_i iff
e^ell <= (1+lam_i)/(1+lam_i*tau) (lam_i = 1/3 > 0).  Decided with an exact rational upper bound of e^ell:
  for 0 <= ell <= 1:  e^ell <= sum_{j<=N} ell^j/j! + 3 ell^(N+1)/(N+1)!   (Lagrange remainder, e^xi <= e < 3), N = 14;
  for ell <= 0: e^ell <= 1 <= (1+lam_i)/(1+lam_i*tau) (tau <= 1).
Margins log((1+lam_i)/(1+lam_i*tau)) - ell are also enclosed with python-flint arb (rigorous balls), as a second,
independent decision.
2(b): 0 <= ell <= 1, a_U >= 0, e^ell <= 1 + lamhat_iota, the same two ways.
3: exact rational: 3 ell_0 - 1/10 >= 0 and 1 + lam_{i+1} <= sum_{j<12} (3 ell_0 - 1/10)^j / j!.
Data: Profile30.lean (edges, tvals, rates), TailCert/Glue.lean (aTab), N44/Data/Params.lean (pieceLo/Hi, newEll,
newA, rowOf), Ladder/O3/Rows.lean (rowLo/Hi/A/Ell), N48/TailChecks/P*.lean; paper Tables apA:tab:rates, apA:tab:a,
apA:tab:extra, apA:tab:pieces.
"""
import json
import math
import os
import re
import sys
import time
from fractions import Fraction as Q

sys.path.insert(0, os.path.dirname(__file__))
from common import OUT, lean_file, lean_rat_list, lean_nat_list, paper_file, parse_tex_rat, strip_lean_comments
import flint

flint.ctx.prec = 200
T0 = time.time()
LOG = []


def log(*a):
    s = " ".join(str(x) for x in a)
    print(s)
    LOG.append(s)


def exp_upper(ell, N=14):
    """Rational upper bound of e^ell for 0 <= ell <= 1."""
    assert 0 <= ell <= 1
    s, term = Q(0), Q(1)
    for j in range(N + 1):
        s += term
        term = term * ell / (j + 1)
    return s + 3 * term  # term = ell^(N+1)/(N+1)!


def paper_ub(ell):
    """The paper's stated bound: e^ell <= sum_{j<=4} ell^j/j! + ell^5/100 (valid for 0 <= ell <= 1)."""
    return 1 + ell + ell ** 2 / 2 + ell ** 3 / 6 + ell ** 4 / 24 + ell ** 5 / 100


def arb_of(qq):
    return flint.arb(qq.numerator) / flint.arb(qq.denominator)


def arb_log_margin(arg, ell):
    """Rigorous ball for log(arg) - ell; returns (lower, upper) as floats-with-direction strings and the ball."""
    b = flint.arb(arg.numerator) / arg.denominator
    m = b.log() - arb_of(ell)
    return m


# ---------------------------------------------------------------- data
edges = lean_rat_list("Profile30.lean", "edges")
tvals = lean_rat_list("Profile30.lean", "tvals")
rates = lean_rat_list("Profile30.lean", "rates")
aTab = lean_rat_list("TailCert/Glue.lean", "aTab")
assert len(edges) == 31 and len(rates) == 30 and all(len(r) == 5 for r in rates)
assert len(aTab) == 30 and all(len(r) == 5 for r in aTab)
paper_tau = [Q(0), Q(1, 20), Q(1, 10), Q(1, 5), Q(3, 10)]

A = paper_file("appendix_A_pieces.tex")


def table_rows(label, ncols_min):
    i = A.index("\\label{%s}" % label)
    j = A.rindex("\\begin{table}", 0, i)
    rows = []
    for line in A[j:i].splitlines():
        line = line.strip()
        if re.match(r"^\d+\s*&", line):
            cells = [c.strip() for c in re.sub(r"\\\\\s*$", "", line).split("&")]
            if len(cells) >= ncols_min:
                rows.append(cells)
    return rows


rate_rows = table_rows("apA:tab:rates", 7)
a_rows = table_rows("apA:tab:a", 6)
extra_rows_raw = table_rows("apA:tab:extra", 10)
assert len(rate_rows) == 30 and len(a_rows) == 30 and len(extra_rows_raw) == 13
disc = []
# paper rates table vs Lean
for i, c in enumerate(rate_rows):
    assert int(c[0]) == i
    m = re.match(r"\$\((.*),\\,(.*)\]\$", c[1])
    lo_, hi_ = parse_tex_rat(m.group(1)), parse_tex_rat(m.group(2))
    if (lo_, hi_) != (edges[i], edges[i + 1]):
        disc.append("rates table band %d endpoints %s,%s vs Lean edges %s,%s" % (i, lo_, hi_, edges[i], edges[i + 1]))
    pr = [parse_tex_rat(x) for x in c[2:7]]
    if pr != rates[i]:
        disc.append("rates table band %d: paper %s vs Lean %s" % (i, pr, rates[i]))
for i, c in enumerate(a_rows):
    assert int(c[0]) == i
    pa = [parse_tex_rat(x) for x in c[1:6]]
    if pa != aTab[i]:
        disc.append("a table band %d: paper %s vs Lean %s" % (i, pa, aTab[i]))
if tvals != paper_tau:
    disc.append("tilts: Lean tvals %s vs paper %s" % (tvals, paper_tau))
log("== data cross-checks: paper Tables apA:tab:rates (30x5 + endpoints), apA:tab:a (30x5), tilts vs Lean: %s" % (
    "all identical" if not disc else "%d DISCREPANCIES" % len(disc)))
for d in disc:
    log("DISCREPANCY:", d)

# ---------------------------------------------------------------- item 2(a)
log("== Item 2(a): 150 band/tilt cases ==")
res = {"item2a": [], "item2b": [], "item3": [], "data_discrepancies": disc}
fails = 0
for i in range(30):
    lam = edges[i]
    for r in range(5):
        tau, ell, aU = paper_tau[r], rates[i][r], aTab[i][r]
        arg = (1 + lam) / (1 + lam * tau)
        c_a = aU >= 0
        c_t = 0 <= tau <= 1
        mono = c_t and lam >= 0  # (1+lam)/(1+lam tau) nondecreasing in lam
        if ell <= 0:
            c_e, slack_exp = True, None
        else:
            assert ell <= 1
            ub = exp_upper(ell)
            c_e = ub <= arg
            slack_exp = arg - ub
        mb = arb_log_margin(arg, ell)
        arb_ok = bool(mb > 0)
        in01 = 0 <= ell <= 1
        pslack = arg - paper_ub(ell)
        ok = c_a and c_t and mono and c_e and arb_ok
        fails += not ok
        res["item2a"].append({"band": i, "r": r, "lam_i": str(lam), "tau": str(tau), "ell": str(ell), "aU": str(aU),
                              "arg": str(arg), "rational_slack_arg_minus_expub": str(slack_exp),
                              "rational_slack_float": float(slack_exp) if slack_exp is not None else None,
                              "log_margin_lower": float(mb.lower()), "log_margin_upper": float(mb.upper()),
                              "arb_pos": arb_ok, "ell_in_01": in01, "paper_taylor_slack": float(pslack),
                              "paper_taylor_ok": pslack >= 0 and in01, "pass": ok})
mn = min(res["item2a"], key=lambda d: d["log_margin_lower"])
mn2 = min(res["item2a"], key=lambda d: d["rational_slack_float"])
log("150 cases: pass %d/150; least margin log((1+lam_i)/(1+lam_i tau)) - ell in [%.6e, %.6e] at band %d, r=%d "
    "(ell=%s, lam_i=%s); least rational slack (1+lam_i)/(1+lam_i tau) - expUB(ell) = %.6e at band %d, r=%d" % (
        150 - fails, mn["log_margin_lower"], mn["log_margin_upper"], mn["band"], mn["r"], mn["ell"], mn["lam_i"],
        mn2["rational_slack_float"], mn2["band"], mn2["r"]))
log("min a_U = %s; all tilts in [0,1]: %s" % (min(min(r) for r in aTab), all(0 <= t <= 1 for t in paper_tau)))
_tail = flint.arb(1).exp() - flint.arb(65) / 24
log("paper's method (Taylor bound sum_{j<=4} + ell^5/100, valid on [0,1] since e - 65/24 in [%.10f, %.10f] < 1/100: %s): "
    "all 150 rates in [0,1]: %s; bound <= (1+lam_i)/(1+lam_i tau) in %d/150 cases; least slack %.6e at band %d, r=%d" % (
        float(_tail.lower()), float(_tail.upper()), bool(_tail < flint.arb(1) / 100),
        all(d["ell_in_01"] for d in res["item2a"]), sum(d["paper_taylor_ok"] for d in res["item2a"]),
        min(d["paper_taylor_slack"] for d in res["item2a"]),
        min(res["item2a"], key=lambda d: d["paper_taylor_slack"])["band"],
        min(res["item2a"], key=lambda d: d["paper_taylor_slack"])["r"]))
res["item2a_paper_method_pass"] = all(d["paper_taylor_ok"] for d in res["item2a"])
res["item2a_pass"] = fails == 0
with open(OUT + "/item2a_cases.csv", "w") as f:
    f.write("band,r,lam_i,tau,ell,aU,arg,log_margin_lower,log_margin_upper,rational_slack,pass\n")
    for d in res["item2a"]:
        f.write("%d,%d,%s,%s,%s,%s,%s,%.12e,%.12e,%.12e,%s\n" % (d["band"], d["r"], d["lam_i"], d["tau"], d["ell"],
                                                               d["aU"], d["arg"], d["log_margin_lower"],
                                                               d["log_margin_upper"], d["rational_slack_float"],
                                                               d["pass"]))

# ---------------------------------------------------------------- item 2(b)
log("== Item 2(b): the subintervals carrying additional intervals ==")
pieceLo = lean_rat_list("N44/Data/Params.lean", "pieceLo")
pieceHi = lean_rat_list("N44/Data/Params.lean", "pieceHi")
newEll = lean_rat_list("N44/Data/Params.lean", "newEll")
newA = lean_rat_list("N44/Data/Params.lean", "newA")
rowOf = lean_nat_list("N44/Data/Params.lean", "rowOf")
rowLo = lean_rat_list("Ladder/O3/Rows.lean", "rowLo")
rowHi = lean_rat_list("Ladder/O3/Rows.lean", "rowHi")
rowA = lean_rat_list("Ladder/O3/Rows.lean", "rowA")
rowEll = lean_rat_list("Ladder/O3/Rows.lean", "rowEll")
assert len(rowLo) == len(rowHi) == len(rowA) == len(rowEll) == 26
carriers = [p for p in range(55) if newEll[p] != 0]
log("Lean: pieces with newEll != 0: %d (%s)" % (len(carriers), carriers))
# paper extra table: two halves per line
extra = {}
for c in extra_rows_raw:
    for half in (c[0:5], c[5:10]):
        no = int(half[0])
        m = re.match(r"\$\[(.*),\\,(.*)\]\$", half[1])
        extra[no] = {"lo": parse_tex_rat(m.group(1)), "hi": parse_tex_rat(m.group(2)), "aU": parse_tex_rat(half[2]),
                     "ell": parse_tex_rat(half[3]), "iota": int(half[4])}
assert sorted(extra) == list(range(1, 27))
# paper pieces table: add. column and ell0 column
P_i = A.index("\\begin{tabular}", A.index("\\begin{table}[p]"))
P_j = A.index("\\end{tabular}", P_i)
prow = []
for line in A[P_i:P_j].splitlines():
    line = line.strip()
    if re.match(r"^\d+\s*&", line):
        prow.append([c.strip() for c in re.sub(r"\\\\\s*$", "", line).split("&")])
assert len(prow) == 55
pieces_add = {int(c[0]): int(c[12]) for c in prow if c[12].strip()}
pieces_ell0 = {int(c[0]): parse_tex_rat(c[5]) for c in prow}
pieces_band = {int(c[0]): int(c[1]) for c in prow}
paper_carriers = sorted(e["iota"] for e in extra.values())
if paper_carriers != carriers:
    disc.append("carriers: paper extra-table iotas %s vs Lean newEll!=0 pieces %s" % (paper_carriers, carriers))
if sorted(pieces_add) != paper_carriers:
    disc.append("pieces-table add. column iotas %s vs extra-table iotas %s" % (sorted(pieces_add), paper_carriers))
fails_b = 0
for no in range(1, 27):
    e = extra[no]
    p = e["iota"]
    lamhat = pieceLo[p]
    ell, aU = e["ell"], e["aU"]
    # data consistency (paper vs Lean)
    dd = []
    if newEll[p] != ell:
        dd.append("newEll[%d]=%s vs paper ell %s" % (p, newEll[p], ell))
    if newA[p] != aU:
        dd.append("newA[%d]=%s vs paper aU %s" % (p, newA[p], aU))
    ro = rowOf[p]
    if ro >= 26 or (rowLo[ro], rowHi[ro], rowA[ro], rowEll[ro]) != (e["lo"], e["hi"], aU, ell):
        dd.append("Lean row %d = (%s,%s,%s,%s) vs paper no.%d (%s,%s,%s,%s)" % (
            ro, rowLo[ro] if ro < 26 else None, rowHi[ro] if ro < 26 else None, rowA[ro] if ro < 26 else None,
            rowEll[ro] if ro < 26 else None, no, e["lo"], e["hi"], aU, ell))
    if ro < 26 and ro + 1 != no:
        dd.append("numbering: paper no.%d is Lean row index %d" % (no, ro))
    if pieces_add.get(p) != no:
        dd.append("pieces-table add.(%d)=%s vs extra no.%d" % (p, pieces_add.get(p), no))
    if pieces_ell0[p] != ell:
        dd.append("pieces-table ell0(%d)=%s vs extra ell %s" % (p, pieces_ell0[p], ell))
    contains = e["lo"] <= pieceLo[p] and pieceHi[p] <= e["hi"]
    if not contains:
        dd.append("interval no.%d [%s,%s] does not contain I_%d=[%s,%s]" % (no, e["lo"], e["hi"], p, pieceLo[p],
                                                                         pieceHi[p]))
    disc.extend(dd)
    c1 = 0 <= ell <= 1
    c2 = aU >= 0
    ub = exp_upper(ell)
    c3 = ub <= 1 + lamhat
    mb = arb_log_margin(1 + lamhat, ell)
    ok = c1 and c2 and c3 and bool(mb > 0)
    pslack_b = 1 + lamhat - paper_ub(ell)
    fails_b += not ok
    res["item2b"].append({"no": no, "iota": p, "lamhat": str(lamhat), "ell": str(ell), "aU": str(aU),
                          "rational_slack": float(1 + lamhat - ub), "log_margin_lower": float(mb.lower()),
                          "log_margin_upper": float(mb.upper()), "paper_taylor_slack": float(pslack_b),
                          "pass": ok, "data_discrepancies": dd})
mnb = min(res["item2b"], key=lambda d: d["log_margin_lower"])
log("26 intervals: pass %d/26; least margin log(1+lamhat) - ell in [%.6e, %.6e] at no.%d (iota=%d, ell=%s, "
    "lamhat=%s)" % (26 - fails_b, mnb["log_margin_lower"], mnb["log_margin_upper"], mnb["no"], mnb["iota"],
                    mnb["ell"], mnb["lamhat"]))
log("paper-method bound sum_{j<=4} + ell^5/100 <= 1 + lamhat: %d/26; least slack %.6e" % (
    sum(d["paper_taylor_slack"] >= 0 for d in res["item2b"]), min(d["paper_taylor_slack"] for d in res["item2b"])))
# order-48 intervals 1..4 vs N48/TailChecks
n48 = []
for fn in ["P22", "P26", "P27", "P28"]:
    src = strip_lean_comments(lean_file("N48/TailChecks/%s.lean" % fn))
    for m in re.finditer(r"checkBand\s+\(([^)]*)\)\s+\(([^)]*)\)\s+\(([^)]*)\)\s+\(([^)]*)\)\s+(\S+)", src):
        vals = [parse_tex_rat(v) for v in m.groups()[:4]]
        n48.append((fn, vals, m.group(5)))
log("N48/TailChecks checkBand rows (lo, hi, a, ell, tau): %s" % [(f, [str(v) for v in vs], t) for f, vs, t in n48])
for k, (fn, vs, t) in enumerate(n48[:4]):
    e = extra[k + 1]
    if vs != [e["lo"], e["hi"], e["aU"], e["ell"]] or t != "0":
        disc.append("N48 %s row %s vs paper no.%d %s" % (fn, vs, k + 1, (e["lo"], e["hi"], e["aU"], e["ell"])))
res["item2b_pass"] = fails_b == 0
with open(OUT + "/item2b_cases.csv", "w") as f:
    f.write("no,iota,lamhat,ell,aU,rational_slack,log_margin_lower,log_margin_upper,pass\n")
    for d in res["item2b"]:
        f.write("%d,%d,%s,%s,%s,%.12e,%.12e,%.12e,%s\n" % (d["no"], d["iota"], d["lamhat"], d["ell"], d["aU"],
                                                        d["rational_slack"], d["log_margin_lower"],
                                                        d["log_margin_upper"], d["pass"]))

# ---------------------------------------------------------------- item 3
log("== Item 3: Lemma cs:lem:thirdmean (30 bands) ==")
fails3 = 0
for i in range(30):
    l0 = rates[i][0]
    y = 3 * l0 - Q(1, 10)
    s, term = Q(0), Q(1)
    for j in range(12):  # j < 12
        s += term
        term = term * y / (j + 1)
    c1 = y >= 0
    c2 = 1 + edges[i + 1] <= s
    # independent rigorous cross-check: e^y vs 1 + lam_{i+1} (the partial sum is a lower bound of e^y)
    ok = c1 and c2
    fails3 += not ok
    res["item3"].append({"band": i, "ell0": str(l0), "y": str(y), "lam_ip1": str(edges[i + 1]),
                         "partial_sum_minus_rhs": float(s - 1 - edges[i + 1]),
                         "rel_slack": float((s - 1 - edges[i + 1]) / (1 + edges[i + 1])), "pass": ok})
mn3 = min(res["item3"], key=lambda d: d["partial_sum_minus_rhs"])
log("30 bands: pass %d/30; least slack sum_{j<12} y^j/j! - (1+lam_{i+1}) = %.6e at band %d (ell0=%s, lam_{i+1}=%s); "
    "min y = %s" % (30 - fails3, mn3["partial_sum_minus_rhs"], mn3["band"], mn3["ell0"], mn3["lam_ip1"],
                    min(Q(d["y"]) for d in res["item3"])))
res["item3_pass"] = fails3 == 0
with open(OUT + "/item3_bands.csv", "w") as f:
    f.write("band,ell0,y,lam_ip1,slack,rel_slack,pass\n")
    for d in res["item3"]:
        f.write("%d,%s,%s,%s,%.12e,%.6e,%s\n" % (d["band"], d["ell0"], d["y"], d["lam_ip1"],
                                                 d["partial_sum_minus_rhs"], d["rel_slack"], d["pass"]))
res["data_discrepancies"] = disc
log("data discrepancies (all): %d" % len(disc))
for d in disc:
    log("DISCREPANCY:", d)
res["runtime_s"] = round(time.time() - T0, 2)
log("runtime %.2f s" % res["runtime_s"])
with open(OUT + "/item23.json", "w") as f:
    json.dump(res, f, indent=1, default=str)
with open(OUT + "/item23.log", "w") as f:
    f.write("\n".join(LOG) + "\n")
