"""base_transport.py -- PROVED (exact rational): the base inequality of the reserve induction,
   S(lam) = D q^2 - alpha log(1+lam) - gamma q^2/log(1+lam) > 0,  D = 6/5, alpha = 23q/50, gamma = lam(3+lam)/13,
on an activity interval, by the same transport: on [la, lb] with centre lc,
   S(lam) >= S(lc) - max(dp * max(0, -inf S_mu), dm * max(0, sup S_mu)),
   S_mu = dS/dmu = 2D q qd - alphad l - alpha q - (gammad q^2/l + 2 gamma q qd/l - gamma q^3/l^2),
with l = log(1+lam), qd = q(1-q) = lam/(1+lam)^2, dl/dmu = q, alphad = 23 qd/50, gammad = lam(3+2lam)/13;
S_mu is enclosed on [la, lb] by interval arithmetic. The intervals are chosen greedily.
Usage: base_transport.py lo hi"""
import sys, os
from fractions import Fraction as Fr
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ival import I
from ratlib import log_enc
D = Fr(6, 5)
def S_point(lam):
    q = lam / (1 + lam); al = Fr(23, 50) * q; ga = lam * (3 + lam) / 13; l = I(*log_enc(1 + lam))
    return D * q * q - al * l - ga * q * q / l
def S_mu(la, lb):
    L = I(la, lb); q = I(la / (1 + la), lb / (1 + lb)); qd = L / (1 + L).sq()
    al = Fr(23, 50) * q; ga = L * (3 + L) / 13; l = I(log_enc(1 + la)[0], log_enc(1 + lb)[1])
    ald = Fr(23, 50) * qd; gad = L * (3 + 2 * L) / 13
    return 2 * D * q * qd - ald * l - al * q - (gad * q.sq() / l + 2 * ga * q * qd / l - ga * q.sq() * q / l.sq())
def piece(la, lb):
    lc = (la + lb) / 2
    dm = log_enc(lc / la)[1]; dp = log_enc(lb / lc)[1]
    s = S_point(lc).lo; d = S_mu(la, lb)
    return s - max(dp * max(Fr(0), -d.lo), dm * max(Fr(0), d.hi)), s, d
def greedy(lo, hi, grid=Fr(1, 2000)):
    out = []; a = lo
    ok = lambda x, y: piece(x, y)[0] > 0
    while a < hi:
        if not ok(a, min(a + grid, hi)): raise RuntimeError('stuck at %s' % a)
        k = 1
        while a + k * grid < hi and ok(a, min(a + 2 * k * grid, hi)): k *= 2
        x, y = k, 2 * k
        while y - x > 1:
            m = (x + y) // 2
            if ok(a, min(a + m * grid, hi)): x = m
            else: y = m
        b = min(a + x * grid, hi)
        if b < hi and ok(a, hi): b = hi
        out.append((a, b)); a = b
    return out
if __name__ == '__main__':
    lo, hi = Fr(sys.argv[1]), Fr(sys.argv[2])
    P = greedy(lo, hi)
    for a, b in P:
        v, s, d = piece(a, b)
        print('  [%s, %s]  S(centre) >= %.5f  dS/dmu in %s  bound %.5f' % (a, b, float(s), d, float(v)))
    print('base inequality (D = 6/5) PROVED on [%s, %s] with %d exact checks' % (lo, hi, len(P)))
