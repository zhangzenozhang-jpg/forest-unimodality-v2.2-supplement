# DIAGNOSTIC: the mu-derivative formulas of tfun.py (d_mu Phi, d_mu Phig, d_mu C at fixed Y) against central finite
# differences in floats, and the Y-derivative formulas at lam != 1 against finite differences.
import math, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
from tfun import dmu_phi, dmu_C, point_prims, phi_all, C_all
from ival import I
def fl(lam, Y, rho, J, Jbar):
    q = lam/(1+lam); al = 23*q/50; ga = lam*(3+lam)/13; AD = 1+q/5
    p = lam*math.exp(-Y)/(1+lam*math.exp(-Y)); y0 = math.log1p(lam*math.exp(-Y)); k = p/y0; ul = math.exp(Y)/lam
    h = 1-p+ga*k; N = AD-h-al/k; Q = ga+J*(ga*ul-h*Y)
    Phi = al*ul+N/Y+al*rho-J*h*h/Q; Phig = al*ul+N/Y+al*rho-J*h*h/ga
    l = h*Y-ga*ul; B = ul+(math.log(lam)-math.log(math.expm1(Y))-1/k)/Y; C = al*B-ga*l/(ga-Jbar*l)
    return Phi, Phig, C
worst = 0
for lam in (Fr(47, 50), Fr(1), Fr(23, 20), Fr(13, 10)):
    for Y in (Fr(3, 10), Fr(7, 10), Fr(13, 10), Fr(2)):
        for rho, J in ((Fr(0), Fr(3, 100)), (Fr(87, 100), Fr(145, 1000)), (Fr(2), Fr(21, 100))):
            e = 1e-6; L = float(lam); a = fl(L*math.exp(e), float(Y), float(rho), float(J), 0.25); b = fl(L*math.exp(-e), float(Y), float(rho), float(J), 0.25)
            fd = [(x-y)/(2*e) for x, y in zip(a, b)]
            D = dmu_phi(Y, Y, lam, lam, I(J), rho); mu = math.log(L); dc = dmu_C(Y, Y, lam, lam, Fr(1, 4), I(Fr(mu).limit_denominator(10**12)))
            for x, y in ((D['Phi'], fd[0]), (D['Phig'], fd[1]), (dc, fd[2])):
                worst = max(worst, abs(float(x.lo)-y))
            # Y-derivatives at lam
            f1 = [(x-y)/(2*e) for x, y in zip(fl(L, float(Y)+e, float(rho), float(J), 0.25), fl(L, float(Y)-e, float(rho), float(J), 0.25))]
            ul, p, y0, k = point_prims(Y, lam); P = phi_all(ul, p, k, I(Y), I(J), rho, lam)
            muI = I(Fr(mu).limit_denominator(10**12)); Cc = C_all(Y, Y, lam, Fr(1, 4), muI)
            worst = max(worst, abs(float(P['Phi1'].lo)-f1[0]), abs(float(P['Phig1'].lo)-f1[1]), abs(float(Cc['C1'].lo)-f1[2]))
print('max |formula - finite difference| over 48 test points (d_mu Phi, d_mu Phig, d_mu C, Phi\', Phig\', C\'): %.2e' % worst)
