# DIAGNOSTIC (floats): census of the transport certificate. For every sub-interval in outputs/transport_*.json:
#  (a) at random (lam, Y) in Lam x piece, each certified vertex function (Phi or Phig at its vertex) is >= its piece bound;
#  (b) at random (lam, Y) in Lam x piece, the CA bound C(Y, lam) is >= its piece bound (Taylor-transport pieces);
#  (c) at random lam <= lam_p, random children lie under the polygon proved at lam_p;
#  (d) at random feasible pairs (Yt, Y) and lam in Lam, the true AC/p >= 0 and CA/p >= 0 where L < 0.
import json, sys, os, math, random
from fractions import Fraction as Fr
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
random.seed(993)
def mult(l): q = l/(1+l); return 23*q/50, l*(3+l)/13, 1+q/5
def par(l, Y):
    al, ga, AD = mult(l); p = l*math.exp(-Y)/(1+l*math.exp(-Y)); y0 = math.log1p(l*math.exp(-Y)); k = p/y0
    h = 1-p+ga*k; ul = math.exp(Y)/l; return al, ga, AD, p, k, h, ul
def vf(l, Y, rho, J, tag):
    al, ga, AD, p, k, h, ul = par(l, Y); N = AD-h-al/k; Q = ga+J*(ga*ul-h*Y)
    return al*ul+N/Y+al*rho-J*h*h/(Q if tag == 'Phi' else ga)
def Cf(l, Y, Jb):
    al, ga, AD, p, k, h, ul = par(l, Y); lL = h*Y-ga*ul
    B = ul+(math.log(l)-math.log(math.expm1(Y))-1/k)/Y; return al*B-ga*lL/(ga-Jb*lL)
def child(l, t):
    s = l*math.exp(-t)/(1+l*math.exp(-t)); y = math.log1p(l*math.exp(-t)); return t/y, s*s*t/y, s, y
na = nb = nc = nd = 0; worst = dict(a=1e9, b=1e9, c=1e9, d_ac=1e9, d_ca=1e9)
for f in sys.argv[1:]:
    R = json.load(open(f))
    for sub in R['subintervals']:
        la, lb = float(Fr(sub['la'])), float(Fr(sub['lb'])); Jb = float(Fr(sub['Jbar']))
        for c in sub['core']:
            if c['vertex'] == 'cut-polygon':
                items = [(float(Fr(x['Y0'])), float(Fr(x['Y1'])), float(Fr(x['rho'])), float(Fr(x['J'])), x['tag'], x['bound']) for x in c['checks']]
            else:
                items = [(float(Fr(a)), float(Fr(b)), float(Fr(c['rho'])), float(Fr(c['J'])), c['tag'], bd) for (a, b), bd in zip(c['pieces'], c['bounds'])]
            for Y0, Y1, rho, J, tag, bd in items:
                for _ in range(20):
                    l = random.uniform(la, lb); Y = random.uniform(Y0, Y1); v = vf(l, Y, rho, J, tag) - bd
                    worst['a'] = min(worst['a'], v); na += 1
        for x in sub['ca']:
            if x['Lpos']: continue
            for _ in range(20):
                l = random.uniform(la, lb); Y = random.uniform(float(Fr(x['Y0'])), float(Fr(x['Y1'])))
                worst['b'] = min(worst['b'], Cf(l, Y, Jb) - x['bound']); nb += 1
        V = [(float(Fr(r)), float(Fr(j))) for r, j in sub['vertices']]
        lines = []
        for (r1, j1), (r2, j2) in zip(V, V[1:]): b = (j2-j1)/(r2-r1); lines.append((j1-b*r1, b))
        lines.append((V[-1][1], 0.0))
        for _ in range(300):
            l = random.uniform(la, lb); t = random.expovariate(0.5); rho, J, s, y = child(l, t)
            worst['c'] = min(worst['c'], min(a+b*rho for a, b in lines) - J); nc += 1
        for _ in range(3000):
            l = random.uniform(la, lb); Y = random.expovariate(0.7)+1e-4
            tmin = max(0.0, math.log(l)-math.log(math.expm1(Y))); t = tmin+random.expovariate(0.6)
            rho, J, s, y = child(l, t)
            if y > Y: continue
            al, ga, AD, p, k, h, ul = par(l, Y); Lp = ga*ul-h*Y; Q = ga+J*Lp
            ac = al*(ul+rho-1/(k*Y))+(AD-h)/Y-J*h*h/Q; worst['d_ac'] = min(worst['d_ac'], ac)
            if Lp < 0: worst['d_ca'] = min(worst['d_ca'], al*(ul+rho-1/(k*Y))+ga*Lp*(s/y)**2/Q)
            nd += 1
print('census: (a) %d vertex-function samples, min(F - piece bound) = %.5f' % (na, worst['a']))
print('        (b) %d CA samples, min(C - piece bound) = %.5f' % (nb, worst['b']))
print('        (c) %d child samples, min(polygon - J) = %.5f' % (nc, worst['c']))
print('        (d) %d feasible pairs: min AC/p = %.5f, min CA/p (L<0) = %.5f' % (nd, worst['d_ac'], worst['d_ca']))
print('census', 'CLEAN' if min(worst.values()) >= 0 else 'VIOLATION')
