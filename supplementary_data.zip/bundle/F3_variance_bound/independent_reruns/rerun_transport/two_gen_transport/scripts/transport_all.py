"""transport_all.py -- PROVED (exact rational): runs transport_certificate.run on a list of activity sub-intervals
covering a target interval; each polygon (proved at an activity lam_p >= lb, valid for all lam <= lam_p) is counted once.
Usage: transport_all.py PLAN   (PLAN = upper | lower)"""
import sys, os, json, time
from fractions import Fraction as Fr
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import transport_certificate as T
PLANS = {
 'upper': [  # (la, lb, lp, YL, cut) covering [47/50, 13/10]
    ('47/50', '1', '1', '3/10', False), ('1', '21/20', '21/20', '3/10', False),
    ('21/20', '11/10', '23/20', '1/4', False), ('11/10', '23/20', '23/20', '1/4', False),
    ('23/20', '6/5', '5/4', '1/4', True), ('6/5', '5/4', '5/4', '1/5', True), ('5/4', '13/10', '13/10', '1/5', True)],
 'final': [  # [11/20, 263/200], polygons shared by pairs of sub-intervals (counted once)
    ('11/20', '9/16', '23/40', '1/5', False), ('9/16', '23/40', '23/40', '1/5', False),
    ('23/40', '3/5', '5/8', '1/5', False), ('3/5', '5/8', '5/8', '1/5', False),
    ('5/8', '13/20', '27/40', '1/5', False), ('13/20', '27/40', '27/40', '1/5', False),
    ('27/40', '7/10', '3/4', '1/5', False), ('7/10', '3/4', '3/4', '1/5', False),
    ('3/4', '4/5', '17/20', '1/5', False), ('4/5', '17/20', '17/20', '1/5', False),
    ('17/20', '9/10', '47/50', '1/5', False), ('9/10', '47/50', '47/50', '1/5', False),
    ('47/50', '1', '21/20', '3/10', False), ('1', '21/20', '21/20', '3/10', False),
    ('21/20', '11/10', '23/20', '1/4', False), ('11/10', '23/20', '23/20', '1/4', False),
    ('23/20', '6/5', '5/4', '1/4', True), ('6/5', '5/4', '5/4', '1/5', True),
    ('5/4', '13/10', '131/100', '1/5', True), ('13/10', '131/100', '131/100', '1/5', True),
    ('131/100', '263/200', '263/200', '1/5', True)],
 'ext': [  # extensions: up to the base-inequality root (lambda* = 1.3157) and below 3/5
    ('13/10', '131/100', '131/100', '1/5', True), ('131/100', '263/200', '263/200', '1/5', True),
    ('23/40', '3/5', '3/5', '1/5', False), ('11/20', '23/40', '23/40', '1/5', False),   # index 3: stuck (too wide), superseded by 4, 5
    ('9/16', '23/40', '23/40', '1/5', False), ('11/20', '9/16', '9/16', '1/5', False)],
 'lower': [  # covering [3/5, 47/50]
    ('3/5', '5/8', '5/8', '1/5', False), ('5/8', '13/20', '13/20', '1/5', False), ('13/20', '27/40', '27/40', '1/5', False),
    ('27/40', '7/10', '7/10', '1/5', False), ('7/10', '3/4', '3/4', '1/5', False),
    ('3/4', '4/5', '4/5', '1/5', False), ('4/5', '17/20', '17/20', '1/5', False), ('17/20', '9/10', '9/10', '1/5', False),
    ('9/10', '47/50', '47/50', '1/5', False)],
}
if __name__ == '__main__':
    name = sys.argv[1]; only = [int(x) for x in sys.argv[2:]]
    out = []; t0 = time.time(); total = 0; lines = []
    for i, (la, lb, lp, yl, cut) in enumerate(PLANS[name]):
        if only and i not in only: continue
        rep, log = T.run(Fr(la), Fr(lb), None, verbose=False, YL=Fr(yl), cut=cut, lp=Fr(lp))
        out.append(rep); total += rep['checks']; lines += ['--- sub-interval [%s, %s], polygon at %s, YL = %s, cut = %s' % (la, lb, lp, yl, cut)] + log
        print('\n'.join(lines[-len(log) - 1:]), flush=True)
    polys = {k: v['checks'] for k, v in T._POLY.items()}
    ptot = sum(polys.values())
    print('polygons: %s' % {str(k[0]): v for k, v in polys.items()})
    print('PLAN %s: %d sub-intervals, %d checks excluding polygons + %d polygon checks = %d exact checks; ALL PASS (%.0f s)' % (
        name, len(out), total, ptot, total + ptot, time.time() - t0))
    json.dump(dict(plan=name, subintervals=out, polygon_checks={str(k[0]): v for k, v in polys.items()}, total=total + ptot),
              open(os.path.join(HERE, '..', 'outputs', 'transport_%s%s.json' % (name, ''.join('_%d' % i for i in only))), 'w'), indent=1)
