"""base_beyond.py -- exact check for the Remark after the theorem: the base-inequality slack
S(lam) = (6/5)q^2 - alpha log(1+lam) - gamma q^2/log(1+lam) (alpha = 23q/50, gamma = lam(3+lam)/13) decreases in mu = log(lam)
on [13/10, 4] (dS/dmu enclosed by interval arithmetic on a cover by intervals), gamma > (6/5) log(1+lam) for lam >= 4
(so S < 0 there), and the root lam* is bracketed by exact evaluations; also the least D the base inequality allows at 8/5."""
import sys, os
from fractions import Fraction as Fr
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from base_transport import S_point, S_mu
from ratlib import log_enc
a, n = Fr(13, 10), 0
while a < 4:
    b = min(a + Fr(1, 40), Fr(4)); d = S_mu(a, b); assert d.hi < 0, (a, b, d); a = b; n += 1
g4 = Fr(4) * 7 / 13 - Fr(6, 5) * log_enc(Fr(5))[1]
assert g4 > 0 and Fr(11, 13) > Fr(6, 25)       # gamma' = (3+2 lam)/13 >= 11/13 > 6/25 >= ((6/5) log(1+lam))' for lam >= 4
lo_, hi_ = Fr(13156793, 10**7) - Fr(1, 10**7), Fr(13156793, 10**7) + Fr(1, 10**7)
assert S_point(lo_).lo > 0 and S_point(hi_).hi < 0
q = Fr(8, 13); al = Fr(23, 50) * q; ga = Fr(8, 5) * (3 + Fr(8, 5)) / 13; L = log_enc(Fr(13, 5))
Dlo = (al * L[0] + ga * q * q / L[1]) / (q * q); Dhi = (al * L[1] + ga * q * q / L[0]) / (q * q)
print('dS/dmu < 0 on [13/10, 4] (%d intervals); gamma - (6/5)log(1+lam) >= %.4f at 4 and increasing; so S < 0 for lam > lam*' % (n, float(g4)))
print('lam* in [%s, %s] (S > 0 at the left end, S < 0 at the right end); lam* = 1.3156793 to 7 decimals' % (lo_, hi_))
print('least D allowed by the base inequality at lam = 8/5: in [%.7f, %.7f]' % (float(Dlo), float(Dhi)))
