# DIAGNOSTIC (floats): design probe for the activity transport. For a polygon computed at activity lp (tangent lines at
# 3/10, 3/5, 1 + cap, intercepts = max over a dense child grid), evaluate at activity lam <= lp:
#  (i) min over Y in [YL, 4] of the vertex functions Phi, Phig (all 4 vertices);
#  (ii) min over Y in (0, YL] of the feasibility left-flank function Psi (rho >= Ytmin(Y)/Y, J <= Jbar(lam)).
import numpy as np, sys
def mult(lam):
    q = lam/(1+lam); return 23*q/50, lam*(3+lam)/13, 1+q/5
def child(lam, t):
    s = lam*np.exp(-t)/(1+lam*np.exp(-t)); y = np.log1p(lam*np.exp(-t)); rho = t/y; return rho, s*s*rho
def polygon(lam, TP=(0.3, 0.6, 1.0)):
    t = np.linspace(1e-9, 12, 200001); rho, J = child(lam, t); lines = []
    for tp in TP:
        h = 1e-6; r1, J1 = child(lam, tp+h); r0, J0 = child(lam, tp-h); b = (J1-J0)/(r1-r0)
        lines.append((max(0, (J-b*rho).max()), b))
    lines.append((J.max(), 0.0)); V = [(0.0, lines[0][0])]
    for (a1, b1), (a2, b2) in zip(lines, lines[1:]):
        r = (a2-a1)/(b1-b2); V.append((r, a1+b1*r))
    return lines, V
def parent(lam, Y):
    al, ga, AD = mult(lam); p = lam*np.exp(-Y)/(1+lam*np.exp(-Y)); y0 = np.log1p(lam*np.exp(-Y)); k = p/y0
    h = 1-p+ga*k; ul = np.exp(Y)/lam; N = AD-h-al/k; Lp = ga*ul-h*Y
    return al, ga, AD, ul, h, N, Lp
def vfun(lam, Y, rho, J):
    al, ga, AD, ul, h, N, Lp = parent(lam, Y); Q = ga+J*Lp
    return al*ul+N/Y+al*rho-J*h*h/Q, al*ul+N/Y+al*rho-J*h*h/ga
def jbar(lam):
    t = np.linspace(0, 10, 100001); return (t/(1+np.exp(t)/lam)).max()
def psi(lam, Y):
    al, ga, AD, ul, h, N, Lp = parent(lam, Y); Jb = jbar(lam)
    ytmin = np.maximum(0, np.log(lam)-np.log(np.expm1(Y)))
    return al*ul+(N+al*ytmin)/Y-Jb*h*h/(ga+Jb*np.minimum(Lp, 0))
if __name__ == '__main__':
    YL = float(sys.argv[1]) if len(sys.argv) > 1 else 0.3
    Yg = np.linspace(YL, 4, 4000); Ys = np.linspace(1e-3, YL, 2000)
    for lp in [1.0, 1.1, 1.2, 1.3]:
        lines, V = polygon(lp)
        print('polygon at %.2f: V =' % lp, [(round(r, 3), round(j, 3)) for r, j in V])
        for lam in [lp-0.1, lp-0.05, lp]:
            if lam < 0.94-1e-9: continue
            mins = []
            for r, j in V:
                a, b = vfun(lam, Yg, r, j); mins.append(min(a.min(), b.min()))
            print('   lam %.2f: min vertex fn on [%.2f,4] = %s ; min Psi on (0,%.2f] = %.4f' % (lam, YL, [round(m, 4) for m in mins], YL, psi(lam, Ys).min()))
