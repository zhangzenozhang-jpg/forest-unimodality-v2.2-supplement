# DIAGNOSTIC (floats): the root lambda* of the base-inequality slack S(lam) = (6/5)q^2 - alpha log(1+lam) - gamma q^2/log(1+lam)
# (alpha = 23q/50, gamma = lam(3+lam)/13), and the least D the base inequality allows at lam = 8/5 with these multipliers.
import math
def parts(l):
    q = l/(1+l); a = 23*q/50; g = l*(3+l)/13; L = math.log(1+l); return q, a*L+g*q*q/L
def S(l): q, r = parts(l); return 1.2*q*q-r
lo, hi = 1.3, 1.4
for _ in range(80):
    m = (lo+hi)/2; lo, hi = (m, hi) if S(m) > 0 else (lo, m)
print('base slack S(13/10) = %.5f; root lambda* = %.6f' % (S(1.3), lo))
for l in (1.4, 1.5, 1.6):
    q, r = parts(l); print('lam %.2f: least D allowed by the base inequality = %.4f' % (l, r/(q*q)))
