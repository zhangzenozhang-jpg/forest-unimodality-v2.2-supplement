# DIAGNOSTIC: size of the mu-derivative of the tight vertex function near its minimiser. For the polygon at lam (child_poly),
# the vertex v1 function Phi(Y; v1) at activity lam: float minimiser Y*, the float d_mu Phi at (Y*, lam) (fixed Y), and the
# exact interval enclosure of d_mu Phi on the box [Y*-1/20, Y*+1/20] x [lam - 1/40, lam + 1/40] (tfun.dmu_phi).
import sys, os, math
from fractions import Fraction as Fr
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from tfun import dmu_phi
from ival import I
from child_poly import polygon
def phi(l, Y, rho, J):
    q = l/(1+l); al = 23*q/50; ga = l*(3+l)/13; AD = 1+q/5
    p = l*math.exp(-Y)/(1+l*math.exp(-Y)); y0 = math.log1p(l*math.exp(-Y)); k = p/y0; h = 1-p+ga*k; ul = math.exp(Y)/l
    return al*ul+(AD-h-al/k)/Y+al*rho-J*h*h/(ga+J*(ga*ul-h*Y))
for lam in (Fr(3, 5), Fr(1), Fr(13, 10)):
    P = polygon(lam); rho, J = P['V'][1]; r, j = float(rho), float(J); L = float(lam)
    Ys = min((phi(L, 0.2+i/1000, r, j), 0.2+i/1000) for i in range(2800))
    Y = Ys[1]; e = 1e-6; d = (phi(L*math.exp(e), Y, r, j)-phi(L*math.exp(-e), Y, r, j))/(2*e)
    Yq = Fr(Y).limit_denominator(1000); D = dmu_phi(Yq-Fr(1, 20), Yq+Fr(1, 20), lam-Fr(1, 40), lam+Fr(1, 40), I(J), rho)['Phi']
    print('lam %s: v1 = (%.3f, %.3f), min Phi = %.4f at Y* = %.3f, d_mu Phi(Y*) = %.3f, box enclosure %s' % (lam, r, j, Ys[0], Y, d, D))
