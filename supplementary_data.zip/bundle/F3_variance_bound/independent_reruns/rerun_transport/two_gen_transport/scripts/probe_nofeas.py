# DIAGNOSTIC (floats): min over ALL children Yt >= 0 (feasibility ignored) and Y in [0.05, 4] of AC/p, versus lambda;
# and the same with the 4-vertex polygon at lambda (min over vertices of min(Phi, Phig)). Locates where the lambda = 1
# architecture (AC without feasibility) stops working.
import numpy as np
from probe_design import mult, child, polygon, vfun
Yt = np.linspace(0, 8, 1601); Y = np.linspace(0.05, 4, 1581); A, B = np.meshgrid(Yt, Y, indexing='ij')
for lam in [0.6, 0.7, 0.8, 0.94, 1.0, 1.1, 1.15, 1.2, 1.22, 1.24, 1.26, 1.28, 1.3, 1.4, 1.6]:
    al, ga, AD = mult(lam); rho, J = child(lam, np.maximum(A, 1e-12))
    p = lam*np.exp(-B)/(1+lam*np.exp(-B)); y0 = np.log1p(lam*np.exp(-B)); k = p/y0; h = 1-p+ga*k; ul = np.exp(B)/lam
    Q = ga+J*(ga*ul-h*B); ac = al*(ul+rho-1/(k*B))+(AD-h)/B-J*h*h/Q
    i = np.unravel_index(np.argmin(ac), ac.shape)
    lines, V = polygon(lam); vm = min(min(vfun(lam, Y, r, j)[0].min(), vfun(lam, Y, r, j)[1].min()) for r, j in V)
    lines6, V6 = polygon(lam, TP=(0.2, 0.4, 0.6, 0.8, 1.0, 1.3)); vm6 = min(min(vfun(lam, Y, r, j)[0].min(), vfun(lam, Y, r, j)[1].min()) for r, j in V6)
    print('lam %.2f: min AC/p (no feasibility) %.4f at (Yt,Y)=(%.2f,%.2f); 4-vertex polygon %.4f; 7-vertex polygon %.4f' % (lam, ac.min(), A[i], B[i], vm, vm6))
