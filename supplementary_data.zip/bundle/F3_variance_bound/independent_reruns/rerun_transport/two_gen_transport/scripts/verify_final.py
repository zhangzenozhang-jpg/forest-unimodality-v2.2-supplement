"""verify_final.py -- the final certificate of transport_section.tex (version 2, after the referee's report).
Every check on the final subdivision, with exactly the enclosure method stated in the text:
 * primitives on a box [Y0,Y1] x [la,lb] (or [Y0,Y1] at one activity) by their values at the corners (Y0,lb), (Y1,la):
   u_lam, k increase and p, y0, w decrease in x = Y - mu (w: dw/dx = kw - p(1-p) < 0 while p <= 1 - 1/e; asserted p <= 0.63);
 * p(1-p) by its values at the two ends of the range of p, and by 1/4 when that range contains 1/2;
 * alpha, gamma, A_D, gamma-dot by their values at la, lb (increasing); q(1-q) = lam/(1+lam)^2 by its values at la, lb
   (no sub-interval contains 1 in its interior, asserted);
 * m (curvature) and d_- , d_+ (mu-derivative) are the extreme interval values over the TWO HALVES of each parent
   subinterval (always), of the Y-derivative formulas (no mean-value forms) at lc and of the mu-derivative formulas on
   half x [la, lb];
 * polygons: the six-decimal constants of the referee's report (MF4), re-proved here on the child curve at lambda_p;
 * cut points (floor_6 of the lower end of rho_f(Y1), U(.)); base inequality on the six intervals of the text.
Reads the subdivision from outputs/transport_{upper,lower,ext_0,ext_1,ext_2,ext_4,ext_5}.json (parent and CA
subintervals only); writes final_data/*.json (same format, new vertices, Jbar, cut points and bounds) and a log.
Usage: verify_final.py"""
import sys, os, json, math, time
from fractions import Fraction as Fr
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from ival import I
from ratlib import exp_pos, msg, lm, log_enc
from tfun import mults, point_prims, pp_of, phi_all
import child_poly as CP
from base_transport import S_point, S_mu
ROOT = os.path.join(HERE, '..')
FILES = ['transport_lower.json', 'transport_upper.json', 'transport_ext_0.json', 'transport_ext_1.json',
         'transport_ext_2.json', 'transport_ext_4.json', 'transport_ext_5.json']
# six-decimal polygon constants (referee_transport/rt_decimal_polygons.log, MF4): lambda_p: a0 b0 a1 b1 a2 b2 Jcap
POLY_TXT = """9/16 0.025279 0.057282 0.074661 0.022210 0.135587 0.003914 0.161255
23/40 0.025444 0.059259 0.075402 0.023117 0.137416 0.004136 0.164090
3/5 0.025747 0.063249 0.076813 0.024971 0.140965 0.004600 0.169690
5/8 0.026019 0.067285 0.078133 0.026876 0.144373 0.005090 0.175199
13/20 0.026263 0.071361 0.079369 0.028829 0.147646 0.005606 0.180620
27/40 0.026479 0.075472 0.080524 0.030827 0.150789 0.006148 0.185956
7/10 0.026671 0.079612 0.081604 0.032870 0.153805 0.006716 0.191210
3/4 0.026986 0.087968 0.083549 0.037078 0.159482 0.007927 0.201480
4/5 0.027222 0.096397 0.085236 0.041437 0.164709 0.009239 0.211450
17/20 0.027387 0.104874 0.086691 0.045932 0.169520 0.010647 0.221137
9/10 0.027493 0.113373 0.087937 0.050548 0.173946 0.012150 0.230558
47/50 0.027540 0.120176 0.088799 0.054320 0.177226 0.013419 0.237912
1 0.027556 0.130365 0.089886 0.060093 0.181745 0.015427 0.248655
21/20 0.027527 0.138824 0.090624 0.064997 0.185168 0.017194 0.257358
23/20 0.027371 0.155606 0.091704 0.075016 0.191167 0.020971 0.274129
5/4 0.027116 0.172140 0.092337 0.085253 0.196164 0.025046 0.290121
13/10 0.026959 0.180294 0.092513 0.090433 0.198328 0.027188 0.297847
131/100 0.026925 0.181915 0.092539 0.091473 0.198736 0.027624 0.299372
263/200 0.026908 0.182725 0.092550 0.091993 0.198937 0.027843 0.300132"""
POLY = {}
for line in POLY_TXT.splitlines():
    f = line.split(); c = [Fr(x) for x in f[1:]]
    POLY[Fr(f[0])] = [(c[0], c[1]), (c[2], c[3]), (c[4], c[5]), (c[6], Fr(0))]
BASE = [Fr(11, 20), Fr(1491, 2000), Fr(387, 400), Fr(461, 400), Fr(633, 500), Fr(1309, 1000), Fr(263, 200)]
LOG = []
def out(s=''):
    print(s, flush=True); LOG.append(s)
# ------------------------------------------------------------------ enclosures (the stated method)
def corner_box(Y0, Y1, la, lb):
    uA, pA, yA, kA = point_prims(Y0, lb); uB, pB, yB, kB = point_prims(Y1, la)
    assert pA.hi <= Fr(63, 100), 'p > 0.63: monotonicity of w not proved'
    wA = kA + pA - 1; wB = kB + pB - 1
    return I(uA.lo, uB.hi), I(pB.lo, pA.hi), I(yB.lo, yA.hi), I(kA.lo, kB.hi), I(wB.lo, wA.hi)
def act(la, lb):
    assert not (la < 1 < lb), 'q(1-q) is not monotone across 1'
    a0, g0, d0 = mults(la); a1, g1, d1 = mults(lb)
    q0, q1 = la / (1 + la) ** 2, lb / (1 + lb) ** 2; qq = I(min(q0, q1), max(q0, q1))
    return dict(al=I(a0, a1), ga=I(g0, g1), AD=I(d0, d1), ald=Fr(23, 50) * qq, gad=I(la * (3 + 2 * la) / 13, lb * (3 + 2 * lb) / 13), ADd=qq / 5)
def second(a, b, lc, rho, J):
    AL, GA, AD = mults(lc); u, p, y0, k, w = corner_box(a, b, lc, lc); Y = I(a, b); pp = pp_of(p)
    h = 1 - p + GA * k; h1 = pp + GA * k * w; h2 = -pp * (1 - 2 * p) + GA * k * (w.sq() + k * w - pp)
    N = AD - h - AL / k; N1 = -h1 + AL * w / k; N2 = -h2 + AL * (w - pp / k - w.sq() / k)
    M2 = (N2 * Y.sq() - 2 * N1 * Y + 2 * N) / (Y.sq() * Y)
    Q = GA + J * (GA * u - h * Y); Q1 = J * (GA * u - h - h1 * Y); Q2 = J * (GA * u - 2 * h1 - h2 * Y)
    assert Q.lo > 0
    G2 = J * ((2 * h1.sq() + 2 * h * h2) / Q - 4 * h * h1 * Q1 / Q.sq() - h.sq() * Q2 / Q.sq() + 2 * h.sq() * Q1.sq() / (Q.sq() * Q))
    return dict(Phi=AL * u + M2 - G2, Phig=AL * u + M2 - J * (2 * h1.sq() + 2 * h * h2) / GA)
def dmu(a, b, la, lb, rho, J):
    A = act(la, lb); u, p, y0, k, w = corner_box(a, b, la, lb); Y = I(a, b); pp = pp_of(p)
    al, ga = A['al'], A['ga']
    h = 1 - p + ga * k; hd = -pp - ga * k * w + A['gad'] * k
    Nd = A['ADd'] - hd - A['ald'] / k - al * w / k
    Q = ga + J * (ga * u - h * Y); assert Q.lo > 0
    Qd = A['gad'] + J * (A['gad'] * u - ga * u - hd * Y)
    common = A['ald'] * u - al * u + Nd / Y + A['ald'] * rho
    return dict(Phi=common - J * (2 * h * hd * Q - h.sq() * Qd) / Q.sq(), Phig=common - J * (2 * h * hd / ga - h.sq() * A['gad'] / ga.sq()))
def logm1(E): return I(log_enc(E.lo - 1)[0], log_enc(E.hi - 1)[1])
def C_parts(a, b, lam, Jbar, mu):
    AL, GA, AD = mults(lam)
    if a == b: u, p, y0, k = point_prims(a, lam); w = k + p - 1
    else: u, p, y0, k, w = corner_box(a, b, lam, lam)
    E = I(exp_pos(Fr(a))[0], exp_pos(Fr(b))[1]); Y = I(a, b); pp = pp_of(p)
    h = 1 - p + GA * k; h1 = pp + GA * k * w; h2 = -pp * (1 - 2 * p) + GA * k * (w.sq() + k * w - pp)
    Em1 = E - 1; n = mu - logm1(E) - 1 / k; n1 = -E / Em1 + w / k; n2 = E / Em1.sq() + w - pp / k - w.sq() / k
    B = u + n / Y; B1 = u + (n1 * Y - n) / Y.sq(); B2 = u + (n2 * Y.sq() - 2 * n1 * Y + 2 * n) / (Y.sq() * Y)
    l = h * Y - GA * u; l1 = h + h1 * Y - GA * u; l2 = 2 * h1 + h2 * Y - GA * u
    den = GA - Jbar * l; assert den.lo > 0
    f1 = GA * GA / den.sq(); f2 = 2 * Jbar * GA * GA / (den.sq() * den)
    return AL * B - GA * l / den, AL * B1 - f1 * l1, AL * B2 - f2 * l1.sq() - f1 * l2
def dmu_C(a, b, la, lb, Jbar):
    A = act(la, lb); u, p, y0, k, w = corner_box(a, b, la, lb); Y = I(a, b); pp = pp_of(p)
    E = I(exp_pos(Fr(a))[0], exp_pos(Fr(b))[1]); mu_iv = I(log_enc(la)[0], log_enc(lb)[1])
    al, ga = A['al'], A['ga']
    h = 1 - p + ga * k; hd = -pp - ga * k * w + A['gad'] * k
    n = mu_iv - logm1(E) - 1 / k; B = u + n / Y; Bd = -u + (1 - w / k) / Y
    l = h * Y - ga * u; ld = hd * Y - A['gad'] * u + ga * u
    den = ga - Jbar * l; assert den.lo > 0
    fd = -Jbar * l.sq() / den.sq() * A['gad'] + ga.sq() / den.sq() * ld
    return A['ald'] * B + al * Bd - fd
def halves(Y0, Y1): m = (Y0 + Y1) / 2; return [(Y0, m), (m, Y1)]
def two_ended(Y0, Y1, F0, D0, F1, D1, m):
    q0 = lambda Y: F0 + D0 * (Y - Y0) + m * (Y - Y0) ** 2 / 2
    q1 = lambda Y: F1 + D1 * (Y - Y1) + m * (Y - Y1) ** 2 / 2
    cands = [Y0, Y1]; a0 = q0(Y0) - q1(Y0); a1 = q0(Y1) - q1(Y1)
    if a0 != a1 and (a0 < 0) != (a1 < 0): cands.append(Y0 + (Y1 - Y0) * a0 / (a0 - a1))
    return min(max(q0(Y), q1(Y)) for Y in cands)
def loss(dlo, dhi, dm, dp): return max(dp * max(Fr(0), -dlo), dm * max(Fr(0), dhi))
_pt = {}
def vpoint(Y, lc, rho, J):
    key = (Y, lc, rho, J)
    if key not in _pt:
        u, p, y0, k = point_prims(Y, lc); _pt[key] = phi_all(u, p, k, I(Y), I(J), rho, lc)
    return _pt[key]
def vcheck(Y0, Y1, la, lb, lc, rho, J, tag, dm, dp):
    P0 = vpoint(Y0, lc, rho, J); P1 = vpoint(Y1, lc, rho, J)
    m = min([Fr(0)] + [second(a, b, lc, rho, J)[tag].lo for a, b in halves(Y0, Y1)])
    beta = two_ended(Y0, Y1, P0[tag].lo, P0[tag + '1'].lo, P1[tag].lo, P1[tag + '1'].hi, m)
    D = [dmu(a, b, la, lb, rho, J)[tag] for a, b in halves(Y0, Y1)]
    return beta - loss(min(d.lo for d in D), max(d.hi for d in D), dm, dp)
def cacheck(Y0, Y1, la, lb, lc, Jbar, dm, dp, muc):
    c = (Y0 + Y1) / 2; d = (Y1 - Y0) / 2
    C, C1, _ = C_parts(c, c, lc, Jbar, muc)
    m = min([Fr(0)] + [C_parts(a, b, lc, Jbar, muc)[2].lo for a, b in halves(Y0, Y1)])
    beta = C.lo - max(-C1.lo, C1.hi) * d + m * d * d / 2
    D = [dmu_C(a, b, la, lb, Jbar) for a, b in halves(Y0, Y1)]
    return beta - loss(min(x.lo for x in D), max(x.hi for x in D), dm, dp)
def lpos(Y0, Y1, la, lb):
    uA, pA, yA, kA = point_prims(Y0, lb); uB, pB, yB, kB = point_prims(Y1, la)
    u, p, k = I(uA.lo, uB.hi), I(pB.lo, pA.hi), I(kA.lo, kB.hi); GA = I(mults(la)[1], mults(lb)[1])
    return (GA * u - (1 - p + GA * k) * I(Y0, Y1)).lo
def hand(la, lb, YL, Jbar):
    aa, ga, Da = mults(la); ab, gb, Db = mults(lb)
    A1 = 1 + gb; B1 = ga / lb; Z = ga - Jbar * A1 * (log_enc(A1 / B1)[1] - 1)          # (i)
    pl = msg(la, YL)[0]; k_hi = (I(*msg(la, YL)) / I(*lm(la, YL))).hi; k_lo = (I(*msg(lb, Fr(0))) / I(*lm(lb, Fr(0)))).lo
    h_hi = 1 - pl + gb * k_hi; N_lo = Da - h_hi - ab / k_lo
    t = max(Fr(0), log_enc(la)[0] - log_enc(exp_pos(YL)[1] - 1)[1]); num = N_lo + aa * t
    assert num >= 0
    Lp_lo = ga / lb - h_hi * YL; QL = ga + Jbar * min(Fr(0), Lp_lo); assert QL > 0
    Lb = aa / lb + num / YL - Jbar * h_hi ** 2 / QL                                      # (ii)
    kR = (I(*msg(lb, Fr(3))) / I(*lm(lb, Fr(3)))).lo; NR = Da - (1 + gb) - ab / kR; assert NR < 0
    assert log_enc((1 + gb) * lb / ga)[1] <= 3
    eR = exp_pos(Fr(3))[0]; mR = (1 + gb) * 3 - ga * eR / lb; QR = min(ga, ga - Jbar * max(Fr(0), mR))
    R = aa * eR / lb + NR / 3 - (1 + gb) ** 2 * Jbar / QR                              # (iii)
    C0 = ga / lb - (1 + gb) * Fr(1, 500)                                                  # (iv) on (0, 1/500]
    C3 = ga * exp_pos(Fr(3))[0] / lb - (1 + gb) * 3                                     # (iv) on [3, oo)
    return dict(Z=Z, L=Lb, R=R, C0=C0, C3=C3)
def vertices(lines):
    V = [(Fr(0), lines[0][0])]
    for (a1, b1), (a2, b2) in zip(lines, lines[1:]):
        assert b1 > b2 >= 0; r = (a2 - a1) / (b1 - b2); V.append((r, a1 + b1 * r))
    return V
def prove_polygon(lp, lines):
    T, segs = CP.jdec_start(lp); n = len(segs)
    for a, b in lines:
        P = CP.greedy(lambda x, y: CP.piece_top(x, y, b, lp) <= a, Fr(0), T); n += len(P)
    return T, n
def floor6(x): return Fr(math.floor(x * 10**6), 10**6)
if __name__ == '__main__':
    t0 = time.time()
    subs = []; src = {}
    for f in FILES:
        for s in json.load(open(os.path.join(ROOT, 'outputs', f)))['subintervals']: s['_file'] = f; subs.append(s)
    subs.sort(key=lambda s: Fr(s['la']))
    assert Fr(subs[0]['la']) == Fr(11, 20) and Fr(subs[-1]['lb']) == Fr(263, 200)
    assert all(Fr(a['lb']) == Fr(b['la']) for a, b in zip(subs, subs[1:]))
    out('final certificate, stated method: hull over the two halves of every parent subinterval; six-decimal polygons')
    # polygons
    npoly = 0; PV = {}
    for lp in sorted(set(Fr(s['lp']) for s in subs)):
        lines = POLY[lp]; T, n = prove_polygon(lp, lines); npoly += n; PV[lp] = vertices(lines)
        out('polygon at lambda_p = %s: lines %s, cap %s; T = %s; %d checks; vertices %s' % (lp, [(str(a), str(b)) for a, b in lines[:3]], lines[3][0], T, n,
            [(round(float(r), 4), round(float(j), 4)) for r, j in PV[lp]]))
    total = 0; least = None; fails = []; newsubs = {f: [] for f in FILES}; maxlw = 0; maxdel = 0
    for s in subs:
        la, lb, lc, YL, lp, cut = Fr(s['la']), Fr(s['lb']), Fr(s['lc']), Fr(s['YL']), Fr(s['lp']), s['cut']
        assert lc == (la + lb) / 2 and lp >= lb and cut == (la >= Fr(23, 20))
        V = PV[lp]; lines = POLY[lp]; Jbar = lines[3][0]
        U = lambda r: min(a + b * r for a, b in lines)
        dm = log_enc(lc / la)[1]; dp = log_enc(lb / lc)[1]; muc = I(*log_enc(lc))
        maxlw = max(maxlw, float(dm + dp)); maxdel = max(maxdel, float(dm), float(dp))
        H = hand(la, lb, YL, Jbar)
        for k_, v in H.items():
            if not v > 0: fails.append((str(la), k_, float(v)))
        n = 5; lst = []; ns = dict(s); ns.pop('_file'); ns['vertices'] = [(str(r), str(j)) for r, j in V]; ns['Jbar'] = str(Jbar)
        ns['left'] = [('0', str(YL))]
        core = []
        if not cut:
            for c in s['core']:
                rho, J = V[c['vertex']]
                bds = [vcheck(Fr(a), Fr(b), la, lb, lc, rho, J, c['tag'], dm, dp) for a, b in c['pieces']]
                n += len(bds); lst += bds
                core.append(dict(vertex=c['vertex'], tag=c['tag'], rho=str(rho), J=str(J), pieces=c['pieces'], bounds=[float(x) for x in bds],
                                 min_bound=float(min(bds))))
                fails += [(str(la), 'V', c['vertex'], c['tag'], a, b) for (a, b), x in zip(c['pieces'], bds) if not x > 0]
        else:
            c = s['core'][0]; checks = []
            lnla = log_enc(la)[0]
            for a, b in c['pieces']:
                Y1 = Fr(b); t = lnla - log_enc(exp_pos(Y1)[1] - 1)[1]
                rf = floor6(max(Fr(0), t / Y1)); act_ = [(r, j) for r, j in V if r >= rf] + ([(rf, U(rf))] if rf > 0 else [])
                for rho, J in act_:
                    for tag in ('Phi', 'Phig'):
                        x = vcheck(Fr(a), Y1, la, lb, lc, rho, J, tag, dm, dp); n += 1; lst.append(x)
                        checks.append(dict(Y0=a, Y1=b, rho=str(rho), J=str(J), tag=tag, bound=float(x)))
                        if not x > 0: fails.append((str(la), 'Vcut', a, b, float(rho), tag))
            core.append(dict(vertex='cut-polygon', tag='both', pieces=c['pieces'], checks=checks, min_bound=float(min(x['bound'] for x in checks))))
        ns['core'] = core
        ca = []
        for x in s['ca']:
            a, b = Fr(x['Y0']), Fr(x['Y1']); n += 1
            if x['Lpos']:
                v = lpos(a, b, la, lb); ca.append(dict(Y0=x['Y0'], Y1=x['Y1'], Lpos=True, bound=None, Lmin=float(v)))
                if not v > 0: fails.append((str(la), 'Lpos', x['Y0'], x['Y1']))
            else:
                v = cacheck(a, b, la, lb, lc, Jbar, dm, dp, muc); lst.append(v); ca.append(dict(Y0=x['Y0'], Y1=x['Y1'], Lpos=False, bound=float(v)))
                if not v > 0: fails.append((str(la), 'CA', x['Y0'], x['Y1'], float(v)))
        ns['ca'] = ca; ns['checks'] = n; ns['hand'] = {k_: float(v) for k_, v in H.items()}
        total += n; mn = min(lst); least = mn if least is None else min(least, mn)
        newsubs[s['_file']].append(ns)
        out('[%s, %s] lc %s lp %s YL %s cut %s: checks %d (hand 5), least bound %.3e; hand Z %.4f L %.4f R %.4f C0 %.4f C3 %.4f' % (
            la, lb, lc, lp, YL, cut, n, float(mn), *[float(H[k_]) for k_ in ('Z', 'L', 'R', 'C0', 'C3')]))
    base = []
    for a, b in zip(BASE, BASE[1:]):
        # S(centre) minus the transport loss, with dS/dmu enclosed over the two halves of [a, b] (hull)
        c = (a + b) / 2; s0 = S_point(c).lo; D = [S_mu(a, c), S_mu(c, b)]; dlo = min(x.lo for x in D); dhi = max(x.hi for x in D)
        v = s0 - loss(dlo, dhi, log_enc(c / a)[1], log_enc(b / c)[1]); base.append(float(v))
        out('base [%s, %s]: S(centre) >= %.6f, dS/dmu in [%.6f, %.6f] (hull over halves), bound %.3e' % (a, b, float(s0), float(dlo), float(dhi), float(v)))
        if not v > 0: fails.append(('base', str(a), str(b)))
    os.makedirs(os.path.join(ROOT, 'final_data'), exist_ok=True)
    allsubs = sorted([x for L in newsubs.values() for x in L], key=lambda x: Fr(x['la']))
    json.dump(dict(description='final subdivision of transport_section.tex (v2): 21 activity sub-intervals, each with centre, '
                   'polygon activity, six-decimal polygon vertices, Jbar, the parent subintervals of every vertex function '
                   '(or the cut family with its active points), the CA subintervals, and the bound of every check; base intervals',
                   base_intervals=[str(x) for x in BASE], polygons={str(k): [(str(a), str(b)) for a, b in v] for k, v in POLY.items()},
                   subintervals=allsubs), open(os.path.join(ROOT, 'final_data', 'transport_subdivision.json'), 'w'), indent=1)
    for f, L in newsubs.items():
        json.dump(dict(subintervals=L, polygon_checks=None, method='halves, stated enclosures, six-decimal polygons'),
                  open(os.path.join(ROOT, 'final_data', f), 'w'), indent=1)
    out('sub-intervals %d; step checks %d; polygon checks %d; base checks 6; TOTAL %d' % (len(subs), total, npoly, total + npoly + 6))
    out('least step bound %.3e; least base bound %.3e; max log-width %.4f; max delta %.4f' % (float(least), min(base), maxlw, maxdel))
    out('FAILURES: %d %s' % (len(fails), fails[:20]))
    out('time %.0f s' % (time.time() - t0))
    open(os.path.join(ROOT, 'outputs', 'verify_final.log'), 'w').write('\n'.join(LOG) + '\n')
