"""fill_tex.py -- fills the counts of transport_section.tex from the certificate outputs (bookkeeping only).
Usage: fill_tex.py LAMLO BASELOG census.log json1 json2 ..."""
import sys, json, re, os
from fractions import Fraction as Fr
lamlo, baselog, censuslog = sys.argv[1], sys.argv[2], sys.argv[3]
subs = []; polys = {}
for f in sys.argv[4:]:
    R = json.load(open(f)); subs += R['subintervals']; polys.update(R['polygon_checks'])
subs.sort(key=lambda s: Fr(s['la']))
for a, b in zip(subs, subs[1:]): assert a['lb'] == b['la'], ('gap', a['lb'], b['la'])
nbase = int(re.search(r'with (\d+) exact checks', open(baselog).read()).group(1))
def frac(x):
    x = Fr(x); return str(x.numerator) if x.denominator == 1 else '\\frac{%d}{%d}' % (x.numerator, x.denominator)
def sl(x):
    x = Fr(x); return str(x.numerator) if x.denominator == 1 else '%d/%d' % (x.numerator, x.denominator)
rows = []; tot = 0; tot_tg = 0
for s in subs:
    V = sum(len(c['checks']) if c['vertex'] == 'cut-polygon' else len(c['pieces']) for c in s['core'])
    CA = s['ca_pieces']; hand = s['checks'] - V - CA
    mins = [c['min_bound'] for c in s['core']] + [x['bound'] for x in s['ca'] if x['bound'] is not None]
    rows.append('$[%s,%s]$&$%s$&$%s$&%s&%d&%d&%d&%.5f\\\\' % (sl(s['la']), sl(s['lb']), sl(s['lp']), sl(s['YL']),
                'yes' if s['cut'] else 'no', V, CA, hand, min(mins)))
    tot += s['checks']
    if Fr(47, 50) <= Fr(s['la']) and Fr(s['lb']) <= Fr(13, 10): tot_tg += s['checks']
ptot = sum(polys.values()); ptg = sum(v for k, v in polys.items() if Fr(47, 50) < Fr(k) <= Fr(13, 10) or Fr(k) == 1)
lps_tg = set(s['lp'] for s in subs if Fr(47, 50) <= Fr(s['la']) and Fr(s['lb']) <= Fr(13, 10))
ptg = sum(polys[k] for k in lps_tg)
# base checks inside [47/50, 13/10]: rerun count from its own log line if present
nbase_tg = 3
N = tot + ptot + nbase; NTG = tot_tg + ptg + nbase_tg
polyrow = ', '.join('$%s$: %d' % (sl(k), v) for k, v in sorted(polys.items(), key=lambda kv: Fr(kv[0]))) + '; total %d' % ptot
census = ' '.join(l.strip() for l in open(censuslog) if l.startswith('census') or l.startswith('        ('))
census = census.replace('census: ', '').replace('_', '\\_')
t = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'transport_section.tex')).read()
for k, v in (('\\LAMLO', frac(lamlo)), ('\\NCHKTG', str(NTG)), ('\\NCHK', str(N)), ('\\NSUB', str(len(subs))),
             ('\\NBASE', str(nbase)), ('\\TABLEROWS', '\n'.join(rows)), ('\\POLYROW', polyrow), ('\\CENSUS', census)):
    t = t.replace(k, v)
open(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'transport_section.tex'), 'w').write(t)
print('sub-intervals %d; step checks %d; polygon checks %d; base checks %d; TOTAL %d; on [47/50,13/10]: %d (step %d + polygons %d + base %d)' % (
    len(subs), tot, ptot, nbase, N, NTG, tot_tg, ptg, nbase_tg))
