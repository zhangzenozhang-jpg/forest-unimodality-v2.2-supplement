"""curve_spot.py -- re-reviewer's in-process driver: reruns the curve section's own checker (curve_all.job, i.e.
transport_certificate.run with the segment's multipliers) on chosen sub-intervals, from the byte-identical copy in
../rerun_curve/multiplier_curve/scripts, with no worker pool (one process), and compares with the authors' JSON."""
import sys, os, json, time
HERE = os.path.dirname(os.path.abspath(__file__))
S = os.path.join(HERE, '..', 'rerun_curve', 'multiplier_curve', 'scripts'); sys.path.insert(0, S)
import curve_all as CA
A = os.path.join(HERE, '..', '..', 'multiplier_curve', 'outputs')
out = []
for spec in sys.argv[1:]:
    plan, idx = spec.split(':'); idx = int(idx); item = CA.PLANS[plan][idx]
    t0 = time.time(); r = CA.job(item)
    ref = [x for x in json.load(open(os.path.join(A, 'curve_%s.json' % plan)))['results'] if x['item'] == list(item)][0]['rep']
    rep = json.loads(json.dumps(r['rep']))  # normalise tuples to lists, as in the stored JSON
    json.dump(rep, open(os.path.join(HERE, 'curve_spot_%s_%d.json' % (plan, idx)), 'w'), indent=1)
    diffkeys = [k for k in ref if rep.get(k) != ref.get(k)]
    same = (rep['checks'] == ref['checks'] and rep['polygon_checks'] == ref['polygon_checks'] and rep['vertices'] == ref['vertices']
            and rep['Jbar'] == ref['Jbar'] and rep['ca'] == ref['ca'] and rep['left'] == ref['left'] and rep['core'] == ref['core'])
    line = '%s#%d %s: ok=%s checks %d (+%d polygon); identical to the authors\' JSON entry: %s %s (%.0f s)' % (
        plan, idx, item[:2], r['ok'], rep['checks'], rep['polygon_checks'], same, ('differing keys %s' % diffkeys) if diffkeys else '', time.time() - t0)
    print('\n'.join(r['log'])); print(line, flush=True); out.append(line)
open(os.path.join(HERE, 'curve_spot.log'), 'w').write('\n'.join(out) + '\n')
