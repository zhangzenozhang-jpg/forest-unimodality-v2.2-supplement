"""indep_check.py -- independent re-check (re-reviewer, 1 Oct 2026) of the finite data that the fixes changed or published.
Written from the statements of the two sections only; uses mpmath interval arithmetic (mpmath.iv, outward rounding),
not the authors' or the referees' code.

Part A  base inequality sl(lam) = D q^2 - a q log(1+lam) - (lam(3+lam)/g) q^2/log(1+lam) > 0 on all six segments
        (lo, mid, u1..u4) with the parameters of Table mc:tab:curve; adaptive bisection, naive or mean-value form.
Part B  child polygons J <= a + b rho and J <= Jcap on the child curve at lam_p, for
        (B1) the 19 six-decimal polygons printed in transport_section.tex (Table tr:tab:poly),
        (B2) the 26 exact polygons of multiplier_curve/outputs/polygon_data.json,
        on [0, 10] by adaptive bisection with the mean-value form f(I) in f(c) + f'(I)(I - c), and on [10, oo) by
        J <= lam t e^{-t} <= (7/3) 10 e^{-10} < min a (y = log(1+x) >= x/(1+x) = s). No chain, no T needed.
Part C  the start T of the monotone tail (the authors' rule: least T in {3/2, 13/8, ..., 3} for which the chain condition
        of Lemma tr:lem:child(b) holds, chain [T,2],[2,3],[3,oo) or steps of 1/4 to 3 then [3,4],[4,oo)), recomputed
        with interval enclosures of s, and compared with the T stated in each text.
Part D  DIAGNOSTIC: the curve section's Table mc:tab:poly prints six decimals rounded to nearest; float max (mpmath, 50
        digits, grid step 1e-4 on [0,8] then local refinement) of J - b rho - a with the PRINTED constants."""
import sys, os, re, json, time
from fractions import Fraction as Fr
from mpmath import iv, mp, mpf
iv.prec = 80; mp.dps = 40
HERE = os.path.dirname(os.path.abspath(__file__))
CF = os.path.join(HERE, '..', '..')            # certfree/
OUT = []
def out(s=''):
    print(s, flush=True); OUT.append(s)
def ivq(x):  # exact rational -> tight interval
    x = Fr(x); return iv.mpf(x.numerator) / iv.mpf(x.denominator)
def lo(x): return x.a
def hi(x): return x.b
# ---------------------------------------------------------------- Part A
SEG = {'lo': ('1/3', '11/20', '11/25', '21/2', '6/5'), 'mid': ('11/20', '263/200', '23/50', '13', '6/5'),
       'u1': ('263/200', '3/2', '9/20', '23/2', '7/5'), 'u2': ('3/2', '7/4', '47/100', '43/4', '8/5'),
       'u3': ('7/4', '2', '1/2', '41/4', '9/5'), 'u4': ('2', '7/3', '57/100', '39/4', '21/10')}
def sl(L, a, g, D):
    q = L / (1 + L); l = iv.log(1 + L)
    return D * q * q - a * q * l - (L * (3 + L) / g) * q * q / l
def dsl(L, a, g, D):   # d/dlam
    q = L / (1 + L); qd = 1 / ((1 + L) * (1 + L)); l = iv.log(1 + L); ld = 1 / (1 + L)
    ga = L * (3 + L) / g; gad = (3 + 2 * L) / g
    return 2 * D * q * qd - a * qd * l - a * q * ld - (gad * q * q / l + ga * 2 * q * qd / l - ga * q * q * ld / (l * l))
def base_segment(name):
    la, lb, a, g, D = [Fr(x) for x in SEG[name]]
    A, G, DD = ivq(a), ivq(g), ivq(D)
    stack = [(la, lb)]; n = 0; least = None
    while stack:
        x0, x1 = stack.pop(); L = iv.mpf([float(0), 1]) * 0  # placeholder
        L = iv.mpf([ivq(x0).a, ivq(x1).b]); c = (x0 + x1) / 2; C = ivq(c)
        v1 = sl(L, A, G, DD)                                         # naive
        v2 = sl(C, A, G, DD) + dsl(L, A, G, DD) * (L - C)            # mean-value form
        b = max(lo(v1), lo(v2))
        if b > 0:
            n += 1; least = b if least is None or b < least else least
        else:
            if x1 - x0 < Fr(1, 10**9): raise RuntimeError('base fails near %s' % float(x0))
            stack += [(x0, c), (c, x1)]
    return n, least
# ---------------------------------------------------------------- child curve
def child(t, lam):
    x = lam * iv.exp(-t); s = x / (1 + x); y = iv.log(1 + x); rho = t / y; J = s * s * rho
    return s, y, rho, J
def child_d(t, lam):  # derivatives in t: s' = -s(1-s), y' = -s
    s, y, rho, J = child(t, lam)
    rhod = (y + t * s) / (y * y)
    Jd = -2 * s * s * (1 - s) * t / y + s * s / y + s * s * s * t / (y * y)
    return rho, J, rhod, Jd
def line_ok(lam, a, b, tmax=Fr(10)):
    """prove J - b rho <= a on [0, tmax] at lam; returns (#intervals, least slack lower bound)"""
    LAM, A, B = ivq(lam), ivq(a), ivq(b)
    stack = [(Fr(0), tmax)]; n = 0; least = None; cnt = 0
    while stack:
        t0, t1 = stack.pop(); cnt += 1
        if cnt > 400000: raise RuntimeError('too many intervals')
        T = iv.mpf([ivq(t0).a, ivq(t1).b]); c = (t0 + t1) / 2; Cc = ivq(c)
        _, _, rc, Jc = child(Cc, LAM)
        rho, J, rhod, Jd = child_d(T, LAM)
        fI = J - B * rho - A                                   # naive
        fM = (Jc - B * rc - A) + (Jd - B * rhod) * (T - Cc)    # mean-value form
        up_ = min(hi(fI), hi(fM))
        if up_ <= 0:
            n += 1; s_ = -up_; least = s_ if least is None or s_ < least else least
        else:
            if t1 - t0 < Fr(1, 2**40): raise RuntimeError('line fails at lam=%s near t=%s' % (lam, float(t0)))
            stack += [(t0, c), (c, t1)]
    return n, least
def tail_ok(min_a, lam_max=Fr(7, 3)):
    # for t >= 10: J <= lam t e^{-t} <= lam_max * 10 e^{-10}
    bound = ivq(lam_max) * 10 * iv.exp(-10)
    return hi(bound) < lo(ivq(min_a)), float(hi(bound))
# ---------------------------------------------------------------- Part C: the authors' T rule, recomputed
def s_iv(lam, t): x = ivq(lam) * iv.exp(-ivq(t)); return x / (1 + x)
def chain_val(lam, a_, b_):
    # upper bound of 1/a + 1/(1 + s_b/2) - 2 + 2 s_a (s_b by its lower end, s_a by its upper end), as an mpf
    sb = iv.mpf(s_iv(lam, b_).a) if b_ is not None else iv.mpf(0)
    sa = iv.mpf(s_iv(lam, a_).b)
    v = 1 / ivq(a_) + 1 / (1 + sb / 2) - 2 + 2 * sa
    return v.b
def chain_holds(lam, T):
    for step in (None, Fr(1, 4)):
        if step is None: pts = sorted(set([T] + [x for x in (Fr(2), Fr(3)) if x > T]))
        else:
            pts = [T]
            while pts[-1] < 3: pts.append(min(pts[-1] + step, Fr(3)))
            pts.append(Fr(4))
        segs = list(zip(pts, pts[1:])) + [(pts[-1], None)]
        if all(chain_val(lam, a_, b_) < 0 for a_, b_ in segs): return True
    return False
def least_T(lam):
    for k in range(13):
        T = Fr(3, 2) + Fr(k, 8)
        if chain_holds(lam, T): return T
    return None
# ---------------------------------------------------------------- data
def transport_polys():
    tex = open(os.path.join(CF, 'two_gen_transport', 'transport_section.tex')).read()
    rows = re.findall(r'^\$(\d+(?:/\d+)?)\$ & ([\d.]+) & ([\d.]+) & ([\d.]+) & ([\d.]+) & ([\d.]+) & ([\d.]+) & ([\d.]+) & \$(\d+/\d+)\$ & (\d+)', tex, re.M)
    P = []
    for r in rows:
        lam = Fr(r[0]); c = [Fr(x) for x in r[1:8]]; P.append((lam, [(c[0], c[1]), (c[2], c[3]), (c[4], c[5]), (c[6], Fr(0))], Fr(r[8]), int(r[9])))
    return P
def curve_polys():
    d = json.load(open(os.path.join(CF, 'multiplier_curve', 'outputs', 'polygon_data.json')))
    return d
def curve_printed():
    tex = open(os.path.join(CF, 'multiplier_curve', 'curve_section.tex')).read()
    rows = re.findall(r'^\$(\d+(?:/\d+)?)\$&([\d.]+)&([\d.]+)&([\d.]+)&([\d.]+)&([\d.]+)&([\d.]+)&([\d.]+)&(\w+)&\$(\d+/\d+)\$&(\d+)', tex, re.M)
    P = {}
    for r in rows:
        c = [Fr(x) for x in r[1:8]]; P[Fr(r[0])] = dict(lines=[(c[0], c[1]), (c[2], c[3]), (c[4], c[5]), (c[6], Fr(0))], seg=r[8], T=Fr(r[9]), checks=int(r[10]))
    return P
def fmax_float(lam, a, b):
    L = mpf(lam.numerator) / lam.denominator; A = mpf(a.numerator) / a.denominator; B = mpf(b.numerator) / b.denominator
    def f(t):
        x = L * mp.exp(-t); s = x / (1 + x); y = mp.log(1 + x); rho = t / y; return s * s * rho - B * rho - A
    best = (None, None)
    for i in range(0, 8001):
        t = mpf(i) / 1000; v = f(t)
        if best[0] is None or v > best[0]: best = (v, t)
    t0 = best[1]
    for i in range(-2000, 2001):
        t = t0 + mpf(i) / 10**6
        if t < 0: continue
        v = f(t)
        if v > best[0]: best = (v, t)
    return best
if __name__ == '__main__':
    t00 = time.time(); part = sys.argv[1] if len(sys.argv) > 1 else 'ABCD'
    if 'A' in part:
        out('== Part A: base inequality on the six segments (mpmath.iv, 80 bits)')
        for name in ['lo', 'mid', 'u1', 'u2', 'u3', 'u4']:
            n, least = base_segment(name)
            out('  %-3s %s: PASS, %d intervals, least lower bound %.3e' % (name, SEG[name], n, float(least)))
    if 'B' in part:
        out('== Part B1: the 19 six-decimal polygons printed in transport_section.tex')
        TP = transport_polys(); assert len(TP) == 19, len(TP)
        mina = min(min(a for a, b in L) for lam, L, T, ch in TP)
        ok, tb = tail_ok(mina, Fr(263, 200)); out('  tail t >= 10: J <= %.3e < min a = %s: %s' % (tb, float(mina), ok)); assert ok
        for lam, L, T, ch in TP:
            res = [line_ok(lam, a, b) for a, b in L]
            out('  lam_p %-8s PASS  intervals %s  least slack %.2e' % (lam, [r[0] for r in res], float(min(r[1] for r in res))))
        out('== Part B2: the 26 exact polygons of multiplier_curve/outputs/polygon_data.json')
        d = curve_polys(); polys = d['polygons']
        items = [(p['lam_p'], p) for p in polys]
        allmin = []
        for key, p in items:
            lam = Fr(key)
            lines = [(Fr(l['a']), Fr(l['b'])) for l in p['lines']]
            assert len(lines) == 4 and lines[3] == (Fr(p['J_cap']), Fr(0))
            mina = min(a for a, b in lines); ok, tb = tail_ok(mina)
            assert ok
            res = [line_ok(lam, a, b) for a, b in lines]
            m = min(r[1] for r in res); allmin.append((m, lam))
            out('  lam_p %-8s PASS  intervals %s  least slack %.2e  (tail bound %.1e < %.4f)' % (lam, [r[0] for r in res], float(m), tb, float(mina)))
        out('  least slack over the 26: %.2e at lam_p = %s' % (float(min(allmin)[0]), min(allmin)[1]))
    if 'C' in part:
        out('== Part C: start T of the monotone tail (authors\' rule, recomputed with interval enclosures of s)')
        TP = transport_polys()
        bad = 0
        for lam, L, T, ch in TP:
            Tm = least_T(lam); okT = chain_holds(lam, T)
            flag = '' if (Tm == T and okT) else '  <-- DIFFERS'
            bad += bool(flag)
            out('  transport lam_p %-8s stated T %-5s chain holds at stated T: %s; least T by the rule: %s%s' % (lam, T, okT, Tm, flag))
        CPR = curve_printed()
        for lam in sorted(CPR):
            T = CPR[lam]['T']; Tm = least_T(lam); okT = chain_holds(lam, T)
            flag = '' if (Tm == T and okT) else '  <-- DIFFERS'
            bad += bool(flag)
            out('  curve     lam_p %-8s stated T %-5s chain holds at stated T: %s; least T by the rule: %s%s' % (lam, T, okT, Tm, flag))
        out('  T mismatches: %d' % bad)
        # (log J)' at lam = 7/3, Yt = 13/8 (text: +0.078)
        L = mpf(7) / 3; t = mpf(13) / 8; x = L * mp.exp(-t); s = x / (1 + x); y = mp.log(1 + x)
        out("  (log J)'(13/8) at lam = 7/3: %.4f" % float(1 / t + s / y - 2 * (1 - s)))
    if 'D' in part:
        out('== Part D (DIAGNOSTIC): curve Table mc:tab:poly printed constants (rounded to nearest) vs exact; float max of J - b rho - a')
        CPR = curve_printed(); d = curve_polys(); polys = d['polygons']
        items = {p['lam_p']: p for p in polys}
        nviol = 0; worst = None
        for key in sorted(items, key=lambda k: Fr(k)):
            p = items[key]; lam = Fr(key)
            ex = [(Fr(l['a']), Fr(l['b'])) for l in p['lines']]
            pr = CPR[lam]['lines']
            dif = [float(pa - ea) for (pa, pb), (ea, eb) in zip(pr, ex)]
            viol = []
            for (a, b) in pr:
                v, t = fmax_float(lam, a, b)
                if v > 0: viol.append((float(v), float(t), float(a), float(b)))
                if worst is None or v > worst[0]: worst = (v, lam, float(a), float(b), float(t))
            nviol += len(viol)
            out('  lam_p %-6s printed - exact intercepts/cap: %s%s' % (lam, ['%+.1e' % x for x in dif], ('  VIOLATED by printed: %s' % viol) if viol else ''))
        out('  printed lines violated on the child curve: %d; largest max(J - b rho - a) with printed constants: %.2e (lam_p=%s, a=%s, b=%s, t=%.4f)' % (
            nviol, float(worst[0]), worst[1], worst[2], worst[3], worst[4]))
    out('time %.0f s' % (time.time() - t00))
    open(os.path.join(HERE, 'indep_check_%s.log' % part), 'w').write('\n'.join(OUT) + '\n')
