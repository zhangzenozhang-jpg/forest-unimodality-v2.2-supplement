"""design_probe.py -- DIAGNOSTIC (floats). For an activity lam and multipliers (alpha, gamma, D) with beta = 0, the least
values over feasible pairs (Yt >= 0, Y >= lm(Yt)) of AC/p and (where L < 0) CA/p, the least Z/p, and the base slack
S = D q^2 - alpha log(1+lam) - gamma q^2/log(1+lam) (all as in Appendix B / two_gen_section.tex).
Also: at each lam, the least D over a grid of (alpha, gamma) for which min AC/p >= mAC, min CA/p >= mCA, S >= mS.
AC is affine in A_D = 1 + (D-1) q with coefficient p/Y > 0, so the least D for the step is solved exactly on the grid."""
import numpy as np, sys, json
def grid(lam, nt=260, ny=260):
    t = np.concatenate([np.linspace(0, 2, nt // 2), np.linspace(2, 9, nt // 2)[1:]])       # child's children log-mass Yt
    s = lam * np.exp(-t) / (1 + lam * np.exp(-t)); y = np.log1p(lam * np.exp(-t))
    Ys = np.concatenate([np.geomspace(1e-3, 0.05, 30), np.linspace(0.05, 2.5, ny - 60), np.linspace(2.5, 6, 30)[1:]])
    T, Y = np.meshgrid(t, Ys, indexing='ij'); S_, Yc = np.meshgrid(s, Ys, indexing='ij'); yy, _ = np.meshgrid(y, Ys, indexing='ij')
    feas = Y >= yy
    return T[feas], Y[feas], S_[feas], yy[feas]
def comps(lam, al, ga, D, G):
    t, Y, s, y = G; q = lam / (1 + lam)
    p = lam * np.exp(-Y) / (1 + lam * np.exp(-Y)); y0 = np.log1p(lam * np.exp(-Y))
    E = 1 - p + p * t / y - y0 / Y
    H = p * (1 - p) + ga * p * p / y0; L = ga * (1 - p) - H * Y
    J = s * s * t / y; Z = p * ga + L * J; AD = 1 + (D - 1) * q
    AC = al * E + (AD * p - H) / Y - H * H * J / Z
    CA = np.where(L < 0, al * E + p * ga * L * (s / y) ** 2 / Z, np.inf)
    return (AC / p).min(), (CA / p).min(), (Z / p).min()
def base(lam, al, ga, D):
    q = lam / (1 + lam); l = np.log1p(lam); return D * q * q - al * l - ga * q * q / l
def best_D(lam, mAC=0.03, mCA=0.02, mS=0.0, A=None, Gm=None):
    """least D over the (alpha, gamma) grid such that all margins hold; returns (D, alpha, gamma, margins)."""
    G = grid(lam); t, Y, s, y = G; q = lam / (1 + lam); l = np.log1p(lam)
    p = lam * np.exp(-Y) / (1 + lam * np.exp(-Y)); y0 = np.log1p(lam * np.exp(-Y)); E = 1 - p + p * t / y - y0 / Y
    J = s * s * t / y
    A = A if A is not None else np.linspace(0.05, 0.8, 76) * q
    Gm = Gm if Gm is not None else np.linspace(0.02, 1.6, 80) * lam
    best = (np.inf, None, None, None)
    for ga in Gm:
        H = p * (1 - p) + ga * p * p / y0; L = ga * (1 - p) - H * Y; Z = p * ga + L * J
        if Z.min() <= 0: continue
        cag = np.where(L < 0, p * ga * L * (s / y) ** 2 / Z, np.inf) / p
        rest = ((p - H) / Y - H * H * J / Z) / p        # AC/p at A_D = 1 minus alpha E/p
        for al in A:
            ca = (al * E / p + cag).min()
            if ca < mCA: continue
            # AC/p(D) = al E/p + rest + (D-1) q / Y >= mAC  <=>  D >= 1 + max((mAC - al E/p - rest) Y / q)
            Dst = 1 + ((mAC - al * E / p - rest) * Y / q).max()
            Dba = (al * l + ga * q * q / l + mS) / (q * q)
            Dn = max(Dst, Dba)
            if Dn < best[0]: best = (Dn, al, ga, dict(Dstep=Dst, Dbase=Dba, CA=ca))
    return best
if __name__ == '__main__':
    out = []
    for lam in [float(x) for x in sys.argv[1:]]:
        q = lam / (1 + lam)
        Dn, al, ga, info = best_D(lam)
        a0, g0 = 23 * q / 50, lam * (3 + lam) / 13
        ac, ca, z = comps(lam, a0, g0, 1.2, grid(lam))
        print('lam %.4f: paper mults (D=6/5): minAC/p %.4f minCA/p %.4f minZ/p %.4f base %.5f (D_base %.4f) | best D %.4f at alpha/q %.3f gamma/lam %.3f (Dstep %.4f Dbase %.4f CA %.4f)' % (
            lam, ac, ca, z, base(lam, a0, g0, 1.2), (a0 * np.log1p(lam) + g0 * q * q / np.log1p(lam)) / q / q, Dn, al / q, ga / lam, info['Dstep'], info['Dbase'], info['CA']), flush=True)
        out.append(dict(lam=lam, D=Dn, a=al / q, g_over_lam=ga / lam, **info))
