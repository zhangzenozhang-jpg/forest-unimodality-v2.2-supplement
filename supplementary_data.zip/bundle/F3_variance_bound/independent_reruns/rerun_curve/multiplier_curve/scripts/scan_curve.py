#!/usr/bin/env python3
"""scan_curve.py -- DIAGNOSTIC (float LP). The stage-2 threshold scan (certfree/middle/scripts/threshold_scan.py, imported
read-only, LP code unchanged), with
  * D per piece = the largest value on the piece of the certificate-free cap D(lam) PROVED along the multiplier curve
    (this stage on [1/3, 11/20] and [263/200, 7/3]; two_gen_transport on [11/20, 263/200]):
        D = 6/5 on [1/3, 263/200], 7/5 on (263/200, 3/2], 8/5 on (3/2, 7/4], 9/5 on (7/4, 2], 21/10 on (2, 7/3];
  * theta = the proved variance-ratio band profile of the note, Section 5 (certfree/o2/outputs/bands/FINAL_bands_v2.json,
    max over the bands containing the activity), as in tail_var/scripts/scan_tail_var.py;
  * the zero-tilt row E(1-q)^M <= exp(-l_p m) with the proved hand rate l_p of the note, Section 6
    (certfree/tail_var/outputs/tail_kappa.json).
Usage: scan_curve.py [curve|control|flat<D>] [PLO PHI]  (control = the paper's certified caps D21, to reproduce the
published n0 = 57; flat<D> = a hypothetical flat cap, for sensitivity only, on pieces PLO..PHI)."""
import sys, os, json, math, time
from fractions import Fraction as Fr
from multiprocessing import Pool
HERE = os.path.dirname(os.path.abspath(__file__))
CF = os.path.join(HERE, '..', '..')
sys.path.insert(0, os.path.join(CF, 'middle', 'scripts'))
import threshold_scan as TS
from pieces import pieceLo, pieceHi
MODE = sys.argv[1] if len(sys.argv) > 1 else 'curve'
STEPS = [(Fr(1, 3), Fr(263, 200), Fr(6, 5)), (Fr(263, 200), Fr(3, 2), Fr(7, 5)), (Fr(3, 2), Fr(7, 4), Fr(8, 5)),
         (Fr(7, 4), Fr(2), Fr(9, 5)), (Fr(2), Fr(7, 3), Fr(21, 10))]
def D_curve(lo, hi):
    """largest proved cap on [lo, hi]: D(lam) = the least cap of a closed step containing lam; max over the piece"""
    pts = sorted(set([lo, hi] + [b for a, b, d in STEPS if lo < b < hi] + [a for a, b, d in STEPS if lo < a < hi]))
    probe = pts + [(x + y) / 2 for x, y in zip(pts, pts[1:])]
    return max(min(d for a, b, d in STEPS if a <= l <= b) for l in probe)
if MODE == 'curve':
    TS.D21 = [D_curve(pieceLo[p], pieceHi[p]) for p in range(55)]
elif MODE.startswith('flat'):          # sensitivity (DIAGNOSTIC): a flat hypothetical D on pieces PLO..PHI only
    TS.D21 = [Fr(MODE[4:])] * 55
PLO, PHI = (int(sys.argv[2]), int(sys.argv[3])) if len(sys.argv) > 3 else (0, 54)
kap = json.load(open(os.path.join(CF, 'tail_var', 'outputs', 'tail_kappa.json')))
HAND_RATE = [float(Fr(r['rate'])) for r in kap['pieces']]
bands = [(Fr(r['a']), Fr(r['b']), r['theta']) for r in json.load(open(os.path.join(CF, 'o2', 'outputs', 'bands', 'FINAL_bands_v2.json'))) if r.get('PASS')]
def theta_o2(lam):
    ths = [t for (a, b, t) in bands if a <= lam <= b]; return max(ths) if ths else float('inf')
TS.theta_lead = theta_o2
NAME = 'o2th_handtail_%sD' % MODE
TS.SETS = {NAME: dict(D='cert', theta='lead', rows='handtail')}
_orig_rows = TS.rows_for
def job(args):
    p, where = args
    def rf(kind, q, m, rates, _p=p):
        if kind == 'handtail': return [(1 - q, math.exp(-HAND_RATE[_p] * m))]
        return _orig_rows(kind, q, m, rates)
    TS.rows_for = rf
    return TS.job(args)
if __name__ == '__main__':
    t0 = time.time()
    print('D per piece:', [str(TS.D21[p]) for p in range(55)], flush=True)
    jobs = [(p, w) for p in range(PLO, PHI + 1) for w in ('lo', 'mid', 'hi')]
    with Pool(6) as pool:
        out = pool.map(job, jobs, chunksize=1)
    mstar = {}
    for r in out: mstar[r['piece']] = max(mstar.get(r['piece'], 0), r['res'][NAME]['mstar'])
    n0, per = TS.n_threshold(mstar)
    wp = max(per, key=lambda p: per[p])
    print('set %s: n0 = %s (worst piece %d, lambda in [%s, %s], D there %s, m* = %.2f)  [DIAGNOSTIC]' % (
        NAME, n0, wp, pieceLo[wp], pieceHi[wp], TS.D21[wp], mstar[wp]))
    print('n0 per piece:', {p: per[p] for p in sorted(per)})
    json.dump(dict(set=NAME, D=[str(TS.D21[p]) for p in range(55)], n0=n0, worst_piece=wp, mstar={str(k): v for k, v in mstar.items()},
                   n_per_piece={str(k): v for k, v in per.items()}, raw=out), open(os.path.join(HERE, '..', 'outputs', 'scan_%s%s_DIAGNOSTIC.json' % (MODE.replace('/', '_'), '' if (PLO, PHI) == (0, 54) else '_p%d-%d' % (PLO, PHI))), 'w'), indent=1, default=str)
    print('elapsed %.1fs' % (time.time() - t0))
