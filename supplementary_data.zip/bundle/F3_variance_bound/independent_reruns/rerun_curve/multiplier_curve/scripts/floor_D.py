"""floor_D.py -- DIAGNOSTIC (floats). The least cap D for which some beta = 0 multipliers (alpha, gamma) pass the base
inequality and the step comparisons (min AC/p >= 0, min CA/p >= 0, Z > 0) on the feasible-pair grid of design_probe.py,
at several activities: the floor of the multiplier family used here. Also the least D at the margins used for design."""
import sys, numpy as np
from design_probe import best_D
for lam in [1/3, 0.45, 0.55, 0.8, 1.0, 1.1, 1.2, 1.315, 1.5, 1.75, 2.0, 7/3]:
    q = lam / (1 + lam)
    D0, a0, g0, i0 = best_D(lam, 0.0, 0.0, 0.0, A=np.linspace(0.2, 0.8, 121) * q, Gm=np.linspace(0.05, 1.2, 116) * lam)
    D1, a1, g1, i1 = best_D(lam, 0.03, 0.02, 0.0, A=np.linspace(0.2, 0.8, 121) * q, Gm=np.linspace(0.05, 1.2, 116) * lam)
    print('lam %.4f: floor D (zero margins) %.4f at alpha/q %.3f gamma/lam %.3f [step %.4f base %.4f] | with margins (AC/p 0.03, CA/p 0.02) %.4f' % (
        lam, D0, a0 / q, g0 / lam, i0['Dstep'], i0['Dbase'], D1), flush=True)
