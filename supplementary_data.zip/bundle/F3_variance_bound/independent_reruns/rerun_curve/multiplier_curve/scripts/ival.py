"""ival.py -- closed intervals of rationals with outward dyadic rounding (sound interval arithmetic).
Primitive enclosures come from ratlib.py (series with explicit remainders)."""
from fractions import Fraction as Fr
from ratlib import dn, up
class I:
    __slots__ = ('lo', 'hi')
    def __init__(s, lo, hi=None):
        if hi is None: hi = lo
        lo, hi = Fr(lo), Fr(hi)
        assert lo <= hi, (lo, hi)
        s.lo, s.hi = lo, hi
    @staticmethod
    def c(x): return x if isinstance(x, I) else I(x)
    def r(s): return I(dn(s.lo), up(s.hi))
    def __add__(s, o): o = I.c(o); return I(s.lo + o.lo, s.hi + o.hi).r()
    __radd__ = __add__
    def __neg__(s): return I(-s.hi, -s.lo)
    def __sub__(s, o): return s + (-I.c(o))
    def __rsub__(s, o): return I.c(o) + (-s)
    def __mul__(s, o):
        o = I.c(o); v = [s.lo * o.lo, s.lo * o.hi, s.hi * o.lo, s.hi * o.hi]
        return I(min(v), max(v)).r()
    __rmul__ = __mul__
    def inv(s):
        assert s.lo > 0 or s.hi < 0, ('division by interval containing 0', float(s.lo), float(s.hi))
        return I(1 / s.hi, 1 / s.lo).r()
    def __truediv__(s, o): return s * I.c(o).inv()
    def __rtruediv__(s, o): return I.c(o) * s.inv()
    def sq(s):
        if s.lo >= 0: return I(s.lo ** 2, s.hi ** 2).r()
        if s.hi <= 0: return I(s.hi ** 2, s.lo ** 2).r()
        return I(0, max(s.lo ** 2, s.hi ** 2)).r()
    def __repr__(s): return '[%.6g, %.6g]' % (float(s.lo), float(s.hi))
def hull(a, b): return I(min(a.lo, b.lo), max(a.hi, b.hi))
