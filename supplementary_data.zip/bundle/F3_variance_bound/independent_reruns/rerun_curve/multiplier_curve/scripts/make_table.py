"""make_table.py -- bookkeeping: the table of sub-intervals of curve_section.tex and the check totals, read from
outputs/curve_{lo,u1,u2,u3,u4}.json and outputs/base_*.log (no computation)."""
import json, os, re
from fractions import Fraction as Fr
O = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'outputs')
def tf(s):
    f = Fr(s); return '$%d$' % f.numerator if f.denominator == 1 else '$%d/%d$' % (f.numerator, f.denominator)
rows = []; tot = dict(step=0, poly=0, base=0)
for P in ['lo', 'u1', 'u2', 'u3', 'u4']:
    R = json.load(open(os.path.join(O, 'curve_%s.json' % P))); assert R['allok']
    for r in R['results']:
        rep = r['rep']
        V = sum(len(c['pieces']) if c['vertex'] != 'cut-polygon' else len(c['checks']) for c in rep['core'])
        hand = rep['checks'] - V - rep['ca_pieces']
        mn = min([c['min_bound'] for c in rep['core']] + [x['bound'] for x in rep['ca'] if x['bound'] is not None])
        rows.append('$[%s,%s]$&%s&%s&%s&%s&%d&%d&%d&%d&%.5f\\\\' % (tf(rep['la'])[1:-1], tf(rep['lb'])[1:-1], P, tf(rep['lp']), tf(rep['YL']),
                    'yes' if rep['cut'] else 'no', V, rep['ca_pieces'], hand, rep['polygon_checks'], mn))
        tot['step'] += rep['checks']; tot['poly'] += rep['polygon_checks']
for P in ['lo', 'u1', 'u2', 'u3', 'u4']:
    tot['base'] += int(re.search(r'with (\d+) exact checks', open(os.path.join(O, 'base_%s.log' % P)).read()).group(1))
print('\n'.join(rows))
print('% totals:', tot, 'sum', sum(tot.values()), 'sub-intervals', len(rows))
# ---- the table of polygons (display: six decimals, rounded to nearest; exact values in outputs/polygon_data.json) ----
PD = json.load(open(os.path.join(O, 'polygon_data.json')))
prow = []
for g in PD['polygons']:
    L = g['lines']
    vals = [float(Fr(L[i][k])) for i in range(3) for k in ('a', 'b')] + [float(Fr(g['J_cap']))]
    prow.append('%s&%s&%s&%s&%d\\\\' % (tf(g['lam_p']), '&'.join('%.6f' % v for v in vals), g['segment'], tf(g['T']), g['checks']))
open(os.path.join(O, 'polygon_rows.tex.part'), 'w').write('\n'.join(prow) + '\n')
print('% polygon rows:', len(prow), 'checks', PD['total_checks'])
