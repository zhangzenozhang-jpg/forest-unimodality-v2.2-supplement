"""design_segments.py -- DIAGNOSTIC (floats). For an activity segment [l0, l1] and a cap D, the multipliers of the
paper's family alpha = a q, gamma = lam(3+lam)/g (a on a 1/100 grid, g on a 1/4 grid) that maximise the least, over
five activities of the segment, of min AC/p, min CA/p and the base slack S/q^2 (grid of design_probe.py).
Usage: design_segments.py l0 l1 D [D ...]"""
import numpy as np, sys
from fractions import Fraction as Fr
from design_probe import grid
def pre(lam):
    G = grid(lam, 200, 200); t, Y, s, y = G
    p = lam * np.exp(-Y) / (1 + lam * np.exp(-Y)); y0 = np.log1p(lam * np.exp(-Y)); E = 1 - p + p * t / y - y0 / Y
    return dict(lam=lam, q=lam / (1 + lam), l=np.log1p(lam), Y=Y, s=s, y=y, p=p, y0=y0, E=E, J=s * s * t / y)
def seg_margin(P, a, g, D):
    worst = (np.inf,)
    for d in P:
        lam, q, l, Y, s, y, p, y0, E, J = (d[k] for k in ('lam', 'q', 'l', 'Y', 's', 'y', 'p', 'y0', 'E', 'J'))
        al, ga, AD = a * q, lam * (3 + lam) / g, 1 + (D - 1) * q
        H = p * (1 - p) + ga * p * p / y0; L = ga * (1 - p) - H * Y; Z = p * ga + L * J
        if Z.min() <= 0: return (-np.inf, lam)
        ca = (al * E / p + np.where(L < 0, p * ga * L * (s / y) ** 2 / Z, np.inf) / p).min()
        ac = ((al * E + (AD * p - H) / Y - H * H * J / Z) / p).min()
        S = D - (al * l + ga * q * q / l) / (q * q)
        m = min(ac, ca, S)
        if m < worst[0]: worst = (m, lam, ac, ca, S)
    return worst
if __name__ == '__main__':
    l0, l1 = float(Fr(sys.argv[1])), float(Fr(sys.argv[2]))
    P = [pre(l0 + (l1 - l0) * i / 4) for i in range(5)]
    for D in sys.argv[3:]:
        Df = float(Fr(D)); best = None
        for a in np.arange(0.40, 0.62, 0.01):
            for g in np.arange(8.0, 15.0, 0.25):
                w = seg_margin(P, a, g, Df)
                if best is None or w[0] > best[0][0]: best = (w, a, g)
        w, a, g = best
        print('segment [%s, %s] D = %s: best a = %.2f g = %.2f; least margin %.4f at lam %.3f (AC/p %.4f CA/p %.4f S/q^2 %.4f)' % (
            sys.argv[1], sys.argv[2], D, a, g, w[0], w[1], *(w[2:] if len(w) > 2 else (np.nan,) * 3)), flush=True)
