"""base_slack_table.py -- DIAGNOSTIC (floats): the base slack S = D q^2 - alpha log(1+lam) - gamma q^2/log(1+lam) of each
segment of the curve at its two ends, and of the old curve (23/50, 13, 6/5) at the same activities."""
import math
SEG = [('lo', 1/3, 11/20, 11/25, 21/2, 6/5), ('mid', 11/20, 263/200, 23/50, 13, 6/5), ('u1', 263/200, 3/2, 9/20, 23/2, 7/5),
       ('u2', 3/2, 7/4, 47/100, 43/4, 8/5), ('u3', 7/4, 2, 1/2, 41/4, 9/5), ('u4', 2, 7/3, 57/100, 39/4, 21/10)]
def S(lam, a, g, D):
    q = lam / (1 + lam); l = math.log1p(lam); return D * q * q - a * q * l - lam * (3 + lam) / g * q * q / l
for n, l0, l1, a, g, D in SEG:
    print('%-3s [%.4f, %.4f] (a, g, D) = (%.2f, %.2f, %.2f): S = %.5f, %.5f  (S/q^2 = %.4f, %.4f); old curve D=6/5: S = %.5f, %.5f' % (
        n, l0, l1, a, g, D, S(l0, a, g, D), S(l1, a, g, D), S(l0, a, g, D) / (l0 / (1 + l0)) ** 2, S(l1, a, g, D) / (l1 / (1 + l1)) ** 2,
        S(l0, 23/50, 13, 6/5), S(l1, 23/50, 13, 6/5)))
