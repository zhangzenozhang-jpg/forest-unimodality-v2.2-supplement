"""floor_witness.py -- DIAGNOSTIC (floats). At the floor multipliers of floor_D.py (least D of the beta = 0 family), the
location of the binding step comparison: the feasible pair (Yt, Y) where AC/p (or CA/p) attains its minimum, with the
base slack.  Usage: floor_witness.py lam alpha_over_q gamma_over_lam D"""
import sys, numpy as np
from design_probe import grid
lam, a, gl, D = (float(x) for x in sys.argv[1:5])
q = lam / (1 + lam); al, ga = a * q, gl * lam; AD = 1 + (D - 1) * q
t, Y, s, y = grid(lam, 500, 500)
p = lam * np.exp(-Y) / (1 + lam * np.exp(-Y)); y0 = np.log1p(lam * np.exp(-Y)); E = 1 - p + p * t / y - y0 / Y
H = p * (1 - p) + ga * p * p / y0; L = ga * (1 - p) - H * Y; J = s * s * t / y; Z = p * ga + L * J
AC = (al * E + (AD * p - H) / Y - H * H * J / Z) / p
CA = np.where(L < 0, (al * E + p * ga * L * (s / y) ** 2 / Z) / p, np.inf)
i, j = AC.argmin(), CA.argmin(); l = np.log1p(lam)
print('lam %.4f D %.4f alpha/q %.3f gamma/lam %.3f: base slack S/q^2 %.4f; min AC/p %.4f at (Yt, Y) = (%.3f, %.3f), feasibility gap Y - lm(Yt) = %.3f; min CA/p %.4f at (%.3f, %.3f), gap %.3f' % (
    lam, D, a, gl, D - (al * l + ga * q * q / l) / q / q, AC[i], t[i], Y[i], Y[i] - y[i], CA[j], t[j], Y[j], Y[j] - y[j]))
