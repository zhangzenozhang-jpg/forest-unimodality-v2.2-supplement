"""design_margin.py -- DIAGNOSTIC (floats). At activity lam and a fixed cap D, the multipliers (alpha, gamma) = (a q, g lam)
on a grid maximising the least of: min AC/p, min CA/p (L<0), and the base slack S/q^2 (feasible-pair grid of
design_probe.py).  Usage: design_margin.py D lam [lam ...]"""
import numpy as np, sys
from design_probe import grid
def margins(lam, D, A, Gs):
    G = grid(lam); t, Y, s, y = G; q = lam / (1 + lam); l = np.log1p(lam)
    p = lam * np.exp(-Y) / (1 + lam * np.exp(-Y)); y0 = np.log1p(lam * np.exp(-Y)); E = 1 - p + p * t / y - y0 / Y
    J = s * s * t / y; AD = 1 + (D - 1) * q
    res = []
    for ga in Gs:
        H = p * (1 - p) + ga * p * p / y0; L = ga * (1 - p) - H * Y; Z = p * ga + L * J
        if Z.min() <= 0: continue
        cag = np.where(L < 0, p * ga * L * (s / y) ** 2 / Z, np.inf) / p
        rest = ((AD * p - H) / Y - H * H * J / Z) / p
        for al in A:
            ca = (al * E / p + cag).min(); ac = (al * E / p + rest).min(); S = D - (al * l + ga * q * q / l) / (q * q)
            res.append((min(ac, ca, S), ac, ca, S, al / q, ga / lam))
    res.sort(reverse=True); return res[0]
if __name__ == '__main__':
    D = float(sys.argv[1])
    for lam in [float(x) for x in sys.argv[2:]]:
        q = lam / (1 + lam)
        m, ac, ca, S, a, g = margins(lam, D, np.linspace(0.2, 0.8, 61) * q, np.linspace(0.1, 1.0, 91) * lam)
        print('D %.3f lam %.4f: best min margin %.4f (AC/p %.4f CA/p %.4f base S/q^2 %.4f) at a = alpha/q %.3f, gamma/lam %.3f' % (D, lam, m, ac, ca, S, a, g), flush=True)
