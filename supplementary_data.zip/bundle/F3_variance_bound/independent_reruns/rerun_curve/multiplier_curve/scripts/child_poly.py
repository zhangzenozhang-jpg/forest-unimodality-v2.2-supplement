"""child_poly.py -- PROVED (exact rational): a child polygon at one activity lam_b, valid for every lam <= lam_b.
Lines J <= a_i + b_i rho (b_i >= 0, slopes from tangents at the points TP, rationalised) and the cap J <= Jcap; the
intercepts are float maxima rounded up, then CERTIFIED as in child_taylor.py of two_gen_arc: on [0, T] second-order
Taylor pieces in t = Yt (jets of s = msg_lam(t), y = lm_lam(t): s' = -s(1-s), y' = -s at any lam), and on [T, oo)
J decreases (Lemma 2(c) of two_gen, segment checks at lam_b) while rho increases, so f = J - b rho decreases.
Monotone transport in lam (Lemma 2(a),(b) of two_gen): rho decreases and J increases in lam at fixed Yt, so for b >= 0,
J_lam - b rho_lam <= J_lamb - b rho_lamb: the polygon proved at lam_b holds for every lam in (0, lam_b]."""
import sys, os, math
from fractions import Fraction as Fr
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ival import I
from ratlib import msg, lm
class Jet:
    def __init__(s, v, d1, d2): s.v, s.d1, s.d2 = v, d1, d2
    def __sub__(a, b): return Jet(a.v - b.v, a.d1 - b.d1, a.d2 - b.d2)
    def __mul__(a, b):
        if not isinstance(b, Jet): b = I.c(b); return Jet(a.v * b, a.d1 * b, a.d2 * b)
        return Jet(a.v * b.v, a.d1 * b.v + a.v * b.d1, a.d2 * b.v + 2 * a.d1 * b.d1 + a.v * b.d2)
    def inv(a):
        iv = a.v.inv(); return Jet(iv, -a.d1 * iv.sq(), (2 * a.d1.sq() - a.v * a.d2) * iv.sq() * iv)
def jets(t, s, y):
    ss = s * (1 - s)
    T = Jet(t, I(1), I(0)); S = Jet(s, -ss, ss * (1 - 2 * s)); Yj = Jet(y, -s, ss)
    rho = T * Yj.inv(); return rho, S * S * rho
def prims_point(t, lam):
    s = msg(lam, t); y = lm(lam, t); return I(t), I(s[0], s[1]), I(y[0], y[1])
def prims_piece(t0, t1, lam):
    a = prims_point(t0, lam); b = prims_point(t1, lam)
    return I(t0, t1), I(b[1].lo, a[1].hi), I(b[2].lo, a[2].hi)
def piece_top(t0, t1, b, lam):
    c = (t0 + t1) / 2; d = (t1 - t0) / 2
    rc, Jc = jets(*prims_point(c, lam)); rp, Jp = jets(*prims_piece(t0, t1, lam))
    f = Jc - rc * b; fp = Jp - rp * b
    M = max(Fr(0), fp.d2.hi)
    return max(f.v.hi + f.d1.hi * d + M * d * d / 2, f.v.hi - f.d1.lo * d + M * d * d / 2)
def greedy(ok, lo, hi, grid=Fr(1, 256)):
    out = []; t0 = lo
    while t0 < hi:
        if not ok(t0, min(t0 + grid, hi)): raise RuntimeError('stuck at %f' % float(t0))
        k = 1
        while t0 + k * grid < hi and ok(t0, min(t0 + 2 * k * grid, hi)): k *= 2
        a, b = k, 2 * k
        while b - a > 1:
            m = (a + b) // 2
            if ok(t0, min(t0 + m * grid, hi)): a = m
            else: b = m
        t1 = min(t0 + a * grid, hi)
        if t1 < hi and ok(t0, hi): t1 = hi
        out.append((t0, t1)); t0 = t1
    return out
def jdec_start(lam):
    """smallest T in {3/2, 13/8, ..., 3} such that every segment check of Lemma 2(c) passes at lam on the chain
    [T, T+1/4], ..., [.., 3], [3, 4], [4, oo);  returns (T, list of (a, b, value))"""
    val = lambda a_, b_: 1 / a_ + 1 / (1 + (msg(lam, b_)[0] if b_ is not None else Fr(0)) / 2) - 2 + 2 * msg(lam, a_)[1]
    for T in [Fr(3, 2) + Fr(k, 8) for k in range(0, 13)]:
        for step in (None, Fr(1, 4)):          # coarse chain [T,2],[2,3],[3,oo) first, then steps of 1/4
            segs = []; a = T
            if step is None: pts = sorted(set([T] + [x for x in (Fr(2), Fr(3)) if x > T]))
            else:
                pts = [T]
                while pts[-1] < 3: pts.append(min(pts[-1] + step, Fr(3)))
                pts.append(Fr(4))
            segs = list(zip(pts, pts[1:])) + [(pts[-1], None)]
            vals = [val(a_, b_) for a_, b_ in segs]
            if all(v < 0 for v in vals): return T, list(zip(segs, vals))
    raise RuntimeError('Lemma 2(c) chain fails')
def polygon(lam, TP=(Fr(3, 10), Fr(3, 5), Fr(1)), slack=Fr(1, 10**4)):
    lam = Fr(lam); L = float(lam)
    def Jf(t): s = L * math.exp(-t) / (1 + L * math.exp(-t)); return s * s * t / math.log1p(L * math.exp(-t))
    def rf(t): return t / math.log1p(L * math.exp(-t))
    grid = [i / 2000 for i in range(0, 24001)]
    lines = []
    for t in TP:
        e = 1e-6; b = Fr((Jf(float(t) + e) - Jf(float(t) - e)) / (rf(float(t) + e) - rf(float(t) - e))).limit_denominator(10**4)
        a = max(Jf(x) - float(b) * rf(x) for x in grid)
        lines.append((Fr(a).limit_denominator(10**6) + slack, b))
    lines.append((Fr(max(Jf(x) for x in grid)).limit_denominator(10**6) + slack, Fr(0)))
    T, segs = jdec_start(lam)
    pieces = []
    for a, b in lines:
        P = greedy(lambda x, y: piece_top(x, y, b, lam) <= a, Fr(0), T); pieces.append(P)
    V = [(Fr(0), lines[0][0])]
    for (a1, b1), (a2, b2) in zip(lines, lines[1:]):
        assert b1 > b2 >= 0
        r = (a2 - a1) / (b1 - b2); V.append((r, a1 + b1 * r))
    assert all(V[i][0] < V[i + 1][0] for i in range(len(V) - 1))
    return dict(lam=lam, lines=lines, V=V, T=T, segs=segs, pieces=pieces, Jcap=lines[-1][0],
                checks=sum(len(P) for P in pieces) + len(segs))
if __name__ == '__main__':
    for lam in sys.argv[1:]:
        P = polygon(Fr(lam))
        print('lam_b = %s: lines %s' % (lam, [(float(a), float(b)) for a, b in P['lines']]))
        print('   vertices %s, Jcap %.5f, Taylor range [0,%s], pieces %s, Lemma 2(c) segments %d, checks %d' % (
            [(round(float(r), 4), round(float(j), 4)) for r, j in P['V']], float(P['Jcap']), P['T'], [len(x) for x in P['pieces']], len(P['segs']), P['checks']))
