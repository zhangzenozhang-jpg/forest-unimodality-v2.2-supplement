"""ratlib.py -- exact rational enclosures (outward-rounded to dyadic rationals) for exp, log, msg, lm.
All functions return (lo, hi) Fractions with lo <= true value <= hi. PROVED-grade: series with explicit remainders."""
from fractions import Fraction as Fr
import math
PREC = 2**48
def dn(x):  # round down to dyadic grid
    return Fr(math.floor(x * PREC), PREC)
def up(x):
    return Fr(math.ceil(x * PREC), PREC)
def exp_pos(x):
    """enclosure of e^x for rational 0 <= x <= 16, via e^x = (e^{x/2^k})^{2^k}"""
    assert x >= 0
    k = 0
    while x / 2**k > Fr(1, 4): k += 1
    z = x / 2**k
    N = 12; term = Fr(1); s = Fr(1)
    for i in range(1, N + 1):
        term = term * z / i; s += term
    rem = term * z / (N + 1) / (1 - z / (N + 2))
    lo, hi = dn(s), up(s + rem)
    for _ in range(k):
        lo, hi = dn(lo * lo), up(hi * hi)
    return lo, hi
def exp_neg(x):
    """enclosure of e^{-x}, x >= 0 rational"""
    lo, hi = exp_pos(x)
    return dn(1 / hi), up(1 / lo)
_L2 = None
def log2_enc():
    global _L2
    if _L2 is None:
        u = Fr(1, 3); s = Fr(0); t = u; k = 0
        while True:
            s += t / (2 * k + 1); k += 1; t = t * u * u
            if k > 40: break
        rem = t / (2 * k + 1) / (1 - u * u)
        _L2 = (dn(2 * s), up(2 * (s + rem)))
    return _L2
def log_enc(r):
    """enclosure of log r for rational r > 0"""
    assert r > 0
    n = 0
    while r > Fr(3, 2): r /= 2; n += 1
    while r < Fr(3, 4): r *= 2; n -= 1
    u = (r - 1) / (r + 1)          # |u| <= 1/5
    au = abs(u); s = Fr(0); t = au; k = 0
    for k in range(0, 14):
        s += t / (2 * k + 1); t = t * au * au
    rem = t / (2 * 14 + 1) / (1 - au * au)
    lo, hi = 2 * s, 2 * (s + rem)
    if u < 0: lo, hi = -hi, -lo
    L2lo, L2hi = log2_enc()
    if n >= 0: return dn(lo + n * L2lo), up(hi + n * L2hi)
    return dn(lo + n * L2hi), up(hi + n * L2lo)
def msg(lam, z):   # lam e^{-z}/(1+lam e^{-z}); increasing in lam, decreasing in z
    elo, ehi = exp_neg(z)
    a, b = lam * elo, lam * ehi
    return dn(a / (1 + a)), up(b / (1 + b))
def lm(lam, z):    # log(1+lam e^{-z})
    elo, ehi = exp_neg(z)
    return log_enc(1 + lam * elo)[0], log_enc(1 + lam * ehi)[1]
def ell(p):        # -log(1-p) for rational p in [0,1)
    lo, hi = log_enc(1 - p)
    return -hi, -lo
if __name__ == '__main__':
    for x in [Fr(0), Fr(1, 3), Fr(1), Fr(6), Fr(4)]:
        lo, hi = exp_neg(x); print('e^-', x, float(lo), float(hi), math.exp(-float(x)))
    for r in [Fr(2), Fr(1, 3), Fr(101, 100), Fr(50)]:
        lo, hi = log_enc(r); print('log', r, float(lo), float(hi), math.log(float(r)))
