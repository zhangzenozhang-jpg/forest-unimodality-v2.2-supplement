"""polygon_data.py -- PROVED data (exact rational; bookkeeping of the polygon part of the proof). Recomputes, with
child_poly.polygon (the function the proof used; deterministic), the 26 child polygons at lam_p = lam_+ of the
sub-intervals of outputs/curve_{lo,u1,u2,u3,u4}.json; asserts that the vertices, the cap and the check count equal those
recorded by the proof; and writes the data of record:
  outputs/polygon_data.json -- for each lam_p: the lines (a_i, b_i) and the cap (exact rationals), the start T of the
      monotone tail, the chain of Lemma tr:lem:child(b) with its values, and for each line the breakpoints of its
      second-order Taylor subintervals on [0, T] (the polygon checks), with the least slack a - (Taylor upper bound);
  outputs/polygon_data.log  -- a summary (T per lam_p, counts, least slack)."""
import sys, os, json
from fractions import Fraction as Fr
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from child_poly import polygon, piece_top
O = os.path.join(HERE, '..', 'outputs')
out = []; lines_log = []; total = 0
for P in ['lo', 'u1', 'u2', 'u3', 'u4']:
    R = json.load(open(os.path.join(O, 'curve_%s.json' % P)))
    for r in R['results']:
        rep = r['rep']; lp = Fr(rep['lp'])
        Pg = polygon(lp)
        assert [(str(a), str(b)) for a, b in Pg['V']] == [tuple(v) for v in rep['vertices']], lp
        assert str(Pg['Jcap']) == rep['Jbar'] and Pg['checks'] == rep['polygon_checks'], lp
        per_line = []
        for (a, b), pcs in zip(Pg['lines'], Pg['pieces']):
            slack = min(a - piece_top(x, y, b, lp) for x, y in pcs)
            assert slack >= 0
            per_line.append(dict(a=str(a), b=str(b), breakpoints=[str(x) for x, y in pcs] + [str(pcs[-1][1])], n=len(pcs), least_slack=str(slack), least_slack_float=float(slack)))
        chain = [dict(a=str(s[0]), b=(str(s[1]) if s[1] is not None else 'oo'), value=str(v), value_float=float(v)) for s, v in Pg['segs']]
        assert all(Fr(c['value']) < 0 for c in chain)
        out.append(dict(segment=P, sub_interval=[rep['la'], rep['lb']], lam_p=str(lp), T=str(Pg['T']), lines=per_line,
                        J_cap=str(Pg['Jcap']), vertices=rep['vertices'], chain=chain, checks=Pg['checks']))
        total += Pg['checks']
        lines_log.append('lam_p = %-7s (%s): T = %-5s lines (a_i, b_i) = %s, J_cap = %.6f; Taylor subintervals per line %s; chain segments %d; checks %d; least slack %.2e' % (
            lp, P, Pg['T'], [(round(float(a), 6), round(float(b), 6)) for a, b in Pg['lines'][:3]], float(Pg['Jcap']),
            [d['n'] for d in per_line], len(chain), Pg['checks'], min(d['least_slack_float'] for d in per_line)))
json.dump(dict(polygons=out, total_checks=total), open(os.path.join(O, 'polygon_data.json'), 'w'), indent=1)
lines_log.append('26 polygons, %d checks (Taylor subintervals + chain segments); all vertices, caps and counts equal those of the proof' % total)
open(os.path.join(O, 'polygon_data.log'), 'w').write('\n'.join(lines_log) + '\n')
print('\n'.join(lines_log))
