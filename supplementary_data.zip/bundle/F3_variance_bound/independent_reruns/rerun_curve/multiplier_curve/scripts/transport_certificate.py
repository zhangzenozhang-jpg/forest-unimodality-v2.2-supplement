"""transport_certificate.py -- PROVED (exact rational): the step certificate (alpha, 0, gamma, A_D), D = 6/5, on an
activity interval Lam = [la, lb], by transporting the lambda-at-a-point proof of two_gen_arc along mu = log(lambda).
For a sub-interval with centre lc (rational), dm >= log(lc/la), dp >= log(lb/lc):
 (P) child polygon proved at lb (child_poly.py), valid for all lam <= lb; Jbar = its cap.
 (Z) Q = gamma + J L' >= gamma_a - Jbar * A(log(A/B) - 1) > 0,  A = 1+gamma_b, B = gamma_a/lb  (h <= 1+gamma).
 (L) left flank 0 < Y <= YL, every child (feasibility rho >= Yt/Y >= (mu - log(e^Y-1))/Y), uniform constants on Lam.
 (R) right flank Y >= YR, every child (rho >= 0, J <= Jbar), uniform constants on Lam.
 (V) core YL <= Y <= YR, each vertex v and F in {Phi_v, Phig_v}: on a piece [Y0,Y1],
        F(Y, lam) >= TB(lc) - max(dp * max(0, -inf d_mu F), dm * max(0, sup d_mu F)),
     TB(lc) = two-ended second-order Taylor bound at lc (as in arc_certificate.py), inf/sup of d_mu F over [Y0,Y1] x Lam.
 (C) CA: on each piece of [1/500, YB] either L' > 0 on the box, or C(Y, lam) >= TB_C(lc) - (same transport loss);
     (0, 1/500]: L' >= gamma_a/lb - (1+gamma_b) Y > 0;  [YB, oo): L' >= gamma_a e^Y/lb - (1+gamma_b) Y increasing, > 0 at YB.
Usage: transport_certificate.py la lb [lc]"""
import sys, os, json
from fractions import Fraction as Fr
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from ival import I
from ratlib import exp_pos, msg, lm, log_enc
from tfun import (mults, mults_iv, point_prims, box_prims, phi_all, phi2_piece, dmu_phi, C_all, dmu_C, pp_of)
from child_poly import polygon, greedy
YL, YR, YB = Fr(3, 10), Fr(3), Fr(3)
_POLY = {}
def get_polygon(lp, TP):
    key = (Fr(lp), tuple(TP))
    if key not in _POLY: _POLY[key] = polygon(Fr(lp), TP)
    return _POLY[key]
def run(la, lb, lc=None, verbose=True, TP=(Fr(3, 10), Fr(3, 5), Fr(1)), YL=YL, cut=False, lp=None):
    la, lb, YL = Fr(la), Fr(lb), Fr(YL); lc = Fr(lc) if lc is not None else (la + lb) / 2
    dm = log_enc(lc / la)[1] if lc > la else Fr(0); dp = log_enc(lb / lc)[1] if lb > lc else Fr(0)
    muc = I(*log_enc(lc)); mu_iv = I(log_enc(la)[0], log_enc(lb)[1])
    aa, ga, Da = mults(la); ab, gb, Db = mults(lb)
    rep = dict(la=str(la), lb=str(lb), lc=str(lc), YL=str(YL), cut=cut); checks = 0; log = []
    # (P)
    lp = Fr(lp) if lp is not None else lb
    assert lp >= lb
    P = get_polygon(lp, TP); V = P['V']; Jbar = P['Jcap']
    log.append('(P) polygon at lam_p=%s (>= lb, shared, counted once): vertices %s, Jbar = Jcap = %.5f, %d checks' % (lp, [(round(float(r), 4), round(float(j), 4)) for r, j in V], float(Jbar), P['checks']))
    # (Z)
    A = 1 + gb; B = ga / lb; cZ = A * (log_enc(A / B)[1] - 1); Qlo = ga - Jbar * cZ
    assert Qlo > 0; checks += 1
    log.append('(Z) Q >= %.5f > 0' % float(Qlo))
    # (L) left flank: pieces [Y0,Y1] of (0, YL]; on each, uniformly on Lam and for every child,
    #   AC/p >= alpha_a e^{Y0}/lb + (N_lo + alpha_a t)/Y* - Jbar h_hi^2/Q_lo,  t = max(0, log la - log(e^{Y1}-1)) <= Yt,
    #   Y* = Y1 if the numerator is >= 0 (else Y0 > 0);  rho >= Yt/Y >= t/Y by feasibility.
    def left_piece(Y0, Y1):
        pl = msg(la, Y1)[0]; k_hi = (I(*msg(la, Y1)) / I(*lm(la, Y1))).hi; k_lo = (I(*msg(lb, Y0)) / I(*lm(lb, Y0))).lo
        h_hi = 1 - pl + gb * k_hi; N_lo = Da - h_hi - ab / k_lo
        t = max(Fr(0), log_enc(la)[0] - log_enc(exp_pos(Y1)[1] - 1)[1])
        num = N_lo + aa * t
        if num < 0 and Y0 == 0: return None
        term = num / Y1 if num >= 0 else num / Y0
        e0 = exp_pos(Y0)[0]; Lp_lo = ga * e0 / lb - h_hi * Y1; QL = ga + Jbar * min(Fr(0), Lp_lo)
        if QL <= 0: return None
        return aa * e0 / lb + term - Jbar * h_hi ** 2 / QL
    lpcs = greedy(lambda a, b: (lambda v: v is not None and v > 0)(left_piece(a, b)), Fr(0), YL, Fr(1, 256)); checks += len(lpcs)
    log.append('(L) (0, %s]: %d pieces %s, min bound %.4f' % (YL, len(lpcs), [round(float(a), 3) for a, b in lpcs] + [float(YL)],
               float(min(left_piece(a, b) for a, b in lpcs))))
    # (R) right flank
    kR = (I(*msg(lb, YR)) / I(*lm(lb, YR))).lo
    NR = Da - (1 + gb) - ab / kR
    assert NR < 0
    assert log_enc((1 + gb) * lb / ga)[1] <= YR
    eR = exp_pos(YR)[0]; mR = (1 + gb) * YR - ga * eR / lb
    QR = min(ga - Jbar * max(Fr(0), mR), ga)
    right = aa * eR / lb + NR / YR - (1 + gb) ** 2 * Jbar / QR
    assert QR > 0 and right > 0; checks += 1
    log.append('(R) Y >= %s: AC/p >= %.4f > 0' % (YR, float(right)))
    # (V) core
    cache = {}
    def pt(Y, J, rho, tag):
        key = (Y, J, rho, tag)
        if key not in cache:
            ul, p, y0, k = point_prims(Y, lc); D = phi_all(ul, p, k, I(Y), I(J), rho, lc)
            cache[key] = (D[tag], D[tag + '1'])
        return cache[key]
    def vpiece(Y0, Y1, J, rho, tag):
        try:
            F0, d0 = pt(Y0, J, rho, tag); F1, d1 = pt(Y1, J, rho, tag)
            P2 = phi2_piece(Y0, Y1, I(J), rho, lc)
            if P2['Q'].lo <= 0: return None
            Dm = dmu_phi(Y0, Y1, la, lb, I(J), rho)[tag]
        except AssertionError:
            return None
        m2 = min(Fr(0), P2[tag + '2'].lo)
        q0 = lambda Y: F0.lo + d0.lo * (Y - Y0) + m2 * (Y - Y0) ** 2 / 2
        q1 = lambda Y: F1.lo + d1.hi * (Y - Y1) + m2 * (Y - Y1) ** 2 / 2
        cands = [F0.lo, F1.lo]; a0 = q0(Y0) - q1(Y0); a1 = q0(Y1) - q1(Y1)
        if (a0 < 0) != (a1 < 0) and a0 != a1:
            Yx = Y0 + (Y1 - Y0) * a0 / (a0 - a1); cands.append(max(q0(Yx), q1(Yx)))
        TB = min(cands); loss = max(dp * max(Fr(0), -Dm.lo), dm * max(Fr(0), Dm.hi))
        return dict(TB=TB, loss=loss, bound=TB - loss, Dm=Dm)
    core = []
    lines = P['lines']
    def U(r): return min(a + b * r for a, b in lines)
    def rho_cut(Y1):
        """children of a parent with Y <= Y1 at lam >= la: rho = Yt/y >= Yt/Y1 >= (log la - log(e^Y1 - 1))/Y1 (feasibility)"""
        t = log_enc(la)[0] - log_enc(exp_pos(Y1)[1] - 1)[1]
        return max(Fr(0), Fr(t / Y1).limit_denominator(10**6) - Fr(1, 10**6))
    def active(Y1):
        rc = rho_cut(Y1)
        return [(r, j) for r, j in V if r >= rc] + ([(rc, U(rc))] if rc > 0 else [])
    if cut:
        def okc(a, b):
            for rho, J in active(b):
                for tag in ('Phi', 'Phig'):
                    r = vpiece(a, b, J, rho, tag)
                    if r is None or r['bound'] <= 0: return False
            return True
        pcs = greedy(okc, YL, YR, Fr(1, 512))
        nchk = sum(2 * len(active(b)) for a, b in pcs); checks += nchk
        allr = [vpiece(a, b, J, rho, tag) for a, b in pcs for rho, J in active(b) for tag in ('Phi', 'Phig')]
        core.append(dict(vertex='cut-polygon', tag='both', pieces=[(str(a), str(b)) for a, b in pcs], min_bound=float(min(r['bound'] for r in allr)),
                         checks=[dict(Y0=str(a), Y1=str(b), rho=str(rho), J=str(J), tag=tag, bound=float(vpiece(a, b, J, rho, tag)['bound']))
                                 for a, b in pcs for rho, J in active(b) for tag in ('Phi', 'Phig')],
                         max_loss=float(max(r['loss'] for r in allr)), active=[len(active(b)) for a, b in pcs]))
        log.append('(V) feasibility-cut polygon: %d parent pieces, %d vertex-function checks (active vertices per piece %s), min bound %.5f, breakpoints %s' % (
            len(pcs), nchk, core[-1]['active'], core[-1]['min_bound'], [round(float(a), 3) for a, b in pcs] + [float(YR)]))
    for i, (rho, J) in enumerate([] if cut else V):
        for tag in ('Phi', 'Phig'):
            ok = lambda a, b: (lambda r: r is not None and r['bound'] > 0)(vpiece(a, b, J, rho, tag))
            pcs = greedy(ok, YL, YR, Fr(1, 256)); checks += len(pcs)
            rs = [vpiece(a, b, J, rho, tag) for a, b in pcs]
            core.append(dict(vertex=i, tag=tag, rho=str(rho), J=str(J), pieces=[(str(a), str(b)) for a, b in pcs], bounds=[float(r['bound']) for r in rs],
                             min_bound=float(min(r['bound'] for r in rs)),
                             max_loss=float(max(r['loss'] for r in rs))))
            log.append('(V) vertex %d %-4s: %2d pieces, min bound %.5f, max transport loss %.5f, breakpoints %s' % (
                i, tag, len(pcs), core[-1]['min_bound'], core[-1]['max_loss'], [round(float(a), 3) for a, b in pcs] + [float(YR)]))
    # (C) CA
    Ys = Fr(1, 500)
    assert ga / lb - (1 + gb) * Ys > 0
    assert log_enc((1 + gb) * lb / ga)[1] <= YB and ga * exp_pos(YB)[0] / lb - (1 + gb) * YB > 0
    def Lpos(Y0, Y1):
        ul, p, y0, k = box_prims(Y0, Y1, la, lb); GA = I(ga, gb)
        return (GA * ul - (1 - p + GA * k) * I(Y0, Y1)).lo > 0
    def cpiece(Y0, Y1):
        c = (Y0 + Y1) / 2; d = (Y1 - Y0) / 2
        try:
            Dc = C_all(c, c, lc, Jbar, muc); Dp = C_all(Y0, Y1, lc, Jbar, muc)
            Dm = dmu_C(Y0, Y1, la, lb, Jbar, mu_iv)
        except AssertionError:
            return None
        m2 = min(Fr(0), Dp['C2'].lo)
        TB = min(Dc['C'].lo - Dc['C1'].hi * d + m2 * d * d / 2, Dc['C'].lo + Dc['C1'].lo * d + m2 * d * d / 2)
        loss = max(dp * max(Fr(0), -Dm.lo), dm * max(Fr(0), Dm.hi))
        return dict(TB=TB, loss=loss, bound=TB - loss)
    def cok(a, b):
        if Lpos(a, b): return True
        r = cpiece(a, b); return r is not None and r['bound'] > 0
    cpcs = greedy(cok, Ys, YB, Fr(1, 256)); checks += len(cpcs) + 2
    nL = sum(1 for a, b in cpcs if Lpos(a, b)); cb = [cpiece(a, b) for a, b in cpcs if not Lpos(a, b)]
    log.append("(C) CA: %d pieces with L' > 0, %d Taylor-transport pieces of C (min bound %.5f, max loss %.5f), + 2 hand checks" % (
        nL, len(cb), float(min(r['bound'] for r in cb)) if cb else float('nan'), float(max(r['loss'] for r in cb)) if cb else float('nan')))
    rep.update(ca=[dict(Y0=str(a), Y1=str(b), Lpos=Lpos(a, b), bound=(None if Lpos(a, b) else float(cpiece(a, b)['bound']))) for a, b in cpcs],
               left=[(str(a), str(b)) for a, b in lpcs], lp=str(lp), checks=checks, polygon_checks=P['checks'], core_pieces=sum(len(c['pieces']) for c in core), ca_pieces=len(cpcs),
               vertices=[(str(r), str(j)) for r, j in V], Jbar=str(Jbar), core=core, dm=float(dm), dp=float(dp))
    log.append('TOTAL exact checks on [%s, %s] (centre %s), polygon excluded: %d  -- ALL PASS' % (la, lb, lc, checks))
    if verbose: print('\n'.join(log))
    return rep, log
if __name__ == '__main__':
    la, lb = Fr(sys.argv[1]), Fr(sys.argv[2]); lc = Fr(sys.argv[3]) if len(sys.argv) > 3 and sys.argv[3] != '-' else None
    yl = Fr(sys.argv[4]) if len(sys.argv) > 4 else YL
    cut = len(sys.argv) > 5 and sys.argv[5] == 'cut'
    run(la, lb, lc, YL=yl, cut=cut)
