"""curve_all.py -- PROVED (exact rational): the step certificate (alpha, 0, gamma, A_D) along the multiplier curve
(alpha, gamma, A_D) = (a q, lam(3+lam)/g, 1+(D-1)q), with (a, g, D) constant on each segment (SEG), on every activity
sub-interval of a plan, by the transport of two_gen_transport (transport_certificate.run, unchanged; the multipliers enter
only through tfun.mults / mults_iv / dmults_iv, which read tfun.PAR). Each polygon is counted once per activity lam_p.
Usage: curve_all.py PLAN [indices]   (PLAN in PLANS; runs in parallel, 6 workers; the JSON goes to $CURVE_OUTDIR,
default outputs/)."""
import sys, os, json, time, traceback
from fractions import Fraction as Fr
from multiprocessing import Pool
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
SEG = {  # name: (a, g, D) -- the curve; 'mid' is the proved centre of two_gen_transport (for reference only)
    'lo': (Fr(11, 25), Fr(21, 2), Fr(6, 5)),       # [1/3, 11/20]
    'mid': (Fr(23, 50), Fr(13), Fr(6, 5)),         # [11/20, 263/200] (two_gen_transport, Theorem tr:thm)
    'u1': (Fr(9, 20), Fr(23, 2), Fr(7, 5)),        # [263/200, 3/2]
    'u2': (Fr(47, 100), Fr(43, 4), Fr(8, 5)),      # [3/2, 7/4]
    'u3': (Fr(1, 2), Fr(41, 4), Fr(9, 5)),         # [7/4, 2]
    'u4': (Fr(57, 100), Fr(39, 4), Fr(21, 10)),    # [2, 7/3]
}
def chain(seg, pts, YL='1/5', cut=False):
    return [(a, b, b, YL, cut, seg) for a, b in zip(pts, pts[1:])]
PLANS = {
 'test': [('1/3', '9/25', '9/25', '1/5', False, 'lo'), ('9/4', '7/3', '7/3', '1/5', True, 'u4')],
 'lo': chain('lo', ['1/3', '9/25', '2/5', '11/25', '12/25', '13/25', '11/20'], YL='1/8'),
 'lo_shared': [('1/3', '2/5', '11/20', '1/8', False, 'lo'), ('2/5', '12/25', '11/20', '1/8', False, 'lo'), ('12/25', '11/20', '11/20', '1/8', False, 'lo')],
 'u1': chain('u1', ['263/200', '27/20', '7/5', '29/20', '3/2'], cut=True),
 'u2': chain('u2', ['3/2', '31/20', '8/5', '33/20', '17/10', '7/4'], cut=True),
 'u3': chain('u3', ['7/4', '9/5', '37/20', '19/10', '39/20', '2'], cut=True),
 'u4': chain('u4', ['2', '41/20', '21/10', '43/20', '11/5', '9/4', '7/3'], cut=True),
}
def job(item):
    la, lb, lp, yl, cut, seg = item
    import tfun; tfun.PAR = SEG[seg]
    import transport_certificate as T
    t0 = time.time()
    try:
        rep, log = T.run(Fr(la), Fr(lb), None, verbose=False, YL=Fr(yl), cut=cut, lp=Fr(lp))
        rep['seg'] = seg; rep['par'] = [str(x) for x in SEG[seg]]
        return dict(ok=True, item=item, rep=rep, log=log, secs=time.time() - t0)
    except Exception as e:
        return dict(ok=False, item=item, err='%s: %s' % (type(e).__name__, e), tb=traceback.format_exc()[-600:], secs=time.time() - t0)
if __name__ == '__main__':
    name = sys.argv[1]; only = [int(x) for x in sys.argv[2:]]
    items = [it for i, it in enumerate(PLANS[name]) if not only or i in only]
    t0 = time.time()
    with Pool(min(6, len(items))) as pool:
        res = pool.map(job, items, chunksize=1)
    total = 0; polys = {}; allok = True
    for r in res:
        la, lb, lp, yl, cut, seg = r['item']
        print('--- sub-interval [%s, %s], segment %s (a, g, D) = %s, polygon at %s, YL = %s, cut = %s (%.0f s)' % (
            la, lb, seg, tuple(str(x) for x in SEG[seg]), lp, yl, cut, r['secs']))
        if r['ok']:
            print('\n'.join(r['log'])); total += r['rep']['checks']; polys[r['rep']['lp']] = r['rep']['polygon_checks']
        else:
            allok = False; print('FAILED: %s\n%s' % (r['err'], r['tb']))
    ptot = sum(polys.values())
    print('polygons: %s' % polys)
    print('PLAN %s: %d sub-intervals, %d checks excluding polygons + %d polygon checks = %d exact checks; %s (%.0f s)' % (
        name, len(res), total, ptot, total + ptot, 'ALL PASS' if allok else 'SOME FAILED', time.time() - t0))
    json.dump(dict(plan=name, only=only, segments={k: [str(x) for x in v] for k, v in SEG.items()},
                   results=[dict(ok=r['ok'], item=r['item'], rep=r.get('rep'), err=r.get('err')) for r in res],
                   polygon_checks=polys, total=total + ptot, allok=allok),
              open(os.path.join(os.environ.get('CURVE_OUTDIR', os.path.join(HERE, '..', 'outputs')), 'curve_%s%s.json' % (name, ''.join('_%d' % i for i in only))), 'w'), indent=1)
