"""tfun.py (multiplier_curve copy: multipliers of the segment PAR = (a, g, D) in force) -- the parent-arc functions of arc_section.tex at a rational activity lam, and their derivatives in
mu = log(lam) at fixed log-mass Y, in exact interval arithmetic (ival.py, ratlib.py).
Parent primitives at (Y, lam): E = e^Y, ul = e^Y/lam, p = msg_lam(Y), y0 = lm_lam(Y) = ell(p), k = p/y0, w = k+p-1.
All four are functions of Y - mu (translation), so at fixed Y:  d_mu ul = -ul, d_mu p = p(1-p), d_mu k = -k w.
Multipliers of the segment PAR = (a, g, D): alpha = a q, gamma = lam(3+lam)/g, A_D = 1+(D-1)q; all increase in lam, and
d_mu alpha = a q(1-q), d_mu gamma = lam(3+2lam)/g, d_mu A_D = (D-1) q(1-q), with q(1-q) = lam/(1+lam)^2 (default PAR = the
old curve (23/50, 13, 6/5)).
Vertex functions:  Phi = alpha ul + N/Y + alpha rho - J h^2/Q,  Phig = alpha ul + N/Y + alpha rho - J h^2/gamma,
h = 1-p+gamma k,  N = A_D - h - alpha/k,  Q = gamma + J L',  L' = gamma ul - hY.
mu-derivatives at fixed (Y, rho, J):
  hd = -p(1-p) - gamma k w + gammad k,   Nd = A_Dd - hd - alphad/k - alpha w/k,   Qd = gammad + J(gammad ul - gamma ul - hd Y),
  d_mu Phi  = alphad ul - alpha ul + Nd/Y + alphad rho - J (2 h hd Q - h^2 Qd)/Q^2,
  d_mu Phig = alphad ul - alpha ul + Nd/Y + alphad rho - J (2 h hd/gamma - h^2 gammad/gamma^2)."""
from fractions import Fraction as Fr
from ratlib import exp_pos, msg, lm, log_enc
from ival import I
# multiplier_curve: the segment of the curve in force, PAR = (a, g, D) with alpha = a q, gamma = lam(3+lam)/g,
# A_D = 1 + (D-1) q (a > 0, g > 0, D >= 1: all three increase in lam, as used by mults_iv). Set by the driver.
PAR = (Fr(23, 50), Fr(13), Fr(6, 5))
def mults(lam):
    a, g, D = PAR
    q = Fr(lam) / (1 + Fr(lam)); return a * q, Fr(lam) * (3 + Fr(lam)) / g, 1 + (D - 1) * q
def mults_iv(la, lb):
    a0, g0, d0 = mults(la); a1, g1, d1 = mults(lb); return I(a0, a1), I(g0, g1), I(d0, d1)
def dmults_iv(la, lb):
    a, g, D = PAR
    L = I(la, lb); qq = L / (1 + L).sq()
    return a * qq, L * (3 + 2 * L) / g, (D - 1) * qq
def point_prims(Y, lam):
    Y, lam = Fr(Y), Fr(lam); e = exp_pos(Y); pm = msg(lam, Y); l = lm(lam, Y)
    p = I(pm[0], pm[1]); y0 = I(l[0], l[1])
    return I(e[0], e[1]) / lam, p, y0, p / y0
def piece_prims(Y0, Y1, lam):
    """on [Y0,Y1] at fixed lam: ul increasing, p and y0 decreasing, k increasing (k' = k w > 0)"""
    u0, p0, y00, k0 = point_prims(Y0, lam); u1, p1, y01, k1 = point_prims(Y1, lam)
    return I(u0.lo, u1.hi), I(p1.lo, p0.hi), I(y01.lo, y00.hi), I(k0.lo, k1.hi)
def box_prims(Y0, Y1, la, lb):
    """on [Y0,Y1] x [la,lb]: every primitive is monotone in Y - mu"""
    uA, pA, yA, kA = point_prims(Y0, lb); uB, pB, yB, kB = point_prims(Y1, la)
    return I(uA.lo, uB.hi), I(pB.lo, pA.hi), I(yB.lo, yA.hi), I(kA.lo, kB.hi)
def pp_of(p):
    a, b = p.lo * (1 - p.lo), p.hi * (1 - p.hi)
    if p.lo <= Fr(1, 2) <= p.hi: return I(min(a, b), Fr(1, 4))
    return I(min(a, b), max(a, b))
def blocks(ul, p, k, Y, AL, GA, AD):
    w = k + p - 1; pp = pp_of(p)
    h = 1 - p + GA * k
    h1 = pp + GA * k * w
    h2 = -pp * (1 - 2 * p) + GA * k * (w.sq() + k * w - pp)
    N = AD - h - AL / k
    N1 = -h1 + AL * w / k
    N2 = -h2 + AL * (w - pp / k - w.sq() / k)
    M0 = N / Y; M1 = (N1 * Y - N) / Y.sq(); M2 = (N2 * Y.sq() - 2 * N1 * Y + 2 * N) / (Y.sq() * Y)
    return dict(w=w, pp=pp, h=h, h1=h1, h2=h2, N=N, N1=N1, N2=N2, M0=M0, M1=M1, M2=M2)
def phi_all(ul, p, k, Y, J, rho, lam):
    AL, GA, AD = mults(lam)
    b = blocks(ul, p, k, Y, AL, GA, AD); h, h1, h2 = b['h'], b['h1'], b['h2']
    Q = GA + J * (GA * ul - h * Y); Q1 = J * (GA * ul - h - h1 * Y)
    G = J * h.sq() / Q; G1 = J * (2 * h * h1 * Q - h.sq() * Q1) / Q.sq()
    au = AL * ul
    return dict(Q=Q, Phi=au + b['M0'] + AL * rho - G, Phi1=au + b['M1'] - G1,
                Phig=au + b['M0'] + AL * rho - J * h.sq() / GA, Phig1=au + b['M1'] - 2 * J * h * h1 / GA)
def meet(a, b):
    lo, hi = max(a.lo, b.lo), min(a.hi, b.hi); assert lo <= hi, 'empty intersection'; return I(lo, hi)
def phi2_piece(Y0, Y1, J, rho, lam):
    """enclosures of Phi'' and Phig'' on [Y0,Y1] at fixed lam (Y-derivatives), with L' and R1 = (L')' in mean-value form"""
    AL, GA, AD = mults(lam)
    c = (Y0 + Y1) / 2; d = (Y1 - Y0) / 2; D = I(-d, d)
    uc, pc, _, kc = point_prims(c, lam); bc = blocks(uc, pc, kc, I(c), AL, GA, AD)
    Lc = GA * uc - bc['h'] * c; R1c = GA * uc - bc['h'] - bc['h1'] * c
    ul, p, y0, k = piece_prims(Y0, Y1, lam); Y = I(Y0, Y1)
    b = blocks(ul, p, k, Y, AL, GA, AD); h, h1, h2 = b['h'], b['h1'], b['h2']
    R2 = GA * ul - 2 * h1 - h2 * Y
    R1 = meet(GA * ul - h - h1 * Y, R1c + R2 * D)
    Lp = meet(GA * ul - h * Y, Lc + R1 * D)
    Q = GA + J * Lp; Q1 = J * R1; Q2 = J * R2
    G2 = J * ((2 * h1.sq() + 2 * h * h2) / Q - 4 * h * h1 * Q1 / Q.sq() - h.sq() * Q2 / Q.sq() + 2 * h.sq() * Q1.sq() / (Q.sq() * Q))
    au = AL * ul
    return dict(Q=Q, Phi2=au + b['M2'] - G2, Phig2=au + b['M2'] - J * (2 * h1.sq() + 2 * h * h2) / GA)
def dmu_phi(Y0, Y1, la, lb, J, rho):
    """enclosures of d_mu Phi and d_mu Phig on the box [Y0,Y1] x [la,lb] (fixed Y, rho, J)"""
    ul, p, y0, k = box_prims(Y0, Y1, la, lb); Y = I(Y0, Y1)
    AL, GA, AD = mults_iv(la, lb); ALd, GAd, ADd = dmults_iv(la, lb)
    w = k + p - 1; pp = pp_of(p)
    h = 1 - p + GA * k
    hd = -pp - GA * k * w + GAd * k
    N = AD - h - AL / k
    Nd = ADd - hd - ALd / k - AL * w / k
    Q = GA + J * (GA * ul - h * Y)
    assert Q.lo > 0
    Qd = GAd + J * (GAd * ul - GA * ul - hd * Y)
    common = ALd * ul - AL * ul + Nd / Y + ALd * rho
    return dict(Phi=common - J * (2 * h * hd * Q - h.sq() * Qd) / Q.sq(),
                Phig=common - J * (2 * h * hd / GA - h.sq() * GAd / GA.sq()))
# ---------------- the CA bound C(Y) = alpha B - gamma l/(gamma - Jbar l) at activity lam ----------------
def logm1(E):
    return I(log_enc(E.lo - 1)[0], log_enc(E.hi - 1)[1])
def C_all(Y0, Y1, lam, Jbar, mu):
    """C, C', C'' (Y-derivatives at fixed lam) on [Y0,Y1] (Y0 = Y1 for a point); mu = enclosure of log lam.
    B = ul + n/Y, n = mu - log(e^Y - 1) - 1/k (feasibility: Yt >= mu - log(e^Y-1)), l = hY - gamma ul."""
    AL, GA, AD = mults(lam)
    if Y0 == Y1: ul, p, y0, k = point_prims(Y0, lam)
    else: ul, p, y0, k = piece_prims(Y0, Y1, lam)
    E = ul * lam; Y = I(Y0, Y1)
    b = blocks(ul, p, k, Y, AL, GA, AD); h, h1, h2, w, pp = b['h'], b['h1'], b['h2'], b['w'], b['pp']
    Em1 = E - 1
    n = mu - logm1(E) - 1 / k
    n1 = -E / Em1 + w / k
    n2 = E / Em1.sq() + w - pp / k - w.sq() / k
    B = ul + n / Y; B1 = ul + (n1 * Y - n) / Y.sq(); B2 = ul + (n2 * Y.sq() - 2 * n1 * Y + 2 * n) / (Y.sq() * Y)
    l = h * Y - GA * ul; l1 = h + h1 * Y - GA * ul; l2 = 2 * h1 + h2 * Y - GA * ul
    den = GA - Jbar * l
    assert den.lo > 0
    f = GA * l / den; f1 = GA * GA / den.sq(); f2 = 2 * Jbar * GA * GA / (den.sq() * den)
    return dict(C=AL * B - f, C1=AL * B1 - f1 * l1, C2=AL * B2 - f2 * l1.sq() - f1 * l2)
def dmu_C(Y0, Y1, la, lb, Jbar, mu_iv):
    """enclosure of d_mu C at fixed Y on [Y0,Y1] x [la,lb]; mu_iv = enclosure of [log la, log lb]"""
    ul, p, y0, k = box_prims(Y0, Y1, la, lb); Y = I(Y0, Y1)
    E = I(exp_pos(Fr(Y0))[0], exp_pos(Fr(Y1))[1])
    AL, GA, AD = mults_iv(la, lb); ALd, GAd, ADd = dmults_iv(la, lb)
    w = k + p - 1; pp = pp_of(p)
    h = 1 - p + GA * k; hd = -pp - GA * k * w + GAd * k
    n = mu_iv - logm1(E) - 1 / k
    B = ul + n / Y; Bd = -ul + (1 - w / k) / Y
    l = h * Y - GA * ul; ld = hd * Y - GAd * ul + GA * ul
    den = GA - Jbar * l
    assert den.lo > 0
    fd = -Jbar * l.sq() / den.sq() * GAd + GA.sq() / den.sq() * ld
    return ALd * B + AL * Bd - fd
