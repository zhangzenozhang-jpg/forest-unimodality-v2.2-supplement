"""Referee verifier for the transport section (independent; written from the text).

Data read from the authors' outputs (data only, no code): the sub-intervals, the parent
pieces, the polygon vertices (exact rationals), the CA pieces and the base intervals.
Every inequality is re-derived and evaluated here in outward-rounded interval arithmetic.

usage: python3 rt_verify.py [--strict]
  --strict : one interval evaluation per check (no subdivision of the curvature / mu-derivative
             enclosures); otherwise the enclosures are refined by bisection when needed
             (still rigorous: the enclosure of a union is the hull of the parts).
"""
import sys, json, os, time
from fractions import Fraction as Fr
from rt_ival import I, iexp, ilog, imin0, imax0
from rt_model import *

OUT = '../two_gen_transport/outputs/'
FILES = ['transport_lower.json', 'transport_upper.json', 'transport_ext_0.json', 'transport_ext_1.json',
         'transport_ext_2.json', 'transport_ext_4.json', 'transport_ext_5.json']
STRICT = '--strict' in sys.argv
if '--mv' in sys.argv:
    import rt_model
    rt_model.MV['on'] = True
LEVELS = [1] if STRICT else ([2] if '--halves' in sys.argv else [1, 2, 4, 8, 16, 32])
LOG = []


def out(s=''):
    print(s)
    LOG.append(s)


def F(x):
    return Fr(x)


def lo(x):
    return Fr(x.lo, 1 << 200)


def hi(x):
    return Fr(x.hi, 1 << 200)


def split(a, b, n):
    return [(a + (b - a) * i / n, a + (b - a) * (i + 1) / n) for i in range(n)]


# ------------------------------------------------------------ two-ended Taylor bound
def two_ended(Y0, Y1, F0, D0, F1, D1, m):
    """min over [Y0,Y1] of max(q0,q1), q0 = F0 + D0 (Y-Y0) + m/2 (Y-Y0)^2,
    q1 = F1 + D1 (Y-Y1) + m/2 (Y-Y1)^2, m <= 0; exact rationals."""
    def q0(Y):
        return F0 + D0 * (Y - Y0) + m / 2 * (Y - Y0) ** 2

    def q1(Y):
        return F1 + D1 * (Y - Y1) + m / 2 * (Y - Y1) ** 2
    cands = [Y0, Y1]
    # q0 - q1 = c0 + c1 Y (affine)
    c1 = D0 - D1 + m / 2 * (-2 * Y0 + 2 * Y1)
    c0 = F0 - F1 - D0 * Y0 + D1 * Y1 + m / 2 * (Y0 ** 2 - Y1 ** 2)
    if c1 != 0:
        Yx = -c0 / c1
        if Y0 < Yx < Y1:
            cands.append(Yx)
    return min(max(q0(Y), q1(Y)) for Y in cands)


def transport_loss(dm, dp, delm, delp):
    return max(delp * max(Fr(0), -dm), delm * max(Fr(0), dp))


def vf_piece(Y0, Y1, la, lb, lc, rho, J, tag, delm, delp):
    """Lower bound of the vertex function `tag` on [Y0,Y1] x [la,lb]; returns (bound, level, beta, dm, dp)."""
    e0 = vf_point(Y0, lc, rho, J)[tag]
    e1 = vf_point(Y1, lc, rho, J)[tag]
    F0, D0, F1, D1 = lo(e0[0]), lo(e0[1]), lo(e1[0]), hi(e1[1])
    best = None
    for lev in LEVELS:
        m = Fr(0)
        for (a, b) in split(Y0, Y1, lev):
            m = min(m, lo(vf_second(a, b, lc, rho, J)[tag]))
        beta = two_ended(Y0, Y1, F0, D0, F1, D1, m)
        dm, dp = None, None
        for (a, b) in split(Y0, Y1, lev):
            for (c, d) in split(la, lb, 1 if lev < 8 else lev // 4):
                e = vf_dmu(a, b, c, d, rho, J)[tag]
                dm = lo(e) if dm is None else min(dm, lo(e))
                dp = hi(e) if dp is None else max(dp, hi(e))
        bound = beta - transport_loss(dm, dp, delm, delp)
        best = (bound, lev, beta, dm, dp, m)
        if bound > 0:
            break
    return best


def ca_piece(Y0, Y1, la, lb, lc, Jbar, delm, delp):
    c = (Y0 + Y1) / 2
    d = (Y1 - Y0) / 2
    C, Cp, den = C_point(c, lc, Jbar)
    best = None
    for lev in LEVELS:
        m = Fr(0)
        for (a, b) in split(Y0, Y1, lev):
            m = min(m, lo(C_second(a, b, lc, Jbar)))
        beta = lo(C) - max(-lo(Cp), hi(Cp)) * d + m / 2 * d * d
        dm, dp = None, None
        for (a, b) in split(Y0, Y1, lev):
            for (cc, dd) in split(la, lb, 1 if lev < 8 else lev // 4):
                e = C_dmu(a, b, cc, dd, Jbar)
                dm = lo(e) if dm is None else min(dm, lo(e))
                dp = hi(e) if dp is None else max(dp, hi(e))
        bound = beta - transport_loss(dm, dp, delm, delp)
        best = (bound, lev, beta, dm, dp, m)
        if bound > 0:
            break
    return best


def Lpos_box(Y0, Y1, la, lb):
    a = act_box(la, lb)
    x = parent_box(Y0, Y1, la, lb)
    h = 1 - x['p'] + a['ga'] * x['k']
    Lp = a['ga'] * x['u'] - h * x['Y']
    return lo(Lp)


# ------------------------------------------------------------ polygon
def lines_from_vertices(V):
    lines = []
    for i in range(3):
        (r0, j0), (r1, j1) = V[i], V[i + 1]
        b = (j1 - j0) / (r1 - r0)
        lines.append((j0 - b * r0, b))
    return lines


def U_of(lines, Jcap, rho):
    return min([a + b * rho for (a, b) in lines] + [Jcap])


def child_taylor_ok(t0, t1, lam, a, b):
    """f = J - b rho <= a on [t0,t1] by the centred second-order bound; returns slack (a - majorant)."""
    c = (t0 + t1) / 2
    d = (t1 - t0) / 2
    s, y, t = child_point(c, lam)
    rho, rho1, rho2, J, J1, J2 = child_derivs(s, y, t)
    fc = J - b * rho
    f1 = J1 - b * rho1
    sb, yb, tb = child_box(t0, t1, lam)
    _, _, rho2b, _, _, J2b = child_derivs(sb, yb, tb)
    f2 = J2b - b * rho2b
    maj = hi(fc) + max(-lo(f1), hi(f1)) * d + max(Fr(0), hi(f2)) / 2 * d * d
    return a - maj


def prove_line(lam, a, b, T, maxdepth=14):
    """Adaptive bisection on [0,T]; returns (number of pieces, least slack) or raises."""
    stack = [(Fr(0), Fr(T), 0)]
    n, least = 0, None
    while stack:
        t0, t1, dep = stack.pop()
        sl = child_taylor_ok(t0, t1, lam, a, b)
        if sl > 0:
            n += 1
            least = sl if least is None else min(least, sl)
        else:
            if dep >= maxdepth:
                raise AssertionError('polygon line fails near t=%s at lam=%s' % (float(t0), lam))
            m = (t0 + t1) / 2
            stack += [(t0, m, dep + 1), (m, t1, dep + 1)]
    return n, least


def seg_cond(a, b, lam):
    """1/a + 1/(1+s_b/2) - 2 + 2 s_a (upper bound); b = None means infinity (s_b = 0)."""
    sa = child_point(a, lam)[0]
    if b is None:
        sbl = I.fr(0)
    else:
        sbl = child_point(b, lam)[0]
    v = 1 / I.fr(a) + 1 / (1 + sbl / 2) - 2 + 2 * sa
    return hi(v)


def J_decreasing_chain(lam, T):
    """Find a chain T=a0<a1<...<ak, [ak,inf) with all segment conditions < 0."""
    chain = [Fr(T)]
    vals = []
    a = Fr(T)
    while True:
        if seg_cond(a, None, lam) < 0:
            vals.append(float(seg_cond(a, None, lam)))
            return chain, vals
        step = Fr(1)
        while step > Fr(1, 2 ** 12):
            if seg_cond(a, a + step, lam) < 0:
                break
            step /= 2
        else:
            return None, None
        vals.append(float(seg_cond(a, a + step, lam)))
        a = a + step
        chain.append(a)
        if len(chain) > 200:
            return None, None


def prove_polygon(lam, V):
    lines = lines_from_vertices(V)
    Jcap = V[3][1]
    # concavity and order
    assert V[0][0] == 0 and lines[0][0] == V[0][1]
    assert lines[0][1] > lines[1][1] > lines[2][1] > 0, 'slopes not decreasing/positive'
    assert all(V[i][0] < V[i + 1][0] for i in range(3))
    assert lines[2][0] + lines[2][1] * V[3][0] == Jcap
    res = {}
    for T in (Fr(3, 2), Fr(13, 8), Fr(7, 4), Fr(2)):
        chain, vals = J_decreasing_chain(lam, T)
        if chain is not None:
            break
    else:
        raise AssertionError('no J-decreasing chain')
    npieces = 0
    least = None
    for (a, b) in lines + [(Jcap, Fr(0))]:
        n, sl = prove_line(lam, a, b, T)
        npieces += n
        least = sl if least is None else min(least, sl)
    return dict(T=T, chain=[str(c) for c in chain], chain_vals=vals, pieces=npieces,
                least=float(least), checks=npieces + len(chain))


# ------------------------------------------------------------ hand bounds
def hand(la, lb, YL, Jbar):
    A_, B_ = act_point(la), act_point(lb)
    ga_a, ga_b, al_a, al_b, AD_a = A_['ga'], B_['ga'], A_['al'], B_['al'], A_['AD']
    lamb = I.fr(lb)
    Jb = I.fr(Jbar)
    res = {}
    # (Z)
    AA = 1 + ga_b
    BB = ga_a / lamb
    zz = AA * (ilog(AA / BB) - 1)
    Zlo = ga_a - Jb * imax0(zz)
    res['Z'] = lo(Zlo)
    # (L) on [0, YL]
    Y0, Y1 = Fr(0), Fr(YL)
    e1 = iexp(I.fr(Y1))
    t = imax0(ilog(I.fr(la)) - ilog(e1 - 1))
    P1a = parent_point(Y1, la)
    hhi = hi(1 - P1a['p'] + ga_b * P1a['k'])
    P0b = parent_point(Y0, lb)
    Nlo = lo(AD_a - I.fr(hhi) - al_b / P0b['k'])
    num = Nlo + lo(al_a * t)
    Ystar = Y1 if num >= 0 else Y0
    assert Ystar > 0, '(L) numerator negative with Y0 = 0'
    Lp_lo = lo(ga_a * iexp(I.fr(Y0)) / lamb) - hhi * Y1
    Qlo = lo(ga_a) + Fr(Jbar) * min(Fr(0), Lp_lo)
    assert Qlo > 0
    Lval = lo(al_a * iexp(I.fr(Y0)) / lamb) + num / Ystar - Fr(Jbar) * hhi ** 2 / Qlo
    res['L'] = Lval
    # (R) on [3, inf)
    turn = ilog((1 + ga_b) * lamb / ga_a)
    assert hi(turn) <= 3
    P3b = parent_point(Fr(3), lb)
    NlR = AD_a - 1 - ga_b - al_b / P3b['k']
    assert hi(NlR) < 0, 'N_lo must be negative for N/Y >= N_lo/3'
    e3 = iexp(I.fr(3))
    QlR = ga_a - Jb * imax0(3 * (1 + ga_b) - ga_a * e3 / lamb)
    QlR = I(min(QlR.lo, ga_a.lo), min(QlR.hi, ga_a.hi))
    assert QlR.lo > 0
    Rval = al_a * e3 / lamb + NlR / 3 - (1 + ga_b).sq() * Jb / QlR
    res['R'] = lo(Rval)
    # (C) L' > 0 on (0,1/500] and [3, inf)
    res['C0'] = lo(ga_a / lamb - (1 + ga_b) / 500)
    res['C3'] = lo(ga_a * e3 / lamb - 3 * (1 + ga_b))
    return res


# ------------------------------------------------------------ base inequality
def S_point(lam):
    a = act_point(lam)
    q, al, ga = a['q'], a['al'], a['ga']
    ell = ilog(1 + I.fr(lam))
    return Fr(6, 5) * q * q - al * ell - ga * q * q / ell


def dS_box(la, lb):
    a = act_box(la, lb)
    q, al, ga, ald, gad = a['q'], a['al'], a['ga'], a['ald'], a['gad']
    ell = I(ilog(1 + I.fr(la)).lo, ilog(1 + I.fr(lb)).hi)
    omq = 1 - q
    return (Fr(12, 5) * q * q * omq - ald * ell - al * q - gad * q * q / ell
            - 2 * ga * q * q * omq / ell + ga * q * q * q / (ell * ell))


def base_check(la, lb):
    lc = (la + lb) / 2
    delm, delp = hi(ilog(I.fr(lc / la))), hi(ilog(I.fr(lb / lc)))
    s = lo(S_point(lc))
    d = dS_box(la, lb)
    return s - transport_loss(lo(d), hi(d), delm, delp), s, float(lo(d)), float(hi(d))


# ------------------------------------------------------------ main
def main():
    t_start = time.time()
    subs = []
    for f in FILES:
        d = json.load(open(os.path.join(OUT, f)))
        for s in d['subintervals']:
            s['_file'] = f
            subs.append(s)
    subs.sort(key=lambda s: F(s['la']))
    out('referee verifier, mode %s%s' % ('STRICT (one evaluation per check)' if STRICT else ('HALVES (hull of the two halves of each parent interval, always)' if '--halves' in sys.argv else 'refined'), ', mean-value forms for L and its derivative in the curvature' if '--mv' in sys.argv else ''))
    out('%d sub-intervals' % len(subs))
    # coverage of the activity range
    assert F(subs[0]['la']) == Fr(11, 20) and F(subs[-1]['lb']) == Fr(263, 200)
    for s0, s1 in zip(subs, subs[1:]):
        assert F(s0['lb']) == F(s1['la']), 'gap between sub-intervals'
    out('activity cover: [11/20, 263/200], %d consecutive closed sub-intervals, no gap: OK' % len(subs))
    total_checks = 0
    least_overall = None
    polys = {}
    summary = []
    fails = []
    for s in subs:
        la, lb, lc, YL, lp = F(s['la']), F(s['lb']), F(s['lc']), F(s['YL']), F(s['lp'])
        assert lc == (la + lb) / 2
        assert lp >= lb
        cut = s['cut']
        assert cut == (la >= Fr(23, 20))
        V = [(F(r), F(j)) for (r, j) in s['vertices']]
        Jbar = F(s['Jbar'])
        assert Jbar == V[3][1]
        lines = lines_from_vertices(V)
        delm, delp = hi(ilog(I.fr(lc / la))), hi(ilog(I.fr(lb / lc)))
        out('--- [%s, %s]  lc=%s  YL=%s  cut=%s  lp=%s  log-width %.4f' % (la, lb, lc, YL, cut, lp, float(delm + delp)))
        # hand bounds
        hb = hand(la, lb, YL, Jbar)
        for key in ('Z', 'L', 'R', 'C0', 'C3'):
            if not hb[key] > 0:
                fails.append((str(la), key, float(hb[key])))
        out('  hand: Z %.5f  L %.4f  R %.4f  C(0,1/500] %.4f  C[3,inf) %.4f' % tuple(float(hb[k]) for k in ('Z', 'L', 'R', 'C0', 'C3')))
        assert s['left'] == [['0', str(YL)]]
        nchk = 5
        least = None
        # core pieces
        nV = 0
        levels_used = {}
        if not cut:
            seen = set()
            for c in s['core']:
                v = c['vertex']
                rho, J = F(c['rho']), F(c['J'])
                assert (rho, J) == V[v], 'vertex data mismatch'
                seen.add((v, c['tag']))
                pcs = [(F(a), F(b)) for (a, b) in c['pieces']]
                assert pcs[0][0] == YL and pcs[-1][1] == 3
                assert all(pcs[i][1] == pcs[i + 1][0] for i in range(len(pcs) - 1))
                for (Y0, Y1) in pcs:
                    r = vf_piece(Y0, Y1, la, lb, lc, rho, J, c['tag'], delm, delp)
                    nV += 1
                    levels_used[r[1]] = levels_used.get(r[1], 0) + 1
                    least = r[0] if least is None else min(least, r[0])
                    if not r[0] > 0:
                        fails.append((str(la), 'V', c['vertex'], c['tag'], str(Y0), str(Y1), float(r[0])))
            assert seen == {(v, t) for v in range(4) for t in ('Phi', 'Phig')}
        else:
            assert len(s['core']) == 1
            core = s['core'][0]
            pcs = [(F(a), F(b)) for (a, b) in core['pieces']]
            assert pcs[0][0] == YL and pcs[-1][1] == 3
            assert all(pcs[i][1] == pcs[i + 1][0] for i in range(len(pcs) - 1))
            bypiece = {}
            for ch in core['checks']:
                bypiece.setdefault((F(ch['Y0']), F(ch['Y1'])), []).append((F(ch['rho']), F(ch['J']), ch['tag']))
            assert set(bypiece) == set(pcs)
            lnla = ilog(I.fr(la))
            for (Y0, Y1) in pcs:
                pts = bypiece[(Y0, Y1)]
                # true cut rho_c(Y1) = max(0, log la - log(e^Y1 - 1))/Y1 (lower end of enclosure)
                rc = imax0(lnla - ilog(iexp(I.fr(Y1)) - 1)) / I.fr(Y1)
                rc_lo = lo(rc)
                rhos = sorted(set((r, j) for (r, j, t) in pts))
                # the cut point: least rho among the listed points
                rcut, jcut = rhos[0]
                assert rcut <= rc_lo or (rc.lo <= 0 and rcut == 0), 'cut rho above the true cut'
                assert jcut >= U_of(lines, V[3][1], rcut), 'cut J below the polygon'
                needed = [vv for vv in V if vv[0] >= rcut]
                for vv in needed:
                    assert vv in rhos, 'missing vertex right of the cut'
                for (r, j) in rhos:
                    assert (r, j) in V or (r, j) == (rcut, jcut)
                tags = {}
                for (r, j, t) in pts:
                    tags.setdefault((r, j), set()).add(t)
                assert all(tags[x] == {'Phi', 'Phig'} for x in tags)
                for (r, j, tag) in pts:
                    rr = vf_piece(Y0, Y1, la, lb, lc, r, j, tag, delm, delp)
                    nV += 1
                    levels_used[rr[1]] = levels_used.get(rr[1], 0) + 1
                    least = rr[0] if least is None else min(least, rr[0])
                    if not rr[0] > 0:
                        fails.append((str(la), 'Vcut', str(Y0), str(Y1), float(r), tag, float(rr[0])))
        # CA pieces
        nCA = 0
        cps = [(F(c['Y0']), F(c['Y1']), c['Lpos']) for c in s['ca']]
        assert cps[0][0] == Fr(1, 500) and cps[-1][1] == 3
        assert all(cps[i][1] == cps[i + 1][0] for i in range(len(cps) - 1))
        leastCA = None
        for (Y0, Y1, Lpos) in cps:
            nCA += 1
            if Lpos:
                v = Lpos_box(Y0, Y1, la, lb)
                if not v > 0:
                    fails.append((str(la), 'Lpos', str(Y0), str(Y1), float(v)))
                leastCA = v if leastCA is None else min(leastCA, v)
            else:
                r = ca_piece(Y0, Y1, la, lb, lc, Jbar, delm, delp)
                levels_used['CA%d' % r[1]] = levels_used.get('CA%d' % r[1], 0) + 1
                least = r[0] if least is None else min(least, r[0])
                leastCA = r[0] if leastCA is None else min(leastCA, r[0])
                if not r[0] > 0:
                    fails.append((str(la), 'CA', str(Y0), str(Y1), float(r[0])))
        nchk += nV + nCA
        total_checks += nchk
        least_overall = least if least_overall is None else min(least_overall, least)
        out('  V %d  CA %d  hand 5  total %d  (json checks %s)  least piece bound %.6f  least CA %.6f  refinement levels %s'
            % (nV, nCA, nchk, s['checks'], float(least), float(leastCA), dict(sorted(levels_used.items(), key=str))))
        summary.append((str(la), str(lb), nV, nCA, float(least)))
        if lp not in polys:
            polys[lp] = V
        else:
            assert polys[lp] == V, 'two different polygons at the same lambda_p'
    out()
    out('polygons: %d distinct lambda_p' % len(polys))
    npoly = 0
    for lp in sorted(polys):
        r = prove_polygon(lp, polys[lp])
        npoly += r['checks']
        out('  lambda_p %s: T=%s, J-decreasing chain %s (conditions %s), %d Taylor pieces (least slack %.2e), %d checks'
            % (lp, r['T'], r['chain'], ['%.4f' % v for v in r['chain_vals']], r['pieces'], r['least'], r['checks']))
    out()
    base_ints = [(Fr(11, 20), Fr(1491, 2000)), (Fr(1491, 2000), Fr(387, 400)), (Fr(387, 400), Fr(461, 400)),
                 (Fr(461, 400), Fr(633, 500)), (Fr(633, 500), Fr(1309, 1000)), (Fr(1309, 1000), Fr(263, 200))]
    assert base_ints[0][0] == Fr(11, 20) and base_ints[-1][1] == Fr(263, 200)
    assert all(base_ints[i][1] == base_ints[i + 1][0] for i in range(5))
    leastbase = None
    for (a, b) in base_ints:
        bnd, s0, dm, dp = base_check(a, b)
        out('  base [%s, %s]: S(centre) >= %.6f, dS/dmu in [%.6f, %.6f], bound %.3e %s' % (a, b, float(s0), dm, dp, float(bnd), 'OK' if bnd > 0 else 'FAIL'))
        if not bnd > 0:
            fails.append(('base', str(a), str(b), float(bnd)))
        leastbase = bnd if leastbase is None else min(leastbase, bnd)
    out()
    out('checks re-verified (my count): non-polygon %d, polygon %d (my own subdivision), base 6' % (total_checks, npoly))
    out('least vertex/CA piece bound after transport: %.3e' % float(least_overall))
    out('least base bound: %.3e' % float(leastbase))
    out('FAILURES: %d %s' % (len(fails), fails))
    out('time %.0f s' % (time.time() - t_start))
    return fails


if __name__ == '__main__':
    f = main()
    name = ('rt_verify_strict' if STRICT else ('rt_verify_halves' if '--halves' in sys.argv else 'rt_verify')) + ('_mv' if '--mv' in sys.argv else '') + '.log'
    open(name, 'w').write('\n'.join(LOG) + '\n')
