"""DIAGNOSTIC: sampled values of Phi'', d/dmu Phi, C'', d/dmu C, and child f'' must lie inside the
referee's interval enclosures on random boxes (soundness census of rt_model.py)."""
import random, math
from fractions import Fraction as Fr
from rt_model import *
random.seed(993)

def fl(lam, Y):
    q=lam/(1+lam); al=0.46*q; ga=lam*(3+lam)/13; AD=1+q/5
    u=math.exp(Y)/lam; p=1/(1+u); y0=math.log(1+1/u); k=p/y0
    return q,al,ga,AD,u,p,y0,k

def Phi(Y, lam, rho, J, tag):
    q,al,ga,AD,u,p,y0,k=fl(lam,Y)
    h=1-p+ga*k; N=AD-h-al/k; Lp=ga*u-h*Y; Q=ga+J*Lp
    return al*u+N/Y+al*rho-(J*h*h/Q if tag=='Phi' else J*h*h/ga)

def Cf(Y, lam, Jb):
    q,al,ga,AD,u,p,y0,k=fl(lam,Y)
    h=1-p+ga*k; l=h*Y-ga*u
    B=u+(math.log(lam)-math.log(math.exp(Y)-1)-1/k)/Y
    return al*B-ga*l/(ga-Jb*l)

bad=0; n=0
for trial in range(300):
    Y0=Fr(random.randint(20,280),100); Y1=Y0+Fr(random.randint(1,40),100)
    la=Fr(random.randint(550,1300),1000); lb=la+Fr(random.randint(1,50),1000)
    rho=Fr(random.randint(0,500),100); J=Fr(random.randint(20,300),1000)
    Jb=Fr(1,5)
    try:
        d2=vf_second(Y0,Y1,la,rho,J); dm=vf_dmu(Y0,Y1,la,lb,rho,J)
        c2=C_second(Y0,Y1,la,Jb); cm=C_dmu(Y0,Y1,la,lb,Jb)
    except ZeroDivisionError:
        continue
    for i in range(20):
        Y=float(Y0)+(float(Y1)-float(Y0))*random.random(); lam=float(la)+(float(lb)-float(la))*random.random()
        h=1e-4
        for tag in ('Phi','Phig'):
            v2=(Phi(Y+h,float(la),float(rho),float(J),tag)-2*Phi(Y,float(la),float(rho),float(J),tag)+Phi(Y-h,float(la),float(rho),float(J),tag))/h/h
            if Y-h>float(Y0) and Y+h<float(Y1):
                n+=1
                if not (d2[tag].flo()-1e-5<=v2<=d2[tag].fhi()+1e-5): bad+=1; print('Phi2',tag,float(Y0),float(Y1),v2,d2[tag])
            e=1e-6
            vm=(Phi(Y,lam*math.exp(e),float(rho),float(J),tag)-Phi(Y,lam*math.exp(-e),float(rho),float(J),tag))/(2*e)
            if lam*math.exp(e)<float(lb) and lam*math.exp(-e)>float(la):
                n+=1
                if not (dm[tag].flo()-1e-6<=vm<=dm[tag].fhi()+1e-6): bad+=1; print('dmu',tag,vm,dm[tag])
        if Y-h>float(Y0) and Y+h<float(Y1):
            v2=(Cf(Y+h,float(la),float(Jb))-2*Cf(Y,float(la),float(Jb))+Cf(Y-h,float(la),float(Jb)))/h/h
            n+=1
            if not (c2.flo()-1e-5<=v2<=c2.fhi()+1e-5): bad+=1; print('C2',v2,c2)
        e=1e-6
        if lam*math.exp(e)<float(lb) and lam*math.exp(-e)>float(la):
            vm=(Cf(Y,lam*math.exp(e),float(Jb))-Cf(Y,lam*math.exp(-e),float(Jb)))/(2*e)
            n+=1
            if not (cm.flo()-1e-6<=vm<=cm.fhi()+1e-6): bad+=1; print('Cdmu',vm,cm)
# child f''
for trial in range(200):
    t0=Fr(random.randint(0,150),100); t1=t0+Fr(random.randint(1,20),100); lam=Fr(random.randint(550,1315),1000); b=Fr(random.randint(0,15),100)
    sb,yb,tb=child_box(t0,t1,lam); r=child_derivs(sb,yb,tb); f2=r[5]-b*r[2]
    for i in range(10):
        t=float(t0)+(float(t1)-float(t0))*random.random(); h=1e-4
        def f(tt):
            x=float(lam)*math.exp(-tt); s=x/(1+x); y=math.log(1+x); rho=tt/y; return s*s*rho-float(b)*rho
        if t-h>float(t0) and t+h<float(t1):
            v=(f(t+h)-2*f(t)+f(t-h))/h/h; n+=1
            if not (f2.flo()-1e-5<=v<=f2.fhi()+1e-5): bad+=1; print('child',v,f2)
print('samples',n,'outside enclosure',bad)
