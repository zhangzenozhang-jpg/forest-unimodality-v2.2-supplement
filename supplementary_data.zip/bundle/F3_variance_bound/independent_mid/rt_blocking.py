"""Task 4: the base inequality above lambda* (rigorous parts) and the descriptive numbers (floats)."""
import math, json
from fractions import Fraction as Fr
from rt_ival import I, ilog, iexp
from rt_model import *
from rt_verify import S_point, dS_box, lo, hi

out = []
def pr(s): print(s); out.append(s)

# 1. root bracket by exact bisection
a, b = Fr(263, 200), Fr(8, 5)
assert lo(S_point(a)) > 0 and hi(S_point(b)) < 0
for _ in range(40):
    m = (a + b) / 2
    s = S_point(m)
    if lo(s) > 0: a = m
    elif hi(s) < 0: b = m
    else: break
pr('base slack S: S(263/200) >= %.3e ; S(13/10) in %s' % (float(lo(S_point(Fr(263, 200)))), S_point(Fr(13, 10))))
pr('root bracket: S > 0 at %.9f, S < 0 at %.9f' % (float(a), float(b)))
# 2. dS/dmu < 0 on [13/10, 4] (so S strictly decreasing there, unique root, S < 0 on (lambda*, 4])
n = 0; worst = None
x = Fr(13, 10)
while x < 4:
    y = min(Fr(4), x + Fr(1, 50))
    d = hi(dS_box(x, y))
    worst = d if worst is None else max(worst, d)
    assert d < 0, (x, y, float(d))
    n += 1; x = y
pr('dS/dmu < 0 on [13/10, 4] (%d exact intervals, largest upper bound %.4f)' % (n, float(worst)))
# 3. lambda >= 4: gamma - (6/5) log(1+lambda) > 0 at 4 and increasing (gamma' >= 11/13 > 6/5 * 1/5)
g4 = I.fr(4) * 7 / 13 - Fr(6, 5) * ilog(I.fr(5))
pr('lambda = 4: gamma - (6/5)log(1+lambda) >= %.4f > 0; for lambda >= 4 it increases, so S <= q^2 (6/5 - gamma/l) < 0' % float(lo(g4)))
# 4. least D at 8/5
lam = I.fr(Fr(8, 5)); q = lam / (1 + lam); al = q * Fr(23, 50); ga = lam * (3 + lam) / 13; l = ilog(1 + lam)
Dmin = (al * l + ga * q * q / l) / (q * q)
pr('least D allowed by the base inequality at 8/5: %s' % Dmin)
for L in (Fr(7, 5), Fr(3, 2)):
    lam = I.fr(L); q = lam / (1 + lam); al = q * Fr(23, 50); ga = lam * (3 + lam) / 13; l = ilog(1 + lam)
    pr('  at %s: %s' % (L, (al * l + ga * q * q / l) / (q * q)))

# ---------------- floats: the no-feasibility minima and the measured derivative
def fl(lam, Y):
    q=lam/(1+lam); al=0.46*q; ga=lam*(3+lam)/13; AD=1+q/5
    u=math.exp(Y)/lam; p=1/(1+u); y0=math.log(1+1/u); k=p/y0
    return q,al,ga,AD,u,p,y0,k
def ACp(Yt, Y, lam):
    q,al,ga,AD,u,p,y0,k=fl(lam,Y)
    x=lam*math.exp(-Yt); s=x/(1+x); y=math.log(1+x); rho=Yt/y; J=s*s*rho
    h=1-p+ga*k; N=AD-h-al/k; Q=ga+J*(ga*u-h*Y)
    return al*u+N/Y+al*rho-J*h*h/Q
for lam in (1.0, 1.28, 1.3):
    best=(9,None); bestf=(9,None)
    for i in range(1,321):
        Y=i*0.01
        for j in range(0,301):
            Yt=j*0.01
            v=ACp(Yt,Y,lam)
            if v<best[0]: best=(v,(Yt,Y))
            if Y>=math.log(1+lam*math.exp(-Yt)) and v<bestf[0]: bestf=(v,(Yt,Y))
    pr('lambda %.2f: min AC/p over all children %.4f at (Yt,Y)=%s; feasible min %.4f at %s' % (lam, best[0], best[1], bestf[0], bestf[1]))
json.dump(out, open('rt_blocking.json', 'w'), indent=1)
open('rt_blocking.log', 'w').write('\n'.join(out) + '\n')
