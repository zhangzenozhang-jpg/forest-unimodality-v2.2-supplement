"""Referee interval arithmetic (independent of the authors' ratlib/ival).

A number is enclosed by I(lo, hi), meaning [lo/2^P, hi/2^P] with integers lo <= hi.
Every operation rounds outward (floor for lo, ceil for hi), so every result is a
rigorous enclosure.  Inputs are exact Fractions.  exp and log of a point are enclosed
by Taylor / atanh series with explicit remainder bounds, at a working precision W > P.
"""
from fractions import Fraction as Fr
from functools import lru_cache

P = 200
W = P + 48


def _ceil_div(n, d):
    return -((-n) // d)


class I:
    __slots__ = ('lo', 'hi')

    def __init__(s, lo, hi):
        if lo > hi:
            raise ValueError('bad interval %r %r' % (lo, hi))
        s.lo = lo
        s.hi = hi

    @staticmethod
    def fr(x):
        x = Fr(x)
        n, d = x.numerator << P, x.denominator
        return I(n // d, _ceil_div(n, d))

    @staticmethod
    def hull(*xs):
        return I(min(x.lo for x in xs), max(x.hi for x in xs))

    @staticmethod
    def span(a, b):
        """[a.lo, b.hi] (caller asserts the order)."""
        return I(a.lo, b.hi)

    def __add__(s, o):
        o = _c(o)
        return I(s.lo + o.lo, s.hi + o.hi)

    __radd__ = __add__

    def __neg__(s):
        return I(-s.hi, -s.lo)

    def __sub__(s, o):
        o = _c(o)
        return I(s.lo - o.hi, s.hi - o.lo)

    def __rsub__(s, o):
        return _c(o) - s

    def __mul__(s, o):
        o = _c(o)
        ps = (s.lo * o.lo, s.lo * o.hi, s.hi * o.lo, s.hi * o.hi)
        return I(min(ps) >> P, -((-max(ps)) >> P))

    __rmul__ = __mul__

    def __truediv__(s, o):
        o = _c(o)
        if o.lo <= 0 <= o.hi:
            raise ZeroDivisionError('interval divisor contains 0')
        los = [(a << P) // b for a in (s.lo, s.hi) for b in (o.lo, o.hi)]
        his = [_ceil_div(a << P, b) for a in (s.lo, s.hi) for b in (o.lo, o.hi)]
        return I(min(los), max(his))

    def __rtruediv__(s, o):
        return _c(o) / s

    def sq(s):
        if s.lo >= 0:
            return s * s
        if s.hi <= 0:
            return (-s) * (-s)
        m = max(-s.lo, s.hi)
        return I(0, -((-(m * m)) >> P))

    def abs_hi(s):
        return max(-s.lo, s.hi)

    def lo_fr(s):
        return Fr(s.lo, 1 << P)

    def hi_fr(s):
        return Fr(s.hi, 1 << P)

    def f(s):
        return (s.lo + s.hi) / 2.0 / 2.0 ** P

    def flo(s):
        return s.lo / 2.0 ** P

    def fhi(s):
        return s.hi / 2.0 ** P

    def pos(s):
        return s.lo > 0

    def __repr__(s):
        return '[%.12g, %.12g]' % (s.flo(), s.fhi())


def _c(x):
    return x if isinstance(x, I) else I.fr(x)


def imin0(x):
    """min(0, x) as an interval."""
    return I(min(x.lo, 0), min(x.hi, 0))


def imax0(x):
    return I(max(x.lo, 0), max(x.hi, 0))


# ---------------------------------------------------------------- exp
@lru_cache(maxsize=None)
def _exp_nonneg_W(x):
    """x >= 0 integer (scaled 2^P).  Returns (lo, hi) at scale 2^W enclosing e^{x/2^P}."""
    k = 0
    while x > (1 << (P - 12 + k)):
        k += 1
    sh = W - P - k
    assert sh >= 0, 'exp argument too large'
    t = x << sh                      # t/2^W = x/2^(P+k) <= 2^-12, exact
    one = 1 << W
    tl = th = one
    slo = shi = one
    n = 1
    while True:
        tl = (tl * t) // (one * n)
        th = _ceil_div(th * t, one * n)
        slo += tl
        shi += th
        n += 1
        if th <= 1:
            break
    shi += th + 1                    # tail <= t^n/n! * e^t/(1-t) < term
    lo, hi = slo, shi
    for _ in range(k):
        lo = (lo * lo) >> W
        hi = -((-(hi * hi)) >> W)
    return lo, hi


def _exp_point(x):
    """(lo, hi) at scale 2^P enclosing e^{x/2^P}."""
    if x >= 0:
        lo, hi = _exp_nonneg_W(x)
    else:
        plo, phi = _exp_nonneg_W(-x)
        lo, hi = (1 << (2 * W)) // phi, _ceil_div(1 << (2 * W), plo)
    return lo >> (W - P), -((-hi) >> (W - P))


def iexp(x):
    x = _c(x)
    return I(_exp_point(x.lo)[0], _exp_point(x.hi)[1])


# ---------------------------------------------------------------- log
def _atanh_W(num, den, upper):
    """Bound of atanh(s), s = num/den with 0 <= s <= 1/4, at scale 2^W; lower or upper."""
    one = 1 << W
    s = (num << W) // den if not upper else _ceil_div(num << W, den)
    s2 = (s * s) >> W if not upper else _ceil_div(s * s, one)
    pw = s
    tot = 0
    j = 0
    while True:
        tot += (pw // (2 * j + 1)) if not upper else _ceil_div(pw, 2 * j + 1)
        pw = (pw * s2) >> W if not upper else _ceil_div(pw * s2, one)
        j += 1
        if pw <= 1:
            break
    if upper:
        tot += 2 * pw + 2               # tail <= pw/((2j+1)(1-s^2)) <= 2 pw
    return tot


_LN2 = None


def _ln2_W():
    global _LN2
    if _LN2 is None:
        _LN2 = (2 * _atanh_W(1, 3, False) - 0, 2 * _atanh_W(1, 3, True))
        # atanh(1/3) = (1/2) ln 2 ; s = 1/3 > 1/4 but the series still converges with
        # tail <= pw/((2j+1)(1-1/9)) <= 2 pw, so the bound above stays valid.
    return _LN2


@lru_cache(maxsize=None)
def _log_point_W(z, upper):
    """z > 0 integer scaled 2^P.  Bound of log(z/2^P) at scale 2^W."""
    assert z > 0
    Z = z << (W - P)
    e = Z.bit_length() - W - 1          # m = Z/2^(W+e) in [1, 2)
    base = W + e
    assert base >= 0
    if 3 * Z >= 4 * (1 << base):         # m >= 4/3: halve, m in [2/3, 1)
        e += 1
        base += 1
    B = 1 << base
    num, den = Z - B, Z + B               # s = (m-1)/(m+1), |s| <= 1/5
    ln2lo, ln2hi = _ln2_W()
    if num >= 0:
        a = 2 * _atanh_W(num, den, upper)
    else:
        a = -2 * _atanh_W(-num, den, not upper)
    if upper:
        return a + (e * ln2hi if e >= 0 else e * ln2lo)
    return a + (e * ln2lo if e >= 0 else e * ln2hi)


def ilog(x):
    x = _c(x)
    if x.lo <= 0:
        raise ValueError('log of nonpositive interval')
    lo = _log_point_W(x.lo, False) >> (W - P)
    hi = -((-_log_point_W(x.hi, True)) >> (W - P))
    return I(lo, hi)


def selftest():
    import math
    for v in [Fr(1, 3), Fr(-7, 5), Fr(3), Fr(-3), Fr(1, 500), Fr(263, 200), Fr(0)]:
        e = iexp(v)
        assert e.flo() <= math.exp(v) <= e.fhi() or abs(e.f() - math.exp(v)) < 1e-15, v
        assert e.hi - e.lo < 2 ** 30, (v, e.hi - e.lo)
    for v in [Fr(1, 3), Fr(11, 20), Fr(263, 200), Fr(5), Fr(1, 500), Fr(2), Fr(1)]:
        l = ilog(I.fr(v))
        assert abs(l.f() - math.log(v)) < 1e-14, (v, l)
        assert l.hi - l.lo < 2 ** 30
        # round trip e^{log v} contains v
        r = iexp(l)
        assert r.lo <= I.fr(v).lo and r.hi >= I.fr(v).hi, v
    l2 = ilog(I.fr(2))
    assert abs(l2.f() - math.log(2)) < 1e-15
    x = ilog(I.fr(1))
    assert x.lo <= 0 <= x.hi
    return True


if __name__ == '__main__':
    print('selftest', selftest())
