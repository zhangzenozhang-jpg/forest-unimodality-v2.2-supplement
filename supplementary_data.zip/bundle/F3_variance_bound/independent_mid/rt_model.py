"""Referee model of the transport section, written from the text (not from the authors' code).

Activity lambda, mu = log lambda, q = lambda/(1+lambda), alpha = 23q/50,
gamma = lambda(3+lambda)/13, A_D = 1 + q/5.  Parent of log-mass Y: u = e^Y/lambda,
p = 1/(1+u), y0 = log(1+1/u), k = p/y0, w = k+p-1, h = 1-p+gamma k, N = A_D-h-alpha/k,
L' = gamma u - hY, Q = gamma + J L'.  Child: s = msg(t), y = lm(t), rho = t/y, J = s^2 rho.
"""
from fractions import Fraction as Fr
from rt_ival import I, iexp, ilog, imin0, imax0

A23 = Fr(23, 50)


# ------------------------------------------------------------ multipliers
def act_point(lam):
    L = I.fr(lam)
    q = L / (1 + L)
    qq = L / ((1 + L) * (1 + L))
    return dict(lam=L, mu=ilog(L), q=q, al=q * A23, ga=L * (3 + L) / 13, AD=1 + q / 5,
                qq=qq, ald=qq * A23, gad=L * (3 + 2 * L) / 13, ADd=qq / 5)


def act_box(la, lb):
    """Enclosures on [la, lb] by monotonicity: lam, mu, q, alpha, gamma, A_D, gamma-dot increase;
    q(1-q) = lam/(1+lam)^2 increases for lam <= 1 and decreases for lam >= 1."""
    a, b = act_point(la), act_point(lb)
    d = {}
    for key in ('lam', 'mu', 'q', 'al', 'ga', 'AD', 'gad'):
        d[key] = I(a[key].lo, b[key].hi)
    if lb <= 1:
        qq = I(a['qq'].lo, b['qq'].hi)
    elif la >= 1:
        qq = I(b['qq'].lo, a['qq'].hi)
    else:
        qq = I(min(a['qq'].lo, b['qq'].lo), I.fr(Fr(1, 4)).hi)
    d['qq'] = qq
    d['ald'] = qq * A23
    d['ADd'] = qq / 5
    return d


# ------------------------------------------------------------ parent primitives
def parent_point(Y, lam):
    eY = iexp(I.fr(Y))
    L = I.fr(lam)
    u = eY / L
    p = L / (L + eY)
    y0 = ilog(1 + L / eY)
    k = p / y0
    w = k + p - 1
    pq = p * (1 - p)
    return dict(u=u, p=p, y0=y0, k=k, w=w, pq=pq, eY=eY, Y=I.fr(Y))


def pq_encl(p):
    """Enclosure of p(1-p) for p in the interval p (monotone pieces around 1/2)."""
    half = I.fr(Fr(1, 2))
    plo = I(p.lo, p.lo)
    phi = I(p.hi, p.hi)
    vlo = plo * (1 - plo)
    vhi = phi * (1 - phi)
    if p.hi <= half.lo:
        return I(vlo.lo, vhi.hi)
    if p.lo >= half.hi:
        return I(vhi.lo, vlo.hi)
    return I(min(vlo.lo, vhi.lo), I.fr(Fr(1, 4)).hi)


def parent_box(Y0, Y1, la, lb):
    """Primitives on [Y0,Y1] x [la,lb].  u, k increase and p, y0, w decrease in x = Y - mu
    (w decreases in x wherever p < 0.8335; asserted), so each is enclosed by the corners
    (Y0, lb) [least x] and (Y1, la) [largest x]."""
    A = parent_point(Y0, lb)
    B = parent_point(Y1, la)
    assert A['p'].fhi() < 0.83, 'w monotonicity region'
    p = I(B['p'].lo, A['p'].hi)
    return dict(u=I(A['u'].lo, B['u'].hi), p=p, y0=I(B['y0'].lo, A['y0'].hi),
                k=I(A['k'].lo, B['k'].hi), w=I(B['w'].lo, A['w'].hi), pq=pq_encl(p),
                eY=I(A['eY'].lo, B['eY'].hi), Y=I(I.fr(Y0).lo, I.fr(Y1).hi))


# ------------------------------------------------------------ vertex functions
def vf_point(Y, lam, rho, J, gam_only=False):
    """Phi, Phi', Phig, Phig' at a point (exact Y, lam), fixed child (rho, J)."""
    a = act_point(lam)
    x = parent_point(Y, lam)
    al, ga, AD = a['al'], a['ga'], a['AD']
    u, p, k, w, pq, Yi = x['u'], x['p'], x['k'], x['w'], x['pq'], x['Y']
    R, Jj = I.fr(rho), I.fr(J)
    h = 1 - p + ga * k
    N = AD - h - al / k
    hp = pq + ga * k * w
    Np = -hp + al * w / k
    Lp = ga * u - h * Yi
    Q = ga + Jj * Lp
    R1 = ga * u - h - hp * Yi
    base = al * u + N / Yi + al * R
    basep = al * u + Np / Yi - N / (Yi * Yi)
    Phi = base - Jj * h * h / Q
    Phip = basep - Jj * (2 * h * hp / Q - h * h * Jj * R1 / (Q * Q))
    Phig = base - Jj * h * h / ga
    Phigp = basep - Jj * 2 * h * hp / ga
    return dict(Phi=(Phi, Phip), Phig=(Phig, Phigp))


MV = {'on': False}


def _meet(a, b):
    lo_, hi_ = max(a.lo, b.lo), min(a.hi, b.hi)
    assert lo_ <= hi_
    return I(lo_, hi_)


def _mv_LR(Y0, Y1, lam, ga, hp_box, hpp_box, u_box, h_box, Y_box):
    """mean-value forms L'(c) + R1[piece][-d,d] and R1(c) + R2[piece][-d,d]."""
    c = (Y0 + Y1) / 2
    d = I.fr((Y1 - Y0) / 2)
    x = parent_point(c, lam)
    hc = 1 - x['p'] + ga * x['k']
    hpc = x['pq'] + ga * x['k'] * x['w']
    Lc = ga * x['u'] - hc * x['Y']
    R1c = ga * x['u'] - hc - hpc * x['Y']
    R1b = ga * u_box - h_box - hp_box * Y_box
    R2b = ga * u_box - 2 * hp_box - hpp_box * Y_box
    dd = I(-d.hi, d.hi)
    return Lc + R1b * dd, R1c + R2b * dd


def vf_second(Y0, Y1, lam, rho, J):
    """Interval enclosure of Phi'' and Phig'' on [Y0,Y1] at fixed lam (formula of the arc lemma)."""
    a = act_point(lam)
    x = parent_box(Y0, Y1, lam, lam)
    al, ga, AD = a['al'], a['ga'], a['AD']
    u, p, k, w, pq, Yi = x['u'], x['p'], x['k'], x['w'], x['pq'], x['Y']
    Jj = I.fr(J)
    h = 1 - p + ga * k
    N = AD - h - al / k
    hp = pq + ga * k * w
    hpp = -pq * (1 - 2 * p) + ga * k * (w * w + k * w - pq)
    Np = -hp + al * w / k
    Npp = -hpp + al * (w - pq / k - w * w / k)
    NY2 = (Npp * Yi * Yi - 2 * Np * Yi + 2 * N) / (Yi * Yi * Yi)
    Lp = ga * u - h * Yi
    Q = ga + Jj * Lp
    R1 = ga * u - h - hp * Yi
    R2 = ga * u - 2 * hp - hpp * Yi
    if MV['on']:
        Lm, R1m = _mv_LR(Y0, Y1, lam, ga, hp, hpp, u, h, Yi)
        Lp = _meet(Lp, Lm)
        R1 = _meet(R1, R1m)
        Q = ga + Jj * Lp
    r = Jj / Q
    a1 = 2 * hp * hp + 2 * h * hpp
    a2 = -4 * h * hp * R1 - h * h * R2
    a3 = 2 * h * h * R1 * R1
    Phi2 = al * u + NY2 - (a1 * r + a2 * r * r + a3 * r * r * r)
    Phig2 = al * u + NY2 - Jj * a1 / ga
    return dict(Phi=Phi2, Phig=Phig2)


def vf_dmu(Y0, Y1, la, lb, rho, J):
    """Enclosure of d/dmu Phi and d/dmu Phig at fixed (Y, rho, J) on [Y0,Y1] x [la,lb]
    (formulas of the mu-derivative lemma)."""
    a = act_box(la, lb)
    x = parent_box(Y0, Y1, la, lb)
    al, ga, AD, ald, gad, ADd = a['al'], a['ga'], a['AD'], a['ald'], a['gad'], a['ADd']
    u, p, k, w, pq, Yi = x['u'], x['p'], x['k'], x['w'], x['pq'], x['Y']
    R, Jj = I.fr(rho), I.fr(J)
    h = 1 - p + ga * k
    hd = -pq - ga * k * w + gad * k
    Nd = ADd - hd - ald / k - al * w / k
    Lp = ga * u - h * Yi
    Q = ga + Jj * Lp
    Qd = gad + Jj * (gad * u - ga * u - hd * Yi)
    common = (ald - al) * u + Nd / Yi + ald * R
    dPhi = common - Jj * (2 * h * hd * Q - h * h * Qd) / (Q * Q)
    dPhig = common - Jj * (2 * h * hd / ga - h * h * gad / (ga * ga))
    return dict(Phi=dPhi, Phig=dPhig)


# ------------------------------------------------------------ CA function C
def C_point(Y, lam, Jbar):
    a = act_point(lam)
    x = parent_point(Y, lam)
    al, ga, mu = a['al'], a['ga'], a['mu']
    u, p, k, w, pq, Yi, eY = x['u'], x['p'], x['k'], x['w'], x['pq'], x['Y'], x['eY']
    Jb = I.fr(Jbar)
    h = 1 - p + ga * k
    hp = pq + ga * k * w
    l = h * Yi - ga * u
    lp = h + hp * Yi - ga * u
    g = mu - ilog(eY - 1) - 1 / k
    gp = -eY / (eY - 1) + w / k
    B = u + g / Yi
    Bp = u + gp / Yi - g / (Yi * Yi)
    den = ga - Jb * l
    C = al * B - ga * l / den
    Cp = al * Bp - ga * ga * lp / (den * den)
    return C, Cp, den


def C_second(Y0, Y1, lam, Jbar):
    a = act_point(lam)
    x = parent_box(Y0, Y1, lam, lam)
    al, ga, mu = a['al'], a['ga'], a['mu']
    u, p, k, w, pq, Yi, eY = x['u'], x['p'], x['k'], x['w'], x['pq'], x['Y'], x['eY']
    Jb = I.fr(Jbar)
    h = 1 - p + ga * k
    hp = pq + ga * k * w
    hpp = -pq * (1 - 2 * p) + ga * k * (w * w + k * w - pq)
    l = h * Yi - ga * u
    lp = h + hp * Yi - ga * u
    lpp = 2 * hp + hpp * Yi - ga * u
    if MV['on']:
        Lm, R1m = _mv_LR(Y0, Y1, lam, ga, hp, hpp, u, h, Yi)
        l = _meet(l, -Lm)
        lp = _meet(lp, -R1m)
    em1 = eY - 1
    g = mu - ilog(em1) - 1 / k
    gp = -eY / em1 + w / k
    gpp = eY / (em1 * em1) + (k * w - pq - w * w) / k
    Bpp = u + gpp / Yi - 2 * gp / (Yi * Yi) + 2 * g / (Yi * Yi * Yi)
    den = ga - Jb * l
    if den.lo <= 0:
        raise ZeroDivisionError('gamma - Jbar l not positive')
    fpp = ga * ga * (lpp / (den * den) + 2 * Jb * lp.sq() / (den * den * den))
    return al * Bpp - fpp


def C_dmu(Y0, Y1, la, lb, Jbar):
    a = act_box(la, lb)
    x = parent_box(Y0, Y1, la, lb)
    al, ga, ald, gad, mu = a['al'], a['ga'], a['ald'], a['gad'], a['mu']
    u, p, k, w, pq, Yi, eY = x['u'], x['p'], x['k'], x['w'], x['pq'], x['Y'], x['eY']
    Jb = I.fr(Jbar)
    h = 1 - p + ga * k
    hd = -pq - ga * k * w + gad * k
    l = h * Yi - ga * u
    B = u + (mu - ilog(eY - 1) - 1 / k) / Yi
    den = ga - Jb * l
    if den.lo <= 0:
        raise ZeroDivisionError('gamma - Jbar l not positive (box)')
    return (ald * B + al * (-u + (1 - w / k) / Yi)
            + (gad * Jb * l.sq() - ga * ga * (hd * Yi - gad * u + ga * u)) / (den * den))


# ------------------------------------------------------------ child curve
def child_point(t, lam):
    """s, y, rho, J and first two t-derivatives at exact t >= 0."""
    L = I.fr(lam)
    tt = I.fr(t)
    e = iexp(-tt)
    xx = L * e
    s = xx / (1 + xx)
    y = ilog(1 + xx)
    return s, y, tt


def child_derivs(s, y, t):
    """rho, J and derivatives from interval s, y, t (s' = -s(1-s), y' = -s)."""
    rho = t / y
    rho1 = 1 / y + t * s / (y * y)
    rho2 = (2 * s - t * s * (1 - s)) / (y * y) + 2 * t * s * s / (y * y * y)
    s2 = s * s
    s2_1 = -2 * s2 * (1 - s)
    s2_2 = s2 * (1 - s) * (4 - 6 * s)
    J = s2 * rho
    J1 = s2_1 * rho + s2 * rho1
    J2 = s2_2 * rho + 2 * s2_1 * rho1 + s2 * rho2
    return rho, rho1, rho2, J, J1, J2


def child_box(t0, t1, lam):
    """Enclosures of s, y, t on [t0, t1] (s and y decrease in t)."""
    s0, y0, _ = child_point(t0, lam)
    s1, y1, _ = child_point(t1, lam)
    return I(s1.lo, s0.hi), I(y1.lo, y0.hi), I(I.fr(t0).lo, I.fr(t1).hi)
