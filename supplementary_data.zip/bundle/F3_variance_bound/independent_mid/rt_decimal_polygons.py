"""Proposal for MF4: six-decimal polygon constants for the 19 activities lambda_p, proved on the child
curve and re-run through every vertex-function, hand and CA check of the section with the authors' pieces."""
import json, math, sys
from fractions import Fraction as Fr
import rt_verify as R
from rt_ival import I, ilog, iexp, imax0
from rt_model import *

E6 = Fr(1, 10**6)
def ceil6(x): return Fr(math.ceil(x * 10**6), 10**6)
def floor6(x): return Fr(math.floor(x * 10**6), 10**6)
def near6(x): return Fr(round(x * 10**6), 10**6)

subs = []
for f in R.FILES:
    for s in json.load(open(R.OUT + f))['subintervals']:
        subs.append(s)
subs.sort(key=lambda s: Fr(s['la']))
polys = {}
for s in subs:
    polys[Fr(s['lp'])] = [(Fr(r), Fr(j)) for r, j in s['vertices']]

newpoly = {}
out = []
for lp in sorted(polys):
    V = polys[lp]
    lines = R.lines_from_vertices(V)
    Jcap = V[3][1]
    T = Fr(3, 2) if lp < Fr(5, 4) else Fr(13, 8)
    dec = []
    for (a, b) in lines:
        b2 = near6(b)
        a2 = ceil6(a)
        while True:
            try:
                R.prove_line(lp, a2, b2, T, maxdepth=12)
                break
            except AssertionError:
                a2 += E6
        dec.append((a2, b2))
    J2 = ceil6(Jcap)
    R.prove_line(lp, J2, Fr(0), T, maxdepth=12)
    chain, vals = R.J_decreasing_chain(lp, T)
    assert chain is not None
    # vertices of the new polygon
    (a0, b0), (a1, b1), (a2_, b2_) = dec
    assert b0 > b1 > b2_ > 0
    r1 = (a1 - a0) / (b0 - b1); r2 = (a2_ - a1) / (b1 - b2_); r3 = (J2 - a2_) / b2_
    assert 0 < r1 < r2 < r3
    NV = [(Fr(0), a0), (r1, a0 + b0 * r1), (r2, a1 + b1 * r2), (r3, J2)]
    newpoly[lp] = (dec, J2, NV)
    s_ = 'lambda_p %-8s a0 %.6f b0 %.6f  a1 %.6f b1 %.6f  a2 %.6f b2 %.6f  Jcap %.6f   vertices %s' % (
        lp, a0, b0, a1, b1, a2_, b2_, J2, ['(%.4f, %.4f)' % (float(r), float(j)) for r, j in NV])
    print(s_); out.append(s_)

# re-run the step checks with the decimal polygons and the authors' parent pieces
fails = []
least = None
for s in subs:
    la, lb, lc, YL, lp = Fr(s['la']), Fr(s['lb']), Fr(s['lc']), Fr(s['YL']), Fr(s['lp'])
    dec, J2, NV = newpoly[lp]
    delm, delp = R.hi(ilog(I.fr(lc / la))), R.hi(ilog(I.fr(lb / lc)))
    hb = R.hand(la, lb, YL, J2)
    for k in ('Z', 'L', 'R', 'C0', 'C3'):
        if not hb[k] > 0: fails.append((str(la), k))
    def U(r): return min([a + b * r for a, b in dec] + [J2])
    if not s['cut']:
        for c in s['core']:
            rho, J = NV[c['vertex']]
            for (Y0, Y1) in c['pieces']:
                r = R.vf_piece(Fr(Y0), Fr(Y1), la, lb, lc, rho, J, c['tag'], delm, delp)
                least = r[0] if least is None else min(least, r[0])
                if not r[0] > 0: fails.append((str(la), c['vertex'], c['tag'], Y0, Y1, float(r[0])))
    else:
        lnla = ilog(I.fr(la))
        for (Y0, Y1) in s['core'][0]['pieces']:
            Y0, Y1 = Fr(Y0), Fr(Y1)
            rc = imax0(lnla - ilog(iexp(I.fr(Y1)) - 1)) / I.fr(Y1)
            rcut = max(Fr(0), floor6(R.lo(rc)))
            pts = [v for v in NV if v[0] >= rcut] + ([(rcut, U(rcut))] if rcut > 0 else [])
            for (rho, J) in pts:
                for tag in ('Phi', 'Phig'):
                    r = R.vf_piece(Y0, Y1, la, lb, lc, rho, J, tag, delm, delp)
                    least = r[0] if least is None else min(least, r[0])
                    if not r[0] > 0: fails.append((str(la), 'cut', str(Y0), float(rho), tag, float(r[0])))
    for c in s['ca']:
        Y0, Y1 = Fr(c['Y0']), Fr(c['Y1'])
        if c['Lpos']:
            if not R.Lpos_box(Y0, Y1, la, lb) > 0: fails.append((str(la), 'Lpos', str(Y0)))
        else:
            r = R.ca_piece(Y0, Y1, la, lb, lc, J2, delm, delp)
            least = r[0] if least is None else min(least, r[0])
            if not r[0] > 0: fails.append((str(la), 'CA', str(Y0), float(r[0])))
s_ = 'with the six-decimal polygons and the authors\' parent pieces: failures %d %s; least bound %.3e' % (len(fails), fails[:10], float(least))
print(s_); out.append(s_)
open('rt_decimal_polygons.log', 'w').write('\n'.join(out) + '\n')
