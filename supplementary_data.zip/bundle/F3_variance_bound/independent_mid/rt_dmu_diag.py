"""DIAGNOSTIC: the measured mu-derivative at the minimiser of Phi(.; v1) (paragraph 'The derivative bound, measured')."""
import json, math
from fractions import Fraction as Fr
from rt_model import *
V = {}
for f in ['transport_lower.json','transport_upper.json','transport_ext_0.json','transport_ext_1.json','transport_ext_2.json','transport_ext_4.json','transport_ext_5.json']:
    for s in json.load(open('../two_gen_transport/outputs/'+f))['subintervals']:
        V[Fr(s['lp'])] = [(Fr(r), Fr(j)) for r, j in s['vertices']]
out = []
for lam in (Fr(3,5), Fr(1), Fr(13,10)):
    rho, J = V[lam][1]
    best = None
    for i in range(200, 2000):
        Y = Fr(i, 1000)
        v = vf_point(Y, lam, rho, J)['Phi'][0].f()
        if best is None or v < best[0]: best = (v, Y)
    Ys = best[1]
    d = vf_dmu(Ys, Ys, lam, lam, rho, J)['Phi'].f()
    e = vf_dmu(Ys - Fr(1,20), Ys + Fr(1,20), lam - Fr(1,40), lam + Fr(1,40), rho, J)['Phi']
    e2 = None
    for (a,b) in [(Ys - Fr(1,20) + Fr(i,100), Ys - Fr(1,20) + Fr(i+1,100)) for i in range(10)]:
        for (c,dd) in [(lam - Fr(1,40) + Fr(i,200), lam - Fr(1,40) + Fr(i+1,200)) for i in range(10)]:
            x = vf_dmu(a,b,c,dd,rho,J)['Phi']
            e2 = (x.flo(), x.fhi()) if e2 is None else (min(e2[0],x.flo()), max(e2[1],x.fhi()))
    s = 'lambda %s: v1=(%.4f,%.4f), argmin Y* ~ %.3f, min Phi %.4f, d_mu Phi(Y*) = %.3f; one-box enclosure on [Y*+-1/20]x[lam+-1/40] = %s; 100-box hull [%.3f, %.3f]' % (lam, float(rho), float(J), float(Ys), best[0], d, e, e2[0], e2[1])
    print(s); out.append(s)
open('rt_dmu_diag.log','w').write('\n'.join(out)+'\n')
