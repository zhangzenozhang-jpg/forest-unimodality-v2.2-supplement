"""DIAGNOSTIC: finite-difference consistency of the referee's formulas (rt_model.py)."""
from fractions import Fraction as Fr
from rt_model import *
import math

def Phi_val(Y, lam, rho, J, tag):
    return vf_point(Y, lam, rho, J)[tag][0].f()

worst = 0.0
pts = [(Fr(3,10), Fr(7,10)), (Fr(9,10), Fr(1)), (Fr(2), Fr(13,10)), (Fr(1,4), Fr(263,200)), (Fr(13,5), Fr(11,20))]
verts = [(Fr(0), Fr(3,100)), (Fr(87,100), Fr(145,1000)), (Fr(2), Fr(21,100)), (Fr(4), Fr(26,100))]
hY = Fr(1, 10**6)
for (Y, lam) in pts:
    for (rho, J) in verts:
        for tag in ('Phi', 'Phig'):
            # d/dY
            fd = (Phi_val(Y + hY, lam, rho, J, tag) - Phi_val(Y - hY, lam, rho, J, tag)) / (2e-6)
            an = vf_point(Y, lam, rho, J)[tag][1].f()
            worst = max(worst, abs(fd - an))
            # second derivative: compare interval on tiny piece with FD of first derivative
            d1p = vf_point(Y + hY, lam, rho, J)[tag][1].f(); d1m = vf_point(Y - hY, lam, rho, J)[tag][1].f()
            fd2 = (d1p - d1m) / 2e-6
            an2 = vf_second(Y - Fr(1,10**7), Y + Fr(1,10**7), lam, rho, J)[tag].f()
            worst = max(worst, abs(fd2 - an2) / 10)
            # d/dmu at fixed Y: lam -> lam*e^{eps}
            eps = 1e-6
            lp = Fr(float(lam) * math.exp(eps)).limit_denominator(10**12); lm = Fr(float(lam) * math.exp(-eps)).limit_denominator(10**12)
            fdm = (Phi_val(Y, lp, rho, J, tag) - Phi_val(Y, lm, rho, J, tag)) / (math.log(lp) - math.log(lm))
            anm = vf_dmu(Y, Y, lam, lam, rho, J)[tag].f()
            worst = max(worst, abs(fdm - anm))
            print('Y=%s lam=%s v=(%s,%s) %s  dY %.3e  d2Y %.3e  dmu %.3e' % (Y, lam, float(rho), float(J), tag, fd - an, fd2 - an2, fdm - anm))
    Jb = Fr(27, 100)
    c0 = C_point(Y, lam, Jb)
    fd = (C_point(Y + hY, lam, Jb)[0].f() - C_point(Y - hY, lam, Jb)[0].f()) / 2e-6
    fd2 = (C_point(Y + hY, lam, Jb)[1].f() - C_point(Y - hY, lam, Jb)[1].f()) / 2e-6
    an2 = C_second(Y - Fr(1,10**7), Y + Fr(1,10**7), lam, Jb).f()
    eps = 1e-6
    lp = Fr(float(lam) * math.exp(eps)).limit_denominator(10**12); lm = Fr(float(lam) * math.exp(-eps)).limit_denominator(10**12)
    fdm = (C_point(Y, lp, Jb)[0].f() - C_point(Y, lm, Jb)[0].f()) / (math.log(lp) - math.log(lm))
    anm = C_dmu(Y, Y, lam, lam, Jb).f()
    print('C  Y=%s lam=%s  dY %.3e d2Y %.3e dmu %.3e' % (Y, lam, fd - c0[1].f(), fd2 - an2, fdm - anm))
    worst = max(worst, abs(fd - c0[1].f()), abs(fd2 - an2) / 10, abs(fdm - anm))
# child derivatives
for lam in (Fr(11,20), Fr(263,200)):
    for t in (Fr(0), Fr(3,10), Fr(1), Fr(3,2)):
        def JR(tt):
            s, y, T = child_point(tt, lam); r = child_derivs(s, y, T); return [z.f() for z in r]
        a = JR(t); b = JR(t + hY); c = JR(t - hY) if t > 0 else JR(t)
        den = 2e-6 if t > 0 else 1e-6
        print('child lam=%s t=%s  rho1 %.2e rho2 %.2e J1 %.2e J2 %.2e' % (lam, t, (b[0]-c[0])/den - a[1], (b[1]-c[1])/den - a[2], (b[3]-c[3])/den - a[4], (b[4]-c[4])/den - a[5]))
print('worst |formula - FD| (second derivatives scaled by 1/10):', worst)
