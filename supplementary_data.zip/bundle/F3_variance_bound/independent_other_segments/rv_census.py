"""rv_census.py -- DIAGNOSTIC: the comparisons of Appendix B (Definition apB:def:cert, beta = 0) evaluated directly from
their definitions (E, H, L, J, Z, CC, CA, AC) at random and grid feasible pairs, with the curve's multipliers; plus the
coverage of [1/3, 7/3] by the sub-intervals of Table mc:tab:sub; plus a float check of the d_mu S enclosure.
"""
import math
import random
from fractions import Fraction as Fr

PAR = {'lo': (0.44, 10.5, 1.2), 'u1': (0.45, 11.5, 1.4), 'u2': (0.47, 10.75, 1.6), 'u3': (0.5, 10.25, 1.8),
       'u4': (0.57, 9.75, 2.1), 'mid': (0.46, 13.0, 1.2)}
SEG = {'lo': (1 / 3, 11 / 20), 'mid': (11 / 20, 263 / 200), 'u1': (263 / 200, 1.5), 'u2': (1.5, 1.75), 'u3': (1.75, 2.0),
       'u4': (2.0, 7 / 3)}


def comps(lam, par, Yt, Y):
    a, g, D = par
    q = lam / (1 + lam)
    al, ga, AD = a * q, lam * (3 + lam) / g, 1 + (D - 1) * q
    msg = lambda z: lam * math.exp(-z) / (1 + lam * math.exp(-z))
    lm = lambda z: math.log1p(lam * math.exp(-z))
    p, y0 = msg(Y), lm(Y)
    pt, y = msg(Yt), lm(Yt)
    E = 1 - p + p * Yt / y - y0 / Y
    H = p * (1 - p) + ga * p * p / y0
    L = ga * (1 - p) - H * Y
    J = pt * pt * Yt / y
    Z = p * ga + L * J
    CC = al * E
    CA = al * E + p * ga * L * (pt / y) ** 2 / Z
    AC = al * E + (AD * p - H) / Y - H * H * J / Z
    return p, Z, CC, CA, AC, L


def run(seed=7, n=40000):
    random.seed(seed)
    out = {}
    for s, (l0, l1) in SEG.items():
        par = PAR[s]
        worst = dict(Zp=1e9, ACp=1e9, CAp=1e9)
        for i in range(n):
            lam = l0 + (l1 - l0) * (random.random() if i % 10 else (i // 10 % 2))
            Yt = random.choice([random.random() * 0.5, random.random() * 3, random.expovariate(0.4)])
            lmin = math.log1p(lam * math.exp(-Yt))
            Y = lmin + random.choice([random.random() * 0.3, random.random() * 2, random.expovariate(0.5), 0.0])
            if Y <= 0:
                continue
            p, Z, CC, CA, AC, L = comps(lam, par, Yt, Y)
            worst['Zp'] = min(worst['Zp'], Z / p)
            worst['ACp'] = min(worst['ACp'], AC / p)
            if L < 0:
                worst['CAp'] = min(worst['CAp'], CA / p)
        out[s] = worst
    return out


def coverage():
    import rv_verify as R
    rows = sorted(((Fr(a), Fr(b), s) for a, b, s, *_ in R.TEXT_SUB))
    segs = {}
    for a, b, s in rows:
        segs.setdefault(s, []).append((a, b))
    msgs = []
    for s, L in segs.items():
        lo, hi = R.TEXT_SEG[s]
        ok = L[0][0] == lo and L[-1][1] == hi and all(L[i][1] == L[i + 1][0] for i in range(len(L) - 1))
        msgs.append('%s: %d sub-intervals cover [%s, %s]: %s' % (s, len(L), lo, hi, ok))
    # segments tile [1/3, 7/3] with mid = [11/20, 263/200]
    order = [(Fr(1, 3), Fr(11, 20)), (Fr(11, 20), Fr(263, 200)), (Fr(263, 200), Fr(3, 2)), (Fr(3, 2), Fr(7, 4)),
             (Fr(7, 4), Fr(2)), (Fr(2), Fr(7, 3))]
    msgs.append('segments tile [1/3, 7/3]: %s' % all(order[i][1] == order[i + 1][0] for i in range(5)))
    return msgs


def dS_float(par, la, lb, n=2000):
    a, g, D = par
    vals = []
    for i in range(n + 1):
        lam = la + (lb - la) * i / n
        q = lam / (1 + lam)
        qd = q * (1 - q)
        ell = math.log1p(lam)
        al, ald = a * q, a * qd
        ga, gad = lam * (3 + lam) / g, lam * (3 + 2 * lam) / g
        vals.append(2 * D * q * qd - ald * ell - al * q - (gad * q * q / ell + 2 * ga * q * qd / ell - ga * q ** 3 / ell ** 2))
    return min(vals), max(vals)


if __name__ == '__main__':
    for m in coverage():
        print(m)
    res = run()
    for s, w in res.items():
        print('%s: min Z/p %.4f, min AC/p %.4f, min CA/p (L<0) %.4f' % (s, w['Zp'], w['ACp'], w['CAp']))
    for s, ivs in (('lo', [(1 / 3, 2687 / 6000), (2687 / 6000, 11 / 20)]), ('u1', [(263 / 200, 1.5)]), ('u2', [(1.5, 1.75)]),
                   ('u3', [(1.75, 2.0)]), ('u4', [(2.0, 2.32), (2.32, 7 / 3)])):
        for la, lb in ivs:
            print('d_mu S true range on [%.4f, %.4f]: [%.5f, %.5f]' % ((la, lb) + dS_float(PAR[s], la, lb)))
