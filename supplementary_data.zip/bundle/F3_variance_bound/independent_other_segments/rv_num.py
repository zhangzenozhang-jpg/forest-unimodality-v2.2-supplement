"""rv_num.py -- referee's own rigorous rational interval arithmetic (written from scratch for the multiplier_curve review).

Intervals are pairs of Fractions, rounded outward to the grid 2^-GRID after every operation.
exp and log of a rational are enclosed by Taylor / atanh series with explicit remainders.
"""
from fractions import Fraction as Fr
import math

GRID = 72
SC = 1 << GRID


def rdn(x):
    return Fr(math.floor(x * SC), SC)


def rup(x):
    return Fr(-math.floor(-x * SC), SC)


class I:
    __slots__ = ('lo', 'hi')

    def __init__(self, lo, hi=None):
        if hi is None:
            hi = lo
        if isinstance(lo, I):
            lo, hi = lo.lo, lo.hi
        self.lo = Fr(lo)
        self.hi = Fr(hi)
        if self.lo > self.hi:
            raise ValueError('bad interval %s %s' % (float(self.lo), float(self.hi)))

    @staticmethod
    def c(x):
        return x if isinstance(x, I) else I(x, x)

    def __add__(a, b):
        b = I.c(b)
        return I(rdn(a.lo + b.lo), rup(a.hi + b.hi))
    __radd__ = __add__

    def __neg__(a):
        return I(-a.hi, -a.lo)

    def __sub__(a, b):
        b = I.c(b)
        return I(rdn(a.lo - b.hi), rup(a.hi - b.lo))

    def __rsub__(a, b):
        return I.c(b) - a

    def __mul__(a, b):
        b = I.c(b)
        ps = (a.lo * b.lo, a.lo * b.hi, a.hi * b.lo, a.hi * b.hi)
        return I(rdn(min(ps)), rup(max(ps)))
    __rmul__ = __mul__

    def inv(a):
        if a.lo <= 0 <= a.hi:
            raise ZeroDivisionError('interval contains 0: [%g, %g]' % (float(a.lo), float(a.hi)))
        return I(rdn(1 / a.hi), rup(1 / a.lo))

    def __truediv__(a, b):
        return a * I.c(b).inv()

    def __rtruediv__(a, b):
        return I.c(b) * a.inv()

    def sq(a):
        if a.lo >= 0:
            return I(rdn(a.lo * a.lo), rup(a.hi * a.hi))
        if a.hi <= 0:
            return I(rdn(a.hi * a.hi), rup(a.lo * a.lo))
        return I(0, rup(max(a.lo * a.lo, a.hi * a.hi)))

    def mag(a):
        return max(abs(a.lo), abs(a.hi))

    def hull(a, b):
        b = I.c(b)
        return I(min(a.lo, b.lo), max(a.hi, b.hi))

    def __repr__(a):
        return '[%.6g, %.6g]' % (float(a.lo), float(a.hi))


# ---------------------------------------------------------------- exp
def _exp_small(z):
    """enclosure of exp(z) for rational 0 <= z <= 1/4"""
    assert 0 <= z <= Fr(1, 4)
    lo = Fr(0)
    hi = Fr(0)
    term_lo = Fr(1)
    term_hi = Fr(1)
    N = 28
    for j in range(N + 1):
        lo += term_lo
        hi += term_hi
        term_lo = rdn(term_lo * z / (j + 1))
        term_hi = rup(term_hi * z / (j + 1))
    # remainder sum_{j>N} z^j/j! <= term_{N+1} * 1/(1-z)
    hi += rup(term_hi * Fr(4, 3))
    return rdn(lo), rup(hi)


_exp_cache = {}


def exp_r(x):
    """enclosure (lo, hi) of exp(x), x rational"""
    x = Fr(x)
    if x in _exp_cache:
        return _exp_cache[x]
    if x < 0:
        lo, hi = exp_r(-x)
        res = (rdn(1 / hi), rup(1 / lo))
    else:
        k = 0
        z = x
        while z > Fr(1, 4):
            z /= 2
            k += 1
        lo, hi = _exp_small(z)
        for _ in range(k):
            lo, hi = rdn(lo * lo), rup(hi * hi)
        res = (lo, hi)
    if len(_exp_cache) < 200000:
        _exp_cache[x] = res
    return res


def exp_I(a):
    a = I.c(a)
    return I(exp_r(a.lo)[0], exp_r(a.hi)[1])


# ---------------------------------------------------------------- log
def _atanh2(z):
    """enclosure (lo, hi) of 2*atanh(z) for rational |z| <= 1/5"""
    z = Fr(z)
    assert abs(z) <= Fr(1, 5)
    zz = z * z
    zzl, zzh = rdn(zz), rup(zz)
    pl = ph = z                      # enclosure of z^(2j+1)
    lo = hi = Fr(0)
    N = 30
    for j in range(N + 1):
        lo += rdn(pl / (2 * j + 1))
        hi += rup(ph / (2 * j + 1))
        cand = (pl * zzl, pl * zzh, ph * zzl, ph * zzh)
        pl, ph = rdn(min(cand)), rup(max(cand))
    r = rup(Fr(1, 5) ** (2 * N + 3) / ((2 * N + 3) * (1 - Fr(1, 25))))
    return rdn(2 * (lo - r)), rup(2 * (hi + r))


_LOG2 = None


def log2_I():
    global _LOG2
    if _LOG2 is None:
        # log 2 = 2 atanh(1/3); 1/3 > 1/5, so use log2 = 2*atanh(1/7) + 2*atanh(1/17)... use log(2)=log(4/3)+log(3/2)
        # log(4/3) = 2 atanh(1/7), log(3/2) = 2 atanh(1/5)
        a = _atanh2(Fr(1, 7))
        b = _atanh2(Fr(1, 5))
        _LOG2 = (rdn(a[0] + b[0]), rup(a[1] + b[1]))
    return _LOG2


_log_cache = {}


def log_r(x):
    """enclosure (lo, hi) of log(x), x > 0 rational"""
    x = Fr(x)
    assert x > 0
    if x in _log_cache:
        return _log_cache[x]
    m = 0
    r = x
    while r > Fr(7, 5):
        r /= 2
        m += 1
    while r < Fr(7, 10):
        r *= 2
        m -= 1
    z = (r - 1) / (r + 1)   # |z| <= 1/5
    zl = rdn(z)
    zh = rup(z)
    a = _atanh2(zl)
    b = _atanh2(zh)
    lo, hi = min(a[0], b[0]), max(a[1], b[1])   # atanh increasing: lo from zl, hi from zh
    lo = a[0]
    hi = b[1]
    L2 = log2_I()
    if m >= 0:
        lo += m * L2[0]
        hi += m * L2[1]
    else:
        lo += m * L2[1]
        hi += m * L2[0]
    res = (rdn(lo), rup(hi))
    if len(_log_cache) < 200000:
        _log_cache[x] = res
    return res


def log_I(a):
    a = I.c(a)
    return I(log_r(a.lo)[0], log_r(a.hi)[1])


def selftest():
    import random
    random.seed(1)
    for _ in range(300):
        x = Fr(random.randint(-4000, 4000), random.randint(1, 1000))
        lo, hi = exp_r(x)
        v = math.exp(float(x))
        assert float(lo) <= v * (1 + 1e-12) and float(hi) >= v * (1 - 1e-12), (x, lo, hi, v)
        assert hi - lo < Fr(1, 10 ** 12) * max(1, v), (x, float(hi - lo))
        y = Fr(random.randint(1, 10 ** 6), random.randint(1, 10 ** 4))
        lo, hi = log_r(y)
        v = math.log(float(y))
        assert float(lo) <= v + 1e-12 and float(hi) >= v - 1e-12, (y, lo, hi, v)
        assert hi - lo < Fr(1, 10 ** 15)
    # exact-ish identities
    l2 = log2_I()
    assert float(l2[0]) <= math.log(2) <= float(l2[1])
    e1 = exp_r(1)
    assert float(e1[0]) <= math.e <= float(e1[1])
    return True


if __name__ == '__main__':
    print('selftest', selftest())
