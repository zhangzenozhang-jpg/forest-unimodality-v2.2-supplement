"""rv_poly.py -- referee's own verification that the child curve {(rho(t), J(t)) : t >= 0} at activity lam_p lies under
the concave polygon through the published vertices (lines through consecutive vertices, then the cap J <= Jbar).
Method (own subdivision): on [0, T] second-order Taylor upper bounds of f = J - b rho at the midpoint with an interval
bound of f'' on the two halves; on [T, oo) the chain condition of Lemma 2(c) of two_gen (J decreases) and rho increasing.
"""
from fractions import Fraction as Fr
from rv_num import I, exp_I, log_I, rdn, rup
from rv_model import pp_enc


class Jt:
    __slots__ = ('v', 'd1', 'd2')

    def __init__(s, v, d1, d2):
        s.v, s.d1, s.d2 = I.c(v), I.c(d1), I.c(d2)

    def __mul__(a, b):
        return Jt(a.v * b.v, a.d1 * b.v + a.v * b.d1, a.d2 * b.v + 2 * (a.d1 * b.d1) + a.v * b.d2)

    def __sub__(a, b):
        return Jt(a.v - b.v, a.d1 - b.d1, a.d2 - b.d2)

    def scale(a, c):
        return Jt(a.v * c, a.d1 * c, a.d2 * c)

    def inv(a):
        iv = a.v.inv()
        return Jt(iv, -(a.d1 * iv.sq()), (2 * a.d1.sq() - a.v * a.d2) * iv.sq() * iv)


def child_point(t, lam):
    v = Fr(lam) * exp_I(-Fr(t))
    s = v / (1 + v)
    y = log_I(1 + v)
    return s, y


def child_jets(tI, s, y):
    ss = pp_enc(s)
    T = Jt(tI, 1, 0)
    S = Jt(s, -ss, ss * (1 - 2 * s))
    Y = Jt(y, -s, ss)
    rho = T * Y.inv()
    J = S * S * rho
    return rho, J


def f_upper(t0, t1, lam, b):
    """upper bound of J - b rho on [t0, t1] at activity lam"""
    t0, t1 = Fr(t0), Fr(t1)
    c = (t0 + t1) / 2
    d = (t1 - t0) / 2
    s, y = child_point(c, lam)
    rho, J = child_jets(I(c), s, y)
    f = J - rho.scale(b)
    m2 = Fr(0)
    for (a_, b_) in ((t0, c), (c, t1)):
        sa, ya = child_point(a_, lam)
        sb, yb = child_point(b_, lam)
        sr = I(sb.lo, sa.hi)
        yr = I(yb.lo, ya.hi)
        rr, JJ = child_jets(I(a_, b_), sr, yr)
        ff = JJ - rr.scale(b)
        m2 = max(m2, ff.d2.hi)
    return f.v.hi + f.d1.mag() * d + m2 / 2 * d * d


def msg_hi(t, lam):
    return child_point(t, lam)[0].hi


def msg_lo(t, lam):
    return child_point(t, lam)[0].lo


def chain_ok(T, lam, step=Fr(1, 8)):
    pts = [T]
    x = T
    while x < 3:
        x = min(x + step, Fr(3))
        pts.append(x)
    pts += [Fr(4)]
    segs = list(zip(pts[:-1], pts[1:])) + [(Fr(4), None)]
    worst = None
    for a, b in segs:
        sa = msg_hi(a, lam)
        sb = Fr(0) if b is None else msg_lo(b, lam)
        val = rup(1 / a + 1 / (1 + sb / 2) - 2 + 2 * sa)
        worst = val if worst is None else max(worst, val)
        if val >= 0:
            return False, worst
    return True, worst


def lines_from_vertices(V):
    V = [(Fr(r), Fr(j)) for r, j in V]
    assert V[0][0] == 0
    L = []
    for i in range(len(V) - 1):
        (r0, j0), (r1, j1) = V[i], V[i + 1]
        b = (j1 - j0) / (r1 - r0)
        a = j0 - b * r0
        L.append((a, b))
    L.append((V[-1][1], Fr(0)))
    return L


def verify_polygon(V, lam, maxdepth=10):
    lam = Fr(lam)
    L = lines_from_vertices(V)
    out = dict(lam=lam, ok=True, notes=[])
    # concavity / ordering
    bs = [b for a, b in L]
    if not all(bs[i] > bs[i + 1] for i in range(len(bs) - 1)) or bs[-1] != 0:
        out['ok'] = False
        out['notes'].append('slopes not strictly decreasing to 0: %s' % [float(b) for b in bs])
    rs = [Fr(r) for r, j in V]
    if not all(rs[i] < rs[i + 1] for i in range(len(rs) - 1)):
        out['ok'] = False
        out['notes'].append('vertices not ordered')
    # T from the chain condition
    T = None
    for k in range(0, 25):
        cand = Fr(3, 2) + Fr(k, 8)
        ok, worst = chain_ok(cand, lam)
        if ok:
            T = cand
            break
    out['T'] = T
    if T is None:
        out['ok'] = False
        out['notes'].append('chain condition fails')
        return out
    npieces = 0
    minslack = None
    for idx, (a, b) in enumerate(L):
        stack = [(Fr(k, 8) * T / (T), Fr(k + 1, 8)) for k in range(0, int(T * 8))]
        # pieces of width 1/8 on [0, T] (T is a multiple of 1/8)
        stack = [(Fr(k, 8), Fr(k + 1, 8), 0) for k in range(int(T * 8))]
        while stack:
            t0, t1, dep = stack.pop()
            ub = f_upper(t0, t1, lam, b)
            if ub <= a:
                npieces += 1
                sl = a - ub
                minslack = sl if minslack is None else min(minslack, sl)
            elif dep < maxdepth:
                m = (t0 + t1) / 2
                stack.append((t0, m, dep + 1))
                stack.append((m, t1, dep + 1))
            else:
                out['ok'] = False
                out['notes'].append('line %d fails on [%s,%s], ub-a=%g' % (idx, t0, t1, float(ub - a)))
                break
    out['pieces'] = npieces
    out['minslack'] = minslack
    out['lines'] = L
    return out


if __name__ == '__main__':
    import json, sys
    lam = Fr(sys.argv[1])
    print(chain_ok(Fr(3, 2), lam), chain_ok(Fr(13, 8), lam), chain_ok(Fr(7, 4), lam))
