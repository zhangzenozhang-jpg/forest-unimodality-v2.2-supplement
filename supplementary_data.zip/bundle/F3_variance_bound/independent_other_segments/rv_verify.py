"""rv_verify.py -- referee's own exact re-verification of the 2,354 new checks of the multiplier_curve section.

Data read from the authors' JSON outputs (piece lists, polygon vertices, cut points); every bound is recomputed here
from the formulas of the TeX (transport section, arc section) with the referee's own interval arithmetic (rv_num.py).
Usage: python3 rv_verify.py SEG [SEG ...]      (SEG in lo u1 u2 u3 u4)
"""
import json
import sys
import time
from fractions import Fraction as Fr
from rv_num import I, exp_r, exp_I, log_r, log_I, rdn, rup
from rv_model import (mults, mdots, mults_box, prim_point, prim_box, phi_jet, phi_dmu, C_jet, C_dmu,
                      two_ended, centred, transport, deltas)
from rv_poly import verify_polygon, lines_from_vertices

OUT = '../multiplier_curve/outputs/'
TEXT_PAR = {'lo': (Fr(11, 25), Fr(21, 2), Fr(6, 5)), 'mid': (Fr(23, 50), Fr(13), Fr(6, 5)),
            'u1': (Fr(9, 20), Fr(23, 2), Fr(7, 5)), 'u2': (Fr(47, 100), Fr(43, 4), Fr(8, 5)),
            'u3': (Fr(1, 2), Fr(41, 4), Fr(9, 5)), 'u4': (Fr(57, 100), Fr(39, 4), Fr(21, 10))}
TEXT_SEG = {'lo': (Fr(1, 3), Fr(11, 20)), 'u1': (Fr(263, 200), Fr(3, 2)), 'u2': (Fr(3, 2), Fr(7, 4)),
            'u3': (Fr(7, 4), Fr(2)), 'u4': (Fr(2), Fr(7, 3))}
# Table mc:tab:sub of the TeX: (la, lb, seg, lam_p, YL, cut, V, CA, hand, poly)
TEXT_SUB = [
    ('1/3', '9/25', 'lo', '9/25', '1/8', False, 39, 8, 5, 36), ('9/25', '2/5', 'lo', '2/5', '1/8', False, 45, 9, 5, 36),
    ('2/5', '11/25', 'lo', '11/25', '1/8', False, 40, 9, 5, 36), ('11/25', '12/25', 'lo', '12/25', '1/8', False, 38, 8, 5, 36),
    ('12/25', '13/25', 'lo', '13/25', '1/8', False, 36, 8, 5, 36), ('13/25', '11/20', 'lo', '11/20', '1/8', False, 35, 7, 5, 36),
    ('263/200', '27/20', 'u1', '27/20', '1/5', True, 46, 8, 5, 36), ('27/20', '7/5', 'u1', '7/5', '1/5', True, 46, 8, 5, 36),
    ('7/5', '29/20', 'u1', '29/20', '1/5', True, 44, 8, 5, 36), ('29/20', '3/2', 'u1', '3/2', '1/5', True, 44, 8, 5, 36),
    ('3/2', '31/20', 'u2', '31/20', '1/5', True, 38, 8, 5, 41), ('31/20', '8/5', 'u2', '8/5', '1/5', True, 38, 8, 5, 38),
    ('8/5', '33/20', 'u2', '33/20', '1/5', True, 44, 8, 5, 38), ('33/20', '17/10', 'u2', '17/10', '1/5', True, 44, 8, 5, 38),
    ('17/10', '7/4', 'u2', '7/4', '1/5', True, 44, 8, 5, 38), ('7/4', '9/5', 'u3', '9/5', '1/5', True, 36, 7, 5, 38),
    ('9/5', '37/20', 'u3', '37/20', '1/5', True, 36, 7, 5, 37), ('37/20', '19/10', 'u3', '19/10', '1/5', True, 36, 7, 5, 37),
    ('19/10', '39/20', 'u3', '39/20', '1/5', True, 44, 8, 5, 37), ('39/20', '2', 'u3', '2', '1/5', True, 44, 8, 5, 37),
    ('2', '41/20', 'u4', '41/20', '1/5', True, 36, 7, 5, 37), ('41/20', '21/10', 'u4', '21/10', '1/5', True, 36, 7, 5, 38),
    ('21/10', '43/20', 'u4', '43/20', '1/5', True, 36, 7, 5, 38), ('43/20', '11/5', 'u4', '11/5', '1/5', True, 36, 8, 5, 38),
    ('11/5', '9/4', 'u4', '9/4', '1/5', True, 44, 8, 5, 38), ('9/4', '7/3', 'u4', '7/3', '1/5', True, 42, 9, 5, 38)]

LOG = []


def say(*a):
    s = ' '.join(str(x) for x in a)
    print(s, flush=True)
    LOG.append(s)


def F(x):
    return Fr(x)


# ---------------------------------------------------------------- float census (sanity of both bounds; DIAGNOSTIC)
import math


def _prims_f(Y, lam):
    u = math.exp(Y) / lam
    p = 1 / (1 + u)
    y0 = math.log1p(lam * math.exp(-Y))
    return u, p, y0, p / y0


def _mults_f(par, lam):
    a, g, D = (float(x) for x in par)
    q = lam / (1 + lam)
    return a * q, lam * (3 + lam) / g, 1 + (D - 1) * q


def phi_f(par, Y, lam, rho, J, tag):
    al, ga, AD = _mults_f(par, lam)
    u, p, y0, k = _prims_f(Y, lam)
    h = 1 - p + ga * k
    N = AD - h - al / k
    T = J * h * h / (ga + J * (ga * u - h * Y)) if tag == 'Phi' else J * h * h / ga
    return al * u + N / Y + al * rho - T


def C_f(par, Y, lam, Jb):
    al, ga, AD = _mults_f(par, lam)
    u, p, y0, k = _prims_f(Y, lam)
    h = 1 - p + ga * k
    B = u + (math.log(lam) - math.log(math.expm1(Y)) - 1 / k) / Y
    l = h * Y - ga * u
    return al * B - ga * l / (ga - Jb * l)


def box_min_f(fun, Y0, Y1, la, lb, ny=24, nl=4):
    m = float('inf')
    for i in range(ny + 1):
        Y = float(Y0) + (float(Y1) - float(Y0)) * i / ny
        for j in range(nl + 1):
            lam = float(la) + (float(lb) - float(la)) * j / nl
            m = min(m, fun(Y, lam))
    return m


CENSUS = dict(n=0, own_bad=0, auth_bad=0, worst_own=None, worst_auth=None)


def census(fun, Y0, Y1, la, lb, own, auth):
    m = box_min_f(fun, Y0, Y1, la, lb)
    CENSUS['n'] += 1
    if float(own) > m + 1e-9:
        CENSUS['own_bad'] += 1
    gap = m - float(own)
    if CENSUS['worst_own'] is None or gap < CENSUS['worst_own'][0]:
        CENSUS['worst_own'] = (gap, float(Y0), float(Y1), float(la), float(lb))
    if auth is not None:
        g2 = m - auth
        if CENSUS['worst_auth'] is None or g2 < CENSUS['worst_auth'][0]:
            CENSUS['worst_auth'] = (g2, float(Y0), float(Y1), float(la), float(lb))
    if auth is not None and auth > m + 1e-9:
        CENSUS['auth_bad'] += 1
    return m


# ---------------------------------------------------------------- one vertex-function piece
def m2_phi(Y0, Y1, lam, al, ga, AD, rho, J, tag, nsplit=2):
    m2 = Fr(0)
    for i in range(nsplit):
        a = Y0 + (Y1 - Y0) * i / nsplit
        b = Y0 + (Y1 - Y0) * (i + 1) / nsplit
        P = prim_box(a, b, lam, lam)
        v, d1, d2 = phi_jet(P, I(a, b), al, ga, AD, rho, J, tag)
        m2 = min(m2, d2.lo)
    return m2


def dmu_phi_box(par, Y0, Y1, la, lb, rho, J, tag, ny=1, nl=1):
    res = None
    for i in range(ny):
        a = Y0 + (Y1 - Y0) * i / ny
        b = Y0 + (Y1 - Y0) * (i + 1) / ny
        for jl in range(nl):
            l0 = la + (lb - la) * jl / nl
            l1 = la + (lb - la) * (jl + 1) / nl
            al, ga, AD, ald, gad, ADd = mults_box(par, l0, l1)
            P = prim_box(a, b, l0, l1)
            d = phi_dmu(P, I(a, b), al, ga, AD, ald, gad, ADd, rho, J, tag)
            res = d if res is None else res.hull(d)
    return res


def vertex_piece(par, la, lb, lc, dm, dp, Y0, Y1, rho, J, tag, fine=False):
    al, ga, AD = mults(par, lc)
    P0 = prim_point(Y0, lc)
    P1 = prim_point(Y1, lc)
    f0, f0d, _ = phi_jet(P0, I(Y0), al, ga, AD, rho, J, tag)
    f1, f1d, _ = phi_jet(P1, I(Y1), al, ga, AD, rho, J, tag)
    m2 = m2_phi(Y0, Y1, lc, al, ga, AD, rho, J, tag, nsplit=8 if fine else 2)
    beta = two_ended(f0, f0d, f1, f1d, m2, Y0, Y1)
    dI = dmu_phi_box(par, Y0, Y1, la, lb, rho, J, tag, ny=8 if fine else 1, nl=2 if fine else 1)
    return transport(beta, dI, dm, dp), beta, dI


# ---------------------------------------------------------------- one CA piece
def ca_piece(par, la, lb, lc, dm, dp, Y0, Y1, Jb, fine=False):
    al, ga, AD = mults(par, lc)
    Yc = (Y0 + Y1) / 2
    d = (Y1 - Y0) / 2
    mu = log_I(lc)
    Pc = prim_point(Yc, lc)
    fc, fcd, _ = C_jet(Pc, I(Yc), mu, I(al), I(ga), Jb, exp_I(Yc))
    m2 = Fr(0)
    ns = 8 if fine else 2
    for i in range(ns):
        a = Y0 + (Y1 - Y0) * i / ns
        b = Y0 + (Y1 - Y0) * (i + 1) / ns
        P = prim_box(a, b, lc, lc)
        _, _, c2 = C_jet(P, I(a, b), mu, I(al), I(ga), Jb, P['eY'])
        m2 = min(m2, c2.lo)
    beta = centred(fc, fcd, m2, d)
    ny = 8 if fine else 1
    nl = 2 if fine else 1
    dI = None
    for i in range(ny):
        a = Y0 + (Y1 - Y0) * i / ny
        b = Y0 + (Y1 - Y0) * (i + 1) / ny
        for jl in range(nl):
            l0 = la + (lb - la) * jl / nl
            l1 = la + (lb - la) * (jl + 1) / nl
            alI, gaI, ADI, ald, gad, ADd = mults_box(par, l0, l1)
            P = prim_box(a, b, l0, l1)
            mu_box = I(log_r(l0)[0], log_r(l1)[1])
            dd = C_dmu(P, I(a, b), mu_box, alI, gaI, ald, gad, Jb, P['eY'])
            dI = dd if dI is None else dI.hull(dd)
    return transport(beta, dI, dm, dp), beta, dI


def Lpos_piece(par, la, lb, Y0, Y1):
    """L' = gamma u - h Y > 0 on [Y0,Y1] x [la,lb]: gamma_a e^Y0/lb - h_hi Y1, h_hi = 1 - p(Y1,la) + gamma_b k(Y1,la)"""
    ga_a = mults(par, la)[1]
    ga_b = mults(par, lb)[1]
    PB = prim_point(Y1, la)
    hhi = 1 - PB['p'] + ga_b * PB['k']
    v = ga_a * exp_I(Y0) / lb - hhi * Y1
    return v.lo


# ---------------------------------------------------------------- hand bounds (Lemma tr:lem:hand)
def hand(par, la, lb, Jb, left):
    al_a, ga_a, AD_a = mults(par, la)
    al_b, ga_b, AD_b = mults(par, lb)
    res = {}
    # (Z)
    A = 1 + ga_b
    B = ga_a / lb
    zval = ga_a - Jb * A * (log_I(A / B) - 1)
    res['Z'] = zval.lo
    res['Z_note'] = 'A(log(A/B)-1) = %s' % (A * (log_I(A / B) - 1))
    # (L) on each left piece [Y0,Y1]
    Lmin = None
    for (Y0, Y1) in left:
        Y0, Y1 = F(Y0), F(Y1)
        tI = log_I(la) - log_I(exp_I(Y1) - 1)
        t = I(max(Fr(0), tI.lo), max(Fr(0), tI.hi))
        PB = prim_point(Y1, la)
        hhi = 1 - PB['p'] + ga_b * PB['k']
        PA = prim_point(Y0, lb)
        Nlo = AD_a - hhi - al_b / PA['k']
        num = Nlo + al_a * t          # use lower end
        if num.lo >= 0:
            term = num.lo / Y1
        else:
            if Y0 <= 0:
                res['L_fail'] = 'numerator < 0 with Y0 = 0'
                term = Fr(-10 ** 9)
            else:
                term = num.lo / Y0
        Qlo = ga_a + Jb * min(Fr(0), (ga_a * exp_I(Y0) / lb - hhi * Y1).lo)
        if Qlo <= 0:
            res['L_fail'] = 'Qlo <= 0'
            val = Fr(-10 ** 9)
        else:
            val = (al_a * exp_I(Y0) / lb).lo + term - (Jb * hhi.sq() / Qlo).hi
        Lmin = val if Lmin is None else min(Lmin, val)
        res['L_num'] = num
    res['L'] = Lmin
    # (R)
    P3 = prim_point(3, lb)
    Nlo = AD_a - 1 - ga_b - al_b / P3['k']
    res['R_Nlo_sign'] = Nlo.hi
    e3 = exp_I(3)
    crit = log_I((1 + ga_b) * lb / ga_a)
    res['R_crit'] = crit.hi            # must be <= 3
    mx = max(Fr(0), (3 * (1 + ga_b) - ga_a * e3 / lb).hi)
    Qlo = min(ga_a, ga_a - Jb * mx)
    if Qlo <= 0:
        res['R'] = Fr(-10 ** 9)
    else:
        nterm = Nlo.lo / 3 if Nlo.hi <= 0 else Fr(0)   # N_lo/Y >= N_lo/3 needs N_lo <= 0
        res['R'] = (al_a * e3 / lb).lo + nterm - ((1 + ga_b) ** 2 * Jb / Qlo)
        if Nlo.hi > 0:
            res['R_note'] = 'N_lo > 0: text formula N_lo/3 invalid, used 0'
    # (C): L' > 0 on (0, 1/500] and [3, oo): L' >= gamma_a e^Y/lb - (1+gamma_b) Y
    res['C1'] = (ga_a / lb - (1 + ga_b) * Fr(1, 500))       # e^Y >= 1
    res['C2'] = (ga_a * e3 / lb - 3 * (1 + ga_b)).lo
    return res


# ---------------------------------------------------------------- driver
def U_of(lines, rho):
    return min(a + b * rho for a, b in lines)


def run_seg(seg):
    d = json.load(open(OUT + 'curve_%s.json' % seg))
    assert d['allok']
    par = TEXT_PAR[seg]
    jpar = tuple(Fr(x) for x in d['segments'][seg])
    if jpar != par:
        say('PARAMETER MISMATCH', seg, jpar, par)
    for sname, sp in d['segments'].items():
        if tuple(Fr(x) for x in sp) != TEXT_PAR[sname]:
            say('segment table mismatch', sname)
    subs = [r for r in d['results']]
    summary = []
    poly_cache = {}
    for r in subs:
        rep = r['rep']
        la, lb, lc = F(rep['la']), F(rep['lb']), F(rep['lc'])
        assert lc == (la + lb) / 2
        assert rep['seg'] == seg and tuple(Fr(x) for x in rep['par']) == par
        lo_s, hi_s = TEXT_SEG[seg]
        assert lo_s <= la < lb <= hi_s, (la, lb)
        tsub = [x for x in TEXT_SUB if F(x[0]) == la and F(x[1]) == lb]
        assert len(tsub) == 1, (la, lb)
        tsub = tsub[0]
        lp = F(rep['lp'])
        YL = F(rep['YL'])
        issues = []
        if lp != F(tsub[3]) or YL != F(tsub[4]) or rep['cut'] != tsub[5] or tsub[2] != seg:
            issues.append('table row mismatch')
        if lp < lb:
            issues.append('lam_p < lb')
        if lp > Fr(5, 2):
            issues.append('lam_p > 5/2')
        dm, dp = deltas(la, lb, lc)
        V = rep['vertices']
        Jb = F(rep['Jbar'])
        if F(V[-1][1]) != Jb:
            issues.append('Jbar != last vertex J')
        lines = lines_from_vertices(V)
        # --- polygon
        if lp not in poly_cache:
            t0 = time.time()
            poly_cache[lp] = verify_polygon(V, lp)
        pv = poly_cache[lp]
        if not pv['ok']:
            issues.append('POLYGON: %s' % pv['notes'])
        # --- hand
        hd = hand(par, la, lb, Jb, rep['left'])
        nhand = 0
        hand_min = None
        for key in ('Z', 'L', 'R', 'C1', 'C2'):
            v = hd[key]
            v = v.lo if isinstance(v, I) else v
            nhand += 1
            hand_min = v if hand_min is None else min(hand_min, v)
            if v <= 0:
                issues.append('hand %s fails: %g' % (key, float(v)))
        if hd['R_crit'] > 3:
            issues.append('(R) critical point > 3')
        if hd['R_Nlo_sign'] > 0:
            issues.append('(R) N_lo > 0')
        if 'L_fail' in hd:
            issues.append('(L) ' + hd['L_fail'])
        # left pieces cover (0, YL]
        lft = [(F(a), F(b)) for a, b in rep['left']]
        if lft[0][0] != 0 or lft[-1][1] != YL or any(lft[i][1] != lft[i + 1][0] for i in range(len(lft) - 1)):
            issues.append('left pieces do not cover (0, YL]')
        # --- core
        nV = 0
        vmin = None
        vmin_where = None
        maxdiff = 0.0
        refined = 0
        if not rep['cut']:
            seen = set()
            for c in rep['core']:
                vi = c['vertex']
                tag = c['tag']
                seen.add((vi, tag))
                rho, J = F(c['rho']), F(c['J'])
                if (rho, J) != (F(V[vi][0]), F(V[vi][1])):
                    issues.append('core vertex mismatch')
                pcs = [(F(a), F(b)) for a, b in c['pieces']]
                if pcs[0][0] != YL or pcs[-1][1] != 3 or any(pcs[i][1] != pcs[i + 1][0] for i in range(len(pcs) - 1)):
                    issues.append('pieces do not cover [YL,3] for vertex %d %s' % (vi, tag))
                for (Y0, Y1), bd in zip(pcs, c['bounds']):
                    b, beta, dI = vertex_piece(par, la, lb, lc, dm, dp, Y0, Y1, rho, J, tag)
                    if b <= 0:
                        b2, _, _ = vertex_piece(par, la, lb, lc, dm, dp, Y0, Y1, rho, J, tag, fine=True)
                        refined += 1
                        issues.append('vertex piece v%d %s [%s,%s]: own bound %.3g (authors %.3g); refined %.3g'
                                      % (vi, tag, Y0, Y1, float(b), bd, float(b2)))
                        b = b2
                    census(lambda Y, l: phi_f(par, Y, l, float(rho), float(J), tag), Y0, Y1, la, lb, b, bd)
                    nV += 1
                    maxdiff = max(maxdiff, abs(float(b) - bd))
                    if vmin is None or b < vmin:
                        vmin, vmin_where = b, 'v%d %s [%s, %s]' % (vi, tag, Y0, Y1)
            if len(seen) != 8:
                issues.append('not all 8 vertex functions present: %s' % sorted(seen))
        else:
            assert len(rep['core']) == 1
            c = rep['core'][0]
            pcs = [(F(a), F(b)) for a, b in c['pieces']]
            if pcs[0][0] != YL or pcs[-1][1] != 3 or any(pcs[i][1] != pcs[i + 1][0] for i in range(len(pcs) - 1)):
                issues.append('cut pieces do not cover [YL,3]')
            Vs = [(F(x), F(y)) for x, y in V]
            for (Y0, Y1) in pcs:
                chks = [x for x in c['checks'] if F(x['Y0']) == Y0 and F(x['Y1']) == Y1]
                pts = sorted(set((F(x['rho']), F(x['J'])) for x in chks))
                # the cut point: smallest rho; must satisfy rho <= rho_c(Y1) and J >= U(rho)
                rc = min(p[0] for p in pts)
                jc = [p[1] for p in pts if p[0] == rc][0]
                tI = log_I(la) - log_I(exp_I(Y1) - 1)
                rho_c_lo = max(Fr(0), tI.lo) / Y1
                if rc > rho_c_lo:
                    issues.append('cut rho %g > rho_c(Y1) %g on [%s,%s]' % (float(rc), float(rho_c_lo), Y0, Y1))
                if jc < U_of(lines, rc):
                    issues.append('cut J below U on [%s,%s]' % (Y0, Y1))
                need = [v for v in Vs if v[0] >= rc]
                for v in need:
                    if v not in pts:
                        issues.append('vertex %s with rho >= cut missing on [%s,%s]' % (v, Y0, Y1))
                for p_ in pts:
                    if p_ not in Vs and p_ != (rc, jc):
                        issues.append('extra point %s on [%s,%s]' % (p_, Y0, Y1))
                    tags = set(x['tag'] for x in chks if (F(x['rho']), F(x['J'])) == p_)
                    if tags != {'Phi', 'Phig'}:
                        issues.append('missing tag at %s' % (p_,))
                for x in chks:
                    rho, J, tag = F(x['rho']), F(x['J']), x['tag']
                    b, beta, dI = vertex_piece(par, la, lb, lc, dm, dp, Y0, Y1, rho, J, tag)
                    if b <= 0:
                        b2, _, _ = vertex_piece(par, la, lb, lc, dm, dp, Y0, Y1, rho, J, tag, fine=True)
                        refined += 1
                        issues.append('cut piece %s [%s,%s] rho=%.4f: own bound %.3g (authors %.3g); refined %.3g'
                                      % (tag, Y0, Y1, float(rho), float(b), x['bound'], float(b2)))
                        b = b2
                    census(lambda Y, l: phi_f(par, Y, l, float(rho), float(J), tag), Y0, Y1, la, lb, b, x['bound'])
                    nV += 1
                    maxdiff = max(maxdiff, abs(float(b) - x['bound']))
                    if vmin is None or b < vmin:
                        vmin, vmin_where = b, 'cut-family %s rho=%.4f [%s, %s]' % (tag, float(rho), Y0, Y1)
        # --- CA
        nCA = 0
        camin = None
        ca = rep['ca']
        cpc = [(F(x['Y0']), F(x['Y1'])) for x in ca]
        if cpc[0][0] != Fr(1, 500) or cpc[-1][1] != 3 or any(cpc[i][1] != cpc[i + 1][0] for i in range(len(cpc) - 1)):
            issues.append('CA pieces do not cover [1/500,3]')
        for x in ca:
            Y0, Y1 = F(x['Y0']), F(x['Y1'])
            if x['Lpos']:
                v = Lpos_piece(par, la, lb, Y0, Y1)
                if v <= 0:
                    issues.append("L'>0 piece fails [%s,%s]: %g" % (Y0, Y1, float(v)))
            else:
                v, beta, dI = ca_piece(par, la, lb, lc, dm, dp, Y0, Y1, Jb)
                if v <= 0:
                    v2, _, _ = ca_piece(par, la, lb, lc, dm, dp, Y0, Y1, Jb, fine=True)
                    refined += 1
                    issues.append('CA piece [%s,%s]: own %.3g (authors %.3g); refined %.3g' % (Y0, Y1, float(v), x['bound'], float(v2)))
                    v = v2
                census(lambda Y, l: C_f(par, Y, l, float(Jb)), Y0, Y1, la, lb, v, x['bound'])
                maxdiff = max(maxdiff, abs(float(v) - x['bound']))
                camin = v if camin is None else min(camin, v)
            nCA += 1
        tot = nV + nCA + nhand
        cnt_ok = (nV, nCA, nhand) == (tsub[6], tsub[7], tsub[8])
        if not cnt_ok:
            issues.append('count mismatch: own (V, CA, hand) = (%d, %d, %d), text (%d, %d, %d)' % (nV, nCA, nhand, tsub[6], tsub[7], tsub[8]))
        if rep['polygon_checks'] != tsub[9]:
            issues.append('polygon count in JSON %d != text %d' % (rep['polygon_checks'], tsub[9]))
        piece_min = min(vmin, camin) if camin is not None else vmin
        summary.append(dict(seg=seg, la=la, lb=lb, nV=nV, nCA=nCA, nhand=nhand, vmin=vmin, vmin_where=vmin_where,
                            camin=camin, hand_min=hand_min, piece_min=piece_min, maxdiff=maxdiff, issues=issues,
                            polyT=pv.get('T'), poly_pieces=pv.get('pieces'), poly_slack=pv.get('minslack'),
                            poly_count_json=rep['polygon_checks'], refined=refined))
        say('[%s, %s] %s: V %d CA %d hand %d | min V %.5f (%s), min CA %s, min hand %.4f | max |own-authors| %.2e | '
            'polygon at %s: T=%s, own pieces %s, min slack %.2e | issues: %s'
            % (la, lb, seg, nV, nCA, nhand, float(vmin), vmin_where, ('%.5f' % float(camin)) if camin is not None else '-',
               float(hand_min), maxdiff, lp, pv.get('T'), pv.get('pieces'), float(pv['minslack']) if pv.get('minslack') is not None else -1,
               issues if issues else 'none'))
    return summary


if __name__ == '__main__':
    segs = sys.argv[1:] or ['lo', 'u1', 'u2', 'u3', 'u4']
    allsum = []
    for s in segs:
        t = time.time()
        allsum += run_seg(s)
        say('segment %s done in %.0f s' % (s, time.time() - t))
    say('float census (DIAGNOSTIC): %s' % CENSUS)
    ser = []
    for x in allsum:
        y = dict(x)
        for k in ('la', 'lb'):
            y[k] = str(y[k])
        for k in ('vmin', 'camin', 'hand_min', 'piece_min', 'poly_slack'):
            y[k] = None if y[k] is None else float(y[k])
        y['polyT'] = str(y['polyT'])
        ser.append(y)
    json.dump(ser, open('rv_verify_%s.json' % '_'.join(segs), 'w'), indent=1)
