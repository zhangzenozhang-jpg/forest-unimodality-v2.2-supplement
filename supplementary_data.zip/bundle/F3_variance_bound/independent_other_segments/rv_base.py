"""rv_base.py -- referee's own check of Lemma mc:lem:base (the single-vertex base case) on the five new segments.
(1) The seven transport checks as described in the TeX: S(lam_c) enclosed, d_mu S enclosed on the interval, Lemma tr:lem:mvt.
(2) An independent proof by monotone envelopes on a fine cover (no derivative): on [l0,l1],
    S >= D q(l0)^2 - alpha(l1) log(1+l1) - gamma(l1) q(l1)^2 / log(1+l0).
Also: the DIAGNOSTIC slack table S/q^2 at the segment ends, and the root lam* of the old multipliers.
"""
from fractions import Fraction as Fr
from rv_num import I, log_r, log_I, rdn, rup
from rv_model import mults, mdots, qq_range, transport, deltas

PAR = {'lo': (Fr(11, 25), Fr(21, 2), Fr(6, 5)), 'mid': (Fr(23, 50), Fr(13), Fr(6, 5)),
       'u1': (Fr(9, 20), Fr(23, 2), Fr(7, 5)), 'u2': (Fr(47, 100), Fr(43, 4), Fr(8, 5)),
       'u3': (Fr(1, 2), Fr(41, 4), Fr(9, 5)), 'u4': (Fr(57, 100), Fr(39, 4), Fr(21, 10))}
SEG = {'lo': (Fr(1, 3), Fr(11, 20)), 'mid': (Fr(11, 20), Fr(263, 200)), 'u1': (Fr(263, 200), Fr(3, 2)),
       'u2': (Fr(3, 2), Fr(7, 4)), 'u3': (Fr(7, 4), Fr(2)), 'u4': (Fr(2), Fr(7, 3))}
TEXT_BASE = {'lo': [Fr(1, 3), Fr(2687, 6000), Fr(11, 20)], 'u1': [Fr(263, 200), Fr(3, 2)], 'u2': [Fr(3, 2), Fr(7, 4)],
             'u3': [Fr(7, 4), Fr(2)], 'u4': [Fr(2), Fr(58, 25), Fr(7, 3)]}


def S_point(par, lam):
    a, g, D = par
    al, ga, AD = mults(par, lam)
    q = Fr(lam) / (1 + Fr(lam))
    ell = log_I(1 + Fr(lam))
    return D * q * q - al * ell - ga * q * q / ell


def dS_box(par, la, lb):
    a, g, D = par
    q = I(la / (1 + la), lb / (1 + lb))
    qd = qq_range(la, lb)                      # q(1-q) = dq/dmu
    al = a * q
    ald = a * qd
    ga = I(la * (3 + la) / g, lb * (3 + lb) / g)
    gad = I(la * (3 + 2 * la) / g, lb * (3 + 2 * lb) / g)
    ell = log_I(I(1 + la, 1 + lb))
    # d_mu S = 2 D q qd - ald ell - al q - (gad q^2/ell + 2 ga q qd/ell - ga q^3/ell^2)
    return 2 * D * q * qd - ald * ell - al * q - (gad * q.sq() / ell + 2 * ga * q * qd / ell - ga * q.sq() * q / ell.sq())


def transport_check(par, la, lb):
    lc = (la + lb) / 2
    dm, dp = deltas(la, lb, lc)
    Sc = S_point(par, lc)
    dI = dS_box(par, la, lb)
    return transport(Sc.lo, dI, dm, dp), Sc, dI


def envelope_cover(par, la, lb, n0=64):
    """independent proof of S > 0 on [la, lb] by monotone envelopes, adaptive; returns (pieces, least bound)"""
    a, g, D = par
    stack = [(la + (lb - la) * i / n0, la + (lb - la) * (i + 1) / n0, 0) for i in range(n0)]
    n = 0
    least = None
    while stack:
        l0, l1, dep = stack.pop()
        q0, q1 = l0 / (1 + l0), l1 / (1 + l1)
        al1 = a * q1
        ga1 = l1 * (3 + l1) / g
        e0 = log_r(1 + l0)[0]
        e1 = log_r(1 + l1)[1]
        v = D * q0 * q0 - al1 * e1 - ga1 * q1 * q1 / e0
        if v > 0:
            n += 1
            least = v if least is None else min(least, v)
        elif dep < 12:
            m = (l0 + l1) / 2
            stack += [(l0, m, dep + 1), (m, l1, dep + 1)]
        else:
            return n, None
    return n, least


if __name__ == '__main__':
    print('(1) the seven transport checks of Lemma mc:lem:base (as described in the TeX)')
    allmin = None
    for s in ('lo', 'u1', 'u2', 'u3', 'u4'):
        pts = TEXT_BASE[s]
        assert pts[0] == SEG[s][0] and pts[-1] == SEG[s][1]
        for la, lb in zip(pts[:-1], pts[1:]):
            b, Sc, dI = transport_check(PAR[s], la, lb)
            allmin = b if allmin is None else min(allmin, b)
            print('  %s [%s, %s]: S(centre) in %s, d_mu S in %s, bound %.6f %s' % (s, la, lb, Sc, dI, float(b), 'PASS' if b > 0 else 'FAIL'))
    print('  least bound %.3g' % float(allmin))
    print('(2) independent monotone-envelope cover (no derivatives)')
    for s in ('lo', 'mid', 'u1', 'u2', 'u3', 'u4'):
        la, lb = SEG[s]
        n, least = envelope_cover(PAR[s], la, lb, n0=64 if s != 'mid' else 256)
        print('  %s [%s, %s]: %d pieces, least lower bound %s' % (s, la, lb, n, 'FAIL' if least is None else '%.3g' % float(least)))
    print('(3) DIAGNOSTIC: S/q^2 at the segment ends (Table mc:tab:curve column "slack at the ends")')
    for s in ('lo', 'mid', 'u1', 'u2', 'u3', 'u4'):
        la, lb = SEG[s]
        out = []
        for lam in (la, lb):
            q = lam / (1 + lam)
            v = S_point(PAR[s], lam)
            out.append('%.4f' % float(v.lo / (q * q)))
        print('  %s: %s' % (s, ', '.join(out)))
    # root of the old multipliers' slack
    par = PAR['mid']
    lo, hi = Fr(13, 10), Fr(14, 10)
    for _ in range(40):
        m = (lo + hi) / 2
        if S_point(par, m).lo > 0:
            lo = m
        elif S_point(par, m).hi < 0:
            hi = m
        else:
            break
    print('  old multipliers: slack changes sign in [%.6f, %.6f]' % (float(lo), float(hi)))
