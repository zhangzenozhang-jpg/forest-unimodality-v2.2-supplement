"""rv_model.py -- referee's own implementation of the formulas of the transport section (two_gen_transport) and of the
arc section (two_gen_arc), with the multipliers of the curve section: alpha = a q, gamma = lam(3+lam)/g, A_D = 1+(D-1)q.
Written from the TeX only.
"""
from fractions import Fraction as Fr
from rv_num import I, exp_r, exp_I, log_r, log_I, rdn, rup

HALF = Fr(1, 2)


# ------------------------------------------------------------------ multipliers
def mults(par, lam):
    a, g, D = par
    lam = Fr(lam)
    q = lam / (1 + lam)
    return a * q, lam * (3 + lam) / g, 1 + (D - 1) * q


def mdots(par, lam):
    a, g, D = par
    lam = Fr(lam)
    qq = lam / (1 + lam) ** 2
    return a * qq, lam * (3 + 2 * lam) / g, (D - 1) * qq


def qq_range(la, lb):
    f = lambda x: Fr(x) / (1 + Fr(x)) ** 2
    if lb <= 1:
        return I(f(la), f(lb))
    if la >= 1:
        return I(f(lb), f(la))
    return I(min(f(la), f(lb)), Fr(1, 4))


def mults_box(par, la, lb):
    a, g, D = par
    assert a > 0 and g > 0 and D >= 1
    A0, G0, D0 = mults(par, la)
    A1, G1, D1 = mults(par, lb)
    al, ga, AD = I(A0, A1), I(G0, G1), I(D0, D1)
    qq = qq_range(la, lb)
    ald = a * qq
    gad = I(Fr(la) * (3 + 2 * Fr(la)) / g, Fr(lb) * (3 + 2 * Fr(lb)) / g)
    ADd = (D - 1) * qq
    return al, ga, AD, ald, gad, ADd


# ------------------------------------------------------------------ parent primitives
def pp_enc(p):
    """enclosure of p(1-p) for p in interval p"""
    f = lambda x: x * (1 - x)
    if p.hi <= HALF:
        return I(rdn(f(p.lo)), rup(f(p.hi)))
    if p.lo >= HALF:
        return I(rdn(f(p.hi)), rup(f(p.lo)))
    return I(rdn(min(f(p.lo), f(p.hi))), Fr(1, 4))


def prim_point(Y, lam):
    """u = e^Y/lam, p = msg_lam(Y) = 1/(1+u), y0 = lm_lam(Y) = log(1+lam e^-Y), k = p/y0, w = k+p-1 (intervals)"""
    Y = Fr(Y)
    lam = Fr(lam)
    eY = exp_I(Y)
    u = eY / lam
    p = (1 + u).inv()
    v = lam * exp_I(-Y)            # lam e^-Y
    y0 = log_I(1 + v)
    # p is exactly v/(1+v); intersect the two enclosures for tightness
    p2 = v / (1 + v)
    p = I(max(p.lo, p2.lo), min(p.hi, p2.hi))
    k = p / y0
    w = k + p - 1
    return dict(u=u, p=p, y0=y0, k=k, w=w, pp=pp_enc(p), eY=eY)


def prim_box(Y0, Y1, la, lb):
    """ranges on [Y0,Y1] x [la,lb]; everything is a function of Y - mu, monotone: corners (Y0, lb) and (Y1, la)"""
    A = prim_point(Y0, lb)     # smallest Y - mu
    B = prim_point(Y1, la)     # largest Y - mu
    u = I(A['u'].lo, B['u'].hi)
    p = I(B['p'].lo, A['p'].hi)
    y0 = I(B['y0'].lo, A['y0'].hi)
    k = I(A['k'].lo, B['k'].hi)
    w = k + p - 1
    return dict(u=u, p=p, y0=y0, k=k, w=w, pp=pp_enc(p), eY=I(exp_r(Fr(Y0))[0], exp_r(Fr(Y1))[1]))


def prim_range_fixed_lam(Y0, Y1, lam):
    return prim_box(Y0, Y1, lam, lam)


# ------------------------------------------------------------------ vertex functions: jets in Y at fixed lambda
def phi_jet(P, Y, al, ga, AD, rho, J, tag):
    """(value, d/dY, d2/dY2) of Phi (tag 'Phi') or Phi^gamma (tag 'Phig') at fixed (rho, J), fixed lambda.
    P: primitives (intervals) on the Y-range; Y: interval."""
    Y = I.c(Y)
    u, p, k, w, pp = P['u'], P['p'], P['k'], P['w'], P['pp']
    h = 1 - p + ga * k
    h1 = pp + ga * k * w
    h2 = -(pp * (1 - 2 * p)) + ga * k * (w.sq() + k * w - pp)
    N = AD - h - al / k
    N1 = -h1 + al * w / k
    N2 = -h2 + al * (w - pp / k - w.sq() / k)
    NY = N / Y
    NY1 = (N1 * Y - N) / Y.sq()
    NY2 = (N2 * Y.sq() - 2 * N1 * Y + 2 * N) / (Y.sq() * Y)
    if tag == 'Phi':
        Lb = ga * u - h * Y
        Lb1 = ga * u - h - h1 * Y
        Lb2 = ga * u - 2 * h1 - h2 * Y
        Q = ga + J * Lb
        Q1 = J * Lb1
        Q2 = J * Lb2
        T = J * h.sq() / Q
        T1 = J * (2 * h * h1 * Q - h.sq() * Q1) / Q.sq()
        T2 = J * ((2 * h1.sq() + 2 * h * h2) / Q - 4 * h * h1 * Q1 / Q.sq() - h.sq() * Q2 / Q.sq()
                  + 2 * h.sq() * Q1.sq() / (Q.sq() * Q))
    else:
        T = J * h.sq() / ga
        T1 = 2 * J * h * h1 / ga
        T2 = J * (2 * h1.sq() + 2 * h * h2) / ga
    v = al * u + NY + al * rho - T
    d1 = al * u + NY1 - T1
    d2 = al * u + NY2 - T2
    return v, d1, d2


def phi_dmu(P, Y, al, ga, AD, ald, gad, ADd, rho, J, tag):
    """enclosure of d/dmu of Phi / Phi^gamma at fixed (Y, rho, J) on a box (Lemma tr:lem:dmu)"""
    Y = I.c(Y)
    u, p, k, w, pp = P['u'], P['p'], P['k'], P['w'], P['pp']
    h = 1 - p + ga * k
    hd = -pp - ga * k * w + gad * k
    Nd = ADd - hd - ald / k - al * w / k
    base = (ald - al) * u + Nd / Y + ald * rho
    if tag == 'Phi':
        Lb = ga * u - h * Y
        Q = ga + J * Lb
        Qd = gad + J * (gad * u - ga * u - hd * Y)
        return base - J * (2 * h * hd * Q - h.sq() * Qd) / Q.sq()
    return base - J * (2 * h * hd / ga - h.sq() * gad / ga.sq())


# ------------------------------------------------------------------ the CA bound C(Y) = alpha B(Y) + gamma Lb/(gamma + Jbar Lb)
def C_jet(P, Y, lam_mu, al, ga, Jb, eY):
    """jets of C at fixed lambda; lam_mu: interval of mu = log(lam); eY: interval of e^Y"""
    Y = I.c(Y)
    u, p, k, w, pp = P['u'], P['p'], P['k'], P['w'], P['pp']
    h = 1 - p + ga * k
    h1 = pp + ga * k * w
    h2 = -(pp * (1 - 2 * p)) + ga * k * (w.sq() + k * w - pp)
    em1 = eY - 1
    n = lam_mu - log_I(em1) - 1 / k
    n1 = -(eY / em1) + w / k
    n2 = eY / em1.sq() + w - pp / k - w.sq() / k
    B = u + n / Y
    B1 = u + (n1 * Y - n) / Y.sq()
    B2 = u + (n2 * Y.sq() - 2 * n1 * Y + 2 * n) / (Y.sq() * Y)
    Lb = ga * u - h * Y
    Lb1 = ga * u - h - h1 * Y
    Lb2 = ga * u - 2 * h1 - h2 * Y
    De = ga + Jb * Lb
    F = ga * Lb / De
    F1 = ga.sq() * Lb1 / De.sq() if isinstance(ga, I) else ga * ga * Lb1 / De.sq()
    F2 = (ga * ga) * Lb2 / De.sq() - 2 * Jb * (ga * ga) * Lb1.sq() / (De.sq() * De)
    return al * B + F, al * B1 + F1, al * B2 + F2


def C_dmu(P, Y, mu, al, ga, ald, gad, Jb, eY):
    Y = I.c(Y)
    u, p, k, w, pp = P['u'], P['p'], P['k'], P['w'], P['pp']
    h = 1 - p + ga * k
    hd = -pp - ga * k * w + gad * k
    B = u + (mu - log_I(eY - 1) - 1 / k) / Y
    l = h * Y - ga * u
    De = ga - Jb * l
    return ald * B + al * (-u + (1 - w / k) / Y) + (gad * Jb * l.sq() - ga.sq() * (hd * Y - gad * u + ga * u)) / De.sq()


# ------------------------------------------------------------------ bounds
def two_ended(f0, f0d, f1, f1d, m2, Y0, Y1):
    """Proposition arc:prop:ac: phi >= max(Lam0, Lam1) on [Y0,Y1]; returns a rational lower bound of min over [Y0,Y1].
    f0,f0d,f1,f1d intervals (values, slopes at the ends); m2 <= min(0, inf phi'')."""
    assert m2 <= 0
    Y0, Y1 = Fr(Y0), Fr(Y1)
    a0, s0 = f0.lo, f0d.lo
    a1, s1 = f1.lo, f1d.hi
    cands = [a0, a1]
    # Lam0 - Lam1 affine in Y: Lam0(Y) = a0 + s0 (Y-Y0) + m2/2 (Y-Y0)^2 ; Lam1(Y) = a1 + s1 (Y-Y1) + m2/2 (Y-Y1)^2
    # difference: a0 - a1 + s0 (Y - Y0) - s1 (Y - Y1) + m2/2 [ (Y-Y0)^2 - (Y-Y1)^2 ]
    #  (Y-Y0)^2-(Y-Y1)^2 = (Y1-Y0)(2Y - Y0 - Y1)
    c1 = s0 - s1 + m2 * (Y1 - Y0)            # coefficient of Y
    c0 = a0 - a1 - s0 * Y0 + s1 * Y1 - m2 / 2 * (Y1 - Y0) * (Y0 + Y1)
    if c1 != 0:
        Ys = -c0 / c1
        if Y0 < Ys < Y1:
            L0 = a0 + s0 * (Ys - Y0) + m2 / 2 * (Ys - Y0) ** 2
            L1 = a1 + s1 * (Ys - Y1) + m2 / 2 * (Ys - Y1) ** 2
            cands.append(min(L0, L1))
    return min(cands)


def centred(fc, fcd, m2, d):
    assert m2 <= 0
    return fc.lo - fcd.mag() * d + m2 / 2 * d * d


def transport(beta, dI, dminus, dplus):
    """Lemma tr:lem:mvt"""
    return beta - max(dplus * max(Fr(0), -dI.lo), dminus * max(Fr(0), dI.hi))


def deltas(la, lb, lc):
    dm = log_r(Fr(lc) / Fr(la))[1]
    dp = log_r(Fr(lb) / Fr(lc))[1]
    return dm, dp
