#!/usr/bin/python3
"""Direct sanity check of the certificate inequality (F) of the lower-tail certificate at the binding atom of each
covering: rhs_T(M) <= kappa(q;M,j) + xi*(j-qM) + eta*(j-qM)^2 at 9 equally spaced exact q in [q_l, q_h], with
kappa = f_L/q + f_R/(1-q), f_L = (1-q)b(j) - q b(j-1), f_R = q b(j) - (1-q) b(j+1) from the binomial law itself
(not from the atom bounds).  Exact rationals.  Also checks the reported slack is <= the pointwise minimum."""
import csv, pickle, sys, math
from gmpy2 import mpq
out = sys.argv[1]
tag = sys.argv[2] if len(sys.argv) > 2 else "full"
covs = {c["name"]: c for c in pickle.load(open(f"{out}/coverings.pkl", "rb"))}
Q = lambda f: mpq(int(f.numerator), int(f.denominator))
def b(M, j, q):
    if j < 0 or j > M: return mpq(0)
    return mpq(math.comb(M, j)) * q ** j * (1 - q) ** (M - j)
nbad = 0; n = 0; lines = []
for r in csv.DictReader(open(f"{out}/coverings_{tag}.csv")):
    bi, M, j = (int(x) for x in r["least_F_box_M_j"].split("/"))
    bx = covs[r["covering"]]["boxes"][bi]
    ql, qh, m0 = Q(bx["ql"]), Q(bx["qh"]), Q(bx["m0"])
    eta, xi, al, be, ga = (Q(bx[k]) for k in ("mu", "c", "alpha", "beta", "gamma"))
    z = [Q(x) for x in bx["z"]]
    rhs = al + be * (M - m0) - ga * (M - m0) ** 2 - sum(z[M:], mpq(0))
    worst = None
    for k in range(9):
        q = ql + (qh - ql) * k / 8
        fL = (1 - q) * b(M, j, q) - q * b(M, j - 1, q)
        fR = q * b(M, j, q) - (1 - q) * b(M, j + 1, q)
        d = j - q * M
        v = fL / q + fR / (1 - q) + xi * d + eta * d * d - rhs
        n += 1
        if v < 0: nbad += 1
        worst = v if worst is None or v < worst else worst
    rep = float(r["least_F_atom_slack"])
    lines.append(f"{r['covering']} box {bi} M={M} j={j}: reported slack {rep:.4e}, pointwise min over 9 q {float(worst):.4e} {'OK' if worst >= 0 and rep <= float(worst) + 1e-15 else 'CHECK'}")
lines.append(f"pointwise evaluations {n}, negative {nbad}")
open(f"{out}/pointwise_binding_{tag}.txt" if tag != "full" else f"{out}/pointwise_binding.txt", "w").write("\n".join(lines) + "\n")
print("\n".join(lines[-6:]))
