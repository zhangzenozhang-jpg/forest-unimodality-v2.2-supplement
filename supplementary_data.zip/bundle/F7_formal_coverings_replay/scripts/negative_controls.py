#!/usr/bin/python3
"""Negative controls: perturb single boxes (in memory only) and confirm the replay rejects them."""
import sys, pickle, copy
from fractions import Fraction as F
sys.path.insert(0, sys.argv[1])
import t1box_check as T
covs = pickle.load(open(sys.argv[2], "rb"))
byname = {c["name"]: c for c in covs}
stats = {"sample_checked": 0, "sample_mismatch": 0}

def run(cname, bi, mod, label):
    c = byname[cname]; b = copy.deepcopy(c["boxes"][bi])
    mod(b)
    lam = T.Q(c["band"]["lamHi"]) if c["tail"][0] == "const" else T.Q(b["qh"]) / (1 - T.Q(b["qh"]))
    r = T.check_box(c["band"], lam, b, stats)
    print(f"{cname} box {bi} [{label}]: ok={r['ok']} why={r['why'][:2]} Mg={r.get('Mg')} Fslack={r.get('F_slack')}")
    return r

for cname, bi in [("Atlas/L01", 0), ("Atlas/U01", 5), ("N45/P13", 102)]:
    r0 = run(cname, bi, lambda b: None, "unmodified")
    fs = r0["F_slack"][0]; mg = r0["Mg"]
    run(cname, bi, lambda b: b.__setitem__("alpha", b["alpha"] + F(2 * fs).limit_denominator(10**30) + F(1, 10**30)), "alpha += 2*Fslack (F must fail)")
    run(cname, bi, lambda b: b.__setitem__("alpha", b["alpha"] - F(2 * mg).limit_denominator(10**30)), "alpha -= 2*Mg (Mg must fail)")
    run(cname, bi, lambda b: b.__setitem__("N", b["N"] // 2), "N halved (T must fail)")
    run(cname, bi, lambda b: (b.__setitem__("mu", b["c"]), b.__setitem__("c", b["mu"])), "mu<->c swapped")
    run(cname, bi, lambda b: b.__setitem__("z", [F(0)] + list(b["z"])), "z shifted by one index")
    run(cname, bi, lambda b: b.__setitem__("cm", b["cm"] + 1), "cm = ceil(ml)+1 (S must fail)")
