#!/usr/bin/python3
"""The 78 split boxes of the coarse lower covering: each pair keeps the dual and the centre m0, the halves are
[ml, m0] and [m0, mh] with m0 the midpoint of the merged box; and the merged (unsplit) box fails the (Mg) test with
the band-edge tail base while both halves pass (the paper's stated reason for the split)."""
import sys, pickle, copy
from fractions import Fraction as F
sys.path.insert(0, sys.argv[1])
import t1box_check as T
covs = pickle.load(open(sys.argv[2], "rb"))
stats = {"sample_checked": 0, "sample_mismatch": 0}
keyf = lambda b: (b["ql"], b["qh"], b["m0"], b["mu"], b["c"], b["alpha"], b["beta"], b["gamma"], tuple(b["z"]))
npairs = nmid = nmerged_fail = nhalves_pass = 0; lines = []
for c in covs:
    if c["family"] != "coarse_lower": continue
    groups = {}
    for i, b in enumerate(c["boxes"]):
        groups.setdefault(keyf(b), []).append(i)
    lam = T.Q(c["band"]["lamHi"])
    for k, ids in groups.items():
        if len(ids) != 2: continue
        a, b = sorted((c["boxes"][i] for i in ids), key=lambda x: x["ml"])
        if a["mh"] != b["ml"]: continue
        npairs += 1
        if a["mh"] == a["m0"] and (a["ml"] + b["mh"]) / 2 == a["m0"]: nmid += 1
        mg = copy.deepcopy(a); mg["mh"] = b["mh"]; mg["cm"] = a["cm"]; mg["N"] = max(a["N"], b["N"])
        r = T.check_box(c["band"], lam, mg, stats)
        if not r["ok"] and r["why"] == ["Mg"]: nmerged_fail += 1
        else: lines.append(f"{c['name']} pair {ids}: merged box ok={r['ok']} why={r['why']} Mg={r.get('Mg')}")
        ra = T.check_box(c["band"], lam, a, stats); rb = T.check_box(c["band"], lam, b, stats)
        if ra["ok"] and rb["ok"]: nhalves_pass += 1
        else: lines.append(f"{c['name']} pair {ids}: half failed")
lines.append(f"split pairs {npairs}; split at the centre m0 = midpoint of the merged box: {nmid}; "
             f"merged box fails (Mg) only: {nmerged_fail}; both halves pass: {nhalves_pass}")
open(sys.argv[3], "w").write("\n".join(lines) + "\n")
print("\n".join(lines[-8:]))
