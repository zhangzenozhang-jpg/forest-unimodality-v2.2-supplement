#!/usr/bin/python3
"""Cross-check of the evaluated parameters (lamLo, lamHi, mmin, cap) of each covering against the ranges printed in
the docstring of its data module ('The slabs cover `[q(a), q(b)] x [c, d]`' and the header activity band).
Documentation only; the replay itself uses the parameters evaluated from the Params definitions."""
import re, pickle, sys
from fractions import Fraction as F
out = sys.argv[1]
covs = pickle.load(open(f"{out}/coverings.pkl", "rb"))
def fr(s):
    s = s.strip()
    return F(s) if s else None
lines = []; nok = nbad = nmiss = 0
for c in covs:
    t = open(c["data_file"], encoding="utf-8").read()
    m = re.search(r"slabs cover `\[q\(([^)]*)\), q\(([^)]*)\)\] × \[([^,\]]+), ([^\]]+)\]`", t)
    h = re.search(r"activity(?: band)? `\[([^,]+), ([^\]]+)\]`", t)
    b = c["band"]
    got = {}
    if m:
        a1, a2, mlo, mhi = m.groups()
        if "λ" not in a1:
            got["lamLo"] = fr(a1); got["lamHi"] = fr(a2)
        got["mmin"] = fr(mlo); got["cap"] = fr(mhi)
    if h:
        got.setdefault("lamLo", fr(h.group(1))); got.setdefault("lamHi", fr(h.group(2)))
    if not got:
        nmiss += 1; lines.append(f"{c['name']}: no docstring range"); continue
    mine = {"lamLo": b["lamLo"], "lamHi": b["lamHi"], "mmin": b["mmin"], "cap": c["cap"]}
    bad = [k for k in got if got[k] != mine[k]]
    if bad:
        nbad += 1; lines.append(f"{c['name']}: MISMATCH " + ", ".join(f"{k}: doc {got[k]} vs evaluated {mine[k]}" for k in bad))
    else:
        nok += 1
lines.append(f"docstring ranges agree on {nok} coverings, mismatch on {nbad}, absent on {nmiss}")
open(f"{out}/docstring_ranges.txt", "w").write("\n".join(lines) + "\n")
print("\n".join(lines[-12:]))
