#!/usr/bin/python3
"""Summaries of the full replay: per family; data-structure checks; comparison of the least (Mg) margin with the
'smallest margin (2)' stated in the docstrings of the data modules (documentation only, not checker logic)."""
import csv, pickle, re, sys, json
from fractions import Fraction as F
from collections import defaultdict
out = sys.argv[1]
tag = sys.argv[2] if len(sys.argv) > 2 else "full"
covs = pickle.load(open(f"{out}/coverings.pkl", "rb"))
rows = list(csv.DictReader(open(f"{out}/coverings_{tag}.csv")))
byname = {r["covering"]: r for r in rows}
fams = ["coarse_lower", "coarse_upper", "above_m52", "above_m48", "above_m45", "above_m44"]
expected = {"coarse_lower": (30, 1580), "coarse_upper": (30, 215), "above_m52": (30, 594), "above_m48": (31, 547),
            "above_m45": (30, 1969), "above_m44": (27, 935)}
lines = []
P = lines.append
P("family | verifications run/pass (expected) | entries (expected) | split pairs | fibers | atoms | exact atoms | least Mg @box | least Mg/alpha @box | least T slack | least F slack | runtime s")
tot = defaultdict(float)
for f in fams:
    rs = [r for r in rows if r["family"] == f]
    npass = sum(r["result"] == "PASS" for r in rs)
    ent = sum(int(r["boxes_entries"]) for r in rs)
    sp = sum(int(r["split_pairs"]) for r in rs)
    fib = sum(int(r["fibers"]) for r in rs); at = sum(int(r["atoms"]) for r in rs); ex = sum(int(r["atoms_exact"]) for r in rs)
    rt = sum(float(r["runtime_s"]) for r in rs)
    mg = min(rs, key=lambda r: float(r["least_Mg"])) if rs else None
    rl = min(rs, key=lambda r: float(r["least_Mg_rel"])) if rs else None
    ts = min(rs, key=lambda r: float(r["least_T_slack"])) if rs else None
    fs = min(rs, key=lambda r: float(r["least_F_atom_slack"])) if rs else None
    if rs:
        P(f"{f} | {len(rs)}/{npass} ({expected[f][0]}) | {ent} ({expected[f][1]}) | {sp} | {fib} | {at} | {ex} | "
          f"{mg['least_Mg']} {mg['covering']}#{mg['least_Mg_box']} | {rl['least_Mg_rel']} {rl['covering']}#{rl['least_Mg_rel_box']} | "
          f"{ts['least_T_slack']} {ts['covering']}#{ts['least_T_slack_box']} | {fs['least_F_atom_slack']} {fs['covering']}#{fs['least_F_box_M_j']} | {rt:.1f}")
    else:
        P(f"{f} | not run")
    tot["cov"] += len(rs); tot["pass"] += npass; tot["entries"] += ent; tot["atoms"] += at; tot["fibers"] += fib; tot["rt"] += rt
P(f"TOTAL verifications {int(tot['cov'])} pass {int(tot['pass'])}; entries {int(tot['entries'])}; fibers {int(tot['fibers'])}; atoms {int(tot['atoms'])}; runtime {tot['rt']:.1f}s")
# data-structure checks
P("")
P("data checks per covering: slabs, slabs with lo>hi, entries not used by any chain, duplicate entries, cm==ceil(ml)")
anyissue = False
for c in covs:
    sl = c["slabs"]; nb = len(c["boxes"])
    used = set(i for s in sl for i in s["chain"])
    unused = nb - len(used)
    lohi = sum(1 for s in sl if s["lo"] > s["hi"])
    keys = [tuple(sorted((k, str(v)) for k, v in b.items())) for b in c["boxes"]]
    dup = len(keys) - len(set(keys))
    r = byname.get(c["name"])
    if unused or lohi or dup or (r and r["cm_eq_ceil_ml_all"] != "True"):
        anyissue = True
        P(f"  {c['name']}: slabs={len(sl)} lo>hi={lohi} unused={unused} duplicates={dup} cm_ok={r['cm_eq_ceil_ml_all'] if r else '?'}")
if not anyissue:
    P("  none: every entry is used by some chain, no slab has lo>hi, no duplicate entries, cm = ceil(m_l) for every box")
# docstring margins
P("")
P("least (Mg) margin vs the 'smallest margin (2)' printed in the data module docstring (3 significant digits):")
nmatch = nmis = nnone = 0
for c in covs:
    t = open(c["data_file"], encoding="utf-8").read()
    m = re.search(r"smallest margin \(2\)[^:]*:\s*([0-9.]+e[+-]?\d+)", t)
    r = byname.get(c["name"])
    if not r: continue
    if not m:
        nnone += 1; continue
    doc = float(m.group(1)); mine = float(r["least_Mg"])
    if f"{doc:.3e}" == f"{mine:.3e}": nmatch += 1
    else:
        nmis += 1; P(f"  MISMATCH {c['name']}: docstring {doc:.3e} replay {mine:.3e}")
P(f"  docstring margin agrees (3 s.f.) on {nmatch} coverings, differs on {nmis}, no stated margin on {nnone}")
open(f"{out}/summary_{tag}.txt" if tag != "full" else f"{out}/summary.txt", "w").write("\n".join(lines) + "\n")
print("\n".join(lines))
