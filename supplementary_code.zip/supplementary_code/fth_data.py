"""Subinterval data of TWIN v2.1 (Part 1 of the supplementary data file), parsed exactly, and the
one-generation hand caps of certfree/o2 (Theorem o2:thm:B, 31 rows).  Read only; no computation here."""
from fractions import Fraction as Fr
import os, re

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, 'data', 'twin_v2.1_data.txt')


def _fr(s):
    return Fr(s.strip())


def subintervals():
    """List of dicts: iota, band, lo, hi (lambda), theta, D, ell0, m25, mstar (all Fractions)."""
    rows = []
    with open(DATA) as f:
        lines = f.read().splitlines()
    start = None
    for i, L in enumerate(lines):
        if L.startswith('PART 1.'):
            start = i
            break
    for L in lines[start:]:
        if L.startswith('Totals'):
            break
        m = re.match(r'^(\d+) \| (\d+) \| \[([^,]+), ([^\]]+)\] \| ([^|]+) \| ([^|]+) \| ([^|]+) \| ([^|]+) \| ([^|]+) \|', L)
        if m:
            rows.append(dict(iota=int(m.group(1)), band=int(m.group(2)), lo=_fr(m.group(3)), hi=_fr(m.group(4)),
                             theta=_fr(m.group(5)), D=_fr(m.group(6)), ell0=_fr(m.group(7)), m25=_fr(m.group(8)),
                             mstar=_fr(m.group(9))))
    assert len(rows) == 55, len(rows)
    return rows


# o2 caps (Theorem o2:thm:B): (a, b, theta) with theta = gamma - 1
O2_ROWS = [
    ('1/3', '37/100', '0.76'), ('37/100', '2/5', '0.74'), ('2/5', '11/25', '0.74'), ('11/25', '47/100', '0.72'),
    ('47/100', '51/100', '0.72'), ('51/100', '11/20', '0.72'), ('11/20', '29/50', '0.70'), ('29/50', '3/5', '0.69'),
    ('3/5', '16/25', '0.71'), ('16/25', '17/25', '0.70'), ('17/25', '18/25', '0.70'), ('18/25', '77/100', '0.71'),
    ('77/100', '81/100', '0.70'), ('81/100', '43/50', '0.71'), ('43/50', '9/10', '0.70'), ('9/10', '19/20', '0.71'),
    ('19/20', '1', '0.72'), ('1', '21/20', '0.72'), ('21/20', '11/10', '0.73'), ('11/10', '23/20', '0.73'),
    ('23/20', '121/100', '0.75'), ('121/100', '63/50', '0.75'), ('63/50', '33/25', '0.78'), ('33/25', '69/50', '0.79'),
    ('69/50', '143/100', '0.80'), ('143/100', '3/2', '0.85'), ('3/2', '39/25', '0.89'), ('39/25', '8/5', '0.90'),
    ('8/5', '9/5', '1.09'), ('9/5', '21/10', '1.34'), ('21/10', '7/3', '1.52')]


def o2_cap(lo, hi):
    """Least o2 cap valid on all of [lo, hi]: the max theta over the o2 rows meeting [lo, hi] (rows are closed)."""
    best = None
    for a, b, th in O2_ROWS:
        a, b = Fr(a), Fr(b)
        if b < lo or a > hi:
            continue
        # a row meeting the subinterval only at an end point still has to be used only if needed; take the rows
        # whose interior meets [lo, hi], plus the row containing a degenerate interval
        if (b == lo and hi > lo) or (a == hi and hi > lo):
            continue
        t = Fr(th)
        best = t if best is None else max(best, t)
    return best


if __name__ == '__main__':
    for r in subintervals():
        print(r['iota'], r['band'], r['lo'], r['hi'], r['theta'], r['D'], r['ell0'], float(r['m25']),
              float(r['mstar']), 'o2cap', o2_cap(r['lo'], r['hi']))
