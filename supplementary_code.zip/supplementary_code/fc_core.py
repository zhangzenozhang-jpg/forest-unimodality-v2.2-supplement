"""fiber_theorem_closed: closed-form bounds (core module).

Every function takes a context `C` (mpmath.mp for floating point DIAGNOSTICS, mpmath.iv for RIGOROUS interval
evaluation with outward rounding) so that the same formula is used in both.  The only non-elementary function is
s(L), the root of s + log(1+s) = L (s > -1); it is increasing, and its interval version returns a certified
enclosure built from two certified point bounds.

Notation as in fiber_theorem_hand.tex (version 3): r = |2q-1| in [0, rm], N = M+2,
nu = r sqrt(N) (called u there), t = M/mu, lambda_t = (5/2) log t, k in [3.55, 3.85 + 10/M].
"""
import math
from mpmath import mp, iv, mpf

mp.dps = 30
iv.dps = 30


def lo(x):
    return mpf(x.a) if hasattr(x, 'a') else mpf(x)


def hi(x):
    return mpf(x.b) if hasattr(x, 'b') else mpf(x)


def isiv(C):
    return C is iv


# ----------------------------------------------------------------------------------------------- the root map s(L)
def _s_float(L):
    L = float(L)
    a, b = -1 + 1e-17, max(1.0, L + 1.0)
    for _ in range(200):
        m = (a + b) / 2
        if m + math.log1p(m) < L:
            a = m
        else:
            b = m
    return (a + b) / 2


def _lam_iv(s):
    s = iv.mpf(s)
    return s + iv.log(1 + s)


def s_upper(L):
    """certified s_u >= s(L)."""
    L = mpf(L)
    s = mpf(_s_float(L))
    step = mpf(10) ** -14
    while lo(_lam_iv(s)) < L:
        s += step
        step *= 2
    return s


def s_lower(L):
    """certified s_l <= s(L), s_l > -1."""
    L = mpf(L)
    s = mpf(_s_float(L))
    step = mpf(10) ** -14
    while True:
        if s <= -1:
            s = (-1 + (s + step)) / 2
        if hi(_lam_iv(s)) <= L:
            return s
        s -= step
        step *= 2


def s_of(C, L):
    """s(L): float for mp; certified enclosure for iv (s is increasing)."""
    if isiv(C):
        L = iv.mpf(L)
        return iv.mpf([s_lower(lo(L)), s_upper(hi(L))])
    return mp.mpf(_s_float(L)) if abs(float(L)) < 50 else mp.findroot(lambda s: s + mp.log(1 + s) - L, 0.5)


def G_of(C, L):
    """G(L) = s^2/(1+s): decreasing on L <= 0, increasing on L >= 0, G(0) = 0."""
    if not isiv(C):
        s = s_of(C, L)
        return s * s / (1 + s)
    L = iv.mpf(L)
    def g_up(x):
        s = s_upper(x) if x >= 0 else s_lower(x)
        si = iv.mpf(s)
        return hi(si * si / (1 + si))
    def g_lo(x):
        s = s_lower(x) if x >= 0 else s_upper(x)
        si = iv.mpf(s)
        return lo(si * si / (1 + si))
    a, b = lo(L), hi(L)
    if b <= 0:
        return iv.mpf([g_lo(b), g_up(a)])
    if a >= 0:
        return iv.mpf([g_lo(a), g_up(b)])
    return iv.mpf([0, max(g_up(a), g_up(b))])


def G1_of(C, L):
    """G'(L) = s/(1+s), increasing."""
    s = s_of(C, L)
    if isiv(C):
        sa, sb = iv.mpf(lo(s)), iv.mpf(hi(s))
        return iv.mpf([lo(sa / (1 + sa)), hi(sb / (1 + sb))])
    return s / (1 + s)


def G2_of(C, L):
    """G''(L) = 1/((1+s)(2+s)), decreasing."""
    s = s_of(C, L)
    if isiv(C):
        sa, sb = iv.mpf(lo(s)), iv.mpf(hi(s))
        return iv.mpf([lo(1 / ((1 + sb) * (2 + sb))), hi(1 / ((1 + sa) * (2 + sa)))])
    return 1 / ((1 + s) * (2 + s))


def pos(C, x):
    """positive part."""
    if isiv(C):
        x = iv.mpf(x)
        return iv.mpf([max(lo(x), 0), max(hi(x), 0)])
    return x if x > 0 else C.mpf(0)


def imax(C, *xs):
    if isiv(C):
        xs = [iv.mpf(x) for x in xs]
        return iv.mpf([max(lo(x) for x in xs), max(hi(x) for x in xs)])
    return max(xs)


def imin(C, *xs):
    if isiv(C):
        xs = [iv.mpf(x) for x in xs]
        return iv.mpf([min(lo(x) for x in xs), min(hi(x) for x in xs)])
    return min(xs)


# ----------------------------------------------------------------------------------------------- the template
def template_T(C, t, M0):
    """T(t, M0) = min over k in {3.55, 3.85 + 10/M0} of M0 S(t) + 2 - 6 G0 - 2 k G1 - k^2 G2/(M0+3)
    (concave in k, so the end points suffice), with S = (9/2)(t-1)^2/t - 2 G0, G_i at lambda_t = (5/2) log t."""
    t = C.mpf(t) if not isiv(C) else iv.mpf(t)
    M0 = C.mpf(M0) if not isiv(C) else iv.mpf(M0)
    lam = C.mpf(5) / 2 * C.log(t)
    G0 = G_of(C, lam); G1 = G1_of(C, lam); G2 = G2_of(C, lam)
    S = C.mpf(9) / 2 * (t - 1) ** 2 / t - 2 * G0
    vals = []
    for k in (C.mpf('3.55'), C.mpf('3.85') + 10 / M0):
        vals.append(M0 * S + 2 - 6 * G0 - 2 * k * G1 - k * k * G2 / (M0 + 3))
    return imin(C, *vals)


# ----------------------------------------------------------------------------------------------- D_L in closed form
def alpha12(C, N, rm):
    """(N+1) e_L <= alpha1 nu + alpha2 nu^2 for 0 <= nu <= rm sqrt(N) (Lemma 4.3(a) of v3, linearised);
    both coefficients are nonincreasing in N."""
    N = C.mpf(N) if not isiv(C) else iv.mpf(N)
    rm = C.mpf(rm) if not isiv(C) else iv.mpf(rm)
    om = 1 - rm * rm
    Z02 = N / (N + 1) ** 2
    phim = 1 + 2 * rm / C.sqrt(N)
    KL = 1 + phim ** 2 / (1 - Z02 * phim ** 2)
    KR = 1 / (1 - (rm + C.sqrt(Z02)) ** 2)
    cL1 = 4 * KL / (N * om); cL2 = (4 * KL / N ** 2 + 1 / N) / om
    cR1 = 2 * KR / ((N + 1) * om); cR2 = (KR + 1) / (N * om)
    a1 = 2 / C.sqrt(om) + imax(C, cL1, cR1) / 12
    a2 = 2 / (N * om) + imax(C, cL2, cR2) / 12
    return a1, a2


def DL_closed(C, t, N0, M0, rm):
    """sup over nu in [0, rm sqrt(N)] and N >= N0 of D_L, by AM-GM:
    D_L <= (sigma0 alpha1)^2 / beta_L, sigma0 = s(lambda_t + kbar/(M0+3))_+."""
    t = iv.mpf(t) if isiv(C) else C.mpf(t)
    N0 = iv.mpf(N0) if isiv(C) else C.mpf(N0)
    M0 = iv.mpf(M0) if isiv(C) else C.mpf(M0)
    kbar = C.mpf('3.85') + 10 / M0
    lamL = C.mpf(5) / 2 * C.log(t) + kbar / (M0 + 3)
    sig0 = pos(C, s_of(C, lamL))
    a1, a2 = alpha12(C, N0, rm)
    rmC = C.mpf(rm) if not isiv(C) else iv.mpf(rm)
    num = C.sqrt(N0) * rmC
    ebar = (a1 * num + a2 * num ** 2) / (N0 + 1)
    beta = (N0 - 1) * (1 - ebar) - 2 * sig0 * a2 - 2 * a1 ** 2 / (N0 + 1) - 4 * a1 * a2 * num / (N0 + 1) \
        - 2 * a2 ** 2 * num ** 2 / (N0 + 1)
    return (sig0 * a1) ** 2 / beta, beta, sig0


# ----------------------------------------------------------------------------------------------- D_U in closed form
def rho_star(C, N, rm):
    N = iv.mpf(N) if isiv(C) else C.mpf(N)
    rm = iv.mpf(rm) if isiv(C) else C.mpf(rm)
    om = 1 - rm * rm
    c = 1 - 1 / N
    return om * N / (N + 1) - 2 / ((N + 1) * C.sqrt(c)) - rm * rm / (3 * om * C.sqrt(c))


def kappaA(C, N, rm):
    N = iv.mpf(N) if isiv(C) else C.mpf(N)
    rm = iv.mpf(rm) if isiv(C) else C.mpf(rm)
    om = 1 - rm * rm
    c = 1 - 1 / N
    return 2 + 2 * (N + 1) / (3 * N * om * C.sqrt(c))


def Ecoef(C, N, rm):
    """N e_U <= E(nu) = 2 nu + e2 nu^2 + e3 nu^3 + e4 nu^4 + e5 nu^5."""
    N = iv.mpf(N) if isiv(C) else C.mpf(N)
    rm = iv.mpf(rm) if isiv(C) else C.mpf(rm)
    om = 1 - rm * rm
    return (C.mpf(1) / 2, C.mpf(5) / (6 * om), (N + 1) / (12 * N * om ** 2), 1 / (12 * om ** 2))


def DU_closed(C, t, N0, M0, rm, numax=None):
    """D_U <= D_UA + g1 D_Ue (t < 1; D_U = 0 for t >= 1), with
    D_UA = 4 Ghat^2 / (rho*^2 (N0 - 1 - kappaA Ghat/rho*)),  D_Ue = 4/(rho*^2 beta_e),
    beta_e = N0 - 1 - (2/rho*)(e2 + e3 nm + e4 nm^2 + e5 nm^3),  nm = min(numax, rm sqrt(N0)),
    Ghat = max(G(lambda_t), G(lambda_t + kbar/(M0+3))), g1 = |G'(lambda_t)|."""
    t = iv.mpf(t) if isiv(C) else C.mpf(t)
    N0 = iv.mpf(N0) if isiv(C) else C.mpf(N0)
    M0 = iv.mpf(M0) if isiv(C) else C.mpf(M0)
    lam = C.mpf(5) / 2 * C.log(t)
    kbar = C.mpf('3.85') + 10 / M0
    Ghat = imax(C, G_of(C, lam), G_of(C, lam + kbar / (M0 + 3)))
    g1 = pos(C, -G1_of(C, lam))
    rs = rho_star(C, N0, rm)
    kA = kappaA(C, N0, rm)
    DUA = 4 * Ghat ** 2 / (rs ** 2 * (N0 - 1 - kA * Ghat / rs))
    e2, e3, e4, e5 = Ecoef(C, N0, rm)
    rmC = iv.mpf(rm) if isiv(C) else C.mpf(rm)
    nm = C.sqrt(N0) * rmC
    if numax is not None:
        nm = imin(C, nm, numax)
    beta_e = N0 - 1 - (2 / rs) * (e2 + e3 * nm + e4 * nm ** 2 + e5 * nm ** 3)
    DUe = 4 / (rs ** 2 * beta_e)
    return DUA + g1 * DUe, (DUA, DUe, g1, beta_e, rs)


# ----------------------------------------------------------------------------------------------- block versions
def rho_star_block(N0, nm, rm):
    """rho_U >= (1-rm^2) N0/(N0+1) - [2 nm/(N0+1) + nm^3/(3 N0 (1-rm^2))]/sqrt(1 + (1-1/N0) nm^2)
    for every N >= N0 and nu <= nm (eps'/sqrt(gamma) is increasing in nu and decreasing in N)."""
    N0 = iv.mpf(N0); nm = iv.mpf(nm); rm = iv.mpf(rm)
    om = 1 - rm * rm
    c0 = 1 - 1 / N0
    return om * N0 / (N0 + 1) - (2 * nm / (N0 + 1) + nm ** 3 / (3 * N0 * om)) / iv.sqrt(1 + c0 * nm * nm)


def kappaA_block(N0, nm, rm):
    """A1 <= 4 nu + kappa nu^2 for nu <= nm, N >= N0: kappa = 2 + (2(N0+1)/(3 N0 (1-rm^2))) nm/sqrt(1+(1-1/N0) nm^2)."""
    N0 = iv.mpf(N0); nm = iv.mpf(nm); rm = iv.mpf(rm)
    om = 1 - rm * rm
    c0 = 1 - 1 / N0
    return 2 + (2 * (N0 + 1) / (3 * N0 * om)) * nm / iv.sqrt(1 + c0 * nm * nm)


def supq_iv(b, c, nm):
    """rigorous upper bound of sup over nu in [0, nm] of (b nu - c nu^2), b >= 0."""
    b = iv.mpf(b); c = iv.mpf(c); nm = iv.mpf(nm)
    if lo(c) > 0:
        return min(hi(b * b / (4 * c)), hi(b * nm))
    return hi(b * nm - iv.mpf(lo(c)) * nm * nm)


def DU_block(Gh, g1, N0, nm, rm, rs=None, kA=None):
    """D_U' <= sup_nu[(4 nu + kA nu^2) Gh/rs - (N0-1) nu^2] + g1 sup_nu[2 E(nu)/rs - (N0-1) nu^2], nu in [0, nm]."""
    Gh = iv.mpf(Gh); g1 = iv.mpf(g1); N0 = iv.mpf(N0); nm = iv.mpf(nm)
    if rs is None:
        rs = rho_star_block(N0, nm, rm)
    if kA is None:
        kA = kappaA_block(N0, nm, rm)
    assert lo(rs) > 0
    DUA = supq_iv(4 * Gh / rs, N0 - 1 - kA * Gh / rs, nm)
    e2, e3, e4, e5 = Ecoef(iv, N0, rm)
    DUe = supq_iv(4 / rs, N0 - 1 - (2 / rs) * (e2 + e3 * nm + e4 * nm ** 2 + e5 * nm ** 3), nm)
    return hi(iv.mpf(max(DUA, mpf(0))) + g1 * iv.mpf(max(DUe, mpf(0))))


def a4_margins(rm, Nlo):
    """Lemma 2.4 (lambda_U >= lambda_t) for r <= rm and N >= Nlo: returns the three margins
    (f(Nlo), rho*(Nlo)/2 - dE, tail at N = (6/rm)^2); all must be > 0 (if Nlo >= (6/rm)^2 only the tail form is used)."""
    rm = iv.mpf(rm); Nlo = iv.mpf(Nlo)
    def E2(N, cap=None):
        e2, e3, e4, e5 = Ecoef(iv, N, rm)
        nm = iv.sqrt(N) * rm
        if cap is not None:
            nm = iv.mpf(min(hi(nm), mpf(cap)))
        return e2 + e3 * nm + e4 * nm ** 2 + e5 * nm ** 3
    Nmax = (6 / rm) ** 2
    rs = rho_star(iv, Nlo, rm)
    f = (Nlo - 1) * rs / 2 - E2(Nlo, cap=6) - (Nlo + 1) / (iv.mpf('3.55') * Nlo)
    e2, e3, e4, e5 = Ecoef(iv, Nlo, rm)
    dE = e3 * rm / (2 * iv.sqrt(Nlo)) + e4 * rm ** 2 + iv.mpf(3) / 2 * e5 * rm ** 3 * iv.sqrt(Nmax)
    d = rs / 2 - dE
    NC = iv.mpf(Nmax)
    E2c = E2(NC, cap=6)
    rNC = rho_star(iv, NC, rm)
    v1 = iv.mpf(355) / 100 * (NC * (NC - 1) * rNC / 2 - NC * E2c) - (NC + 1)
    v2 = (2 * NC - 1) * rNC / 2 - E2c - 1 / iv.mpf('3.55')
    return lo(f), lo(d), min(lo(v1), lo(v2))


# ----------------------------------------------------------------------------------------------- directed decimal printing
def _as_fraction(x):
    """exact rational value of an mpf, an int, a Fraction or a decimal string."""
    from fractions import Fraction
    if isinstance(x, (Fraction, int)):
        return Fraction(x)
    if isinstance(x, str):
        return Fraction(x)
    sign, man, e, bc = mpf(x)._mpf_
    m = -int(man) if sign else int(man)
    e = int(e)
    return Fraction(m) * (Fraction(2) ** e) if e >= 0 else Fraction(m, 2 ** (-e))


def _sig(x, k, up):
    import math
    from fractions import Fraction
    from decimal import Decimal
    v = _as_fraction(x)
    if v == 0:
        return '0'
    if v < 0:
        s = _sig(-v, k, not up)
        return '-' + s
    e = 0
    while Fraction(10) ** e > v:
        e -= 1
    while Fraction(10) ** (e + 1) <= v:
        e += 1
    scale = Fraction(10) ** (k - 1 - e)
    c = math.ceil(v * scale) if up else math.floor(v * scale)
    if c == 10 ** k:
        c, e = 10 ** (k - 1), e + 1
    out = format(Decimal(c).scaleb(e - k + 1), 'f')
    if '.' in out:
        out = out.rstrip('0').rstrip('.')
    return out


def ceil_sig(x, k):
    """decimal string of the least number with k significant digits that is >= x (exact)."""
    return _sig(x, k, True)


def floor_sig(x, k):
    """decimal string of the largest number with k significant digits that is <= x (exact)."""
    return _sig(x, k, False)
