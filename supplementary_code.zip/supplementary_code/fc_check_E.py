#!/usr/bin/python3
"""fiber_theorem_closed: the checks added after the referee report (REFEREE.md,
fixes 1-3), RIGOROUS (mpmath.iv, 30 digits, one process).  Writes logs/fc_check_E.log.

(A3')  beta_e(N) = N - 1 - (2/rho*(N)) E2(N), E2 = e2 + e3 nu_m + e4(N) nu_m^2 + e5 nu_m^3, nu_m = min(6, r_m sqrt N), is
       nondecreasing on [N_lo, oo) for every (r_m, N_lo) at which an all-nu AM-GM bound is evaluated once and used for all
       N >= N_lo.  On [N_lo, (6/r_m)^2]: beta_e' >= 1 - (2/rho*(N_lo)) (e3 r_m/(2 sqrt N_lo) + e4(N_lo) r_m^2
       + (3/2) e5 r_m^3 sqrt((6/r_m)^2)) (rho*' >= 0, e4' <= 0); beyond (6/r_m)^2, nu_m = 6 is constant and beta_e increases
       termwise.  Uses: the wing classes (D_e), the first (A2) cell (N_0 = 13.392 < 13.4), the last M-block of every
       window-class spike cell.  [(A3) already covers r_m = 1/4 from N = 13.4, which includes the band spike cells.]
(A4m)  in check (A4d) the term ytilde R/(N+1) of e_U is evaluated at the block's upper N.  Its N-derivative is
       h(r,N)/(4R) with h = a (1 + 2 r^2 (N-1)) - 2 r (1-4r^2)(N-1)/(N+1)^2, a = artanh r - r, R = sqrt(N + r^2 (N-1)^2);
       dh/dN = 2 a r^2 + 2 r (1-4r^2)(N-3)/(N+1)^3 >= 0 for N >= 3, r <= 1/2, so h(r,N) >= h(r,11.45) for N >= 11.45, and
       the check is h(r, 11.45) > 0 for r in [0.3793, 0.5] (termwise on r-cells: a and r^2 increase, r(1-4r^2) decreases
       on r >= 0.29).  It is increasing in r as well (ytilde and R increase in r).
(D1')  (c3) of Lemma 6.2 in a form monotone in N: 12(1-(r+Z_R)^2)/(1-r^2) >= 3 (it implies (c3) because rho < 1;
       Z_R = 2 sqrt(3vN)/(N+1) decreases in N), at N0min = mu_D tau + 2 for the eight classes, and at the least N of every
       window-class spike cell where the window bound is used.
"""
import os, sys
from fractions import Fraction as Fr
from mpmath import iv, mpf
from fc_core import lo, hi, rho_star, Ecoef
from fc_window import conditions, umono_derivative

iv.dps = 30
F = iv.mpf
HERE = os.path.dirname(os.path.abspath(__file__))
LOG = open(os.path.join(HERE, 'logs', 'fc_check_E.log'), 'w')
ITEMS = []


def P(*a):
    print(*a, file=LOG, flush=True)


def item(tag, statement, rng, method, margin):
    ok = margin > 0
    ITEMS.append((tag, statement, rng, method, margin, ok))
    P('%-8s %-6s least margin %-12s | %s | range %s | %s' % (tag, 'PASS' if ok else 'FAIL', '%.6g' % float(margin),
                                                            statement, rng, method))
    return ok


# ----------------------------------------------------------------------------------------------- (A3')
def beta_e_deriv_lb(rm, Nlo):
    rm = F(rm); Nlo = F(Nlo)
    Nmax = (6 / rm) ** 2
    if lo(Nlo) >= hi(Nmax):
        return None, Nmax
    e2, e3, e4, e5 = Ecoef(iv, Nlo, rm)
    rs = rho_star(iv, Nlo, rm)
    dE = e3 * rm / (2 * iv.sqrt(Nlo)) + e4 * rm ** 2 + F(3) / 2 * e5 * rm ** 3 * iv.sqrt(Nmax)
    return lo(1 - (2 / rs) * dE), Nmax


def A3p(label, rm, Nlo):
    v, Nmax = beta_e_deriv_lb(rm, Nlo)
    if v is None:
        item('A3p', "beta_e nondecreasing: %s (N_lo >= (6/r_m)^2, nu_m = 6 constant: termwise)" % label,
             'r_m = %s, N >= %.2f' % (rm, float(lo(F(Nlo)))), 'interval: margin = N_lo - (6/r_m)^2',
             lo(F(Nlo) - Nmax))
    else:
        item('A3p', "beta_e nondecreasing: %s; beta_e'(N) >= 1 - (2/rho*)(e3 r_m/(2 sqrt N_lo) + e4 r_m^2 + 1.5 e5 r_m^3 (6/r_m))"
             % label, 'r_m = %s, N in [%.2f, %.1f], then termwise' % (rm, float(lo(F(Nlo))), float(hi(Nmax))),
             'interval (constants)', v)


# wing classes: N_0 = mu_W tau + 2 at the class's least t (fc_check_C.py: M0 = mu_W t_a, N0 = M0 + 2)
for (name, rb, muW, tau) in [('Wa', '0.0741', 19, '0.58'), ('Wb', '0.1112', 20, '0.55'), ('Wc', '0.1667', 26, '0.52')]:
    A3p('wing class %s (D_e of Lemma 5.1)' % name, rb, F(lo(F(muW) * F(tau))) + 2)
# the first (A2) cell: M_0 = 19 t(-0.528), N_0 = M_0 + 2 = 13.392
t0 = (iv.exp(F('-0.528')) * (1 + F('-0.528'))) ** (F(2) / 5)
A3p('first (A2) cell (N_0 = 19 t(-0.528) + 2)', '0.25', F(lo(19 * t0)) + 2)
# Theorem 3.1(ii) (optional variant, r <= 0.28, mu >= 30): its first cell starts at N_0 = 30 t(-0.528) + 2 = 19.988 < 20
A3p('first (A2) cell of Theorem 3.1(ii) (r <= 0.28, mu >= 30; N_0 = 30 t(-0.528) + 2)', '0.28', F(lo(30 * t0)) + 2)
# window-class spike cells, last M-block [16 M_a, oo), M_a = max(8, mu_D t_a), r_m = r_b of the class
class _D:
    pass
D = _D()
_src = open(os.path.join(HERE, 'fc_check_D.py')).read()
_ns = {'Fr': Fr, 'mpf': mpf}
exec(_src[_src.index('CLASSES = ['):_src.index('def fr(x):')], _ns)   # the class data only (no checks are run)
D.CLASSES = _ns['CLASSES']; D.SEDGES = _ns['SEDGES']
for (name, ra, rb, b, beta, tau, thi, muD, iotas) in D.CLASSES:
    worst = None; how = None
    for ta in D.SEDGES[name][:-1]:
        Ma = F(max(mpf(8), lo(F(muD) * F(ta))))
        Nlo = 16 * Ma + 2
        v, Nmax = beta_e_deriv_lb(rb, Nlo)
        if v is None:
            v = lo(Nlo - Nmax) if False else None
        if v is not None:
            worst = v if worst is None else min(worst, v)
        else:
            how = 'termwise' if how is None else how
    if worst is None:
        # every cell is in the constant-nu_m regime: record the least N_lo - (6/r_b)^2
        Ma0 = F(max(mpf(8), lo(F(muD) * F(D.SEDGES[name][0]))))
        A3p('class %s spike cells, last M-block (all cells: N_lo >= (6/r_b)^2)' % name, rb, 16 * Ma0 + 2)
    else:
        item('A3p', "beta_e nondecreasing: class %s spike cells, last M-block [16 M_a, oo) (least over the cells; cells with "
             "N_lo >= (6/r_b)^2 are termwise)" % name, 'r_m = %s, N >= 16 M_a + 2' % rb, 'interval (constants)', worst)


# ----------------------------------------------------------------------------------------------- (A4m)
def atanh(x):
    return iv.log((1 + x) / (1 - x)) / 2


def h_lb(r1, r2, N=F('11.45')):
    """termwise lower bound of h(r, N) on r in [r1, r2] (r1 >= 0.29): a(r), r^2 increase; r(1-4r^2) decreases."""
    r1 = F(r1); r2 = F(r2)
    a1 = atanh(r1) - r1
    return lo(a1 * (1 + 2 * r1 ** 2 * (N - 1)) - 2 * (r1 * (1 - 4 * r1 ** 2)) * (N - 1) / (N + 1) ** 2)


worst = None
nr = 24
for i in range(nr):
    r1 = lo(F('0.3793')) + (mpf('0.5') - lo(F('0.3793'))) * i / nr
    r2 = lo(F('0.3793')) + (mpf('0.5') - lo(F('0.3793'))) * (i + 1) / nr
    v = h_lb(r1, r2)
    worst = v if worst is None else min(worst, v)
item('A4m', 'ytilde R/(N+1) nondecreasing in N (used in (A4d)): h(r, 11.45) > 0, h nondecreasing in N for N >= 3',
     'r in [0.3793, 0.5], N >= 11.45', 'interval, %d r-cells, termwise' % nr, worst)


# ----------------------------------------------------------------------------------------------- (D1')
def c3_mono(ra, rb, N, ncell=20):
    """least lower bound of 12(1-(r+Z_R)^2)/(1-r^2) - 3 over r in [ra, rb] at this N (interval on r-cells)."""
    N = F(N); ra = F(ra); rb = F(rb)
    worst = None
    for i in range(ncell):
        r = F([lo(ra + (rb - ra) * i / ncell), hi(ra + (rb - ra) * (i + 1) / ncell)])
        v = (1 - r * r) / 4
        ZR = 2 * iv.sqrt(3 * v * N) / (N + 1)
        c3 = 12 * (1 - (r + ZR) ** 2) / (1 - r * r) - 3
        worst = lo(c3) if worst is None else min(worst, lo(c3))
    return worst


for (name, ra, rb, b, beta, tau, thi, muD, iotas) in D.CLASSES:
    N0min = F(muD) * F(tau) + 2
    item('D1p', "class %s: (c3') 12(1-(r+Z_R)^2)/(1-r^2) >= 3 at N0min (implies (c3); nondecreasing in N)" % name,
         'r in [%s, %s], N >= %.2f' % (ra, rb, float(lo(N0min))), 'interval, 20 r-cells', c3_mono(ra, rb, N0min))
    # spike cells where the window bound is used (same test as fc_check_D.py)
    worst = None; nused = 0
    raF, rbF = F(ra), F(rb)
    for ta in D.SEDGES[name][:-1]:
        Na = F(max(mpf(10), lo(F(muD) * F(ta) + 2)))
        if conditions(raF, rbF, Na) > 0 and umono_derivative(raF, rbF, Na) > 0:
            nused += 1
            v = c3_mono(ra, rb, Na)
            worst = v if worst is None else min(worst, v)
    if nused:
        item('D1p', "class %s: (c3') at the least N of the %d spike cell(s) that use the window bound" % (name, nused),
             'r in [%s, %s], N >= cell N_a' % (ra, rb), 'interval, 20 r-cells per cell', worst)
    else:
        P('class %s: no spike cell uses the window bound' % name)

n = len(ITEMS); nf = sum(1 for x in ITEMS if not x[5])
P('SUMMARY: %d items, %d FAIL; least margin %s' % (n, nf, min(float(x[4]) for x in ITEMS)))
LOG.close()
print('done', n, nf)
