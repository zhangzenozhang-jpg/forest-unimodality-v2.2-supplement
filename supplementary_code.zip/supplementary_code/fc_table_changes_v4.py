"""List every printed table value that changed in version 4 (old tables *_v3.tex and old B3 log lines *_pre_v4.log
against the new ones).  Writes logs/table_value_changes_v4.txt.  No computation; text comparison only."""
import os, re, sys
from fractions import Fraction as Fr
HERE = os.path.dirname(os.path.abspath(__file__))
OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, 'logs')
sys.path.insert(0, HERE)
from fc_core import ceil_sig
W = open(os.path.join(OUT, 'table_value_changes_v4.txt'), 'w')
def P(*a):
    print(*a, file=W)
P('Table value changes, version 4 (upper bounds rounded up, margins rounded down).')
P('== Table 4 of the note / table_b3.tex: B3 bounds, old = nearest rounding at 4 digits (old logs), new = ceiling at 4 digits')
nb = 0; nch = 0
for fn in ['fc_check_B', 'fc_check_D']:
    old = [L for L in open(os.path.join(OUT, fn + '_pre_v4.log')) if L.startswith('B3')]
    new = [L for L in open(os.path.join(OUT, fn + '.log')) if L.startswith('B3')]
    assert len(old) == len(new)
    for a, b in zip(old, new):
        va = dict(t.split(':') for t in re.match(r'^B3\s+bounds (.*?) \|', a).group(1).split())
        vb = dict(t.split(':') for t in re.match(r'^B3\s+bounds (.*?) \|', b).group(1).split())
        rng = re.search(r'range t in \[(\S+), (\S+)\]', a).groups()
        mc = re.search(r'class (O\d)', a)
        cell = (mc.group(1).replace('O', 'C_') if mc else 'central') + ' [%s, %s]' % rng
        ch = []
        for m in ('m1', 'm2', 'm4', 'm8', 'm16'):
            nb += 1
            new4 = ceil_sig(Fr(vb[m]), 4)
            if Fr(new4) != Fr(va[m]):
                nch += 1
                ch.append('%s: %s -> %s (certified <= %s)' % (m, va[m], new4, vb[m]))
        if ch:
            P('  %-22s %s' % (cell, '; '.join(ch)))
P('  %d of %d B3 values change' % (nch, nb))
for t in ['table_checks', 'table_rows', 'table_families_named', 'table_families']:
    old = open(os.path.join(OUT, t + '_v3.tex')).read().splitlines()
    new = open(os.path.join(OUT, t + '.tex')).read().splitlines()
    P('== %s.tex: margins now rounded down (from the 6-digit log display minus one unit of its 6th digit)' % t)
    k = 0
    for a, b in zip(old, new):
        if a != b:
            k += 1
            ca = a.split('&'); cb = b.split('&')
            diffs = [(x.strip(), y.strip()) for x, y in zip(ca, cb) if x != y]
            P('  %s' % ' | '.join('%s -> %s' % (x[:60], y[:60]) for x, y in diffs))
    P('  %d lines changed' % k)
W.close()
print('done', nch, nb)
