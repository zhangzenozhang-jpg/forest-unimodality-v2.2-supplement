#!/usr/bin/python3
"""fiber_theorem_closed: do the cells of every family, as actually computed, cover the exact stated range?

For each family the checker builds its cells from decimal edge strings.  Interior edges are shared by adjacent cells (the
same binary number), so only the OUTER ends matter.  An outer end is built either
  - from an interval (iv.mpf of the decimal string, or an interval formula): outward by construction, or
  - by mpf(decimal string) at 30 digits (mp.dps = 30, as set by fc_core): nearest rounding, which can fall on either side.
This script lists, family by family, the outer ends and how the code builds them, and compares each with its exact rational
value (exact arithmetic on the binary value).  "covered" means left end <= exact left and right end >= exact right.
Writes logs/fc_edge_coverage_<before or after>.log.  No checker is run.  Usage: python3 fc_edge_coverage.py [after]"""
import os, sys
from fractions import Fraction as Fr
from mpmath import mp, mpf, iv

mp.dps = 30
iv.dps = 30
HERE = os.path.dirname(os.path.abspath(__file__))
TAG = sys.argv[1] if len(sys.argv) > 1 else 'before'
LOG = open(os.path.join(HERE, 'logs', 'fc_edge_coverage_%s.log' % TAG), 'w')


def P(*a):
    print(*a, file=LOG, flush=True)


def exact(x):
    """the exact rational value of an mpf."""
    sign, man, e, bc = mpf(x)._mpf_
    m = -int(man) if sign else int(man)
    e = int(e)
    return Fr(m) * (Fr(2) ** e) if e >= 0 else Fr(m, 2 ** (-e))


def end_value(s, how):
    """the binary value the code uses for the decimal string s: 'nearest' = mpf(s); 'out-lo' = lower end of iv.mpf(s);
    'out-hi' = upper end of iv.mpf(s)."""
    if how == 'nearest':
        return exact(mpf(s))
    I = iv.mpf(s)
    return exact(I.a) if how == 'out-lo' else exact(I.b)


# (family, statement range, left string, how left is built, right string, how right is built, where in the code)
# 'how' is read from the code (after the fix the outer ends are built outward: out-lo / out-hi).
AFTER = (TAG == 'after')
L, R = ('out-lo', 'out-hi') if AFTER else ('nearest', 'nearest')
FAM = [
    ('A1', 'a in [0, 0.528]', '0', 'exact', '0.528', 'out-hi', 'fc_check_A.py A1_EDGES: (1 - F(b)) with F = iv.mpf, outward'),
    ('A2', 's in [-0.528, 0.67]', '-0.528', L, '0.67', R, 'fc_check_A.py S_EDGES, env_cell(mpf(a), mpf(b))'),
    ('B3 central', 't in [0.21, 0.6]', '0.21', L, '0.6', R, 'fc_check_B.py build_PHI (T_EDGES)'),
]
for (name, tau) in [('O1', '0.6'), ('O2', '0.69'), ('O3', '0.44'), ('O4', '0.42'), ('O5', '0.40'), ('O6', '0.36'),
                    ('O7', '0.33'), ('O8', '0.30')]:
    FAM.append(('B3 class %s' % name, 't in [0.21, %s]' % tau, '0.21', L, tau, R, 'fc_check_D.py SEDGES -> build_PHI'))
for (name, tau) in [('Wa', '0.58'), ('Wb', '0.55'), ('Wc', '0.52')]:
    FAM.append(('C1 %s' % name, 't in [%s, 0.6]' % tau, tau, L, '0.6', R, 'fc_check_C.py cedges, wing_cell(a, b)'))
for (name, tau, thi) in [('O1', '0.600', '1.700'), ('O2', '0.690', '1.700'), ('O3', '0.440', '1.750'),
                         ('O4', '0.420', '1.800'), ('O5', '0.400', '1.700'), ('O6', '0.360', '1.700'),
                         ('O7', '0.330', '1.900'), ('O8', '0.300', '1.900')]:
    FAM.append(('D3 %s' % name, 't in [%s, %s]' % (tau, thi), tau, L, thi, R, 'fc_check_D.py WEDGES, window_cell(a, bb)'))
FAM.append(('A4m', 'r in [0.3793, 0.5]', '0.3793', L, '0.5', R, 'fc_check_E.py h_lb cells'))

P('fc_edge_coverage.py (%s): outer ends of every family, as computed, against the exact stated range' % TAG)
P('outward by construction (no check needed): A0 (exact rationals), A3, A4, A4p (interval formulas for N), A5 and D4 (outer '
  'ends: nu from 0 to 6, both exact; for their inner split see the next line), B1 (q-cells from exact rationals in interval '
  'arithmetic), B2 (t = iv.mpf, monotone), D0 (exact), D1, D2, D1p (N0min = iv.mpf formula; r-cells from iv.mpf ends), A3p '
  '(lower ends lo() of interval formulas), A4d (r from iv.mpf strings; N-blocks from the doubles 11.45 = 11.4499..., '
  '29.1 = 29.1000...01, outward), the rows (q enclosed outward from exact lambda; mu0 integers; T_C = iv.mpf(0.22)).')
P('NOT outward by construction, but no gap: the split of A5 and D4 (Lemmas 7.10, 7.11) between the fixed-N range and the '
  'tied range. The code starts the tied nu-range at hi(nu1), the upper end of the enclosure nu1 of r_m sqrt(N_*) '
  '(N_* = 1.6 mu + 2, NL in the code), less than 2e-30 above the exact split. The sliver r_m sqrt(N_*) <= nu < hi(nu1) is '
  'covered by the fixed-N range, which runs to hi(nu1) at N = N_*: there N >= nu^2/r_m^2 >= N_*, and the check at N = N_* '
  'covers every larger N through the monotonicity in N in the proof of Lemma 4.14. Width of the sliver (at most '
  'hi(nu1) - lo(nu1), computed as in the code):')
for (lab, mu, rm) in [('A5, fc_check_A.py 19 0.25', '19', '0.25'), ('A5, fc_check_A.py 30 0.28', '30', '0.28'),
                      ('D4, fc_check_D.py (mu_D >= 40, r_m = 1/2)', '40', '0.5')]:
    NLs = iv.mpf(mu) * iv.mpf('1.6') + 2
    nu1 = iv.mpf(rm) * iv.sqrt(NLs)
    wd = (iv.mpf(nu1.b) - iv.mpf(nu1.a)).b
    P('  %s: N_* = %.6g, split r_m sqrt(N_*) = %.12g, sliver width <= %.2g' % (lab, float(NLs.a), float(nu1.a), float(wd)))
    assert wd < mpf('2e-30')
short = []
for (fam, rng, ls, lh, rs_, rh, where) in FAM:
    lv = Fr(ls) if lh == 'exact' else end_value(ls, lh)
    rv = end_value(rs_, rh)
    le, re_ = Fr(ls), Fr(rs_)
    okl = lv <= le
    okr = rv >= re_
    st = 'covered' if (okl and okr) else 'SHORT'
    if not (okl and okr):
        short.append(fam)
    P('%-14s %-22s left %s (%s): %s%s | right %s (%s): %s%s | %s | %s'
      % (fam, rng, ls, lh, 'ok' if okl else 'short by ', '' if okl else '%.3g' % float(lv - le), rs_, rh,
         'ok' if okr else 'short by ', '' if okr else '%.3g' % float(re_ - rv), st, where))
P('SUMMARY (%s): %d families checked here; SHORT: %s' % (TAG, len(FAM), ', '.join(short) if short else 'none'))
LOG.close()
print('done', len(FAM), 'short:', short)
