SUPPLEMENTARY CODE OF THE NOTE
"The no-valley inequality above an explicit mean, by a fiber inequality with explicit constants"
=================================================================================================

This folder holds the programs and data of the computer-assisted steps listed in Section 7 of the note, and the
logs they produce. Everything needed to rerun them is in this folder.


1. FILES
--------

The checkers (each writes one log in logs/; Section 2 says which lemma each log line belongs to)
  fc_check_A.py        Lemma 3.12 and the envelope theorem (Theorem 4.15): Lemmas 7.1, 7.2, 7.3, 7.4, 7.6, 7.10
  fc_check_B.py        the small fibers (Lemma 5.3) and the central subintervals (Theorem 5.6): Lemma 7.12, the
                       central entry of Lemma 7.13, the 18 central cells of Lemma 7.14, and the averaging margins
                       of Lemma 7.21 for iota = 6, ..., 30
  fc_check_C.py        the wing (Theorem 5.8): Lemma 7.15, and Lemma 7.21 for iota = 31, ..., 39
  fc_check_D.py        the window theorem and the outer subintervals (Theorem 5.14, Corollary 5.15): Lemmas 7.7,
                       7.8, 7.11, 7.16, 7.17, 7.19, 7.20, the class entries of Lemma 7.13, the 26 class cells of
                       Lemma 7.14, and Lemma 7.21 for iota = 0, ..., 5 and 40, ..., 54
  fc_check_E.py        Lemmas 7.5, 7.9 and 7.18 (it reads the class data from the text of fc_check_D.py)

The modules (used by the checkers; they check nothing by themselves)
  fc_core.py           the closed-form bounds shared by the checkers: the root s(lambda) of s + log(1+s) = lambda
                       with a certified enclosure, G and its derivatives, alpha_1, alpha_2, rho_*, kappa_A, the
                       coefficients e_2, ..., e_5, their block versions, and the three margins of Lemmas 7.6, 7.7
  fc_spike.py          the bound of Phi(t; M) (Lemma 5.4) on a cell of t, block by block in M (for Lemma 7.14)
  fc_window.py         the window shape conditions (c1)-(c3), the derivative bound of Lemma 5.12, the bound of the
                       window inequality on a cell (for Lemma 7.20) and the lower bound of Phi_r(N) (for Lemma 7.8)
  fth_data.py          reads the data of the 55 subintervals of [P] (Part 1 of data/twin_v2.1_data.txt) as exact
                       fractions; it also contains the 31 rows of the one-generation caps of Remark 6.3

The other scripts
  fc_ledger_f6.py      the count of the F6 boxes (the paragraph "The count of the F6 boxes" in Section 7.2; the
                       counts are used in Section 6.3)
  fc_make_tables.py    copies the numbers of the logs into the LaTeX tables of the note (no computation)
  fc_example_cell.py   prints the numbers of the worked line in Section 7.1 (the cell s in [0.155, 0.235] of
                       Lemma 7.3)

Data
  data/twin_v2.1_data.txt   the supplementary data file of [P]
  data/f6_boxes/            the 229 box files of [P, Lemma 5.4] on [m*(iota), 50], in the folders
                            to50/strip_NN/ and band14_to50/strip_NN/ (NN is the subinterval iota)
  Both are byte-for-byte copies from the supplementary archive of [P]; data/f6_boxes/ holds its files
  F6_F7_one_criterion/strips_to_50_and_conversion/outputs/stage2/mgf_one/{to50,band14_to50}/strip_NN/box_*.json.
  Their SHA-256 sums agree with the file MANIFEST.sha256 of that archive.

Logs and records
  logs/                       the logs and tables as produced for the note (the runs below overwrite them)
  CHANGES_FOR_PACKAGING.txt   every line changed to make this folder self-contained (file locations only)
  SHA256SUMS.txt              the SHA-256 of every other file in this folder

fth_data.py is the file whose SHA-256 is printed in Section 7 of the note, except for its line 7, which now points
to data/twin_v2.1_data.txt in this folder. With the old line 7 (given in CHANGES_FOR_PACKAGING.txt) put back, its
SHA-256 is the printed one.


2. WHICH LEMMA EACH LOG LINE BELONGS TO
---------------------------------------

Every line of a log that records a check begins with a tag. The tags and the lemmas of Section 7 of the note
(Table 3 of the note gives the same map; "log" is the letter X of fc_check_X.log):

  tag       log       lemma         what it checks
  A0        A         7.1           phi >= 0 on [0, 0.67] (exact)
  A1        A         7.2           Q >= 0, so S >= 0 on [0.6, 1]
  A2        A         7.3           the envelope inequality E(s) >= 0 (nine cells of s)
  A3        A         7.4           beta_e nondecreasing for r_m = 1/4
  A3p       E         7.5           beta_e nondecreasing on the other ranges
  A4        A         7.6           lambda_U >= lambda_t for r <= 1/4, N >= 13.4
  A4p       D         7.7           lambda_U >= lambda_t on the spike ranges
  A4d       D         7.8           Phi_r(N) >= 0 for the class C_1, on blocks in (r, N)
  A4m       E         7.9           ytilde R/(N+1) nondecreasing in N
  A5        A         7.10          large t, r <= 1/4
  D4        D         7.11          large t, r <= 1/2
  B1        B         7.12          kappa_w(M, .) >= -K_M for M <= 7
  B2        B, D      7.13          no deficit from the range (L) (central entry in B, class entries in D)
  B3        B, D      7.14          upper bounds of Phi on the spike cells (central cells in B, class cells in D)
  C1        C         7.15          the wing inequality
  D0        D         7.16          psi + g < 0 at t_hi (exact)
  D1        D         7.17          the window shape conditions (c1)-(c3)
  D1p       E         7.18          (c3'), the monotone form of (c3)
  D2        D         7.19          the derivative bound for the range (U)
  D3        D         7.20          the window inequality
  ROW-v21   B, C, D   7.21          the averaging margin of one subinterval iota at its starting mean mu_0(iota),
                                    with the caps theta(iota) of [P] (B: iota = 6..30, C: 31..39, D: the others)
  ROW-o2    B, C, D   Remark 6.3    the same margins with the one-generation caps; not used in the note

The variant of Remark 4.16 (|2q-1| <= 0.28, mu >= 30) is the second run of fc_check_A.py in Section 4; its 23 lines
are not used in the note, except its line for Lemma 7.5, which is repeated in fc_check_E.log.

The logs use some names of an earlier draft: the classes O1, ..., O8 are the classes C_1, ..., C_8 of Table 1 of the
note; the wing classes Wa, Wb, Wc are W_1, W_2, W_3; "caps v21" are the caps theta(iota) of [P] (its version 2.1)
and "o2" the one-generation caps of Remark 6.3; "Theorem A'" is Theorem 4.15 and "Theorem B'" is Theorem 5.6;
"[V3, Lemma 5.4]" is Lemma 5.12; "Lemma 5.1" in the A3p lines is Lemma 5.7 (the wing inequality).


3. REQUIREMENTS
---------------

Python 3 and the library mpmath; the rest is the Python standard library. The logs in logs/ were produced with
Python 3.9.6 and mpmath 1.3.0. mpmath used gmpy2 2.3.1, which it picks up by itself when it is installed (gmpy2
only makes mpmath faster). To install mpmath:  python3 -m pip install mpmath==1.3.0
The code has been run only with these versions. With other versions the PASS and FAIL words and the margins are
expected to be the same, but some printed interval ends may be formatted differently.


4. HOW TO RUN
-------------

From inside this folder, one command per script, in this order (fc_ledger_f6.py and fc_make_tables.py read the logs
written by the checkers):

  python3 fc_check_A.py
  python3 fc_check_A.py 30 0.28 fc_check_A_rm028_mu30.log     (the variant of Remark 4.16)
  python3 fc_check_B.py
  python3 fc_check_C.py
  python3 fc_check_D.py
  python3 fc_check_E.py
  python3 fc_ledger_f6.py
  python3 fc_make_tables.py
  python3 fc_example_cell.py

Each run takes from a fraction of a second to about ten seconds (fc_check_B.py is the longest); all of them together
take well under a minute. Each checker writes its log into logs/, overwriting the log shipped there, and prints
"done <number of tagged lines> <number of FAIL lines>"; the expected screen output is "done 23 0" (both runs of
fc_check_A.py), "done 77 0", "done 29 0", "done 163 0", "done 29 0", then "done 229 {'v21': 86, 'o2': 57}" from
fc_ledger_f6.py. fc_example_cell.py prints to the screen; the shipped file logs/fc_example_cell.out is its output
(python3 fc_example_cell.py > logs/fc_example_cell.out recreates it). The folder logs/ must exist. Writing
python3 -B instead of python3 keeps Python from creating a __pycache__ folder; it changes nothing else.

The runs are deterministic, so the new logs can be compared with the shipped ones through the checksums: after the
runs above,
  shasum -a 256 -c SHA256SUMS.txt          (on Linux: sha256sum -c SHA256SUMS.txt)
prints OK for every file of the folder, the logs included, exactly when the new logs are identical to the shipped
ones.


5. WHAT PASS MEANS
------------------

A line with the word PASS or FAIL is one cell: one explicit inequality, with explicit constants, on one stated range
(an interval of one variable, or a block of two). It reads

  TAG  PASS  least margin m | the inequality | range ... | method

The program computes a lower bound of (left side minus right side) that is valid on the whole range, rigorously
(Section 7), and m is this bound, printed with 6 significant digits. PASS means that the bound is positive, so the
inequality holds at every point of the range; FAIL means that the computed bound is not positive, so that the
inequality is not proved on that range. The decision uses the exact bound, not the printed digits. No line fails.
A few side conditions are checked by assert statements; if one of them failed, the program would stop with an
AssertionError and write no SUMMARY line.

The other lines:
  - B3 lines print upper bounds ("bounds m1:... m16:..."): the bounds of Phi(t; M) of Lemma 7.14 on one cell of t
    and the M-blocks m = 1, 2, 4, 8, 16 (Table 4 of the note). They are used in the margins of Lemma 7.21 and carry
    no PASS or FAIL.
  - ROW lines: PASS means that the averaging margin of Lemma 7.21 is positive at the mean printed as
    "range mu >= mu0 = ...", with its side conditions; that mean is the starting mean mu_0(iota) of the note. The
    program tries the means 19, 20, ..., 40, 45, 50, 60, 70 (in fc_check_D.py also 80, 90, 100, 120, 150, 200, 250,
    300, 400) in turn and reports the first one that works.
  - fc_check_D.log has seven lines "iota 48 o2: no mu0 <= 400" (to iota 54): on these subintervals the
    one-generation caps give no starting mean (Remark 6.3). They are not failures and are not used.
  - Lines without a tag (headings, the enclosure of t(-0.528) printed by fc_check_A.py, and "class O3: no spike cell
    uses the window bound" in fc_check_E.log) are information only.


6. EXPECTED SUMMARY LINES
-------------------------

The last lines of the logs:

  logs/fc_check_A.log
    SUMMARY: 23 items, 0 FAIL; least margin 0.005323653534297496
  logs/fc_check_A_rm028_mu30.log
    SUMMARY: 23 items, 0 FAIL; least margin 0.005323653534297496
  logs/fc_check_B.log
    SUMMARY: 77 items, 0 FAIL
    MU0 v21: {6: 23, 7: 23, 8: 23, 9: 23, 10: 20, 11: 19, 12: 19, 13: 19, 14: 19, 15: 19, 16: 19, 17: 19, 18: 19, 19: 19, 20: 19, 21: 19, 22: 19, 23: 19, 24: 19, 25: 19, 26: 19, 27: 19, 28: 19, 29: 19, 30: 20}
    MU0 o2 : {6: 24, 7: 23, 8: 24, 9: 23, 10: 22, 11: 23, 12: 23, 13: 23, 14: 22, 15: 23, 16: 23, 17: 23, 18: 23, 19: 23, 20: 24, 21: 24, 22: 24, 23: 24, 24: 25, 25: 24, 26: 24, 27: 25, 28: 25, 29: 25, 30: 26}
  logs/fc_check_C.log
    SUMMARY: 29 items, 0 FAIL
  logs/fc_check_D.log
    SUMMARY: 163 items, 0 FAIL
  logs/fc_check_E.log
    SUMMARY: 29 items, 0 FAIL; least margin 0.058191942604725835
  logs/fc_ledger_f6.log
    TOTAL boxes on [m*, 50]: 229; removable with the caps of v2.1: 86 (remaining 143); with the o2 caps: 57 (remaining 172)
    boxes below m*: m*(iota) < mu_0(iota) on every iota (caps of v2.1); least mu_0 - m* = 125/23 (= 5.4348) at iota 16; max m* over all iota = 68/3 (iota 0), over iota >= 6 = 198/13; min mu_0 = 19
    o2 caps (where defined): least mu_0 - m* = 59/7 (= 8.4286) > 0
    (then one line with the number of boxes not needed on each subinterval)

"items" counts the tagged lines of a log, ROW lines included. Together the logs fc_check_A.log to fc_check_E.log have
218 lines of cells (the tags A0 to D3, B3 included) and 55 ROW-v21 lines, one per subinterval: the counts of
Section 7 of the note. fc_make_tables.py prints them, among other lines:
    structural checks: 218 (of which B3 cells 44); rows v2.1: 55; rows o2: 48; FAIL: 0
    named families: 85 inequalities, 218 cells, rows 55 (+48 o2)
(85 is the hand count of statements, the column "stmts" of Table 3 of the note.) In fc_ledger_f6.log, "removable"
means "not needed": 86 of the 229 boxes are not needed and 143 remain (Section 6.3 of the note).


7. THE ARITHMETIC
-----------------

"Interval" (every lemma of Section 7 except 7.1 and 7.16): interval arithmetic with outward rounding, by the library
mpmath.iv at a working precision of 30 decimal digits (iv.dps = 30). On a cell every quantity is enclosed in an
interval whose ends are rounded outward, so the lower bound computed for an inequality is a true lower bound on the
whole cell. Where a term is monotone in a variable (as stated in the note and in the comments of the code), it is
taken at the worse end of the cell. Decimal constants are entered as decimal strings and enclosed (for instance
iv.mpf('3.55') is an interval that contains 3.55). Decimal cell edges are rounded to the 30-digit binary grid;
adjacent cells share their edges, and the outer ends overlap the neighbouring ranges, so there are no gaps. The root
s(lambda) of s + log(1+s) = lambda is enclosed between two point bounds, each verified in interval arithmetic
(s_lower and s_upper in fc_core.py).

"Exact" (Lemmas 7.1 and 7.16, and the count in fc_ledger_f6.py): rational arithmetic with Python's
fractions.Fraction.

The data of [P] (the ends of the subintervals in lambda, theta(iota), D(iota), ell_0(iota), m_25(iota), m*(iota))
are read as exact fractions, and q = lambda/(1+lambda) is enclosed outward. The margins printed in the logs are
floating-point displays of the rigorous bounds; the note quotes them rounded down.
