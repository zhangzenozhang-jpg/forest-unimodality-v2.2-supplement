"""fiber_theorem_closed: the spike deficit Phi on t-cells, blockwise in M (RIGOROUS, mpmath.iv).

For a ray t = M/mu < 0.6 with M >= 8 the deficit is (Theorem B' of the tex)
    Def(M, mu) <= Phi(t; M) := t (-S(t))_+ + (t/M) (6 G0 - 2 + Dbar_U + max_k [2k G1 + k^2 G2/(M+3)])_+,
nonincreasing in M.  On a t-cell [ta, tb] and an M-block [m_i Ma, m_{i+1} Ma] (Ma = max(8, MU_LO ta)) we bound Phi at
M = m_i Ma, with G(lambda^T_U) <= Ghat_i = max(G(lambda_t + 3.55/(m_{i+1} Ma + 3)), G(lambda_t + kbar/(m_i Ma + 3)))
and nu <= nm_i = min(6, rm sqrt(m_{i+1} Ma + 2)); the last block [m_last Ma, oo) uses the all-nu AM-GM bound
(nonincreasing in N by (A3), (A4) of Theorem A').  S is bounded below by the mean-value form on the cell.
"""
from mpmath import iv, mpf
from fc_core import lo, hi, G_of, G1_of, G2_of, Ecoef, rho_star, kappaA, rho_star_block, DU_block

iv.dps = 30
F = iv.mpf
MULTS = [1, 2, 4, 8]


def S_upper_neg(ta, tb):
    """upper bound of (-S(t))_+ on [ta, tb]: mean-value form S(t) >= S(tm) - sup|S'| (tb-ta)/2,
    S' = (9/2)(1 - 1/t^2) - 5 G1(lambda_t)/t."""
    tm = (F(ta) + F(tb)) / 2
    t = F([ta, tb])
    lam_m = F(5) / 2 * iv.log(tm)
    Sm = F(9) / 2 * (tm - 1) ** 2 / tm - 2 * G_of(iv, lam_m)
    lam = F(5) / 2 * iv.log(t)
    dS = F(9) / 2 * (1 - 1 / t ** 2) - 5 * G1_of(iv, lam) / t
    dmax = max(abs(lo(dS)), abs(hi(dS)))
    v = F(-lo(Sm)) + F(dmax) * (F(tb) - F(ta)) / 2
    return max(hi(v), mpf(0))


def phi_cell(ta, tb, mu_lo, rm):
    """returns (Ma, [(m_i, Phi_i)]) for the cell [ta, tb]; Phi_i bounds Phi(t; M) for M in block i."""
    t = F([ta, tb])
    rm = F(rm)
    Ma = F(max(mpf(8), lo(F(mu_lo) * F(ta))))
    lam = F(5) / 2 * iv.log(t)
    G0 = G_of(iv, lam); G1 = G1_of(iv, lam); G2 = G2_of(iv, lam)
    tS = hi(t * F(S_upper_neg(ta, tb)))
    res = []
    for i, m in enumerate(MULTS):
        M = m * Ma
        N0 = M + 2
        kbar = F('3.85') + 10 / M
        kk = max(hi(2 * k * G1 + k * k * G2 / (M + 3)) for k in (F('3.55'), kbar))
        last = (i == len(MULTS) - 1)
        if not last:
            Mn = MULTS[i + 1] * Ma
            N1 = Mn + 2
            nm = F(min(hi(rm * iv.sqrt(N1)), mpf(6)))
            Gh = F(max(hi(G_of(iv, lam + F('3.55') / (N1 + 1))), hi(G_of(iv, lam + kbar / (M + 3)))))
            rs = rho_star_block(N0, nm, rm)
            e2, e3, e4, e5 = Ecoef(iv, N0, rm)
            q2 = rs * (1 - 1 / N0) / 2 - (e2 + e3 * nm + e4 * nm ** 2 + e5 * nm ** 3) / N0
            if lo(q2) > 0:
                arg = lam + F('3.55') / (N1 + 1) - 1 / (N0 ** 2 * q2)
                g1 = F(max(-lo(G1_of(iv, F(lo(arg)))), mpf(0)))
            else:
                g1 = F(max(-lo(G1), mpf(0)))
            D = DU_block(Gh, g1, N0, nm, rm)
        else:
            Gh = F(max(hi(G0), hi(G_of(iv, lam + kbar / (M + 3)))))
            g1 = F(max(-lo(G1), mpf(0)))
            rs = rho_star(iv, N0, rm); kA = kappaA(iv, N0, rm)
            c = N0 - 1 - kA * Gh / rs
            e2, e3, e4, e5 = Ecoef(iv, N0, rm)
            nm = F(min(hi(rm * iv.sqrt(N0)), mpf(6)))
            be = N0 - 1 - (2 / rs) * (e2 + e3 * nm + e4 * nm ** 2 + e5 * nm ** 3)
            if lo(c) <= 0 or lo(be) <= 0:
                D = None
            else:
                D = hi(4 * Gh ** 2 / (rs ** 2 * c) + g1 * 4 / (rs ** 2 * be))
        if D is None:
            res.append((m, None))
            continue
        C = 6 * G0 - 2 + kk + D
        res.append((m, hi(F(tS) + (t / M) * F(max(hi(C), mpf(0))))))
    return Ma, res
