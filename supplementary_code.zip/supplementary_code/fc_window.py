"""fiber_theorem_closed: Theorem D'' (the window theorem in closed form) -- the cell function, RIGOROUS (mpmath.iv).

For r = |2q-1| in [ra, rb] (interval), t in a cell, N >= N0 (N0 = mu_D t_a + 2) the fiber function satisfies
    F >= B min(X_split, 3, X_U)        (B = N/mu >= t),
X_split = 1 - (2/rho) Ghat_c + Delta/(1 + sbar0 + rhobar_L Delta/2) - 2 e_L/rho      (L piece on the window w <= 3,
          its global minimum in split form; every term nondecreasing in N, evaluated at N0),
3       = the range 3 <= w <= gamma (F >= B w),
X_U     = gamma - (2/rho*) G(min(0, lambda_U^lo))   (U piece; lambda_U^lo nondecreasing in N by (D2)).
"""
from mpmath import iv, mpf
from fc_core import lo, hi, G_of, s_upper, rho_star

iv.dps = 30
F = iv.mpf


def atanh(x):
    return iv.log((1 + x) / (1 - x)) / 2


def shape_W(r, N, W=3):
    """the quantities of the window shape bound at (r, N) for w <= W."""
    v = (1 - r * r) / 4
    sN = iv.sqrt(v * N)
    ZL = 2 * (iv.sqrt(F(W)) * sN + r) / (N + 1)
    ZR = 2 * iv.sqrt(F(W)) * sN / (N + 1)
    return v, sN, ZL, ZR


def conditions(ra, rb, N, W=3):
    """(c1) Z_L(W) < 1, (c2) r + Z_R(W) < 1, (c3) W <= 12(1-(r+Z_R)^2)/((1-r^2) rho); worst margin."""
    r = F([ra, rb]); N = F(N)
    v, sN, ZL, ZR = shape_W(r, N, W)
    rho = N / (N + 1)
    c1 = 1 - ZL
    c2 = 1 - (r + ZR)
    c3 = 12 * (1 - (r + ZR) ** 2) / ((1 - r * r) * rho) - W
    return min(lo(c1), lo(c2), lo(c3))


def umono_derivative(ra, rb, N):
    """Lemma 5.4 (v3): Phi'(m) >= r^2/2 - a r - c_r - 2r^2/m - 4r^2/m^2 - 1/(m(m-2)) - a/(2r(m-2)) - 3.55/m^2, m = N+1;
    every subtracted term decreases in m, so a positive value at m0 holds for all m >= m0."""
    raF, rbF = F(ra), F(rb); m = F(N) + 1
    def amr(x):
        return atanh(x) - x          # a = artanh r - r (increasing), as in the proof of [V3, Lemma 5.4]
    def crr(x):
        return (atanh(x) ** 2 + iv.log(1 - x * x)) / 2      # increasing
    # termwise worst ends: r^2/2 at ra; a r, c_r, 2r^2/m, 4r^2/m^2 at rb; a/(2r(m-2)) at rb (a/r increasing)
    val = raF ** 2 / 2 - amr(rbF) * rbF - crr(rbF) - 2 * rbF ** 2 / m - 4 * rbF ** 2 / m ** 2 - 1 / (m * (m - 2)) \
        - amr(rbF) / (2 * rbF * (m - 2)) - F('3.55') / m ** 2
    return lo(val)


def window_cell(ta, tb, ra, rb, muD, b, beta=0):
    """lower bound of min(X_split, 3, X_U) - max(0, (psi(t)+b)/t) on t in [ta, tb], r in [ra, rb], N >= muD ta + 2."""
    t = F([ta, tb])
    r = F([ra, rb])
    M0 = F(lo(F(muD) * F(ta)))
    N = M0 + 2
    rho = N / (N + 1)
    v, sN, ZL, ZR = shape_W(r, N, 3)
    eps = r * iv.sqrt(N) / (iv.sqrt(v) * (N + 1))
    c0 = r * r / (2 * v * (N + 1))
    E4 = F(max(hi((N + 1) * ZL ** 4 / (12 * (1 - ZL ** 2) * (1 - r * r))),
               hi((N + 1) * ZR ** 4 / (12 * (1 - (r + ZR) ** 2) * (1 - r * r)))))
    s3 = iv.sqrt(F(3))
    eL = c0 + E4 + eps * s3 / 2 + eps / (2 * s3)
    eL = F(hi(eL))
    rhoLbar = 1 + F(hi(eps)) / s3
    ra_ = F(ra)
    Dlo = ra_ ** 2 * (N * N - N + 1) / ((1 - ra_ ** 2) * N)       # Delta is increasing in r
    Dlo = F(lo(Dlo))
    lam_lo = F(5) / 2 * iv.log(t)
    lam_hi = F(5) / 2 * iv.log(t) + (F('3.85') + 10 / M0) / (M0 + 3)
    Gc = F(max(hi(G_of(iv, F(lo(lam_lo)))), hi(G_of(iv, F(hi(lam_lo)))), hi(G_of(iv, F(hi(lam_hi))))))
    L0 = hi(lam_hi + eL)
    sbar = max(s_upper(L0), mpf(0)) if L0 > 0 else mpf(0)
    Xs = 1 - (2 / rho) * Gc + Dlo / (1 + F(sbar) + rhoLbar * Dlo / 2) - 2 * eL / rho
    # window condition for every N >= N0 (then min over [0, W'] of H_L is H_L(W') >= B W', W' = min(3, gamma)):
    #   Delta(ra, N0) >= 2: lam_hi + e_L + rhoLbar <= log(1 + rho (Delta - 2)/2);  else: lam_hi + e_L + rhoLbar <= 0
    lhs = hi(lam_hi + eL + rhoLbar)
    if lo(Dlo) >= 2:
        wc = lhs <= lo(iv.log(1 + rho * (Dlo - 2) / 2))
    else:
        wc = lhs <= 0
    Wlo = min(mpf(3), lo(1 + Dlo))
    # where the window condition fails, lambda_L > 0 and G(lambda) <= lambda - log(1+lambda) gives
    #   gamma - (2/rho_L) G(lambda_L) >= 1 - (2/rho_L)(lambda^T_c + e_L)  (the log term >= 0 dropped)
    q = hi(lam_hi + eL)
    Xlog = lo(1 - 2 * F(q) / rho) if q >= 0 else lo(1 + 2 * F(-q) / rhoLbar)
    XL = Wlo if wc else min(Wlo, max(lo(Xs), Xlog))
    # U piece at N0 with r in [ra, rb] (exact formulas, interval in r); rho_U >= rho*(N0, rb) for all N >= N0
    # r-dependent primitives by monotonicity in r (avoids interval dependency): artanh r - r, c_r, gamma increasing,
    # s_N decreasing; then interval arithmetic on the products.
    raF, rbF = F(ra), F(rb)
    amr = F([lo(atanh(raF) - raF), hi(atanh(rbF) - rbF)])
    cra = (atanh(raF) ** 2 + iv.log(1 - raF ** 2)) / 2
    crb = (atanh(rbF) ** 2 + iv.log(1 - rbF ** 2)) / 2
    cr = F([lo(cra), hi(crb)])
    gam = F([lo(1 + raF ** 2 * (N * N - N + 1) / ((1 - raF ** 2) * N)), hi(1 + rbF ** 2 * (N * N - N + 1) / ((1 - rbF ** 2) * N))])
    sNi = F([lo(iv.sqrt((1 - rbF ** 2) * N) / 2), hi(iv.sqrt((1 - raF ** 2) * N) / 2)])
    yt = F([lo(raF + F(lo(amr)) * (N + 1) / 2), hi(rbF + F(hi(amr)) * (N + 1) / 2)])
    epsU = 4 * yt * sNi / (N + 1)
    om = F([lo(1 - rbF ** 2), hi(1 - raF ** 2)])
    rhoU = om * rho - epsU / iv.sqrt(gam)
    r2 = F([lo(raF ** 2), hi(rbF ** 2)])
    eU = r2 * rho / 2 + (epsU / 2) * (iv.sqrt(gam) + 1 / iv.sqrt(gam)) + (N + 1) * cr   # -c_0' <= 0 dropped
    lamU = F(5) / 2 * iv.log(t) + F('3.55') / (N + 1) + rhoU * (gam - 1) / 2 - eU
    rs = rho_star(iv, N, F(rb))
    assert lo(rs) > 0
    lu = lo(lamU)
    if lu >= 0:
        XU = lo(gam) if False else lo(1 + Dlo)
    else:
        XU = lo(1 + Dlo - (2 / rs) * G_of(iv, F(lu)))
    # target psi + g, g(t) = b + beta (t - 1) (a line: the tangent of the convex bonus target, residual R2);
    # need B X >= psi + g with B in [t, t N0/(N0-2)] (B = tN/(N-2) decreases in N):
    #   psi + g > 0: X >= (psi + g)/t;  psi + g <= 0: X >= (psi + g)/B_max  (only binding when X < 0)
    psib = t - F(9) / 2 * (t - 1) ** 2 + F(b) + F(beta) * (t - 1)
    Bmax = F(tb) * N / (N - 2)
    if lo(psib) > 0:
        need = hi(psib / t)
    elif hi(psib) <= 0:
        need = hi(psib / Bmax)
    else:
        need = max(hi(psib / t), mpf(0))
    X = min(XL, mpf(3), XU)
    return lo(F(X) - F(need)), (XL, XU, need)


def phi_U_lower(ra, rb, Na, Nb):
    """lower bound of Phi_r(N) = 3.55/(N+1) + rho_U Delta/2 - e_U over r in [ra, rb], N in [Na, Nb] (termwise monotone):
    rho_U >= rho*(Na, rb) (all-nu bound, nondecreasing in N), Delta >= Delta(ra, Na), and e_U <= r^2 rho/2 + ytilde R/(N+1)
    + eps'/(2 sqrt gamma) + (N+1) c_r with each part at its worst end (the first, second and fourth increase in N and r;
    the third is at most 1/((N+1) sqrt c) + r^2/(6(1-r^2) sqrt c) at (Na, rb)).  Then lambda_U >= lambda_t + Phi_r(N)."""
    raF, rbF, Na, Nb = F(ra), F(rb), F(Na), F(Nb)
    rs = rho_star(iv, Na, rbF)
    Dlo = raF ** 2 * (Na * Na - Na + 1) / ((1 - raF ** 2) * Na)
    rhob = Nb / (Nb + 1)
    a_b = atanh(rbF) - rbF
    yt = rbF + a_b * (Nb + 1) / 2
    R = iv.sqrt(Nb + rbF ** 2 * (Nb - 1) ** 2)
    c = 1 - 1 / Na
    third = 1 / ((Na + 1) * iv.sqrt(c)) + rbF ** 2 / (6 * (1 - rbF ** 2) * iv.sqrt(c))
    crb = (atanh(rbF) ** 2 + iv.log(1 - rbF ** 2)) / 2
    eU = rbF ** 2 * rhob / 2 + yt * R / (Nb + 1) + third + (Nb + 1) * crb
    return lo(F('3.55') / (Nb + 1) + rs * Dlo / 2 - eU)
