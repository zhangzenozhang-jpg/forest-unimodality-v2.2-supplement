#!/usr/bin/python3
"""fiber_theorem_closed: Theorem D'' (the window theorem in closed form) for the outer subintervals 0-5 and 40-54,
and their rows, RIGOROUS (mpmath.iv, 30 digits, one process).  Writes logs/fc_check_D.log.

Per class (r in [ra, rb], target psi + b + beta (t-1), cut tau, mu >= muD):
  (D1) window shape conditions (c1)-(c3) at N0min = muD tau + 2 (nonincreasing Z's: valid for N >= N0min)
  (D2) the derivative bound of [V3, Lemma 5.4] positive at m0 = N0min + 1 (lambda_U^lo nondecreasing in N)
  (D3) window cells on [tau, thi]: min(X_L, 3, X_U) >= need(t)  (fc_window.window_cell)
  (B2') Def_L = 0 on t <= tau for r <= rb (as (B2))
  (B3') Phi cells for t in [0.21, tau] with rm = rb, mu_lo = muD
  rows: the averaging margin with alpha = 1 + b (beta is free), spike t < tau, deficits raised by b.
Shared: (D4) large t for r <= 1/2 (F >= 0 >= psi + g for t >= thi): (A5) with r_m = 1/2 at N >= 1.6 muD_min + 2.
"""
import sys, os
from fractions import Fraction as Fr
from mpmath import iv, mpf
from fc_core import lo, hi, alpha12, rho_star, ceil_sig
import fc_spike
import fc_check_B as B
from fc_window import window_cell, conditions, umono_derivative

iv.dps = 30
F = iv.mpf
HERE = os.path.dirname(os.path.abspath(__file__))
LOG = open(os.path.join(HERE, 'logs', 'fc_check_D.log'), 'w')
B.LOG = LOG
item = B.item
P = B.P

CLASSES = [
    # name, ra, rb, b, beta, tau, thi, muD, iotas   (target psi + b + beta (t-1); beta is free in the averaging)
    ('O1', '0.3793', '0.5', Fr(2, 5), Fr(0), '0.6', '1.7', 45, [0, 1, 2]),
    ('O2', '0.25', '0.3794', Fr(2, 5), Fr(0), '0.69', '1.7', 50, [3, 4, 5]),
    ('O3', '0.1666', '0.2309', Fr(0), Fr(1, 2), '0.44', '1.75', 50, [40, 41, 42, 43]),
    ('O4', '0.2307', '0.2728', Fr(3, 20), Fr(3, 10), '0.42', '1.8', 40, [44, 45, 46]),
    ('O5', '0.2727', '0.3104', Fr(3, 10), Fr(0), '0.40', '1.7', 50, [47, 48, 49]),
    ('O6', '0.3103', '0.3444', Fr(3, 10), Fr(0), '0.36', '1.7', 50, [50, 51, 52]),
    ('O7', '0.3442', '0.3847', Fr(3, 10), Fr(1), '0.33', '1.9', 50, [53]),
    ('O8', '0.3846', '0.4', Fr(3, 10), Fr(1), '0.30', '1.9', 50, [54]),
]
# window cells (greedy, fc_greedy_D3.py, threshold 0.02) and spike cells (fc_simplify_spike.py)
WEDGES = {
    'O1': ['0.600', '0.749', '0.835', '1.005', '1.263', '1.597', '1.700'],
    'O2': ['0.690', '0.797', '0.881', '1.052', '1.254', '1.514', '1.700'],
    'O3': ['0.440', '0.485', '0.591', '0.836', '1.069', '1.272', '1.480', '1.750'],
    'O4': ['0.420', '0.450', '0.530', '0.752', '0.890', '1.134', '1.352', '1.625', '1.800'],
    'O5': ['0.400', '0.472', '0.728', '0.847', '1.148', '1.472', '1.700'],
    'O6': ['0.360', '0.391', '0.519', '0.765', '0.959', '1.307', '1.700'],
    'O7': ['0.330', '0.362', '0.494', '0.787', '1.027', '1.279', '1.533', '1.881', '1.900'],
    'O8': ['0.300', '0.322', '0.415', '0.763', '1.005', '1.285', '1.565', '1.900'],
}
SEDGES = {
    'O1': ['0.21', '0.34', '0.42', '0.6'], 'O2': ['0.21', '0.46', '0.6', '0.69'], 'O3': ['0.21', '0.36', '0.42', '0.44'],
    'O4': ['0.21', '0.32', '0.36', '0.38', '0.40', '0.42'], 'O5': ['0.21', '0.34', '0.38', '0.40'],
    'O6': ['0.21', '0.30', '0.34', '0.36'], 'O7': ['0.21', '0.25', '0.30', '0.32', '0.33'], 'O8': ['0.21', '0.28', '0.30'],
}


def fr(x):
    return F(x.numerator) / x.denominator


def window_edges(tau, thi, ncell=20):
    e = [mpf(tau) + mpf('0.02') * i for i in range(5)]
    rest = ncell - 4
    for i in range(1, rest + 1):
        e.append(e[4] + (mpf(thi) - e[4]) * i / rest)
    return e


def check_B2_class(rb, tau, Nmin=10):
    N = F(Nmin)
    a1, a2 = alpha12(iv, N, F(rb))
    num = F(rb) * iv.sqrt(N)
    t = F(tau)
    lhs = 2 * t * (a1 * num + a2 * num ** 2) / (N - 2)
    return lo(F(9) / 2 * (1 - t) ** 2 - lhs)


# ----------------------------------------------------------------------------------------------- (D4) large t, r <= 1/2
def D4(muD_min):
    RM = F(1) / 2
    NL = F(muD_min) * F('1.6') + 2
    def Xbar(nu, N):
        om = 1 - RM ** 2
        return ((N + 1) * nu ** 4 / (12 * N ** 2 * om ** 2)
                + nu * iv.sqrt(1 + nu ** 2) * (1 + nu ** 2 * (N + 1) / (6 * N * om)) / (N + 1)
                - rho_star(iv, N, RM) * (1 + nu ** 2 * (1 - 1 / N)) / 2)
    worst = None
    nu1 = hi(RM * iv.sqrt(NL))
    for i in range(8):
        a = nu1 * i / 8; b = nu1 * (i + 1) / 8
        v = iv.log(F('2.57') * rho_star(iv, NL, RM)) - Xbar(F([a, b]), NL)
        worst = lo(v) if worst is None else min(worst, lo(v))
    item('D4', 'large t, r <= 1/2: Xbar(nu, N) <= log(2.57 rho*(N))', 'nu in [0, %.3f], N = %.1f' % (float(nu1), float(lo(NL))),
         'interval, 8 nu-cells', worst)
    worst = None
    for i in range(12):
        a = nu1 + (6 - nu1) * i / 12; b = nu1 + (6 - nu1) * (i + 1) / 12
        N = F(a) ** 2 / RM ** 2
        v = iv.log(F('2.57') * rho_star(iv, N, RM)) - Xbar(F([a, b]), N)
        worst = lo(v) if worst is None else min(worst, lo(v))
    item('D4', 'large t, r <= 1/2: Xbar(nu, nu^2/rm^2) <= log(2.57 rho*)', 'nu in [%.3f, 6]' % float(nu1),
         'interval, 12 nu-cells', worst)
    c06 = 2 * iv.exp(F(-1) / 2) * F('1.6') ** (F(-3) / 2) * iv.exp(F(3) / (4 * NL) + F('1.1') / NL ** 2)
    item('D4', '2 a_U(N) 1.6^{-3/2} e^{-1/2} <= 0.6225', 'N >= %.1f' % float(lo(NL)), 'interval', lo(F('0.6225') - c06))


D4(40)

# (A4') Lemma 2.4 (lambda_U >= lambda_t) for the spike ranges: sufficient condition of fc_core.a4_margins
from fc_core import a4_margins
from fc_window import phi_U_lower
for (rm, Nlo) in [('0.25', 10), ('0.28', 10), ('0.3104', 10), ('0.3444', 10), ('0.3847', 12), ('0.4', 12)]:
    m = a4_margins(rm, Nlo)
    item('A4p', 'lambda_U >= lambda_t for r <= %s: f(N_lo), f\'-bound, tail at (6/r_m)^2 (three margins, least shown)' % rm,
         'N >= %d' % Nlo, 'interval (constants)', min(m))
# class O1 (r up to 1/2): direct check Phi_r(N) >= 0 on N in [11.45, 29] (then [V3, Lemma 5.4] via (D2) for N >= 29)
rcells = ['0.3793', '0.40', '0.42', '0.44', '0.46', '0.48', '0.5']
Nb1 = ['11.45', '12.5', 14, 16, 18, 20]
for ra, rb in zip(rcells[:-1], rcells[1:]):
    v = min(phi_U_lower(ra, rb, a, b) for a, b in zip(Nb1[:-1], Nb1[1:]))
    item('A4d', 'class O1: Phi_r(N) = 3.55/(N+1) + rho_U Delta/2 - e_U >= 0 (5 N-blocks)', 'r in [%s, %s], N in [11.45, 20]' % (ra, rb),
         'interval, termwise monotone', v)
Nb2 = [20, 23, 26, '29.1']
v = min(phi_U_lower('0.3793', '0.5', a, b) for a, b in zip(Nb2[:-1], Nb2[1:]))
item('A4d', 'class O1: Phi_r(N) >= 0 (3 N-blocks)', 'r in [0.3793, 0.5], N in [20, 29.1]', 'interval, termwise monotone', v)

from fth_data import o2_cap
for (name, ra, rb, b, beta, tau, thi, muD, iotas) in CLASSES:
    raF, rbF = F(ra), F(rb)
    N0min = F(muD) * F(tau) + 2
    item('D1', 'class %s (r in [%s, %s]): window shape conditions (c1)-(c3) for w <= 3' % (name, ra, rb),
         'N >= %.2f' % float(lo(N0min)), 'interval (Z_L, Z_R decrease in N)', conditions(raF, rbF, N0min))
    item('D2', 'class %s: derivative bound of [V3, Lemma 5.4] > 0 (lambda_U^lo nondecreasing in N)' % name,
         'm >= %.2f' % float(lo(N0min + 1)), 'interval (termwise in r)', umono_derivative(raF, rbF, N0min))
    thiF = Fr(thi)
    g_end = thiF - Fr(9, 2) * (thiF - 1) ** 2 + b + beta * (thiF - 1)
    item('D0', 'class %s: psi(t_hi) + b + beta (t_hi - 1) < 0 (then F >= 0 > target for t >= t_hi, by (D4)/(A5))' % name,
         't_hi = %s' % thi, 'exact rational', -g_end)
    edges = [lo(F(x)) if i == 0 else (hi(F(x)) if i == len(WEDGES[name]) - 1 else mpf(x)) for i, x in enumerate(WEDGES[name])]
    for a, bb in zip(edges[:-1], edges[1:]):
        m, info = window_cell(a, bb, raF, rbF, muD, fr(b), fr(beta))
        item('D3', 'class %s: min(X_L, 3, X_U) >= need (target psi + %s + %s(t-1)); X_L %.3f X_U %.3f need %.3f'
             % (name, b, beta, float(info[0]), float(info[1]), float(info[2])),
             't in [%.3f, %.3f], mu >= %d' % (float(a), float(bb), muD), 'interval in t (closed form, N0 = mu_D t_a + 2)', m)
    # spike cells for t < tau: per cell the blockwise template bound Phi and, where the window conditions hold at the
    # cell's least N, the window bound Phi_w = (psi + g + B_max (-X)_+)_+ with X = min(X_L, 3, X_U) (valid for all
    # N >= mu_D t_a + 2); each block uses the smaller of the two.  (B2') Def_L = 0 is checked on every cell.
    tedges = SEDGES[name]
    phi0 = B.build_PHI(edges=tedges, mu_lo=muD, rm=F(rb), log=False)
    phi = []
    worstB2 = None
    nwin = 0
    for (ta, tb, Ma, res), (ta_s, tb_s) in zip(phi0, zip(tedges[:-1], tedges[1:])):
        Na = F(max(mpf(10), lo(F(muD) * F(ta) + 2)))
        a1, a2 = alpha12(iv, Na, rbF)
        num = rbF * iv.sqrt(Na)
        b2 = lo(F(9) / 2 * (1 - F(tb)) ** 2 - 2 * F(tb) * (a1 * num + a2 * num ** 2) / (Na - 2))
        worstB2 = b2 if worstB2 is None else min(worstB2, b2)
        pw = None
        if conditions(raF, rbF, Na) > 0 and umono_derivative(raF, rbF, Na) > 0:
            m, info = window_cell(F(ta), F(tb), raF, rbF, muD, fr(b), fr(beta))
            X = min(info[0], mpf(3), info[1])
            t = F([ta, tb])
            psig = hi(t - F(9) / 2 * (t - 1) ** 2 + fr(b) + fr(beta) * (t - 1))
            Bmax = F(tb) * Na / (Na - 2)
            pw = max(mpf(0), hi(F(psig) + Bmax * F(max(-X, mpf(0)))))
            nwin += 1
        res2 = [(m_, v if pw is None else min(v, pw)) for (m_, v) in res]
        phi.append((ta, tb, Ma, res2))
        B.ITEMS.append(('B3', 'Phi <= blockwise bounds (class %s)' % name, 't in [%s, %s]' % (ta, tb), 'interval', mpf(1), True))
        P('B3       bounds %s | Phi(t; M) class %s, rm = %s, Ma = %.3f%s | range t in [%s, %s] | interval in t'
          % (' '.join('m%d:%s' % (m_, ceil_sig(v, 6)) for m_, v in res2), name, rb, float(lo(Ma)),
             '' if pw is None else ', window bound %s' % ceil_sig(pw, 6), mpf(ta_s), mpf(tb_s)))
    item('B2', 'class %s: Def_L = 0 on the spike cells (r <= %s, t <= %s, N >= max(10, mu_D t_a + 2))' % (name, rb, tau),
         'all spike cells of the class', 'interval, termwise', worstB2)
    for R in B.ROWS:
        if R['iota'] not in iotas:
            continue
        qa, qb, qbh, ell0, L, rhi, vmin, D = B.subint_data(R)
        ra_i = F(min(lo(abs(2 * qa - 1)), lo(abs(2 * qb - 1))))
        rb_i = F(max(hi(abs(2 * qa - 1)), hi(abs(2 * qb - 1))))
        r_ends_exact = [abs(2 * lam / (1 + lam) - 1) for lam in (R['lo'], R['hi'])]
        assert Fr(ra) <= min(r_ends_exact) and max(r_ends_exact) <= Fr(rb), (R['iota'], r_ends_exact)
        assert lo(ell0 / L) > hi(F(tau)), (R['iota'], ell0 / L)
        for capname in ['v21', 'o2']:
            theta = R['theta'] if capname == 'v21' else o2_cap(R['lo'], R['hi'])
            out = None
            for mu0 in [x for x in B.SCAN + [80, 90, 100, 120, 150, 200, 250, 300, 400] if x >= muD]:
                o = B.row(R, theta, mu0, phi=phi, alpha=1 + b)
                if o is not None and o[0] > 0:
                    out = (mu0, o)
                    break
            if out is None:
                P('iota %d %s: no mu0 <= 400 (theta %s, alpha %s)' % (R['iota'], capname, theta, 1 + b))
                continue
            mu0, (m, Za, Zb, Zc, rh) = out
            item('ROW-' + capname, 'iota %d (window %s, alpha = 1 + %s, spike t < %s): theta %s; Za %.3g Zb %.3g Zc %.3g'
                 % (R['iota'], name, b, tau, theta, float(Za), float(Zb), float(Zc)), 'mu >= mu0 = %d' % mu0,
                 'interval (one evaluation)', m)
n = len(B.ITEMS); nf = sum(1 for x in B.ITEMS if not x[5])
P('SUMMARY: %d items, %d FAIL' % (n, nf))
LOG.close()
print('done', n, nf)
