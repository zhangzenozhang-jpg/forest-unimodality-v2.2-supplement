#!/usr/bin/python3
"""fiber_theorem_closed: the F6 recount with the closed-form mu_0 (exact rationals; no heavy computation).

Counts the v2.1 F6 boxes on [m*, 50] (box files of the v2.1 bundle, F6_F7_one_criterion, 229 boxes with keys 'm' = the
mu-range and 'q') whose whole mu-range lies in [mu_0(iota), 50], i.e. whose lower mu-end is >= mu_0(iota): only those
become unnecessary; boxes straddling mu_0 and boxes below m* stay.  mu_0(iota) is read from the margin rows of
logs/fc_check_{B,C,D}.log (caps of v2.1, and the o2 caps where defined).  Also checks that m*(iota) < mu_0(iota) for
every iota (so every box below m* lies below mu_0 and is kept) and that the least box end equals m* of [P, supplement].
Writes logs/fc_ledger_f6.log.  Logic as ref_ledger_f6.py (version 3's
referee), rewritten here."""
import glob, json, os, re, sys
from fractions import Fraction as Fr

HERE = os.path.dirname(os.path.abspath(__file__))
LEAN = os.path.abspath(HERE)
BOX = os.path.join(LEAN, 'data',
                   'f6_boxes')
sys.path.insert(0, HERE)
from fth_data import subintervals

OUT = os.path.join(HERE, 'logs')
LOG = open(os.path.join(OUT, 'fc_ledger_f6.log'), 'w')


def P(*a):
    print(*a, file=LOG, flush=True)


ROWRE = re.compile(r'^ROW-(v21|o2)\s+PASS.*\| iota (\d+)\b.*\| range mu >= mu0 = (\d+) \|')
mu0 = {'v21': {}, 'o2': {}}
for fn in ['fc_check_B.log', 'fc_check_C.log', 'fc_check_D.log']:
    for L in open(os.path.join(OUT, fn)):
        m = ROWRE.match(L)
        if m:
            mu0[m.group(1)][int(m.group(2))] = Fr(int(m.group(3)))
assert len(mu0['v21']) == 55, len(mu0['v21'])

rows = {R['iota']: R for R in subintervals()}
tot = {'v21': 0, 'o2': 0}
allb = 0
per = []
worst_gap = None
P('fc_ledger_f6.py: F6 boxes on [m*, 50] whose lower mu-end is >= mu_0(iota) (exact rationals)')
P('box files: %s/{to50,band14_to50}/strip_NN/box_*.json' % os.path.relpath(BOX, LEAN))
for iota in range(55):
    files = sorted(glob.glob(os.path.join(BOX, 'to50', 'strip_%02d' % iota, 'box_*.json')) +
                   glob.glob(os.path.join(BOX, 'band14_to50', 'strip_%02d' % iota, 'box_*.json')))
    ms = []
    for f in files:
        d = json.load(open(f))
        ms.append((Fr(d['m'][0]), Fr(d['m'][1])))
    allb += len(ms)
    mstar = rows[iota]['mstar']
    least = min(a for a, b in ms)
    assert least == mstar, (iota, least, mstar)
    assert max(b for a, b in ms) == 50, iota
    out = {}
    for key in ('v21', 'o2'):
        m0 = mu0[key].get(iota)
        out[key] = 0 if (m0 is None or m0 > 50) else sum(1 for (a, b) in ms if a >= m0)
        tot[key] += out[key]
    m0 = mu0['v21'][iota]
    gap = m0 - mstar           # boxes below m* lie below mu_0 iff m* <= mu_0; strictly here
    worst_gap = (gap, iota) if worst_gap is None or gap < worst_gap[0] else worst_gap
    per.append((iota, len(ms), out['v21'], out['o2']))
    P('iota %2d: %d boxes on [m* = %s, 50]; lower ends %s; mu_0 v2.1 %s -> removable %d; mu_0 o2 %s -> removable %d'
      % (iota, len(ms), mstar, sorted(set(str(a) for a, b in ms), key=lambda x: Fr(x)), mu0['v21'][iota], out['v21'],
         mu0['o2'].get(iota, '-'), out['o2']))
P('TOTAL boxes on [m*, 50]: %d; removable with the caps of v2.1: %d (remaining %d); with the o2 caps: %d (remaining %d)'
  % (allb, tot['v21'], allb - tot['v21'], tot['o2'], allb - tot['o2']))
mx = max(rows[i]['mstar'] for i in range(55))
mx6 = max(rows[i]['mstar'] for i in range(6, 55))
P('boxes below m*: m*(iota) < mu_0(iota) on every iota (caps of v2.1); least mu_0 - m* = %s (= %.4f) at iota %d;'
  ' max m* over all iota = %s (iota %d), over iota >= 6 = %s; min mu_0 = %s'
  % (worst_gap[0], float(worst_gap[0]), worst_gap[1], mx, [i for i in range(55) if rows[i]['mstar'] == mx][0], mx6,
     min(mu0['v21'].values())))
assert worst_gap[0] > 0
og = min(mu0['o2'][i] - rows[i]['mstar'] for i in mu0['o2'])
P('o2 caps (where defined): least mu_0 - m* = %s (= %.4f) > 0' % (og, float(og)))
assert og > 0
nz = [(i, n, a, b) for (i, n, a, b) in per if a or b]
P('per-subinterval removable (iota: v2.1, o2): %s' % ', '.join('%d: %d, %d' % (i, a, b) for (i, n, a, b) in nz))
LOG.close()
print('done', allb, tot)
