#!/usr/bin/python3
"""fiber_theorem_closed: the finite checks of Theorem B' (closed-form spike pricing and the averaging margin), RIGOROUS.

mpmath.iv (outward rounding), 30 digits, one process.  Writes logs/fc_check_B.log.

Shared checks (independent of the subinterval):
  (B1) K_M: for M = 0..7, every j and q in [1/4, 3/4]: kappa_w(M, j) >= -K_M        (8 items, polynomial in q)
  (B2) Def_L = 0 on the spike range: 2t(alpha1 nu_m + alpha2 nu_m^2)/(N-2) <= (9/2)(1-t)^2 for t <= 0.6, N >= 10
  (B3) Phi(t; M) <= Phi_ic on the t-cells c of T_EDGES and the M-blocks i (fc_spike.py)
Per subinterval (one row each): the margin
     m = 1 - theta - 9D/(2 mu0) - r_hi^2/((1-r_hi^2) mu0) - max(Z_a, Z_b, Z_c) > 0
with Z_a = max_M (A_M mu0^{3/2} + psi(M/mu0))_+ (1-q_b)^{-M} e^{-ell0 mu0}  (and its mu-monotonicity condition),
     Z_b = max_{c,i} Phi_ic exp(-max((ell0/t_c' - L) max(m_i Ma_c, 8, t_c mu0), (ell0 - t_c' L) mu0)),
     Z_c = max(mu0, 8/0.22)^{3/2} e^{-(ell0 - 0.22 L) max(mu0, 8/0.22)}/(16 sqrt(v) aG).
The data (theta, D, ell0, lambda-range) are exact rationals of [P, supplement, Part 1]; q is enclosed outward.
"""
import sys, os
from fractions import Fraction as Fr
from mpmath import iv, mpf
from fc_core import lo, hi, alpha12, ceil_sig
import fc_spike
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fth_data import subintervals, o2_cap

iv.dps = 30
F = iv.mpf
HERE = os.path.dirname(os.path.abspath(__file__))
LOGNAME = sys.argv[1] if len(sys.argv) > 1 else 'fc_check_B.log'
ITEMS = []
LOG = None


def P(*a):
    if LOG is not None:
        print(*a, file=LOG, flush=True)


def item(tag, statement, rng, method, margin):
    ok = margin > 0
    ITEMS.append((tag, statement, rng, method, margin, ok))
    P('%-8s %-6s least margin %-12s | %s | range %s | %s' % (tag, 'PASS' if ok else 'FAIL', '%.6g' % float(margin),
                                                            statement, rng, method))
    return ok


RM = F(1) / 4
aG = iv.exp(F(-1) / 2) / iv.sqrt(2 * iv.pi)


# ----------------------------------------------------------------------------------------------- (B1) K_M
def kw_iv(M, j, q):
    from math import comb
    def b(m, i):
        if 0 <= i <= m:
            return comb(m, i) * q ** i * (1 - q) ** (m - i)
        return F(0)
    wL = q * q * (3 - 4 * q); wR = (1 - q) ** 2 * (4 * q - 1)
    fL = (1 - q) * b(M, j) - q * b(M, j - 1); fR = q * b(M, j) - (1 - q) * b(M, j + 1)
    return wL / q * fL + wR / (1 - q) * fR


KM = [Fr(255, 1000), Fr(1360, 10000), Fr(795, 10000), Fr(488, 10000), Fr(322, 10000), Fr(258, 10000),
      Fr(202, 10000), Fr(162, 10000)]


def check_B1(NQ=800):
    for M in range(8):
        worst = None
        for i in range(NQ):
            q = F([F(1) / 4 + F(i) / (2 * NQ), F(1) / 4 + F(i + 1) / (2 * NQ)])
            for j in range(-1, M + 2):
                v = kw_iv(M, j, q) + F(KM[M].numerator) / KM[M].denominator
                worst = lo(v) if worst is None else min(worst, lo(v))
        item('B1', 'kappa_w(%d, j) >= -K_%d = -%s for all j' % (M, M, KM[M]), 'q in [1/4, 3/4]',
             'interval, %d q-cells, polynomial in q' % NQ, worst)
# true maxima of -kappa_w: 0.25, 0.13348, 0.07776, 0.04768, 0.03125, 0.02510, 0.01951, 0.015625 (DIAGNOSTIC grid)


# ----------------------------------------------------------------------------------------------- (B2)
def check_B2():
    N = F(10)
    a1, a2 = alpha12(iv, N, RM)
    num = RM * iv.sqrt(N)
    lhs = 2 * F('0.6') * (a1 * num + a2 * num ** 2) / (N - 2)
    item('B2', 'Def_L = 0: 2t(alpha1 rm sqrt N + alpha2 rm^2 N)/(N-2) <= (9/2)(1-t)^2',
         't <= 0.6, N >= 10 (left side nonincreasing in N, increasing in t; right side decreasing in t)',
         'interval at t = 0.6, N = 10', lo(F(9) / 2 * F('0.16') - lhs))


# ----------------------------------------------------------------------------------------------- (B3) Phi cells
fc_spike.MULTS = [1, 2, 4, 8, 16]
T_C = F('0.22')          # part (c) covers t < 0.22; part (b) covers [0.21, 0.6)
T_EDGES = ['0.21', '0.25', '0.28', '0.30', '0.32', '0.34', '0.36', '0.38', '0.40', '0.42', '0.44', '0.46', '0.48',
           '0.50', '0.52', '0.55', '0.58', '0.59', '0.6']
PHI = []


def build_PHI(edges=T_EDGES, mu_lo=19, rm=mpf(1) / 4, log=True):
    out = []
    for a, b in zip(edges[:-1], edges[1:]):
        ta_, tb_ = (lo(F(a)) if a == edges[0] else mpf(a)), (hi(F(b)) if b == edges[-1] else mpf(b)); Ma, res = fc_spike.phi_cell(ta_, tb_, mu_lo, rm)
        assert all(v is not None for m, v in res), (a, b, res)
        out.append((ta_, tb_, lo(Ma), res))
        if log:
            ITEMS.append(('B3', 'Phi <= blockwise bounds', 't in [%s, %s]' % (a, b), 'interval', mpf(1), True))
            P('B3       bounds %s | Phi(t; M) for M in block [m Ma, m\' Ma], Ma = %.3f | range t in [%s, %s] | interval in t'
              % (' '.join('m%d:%s' % (m, ceil_sig(v, 6)) for m, v in res), float(lo(Ma)), a, b))
    return out


# ----------------------------------------------------------------------------------------------- the rows
def psi(t):
    return t - F(9) / 2 * (t - 1) ** 2


def subint_data(R):
    lamlo = F(R['lo'].numerator) / R['lo'].denominator
    lamhi = F(R['hi'].numerator) / R['hi'].denominator
    qa = lamlo / (1 + lamlo); qb = lamhi / (1 + lamhi)
    qa = F([lo(qa), hi(qa)]); qb = F([lo(qb), hi(qb)])
    ell0 = F(R['ell0'].numerator) / R['ell0'].denominator
    L = F(hi(-iv.log(1 - qb)))
    qbh = F(hi(qb))
    rhi = F(max(hi(abs(2 * qa - 1)), hi(abs(2 * qb - 1))))
    vmin = F(min(lo(qa * (1 - qa)), lo(qb * (1 - qb))))
    D = F(R['D'].numerator) / R['D'].denominator
    return qa, qb, qbh, ell0, L, rhi, vmin, D


def row(R, theta, mu0, phi=None, tcut=None, alpha=1):
    """margin of the averaging inequality at mu0 (valid for every mu >= mu0), or None if a condition fails.
    phi: the cell list (default PHI); tcut: use only cells with t_c' <= tcut; alpha: the target constant."""
    if phi is None:
        phi = PHI
    qa, qb, qbh, ell0, L, rhi, vmin, D = subint_data(R)
    th = F(theta.numerator) / theta.denominator
    al = F(alpha.numerator) / alpha.denominator if isinstance(alpha, Fr) else F(alpha)
    mu0 = F(mu0)
    Za = mpf(0)
    for M in range(8):
        A = F(KM[M].numerator) / KM[M].denominator / (4 * aG * iv.sqrt(vmin))
        psM = psi(F(M) / mu0) + (al - 1)
        g = A * mu0 ** (F(3) / 2) + psM
        wgt = hi((1 - qbh) ** (-M) * iv.exp(-ell0 * mu0))
        if lo(g) > 0:
            # (A mu^1.5 + c) e^{-ell0 mu} is nonincreasing on mu >= mu0 when ell0 (A mu0^1.5 + c) >= 1.5 A mu0^0.5
            cond = ell0 * g - F(3) / 2 * A * iv.sqrt(mu0)
            if lo(cond) <= 0:
                return None
            val = hi(g * F(wgt))
        else:
            # c < 0 only helps: bound by A mu^1.5 e^{-ell0 mu}, nonincreasing for mu >= 1.5/ell0
            if lo(ell0 * mu0) < F(3) / 2:
                return None
            val = hi(A * mu0 ** (F(3) / 2) * F(wgt))
        Za = max(Za, val)
    Zb = mpf(0)
    for (ta, tb, Ma, res) in phi:
        if tcut is not None and tb > tcut:
            continue
        ta = F(ta); tb = F(tb)
        a_c = ell0 / tb - L
        if lo(a_c) <= 0:
            return None
        for (m, v) in res:
            Mlow = F(max(lo(m * F(Ma)), mpf(8), lo(ta * mu0)))
            e1 = F(max(lo(a_c * Mlow), lo((ell0 - tb * L) * mu0)))
            Zb = max(Zb, hi((F(v) + (al - 1)) * iv.exp(-e1)))     # target psi + b: deficits raised by b
    mc = F([max(lo(mu0), lo(8 / T_C)), max(hi(mu0), hi(8 / T_C))])
    rate = ell0 - T_C * L
    if lo(rate * mc) <= F(3) / 2:
        return None
    Zc = hi((mc ** (F(3) / 2) / (16 * iv.sqrt(vmin) * aG) + (al - 1)) * iv.exp(-rate * mc))
    m = al - th - F(9) * D / (2 * mu0) - rhi ** 2 / ((1 - rhi ** 2) * mu0) - F(max(Za, Zb, Zc))
    return lo(m), Za, Zb, Zc, hi(rhi)


ROWS = subintervals()
SCAN = list(range(19, 41)) + [45, 50, 60, 70]
RESULT = {}
if __name__ == '__main__':
    LOG = open(os.path.join(HERE, 'logs', LOGNAME), 'w')
    check_B1()
    check_B2()
    PHI.extend(build_PHI())
    for capname in ['v21', 'o2']:
        P('--- rows, caps %s (Theorem B\', t_s = 0.6, r_hi <= 1/4, ell0/L_b > 0.6) ---' % capname)
        for R in ROWS:
            i = R['iota']
            if i < 6 or i > 30:
                continue
            theta = R['theta'] if capname == 'v21' else o2_cap(R['lo'], R['hi'])
            found = None
            for mu0 in SCAN:
                out = row(R, theta, mu0)
                if out is not None and out[0] > 0:
                    found = (mu0, out)
                    break
            if found is None:
                P('iota %2d caps %s theta %s: no mu0 <= 70' % (i, capname, theta))
                continue
            mu0, (m, Za, Zb, Zc, rhi) = found
            RESULT[(capname, i)] = mu0
            item('ROW-' + capname,
                 'iota %d: 1-theta-9D/(2mu0)-r^2/((1-r^2)mu0)-max(Za,Zb,Zc) > 0 (theta %s, r_hi %.4f; Za %.3g Zb %.3g Zc %.3g)'
                 % (i, theta, float(rhi), float(Za), float(Zb), float(Zc)), 'mu >= mu0 = %d' % mu0,
                 'interval (one evaluation)', m)
    n = len(ITEMS)
    nf = sum(1 for x in ITEMS if not x[5])
    P('SUMMARY: %d items, %d FAIL' % (n, nf))
    P('MU0 v21: %s' % {k[1]: v for k, v in RESULT.items() if k[0] == 'v21'})
    P('MU0 o2 : %s' % {k[1]: v for k, v in RESULT.items() if k[0] == 'o2'})
    LOG.close()
    print('done', n, nf)
