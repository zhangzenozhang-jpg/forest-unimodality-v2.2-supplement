#!/usr/bin/python3
"""fiber_theorem_closed: the finite checks of Theorem A' (the closed-form envelope theorem), RIGOROUS.

mpmath.iv (outward rounding), 30 digits, one process.  Writes logs/fc_check_A.log.

Theorem A' (r = |2q-1| <= 1/4, mu >= MU_A, t >= 0.6) needs, beyond the hand lemmas of the tex:
  (A0)  phi(s) = (18/25)(2 - s/2)^2 - 2/(1+s) >= 0 on [0, 0.67]      (exact rationals; phi concave, so the ends)
  (A1)  Q(a) = (18/25)(Lam(a)/a)^2 (1 + Lam(a)^2/75)(1-a) - 2 >= 0 on [0, 0.528],
        Lam(a) = 2a + a^2/2 + ... + a^6/6                               (6 cells; termwise monotone)
  (A2)  the envelope inequality E(s) >= 0 on the 9 s-cells of S_EDGES (one inequality per cell, in the variable s)
  (A3)  beta_e is nondecreasing on [N_min, 576]                          (one numeric inequality)
  (A4)  lambda_U >= lambda_t: 3.55[N(N-1)rho*/2 - N E2(N)] - (N+1) >= 0 on [N_min, oo)  (N-cells + a tail argument)
  (A5)  large t: Xbar(nu, N_nu) <= log(2.57 rho*(N_nu)) on nu in [0, 6]  (two ranges)
Every quantity is an explicit formula; each check is a one-variable inequality on a stated range."""
import sys, os
from mpmath import iv, mpf
from fc_core import lo, hi, alpha12, rho_star, kappaA, Ecoef

iv.dps = 30
HERE = os.path.dirname(os.path.abspath(__file__))
ARGS = sys.argv[1:]
LOGNAME = ARGS[2] if len(ARGS) > 2 else 'fc_check_A.log'
LOG = open(os.path.join(HERE, 'logs', LOGNAME), 'w')
ITEMS = []


def P(*a):
    print(*a, file=LOG, flush=True)


def item(tag, statement, rng, method, margin):
    ok = margin > 0
    ITEMS.append((tag, statement, rng, method, margin, ok))
    P('%-8s %-6s least margin %-12s | %s | range %s | %s' % (tag, 'PASS' if ok else 'FAIL', '%.6g' % float(margin),
                                                            statement, rng, method))
    return ok


MU_A = iv.mpf(ARGS[0]) if ARGS else iv.mpf(19)
RM = iv.mpf(ARGS[1]) if len(ARGS) > 1 else iv.mpf(1) / 4
P('Theorem A\' checks: mu_A = %s, r <= %s' % (MU_A, RM))
F = iv.mpf


def tq(s):
    s = F(s)
    return (iv.exp(s) * (1 + s)) ** (F(2) / 5)


# ----------------------------------------------------------------------------------------------- (A0)
from fractions import Fraction as Fr
phi0 = Fr(18, 25) * 4 - 2
s1 = Fr(67, 100)
phi1 = Fr(18, 25) * (2 - s1 / 2) ** 2 - 2 / (1 + s1)
item('A0', 'phi(s)=(18/25)(2-s/2)^2-2/(1+s) >= 0 (concave: ends)', 's in [0, 67/100]', 'exact rational',
     min(phi0, phi1))


# ----------------------------------------------------------------------------------------------- (A1)
def Lam(a):
    a = F(a)
    return 2 * a + a ** 2 / 2 + a ** 3 / 3 + a ** 4 / 4 + a ** 5 / 5 + a ** 6 / 6


def LamA(a):
    a = F(a)
    return 2 + a / 2 + a ** 2 / 3 + a ** 3 / 4 + a ** 4 / 5 + a ** 5 / 6


A1_EDGES = ['0', '0.303', '0.423', '0.479', '0.507', '0.522', '0.528']
for a, b in zip(A1_EDGES[:-1], A1_EDGES[1:]):
    v = F(18) / 25 * LamA(a) ** 2 * (1 + Lam(a) ** 2 / 75) * (1 - F(b)) - 2
    item('A1', 'Q(a) >= 0 [S >= 0 on t in [0.6,1]]', 'a in [%s, %s]' % (a, b),
         'interval, termwise monotone (Lam/a, Lam increasing; 1-a decreasing)', lo(v))


# ----------------------------------------------------------------------------------------------- (A2)
def phi(s):
    return F(18) / 25 * (2 - s / 2) ** 2 - 2 / (1 + s)


def env_cell(sa, sb, verbose=False):
    """Lower bound of T(t, M) - max(Dbar_L, Dbar_U) for t = t(s), s in [sa, sb], every M >= MU_A t, r <= RM.
    M0 = MU_A t(sa) (M >= mu t >= MU_A t_a); N0 = M0 + 2.  T >= M0 S + 2 - 6 G0 - 2k G1 - k^2 G2/(M0+3) with
    k in {3.55, 3.85 + 10/M0}; M0 S >= M0 s^2 phi(s) (s >= 0) or >= 0 (s <= 0, by (A1))."""
    s = F([sa, sb])
    M0 = MU_A * lo(tq(sa))
    M0 = F(lo(M0))
    N0 = M0 + 2
    G0 = s * s / (1 + s); G1 = s / (1 + s); G2 = 1 / ((1 + s) * (2 + s))
    kbar = F('3.85') + 10 / M0
    h = kbar / (M0 + 3)
    base = min(lo(2 - 6 * G0 - 2 * k * G1 - k * k * G2 / (M0 + 3)) for k in (F('3.55'), kbar))
    if mpf(sa) >= 0:
        base = lo(F(base) + M0 * s * s * phi(s))
    # D_L <= (sigma0 alpha1)^2/beta_L, sigma0 = s(lambda_t + h)_+ <= (s + h)_+
    a1, a2 = alpha12(iv, N0, RM)
    sig0 = F(max(hi(s + h), mpf(0)))
    num = iv.sqrt(N0) * RM
    ebar = (a1 * num + a2 * num ** 2) / (N0 + 1)
    betaL = (N0 - 1) * (1 - ebar) - 2 * sig0 * a2 - 2 * a1 ** 2 / (N0 + 1) - 4 * a1 * a2 * num / (N0 + 1) \
        - 2 * a2 ** 2 * num ** 2 / (N0 + 1)
    assert lo(betaL) > 0 and hi(ebar) < 1
    DL = hi((sig0 * a1) ** 2 / betaL)
    D = DL
    DU = mpf(0)
    if mpf(sa) < 0:
        lam = s + iv.log(1 + s)
        Gh = F(max(hi(G0), hi(F(max(hi(lam + h), mpf(0))) ** 2 / 4)))
        g1 = F(max(-lo(G1), mpf(0)))
        rs = rho_star(iv, N0, RM); kA = kappaA(iv, N0, RM)
        den = N0 - 1 - kA * Gh / rs
        assert lo(den) > 0 and lo(rs) > 0
        DUA = 4 * Gh ** 2 / (rs ** 2 * den)
        e2, e3, e4, e5 = Ecoef(iv, N0, RM)
        nm = iv.sqrt(N0) * RM
        be = N0 - 1 - (2 / rs) * (e2 + e3 * nm + e4 * nm ** 2 + e5 * nm ** 3)
        assert lo(be) > 0
        DU = hi(DUA + g1 * 4 / (rs ** 2 * be))
        D = max(D, DU)
    if verbose:
        return lo(F(base) - F(D)), base, DL, DU, M0
    return lo(F(base) - F(D))


S_EDGES = ['-0.528', '-0.373', '-0.104', '0', '0.155', '0.235', '0.317', '0.424', '0.585', '0.67']
P('t(-0.528) = %s, t(0.67) = %s' % (tq('-0.528'), tq('0.67')))
for a, b in zip(S_EDGES[:-1], S_EDGES[1:]):
    m, base, DL, DU, M0 = env_cell(lo(F(a)) if a == S_EDGES[0] else mpf(a), hi(F(b)) if b == S_EDGES[-1] else mpf(b), verbose=True)
    item('A2', 'T(t,M) - max(DbarL, DbarU) >= 0 [M0 = %.4f]' % float(lo(M0)),
         's in [%s, %s] (t in [%.4f, %.4f])' % (a, b, float(lo(tq(a))), float(hi(tq(b)))),
         'interval in s (termwise); base %.4f, DbarL %.4f, DbarU %.4f' % (float(base), float(DL), float(DU)), m)


# ----------------------------------------------------------------------------------------------- (A3)
Nmin = MU_A * F('0.6') + 2
e2, e3, e4, e5 = Ecoef(iv, Nmin, RM)
rs = rho_star(iv, Nmin, RM)
Nmax = (6 / RM) ** 2
dE = e3 * RM / (2 * iv.sqrt(Nmin)) + e4 * RM ** 2 + F(3) / 2 * e5 * RM ** 3 * iv.sqrt(Nmax)
v = 1 - (2 / rs) * dE
item('A3', "beta_e'(N) >= 1 - (2/rho*(Nmin))(e3 rm/(2 sqrt Nmin) + e4(Nmin) rm^2 + 1.5 e5 rm^3 sqrt 576) > 0",
     'N in [%.1f, %.0f] (nu_m = rm sqrt N)' % (float(lo(Nmin)), float(hi(Nmax))), 'interval (constants)', lo(v))


# ----------------------------------------------------------------------------------------------- (A4)
def E2(N, cap=None):
    e2, e3, e4, e5 = Ecoef(iv, N, RM)
    nm = iv.sqrt(N) * RM
    if cap is not None:
        nm = F(min(hi(nm), mpf(cap)))
    return e2 + e3 * nm + e4 * nm ** 2 + e5 * nm ** 3


# f(N)/N = (N-1) rho*(N)/2 - E2(N) - (N+1)/(3.55 N) is nondecreasing on [Nmin, 576]: its derivative is at least
# rho*(N)/2 - E2'(N) >= rho*(Nmin)/2 - dE (dE of (A3) bounds E2' there; rho*' >= 0; d/dN[-(N+1)/(3.55N)] > 0).
v = (Nmin - 1) * rho_star(iv, Nmin, RM) / 2 - E2(Nmin) - (Nmin + 1) / (F('3.55') * Nmin)
item('A4', '(N-1)rho*(N)/2 - E2(N) - (N+1)/(3.55N) > 0 at N = Nmin', 'N = %.1f' % float(lo(Nmin)), 'interval', lo(v))
v = rho_star(iv, Nmin, RM) / 2 - dE
item('A4', 'its N-derivative >= rho*(Nmin)/2 - dE > 0', 'N in [%.1f, %.0f]' % (float(lo(Nmin)), float(hi(Nmax))), 'interval (constants)', lo(v))
# N >= 576: E2 <= E2(576) with nu_m = 6 (constant), rho* >= rho*(576); the quadratic N(N-1)rho*/2 - N E2 - (N+1)/3.55
# is increasing for N >= 576 (derivative (2N-1) rho*/2 - E2 - 1/3.55 > 0, checked at 576).
NC = F(Nmax)
E2c = E2(NC, cap=6)
rNC = rho_star(iv, NC, RM)
v1 = F(355) / 100 * (NC * (NC - 1) * rNC / 2 - NC * E2c) - (NC + 1)
v2 = (2 * NC - 1) * rNC / 2 - E2c - 1 / F('3.55')
item('A4', '... at N = (6/rm)^2 with nu_m = 6, and its N-derivative there (increasing beyond)', 'N >= %.0f' % float(hi(NC)),
     'interval', min(lo(v1), lo(v2)))


# ----------------------------------------------------------------------------------------------- (A5)
NL = MU_A * F('1.6') + 2     # t >= 1.6, mu >= MU_A


def Xbar(nu, N):
    nu = F(nu); N = F(N)
    om = 1 - RM ** 2
    return ((N + 1) * nu ** 4 / (12 * N ** 2 * om ** 2)
            + nu * iv.sqrt(1 + nu ** 2) * (1 + nu ** 2 * (N + 1) / (6 * N * om)) / (N + 1)
            - rho_star(iv, N, RM) * (1 + nu ** 2 * (1 - 1 / N)) / 2)


def A5_range(n0, n1, mode, ncell):
    worst = None
    for i in range(ncell):
        a = n0 + (n1 - n0) * i / ncell
        b = n0 + (n1 - n0) * (i + 1) / ncell
        nu = F([a, b])
        if mode == 'fixed':
            N = NL
            v = iv.log(F('2.57') * rho_star(iv, N, RM)) - Xbar(nu, N)
        else:
            # N = nu^2/rm^2; every term of Xbar is nonincreasing in N at fixed nu, log(2.57 rho*) nondecreasing:
            # on the nu-cell use N = a^2/rm^2 for Xbar's N-monotone terms (worst = smallest N) and the cell for nu
            N = F(a) ** 2 / RM ** 2
            v = iv.log(F('2.57') * rho_star(iv, N, RM)) - Xbar(nu, N)
        worst = lo(v) if worst is None else min(worst, lo(v))
    return worst


nu1 = RM * iv.sqrt(NL)
w1 = A5_range(mpf(0), hi(nu1), 'fixed', 4)
item('A5', 'Xbar(nu, N) <= log(2.57 rho*(N)) [large t]', 'nu in [0, %.3f], N = %.1f' % (float(hi(nu1)), float(lo(NL))),
     'interval, 4 nu-cells', w1)
w2 = A5_range(hi(nu1), mpf(6), 'tied', 8)
item('A5', 'Xbar(nu, nu^2/rm^2) <= log(2.57 rho*(nu^2/rm^2))', 'nu in [%.3f, 6]' % float(hi(nu1)),
     'interval, 8 nu-cells (N at the cell\'s left end)', w2)
c06 = 2 * iv.exp(F(-1) / 2) * F('1.6') ** (F(-3) / 2) * iv.exp(F(3) / (4 * NL) + F('1.1') / NL ** 2)
item('A5', '2 a_U(N) 1.6^{-3/2} e^{-1/2} <= 0.6225 (log a_U <= 3/(4N) + 1.1/N^2)', 'N >= %.1f' % float(lo(NL)),
     'interval', lo(F('0.6225') - c06))

n = len(ITEMS)
nf = sum(1 for x in ITEMS if not x[5])
P('SUMMARY: %d items, %d FAIL; least margin %s' % (n, nf, min(float(x[4]) for x in ITEMS)))
LOG.close()
print('done', n, nf)
