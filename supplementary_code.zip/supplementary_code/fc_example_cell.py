"""Print the termwise values of one (A2) cell, for the worked example in the tex (rigorous interval values)."""
from mpmath import iv, mpf
from fc_core import lo, hi, alpha12
iv.dps = 30
F = iv.mpf
sa, sb = mpf('0.155'), mpf('0.235')
s = F([sa, sb])
t = lambda x: (iv.exp(F(x)) * (1 + F(x))) ** (F(2) / 5)
ta = lo(t(sa)); M0 = F(lo(19 * F(ta))); N0 = M0 + 2
kbar = F('3.85') + 10 / M0; h = kbar / (M0 + 3)
G0 = s * s / (1 + s); G1 = s / (1 + s); G2 = 1 / ((1 + s) * (2 + s))
phi = F(18) / 25 * (2 - s / 2) ** 2 - 2 / (1 + s)
print('t(s_a) =', ta, ' M0 =', M0, ' kbar =', kbar, ' h =', h)
print('G0 =', G0, ' G1 =', G1, ' G2 =', G2, ' phi =', phi)
for k in (F('3.55'), kbar):
    print('k =', k, ' 2 - 6G0 - 2kG1 - k^2 G2/(M0+3) >=', lo(2 - 6 * G0 - 2 * k * G1 - k * k * G2 / (M0 + 3)))
print('M0 s^2 phi >=', lo(M0 * s * s * phi))
a1, a2 = alpha12(iv, N0, F(1) / 4)
num = iv.sqrt(N0) / 4
sig0 = F(hi(s + h))
ebar = (a1 * num + a2 * num ** 2) / (N0 + 1)
betaL = (N0 - 1) * (1 - ebar) - 2 * sig0 * a2 - 2 * a1 ** 2 / (N0 + 1) - 4 * a1 * a2 * num / (N0 + 1) - 2 * a2 ** 2 * num ** 2 / (N0 + 1)
print('alpha1 =', a1, ' alpha2 =', a2, ' sigma0 <=', sig0, ' ebar =', ebar, ' betaL =', betaL)
print('DbarL <=', hi((sig0 * a1) ** 2 / betaL))
