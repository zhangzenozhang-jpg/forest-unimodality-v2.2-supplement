#!/usr/bin/python3
"""fiber_theorem_closed: Theorem C' (the wing, closed form) and the rows of subintervals 31-39, RIGOROUS.

mpmath.iv, 30 digits, one process.  Writes logs/fc_check_C.log.

Wing class (r_a, r_b, tau, mu_W): for r = |2q-1| in [r_a, r_b], mu >= mu_W, t in [tau, 0.6], every j: F >= psi(t).
U piece (the only one that needs work; L piece: (B2); M range: >= 2):
  Xi_U >= T(t, M) + N Delta - (A1/rho_U) G(lambda^T_U) - |sigma_U| ((2N/rho_U) e_U - N Delta)_+
       >= (N-2) S + tau1 + c r_a^2 N - b r_a sqrt(N) - g1 De           (nu = r sqrt N >= r_a sqrt N)
  tau1 = 2 - 6 G0 + 2(3.55)|G1| - kbar^2 G2/(M0+3)  (the template's constant part, nondecreasing in M),
  c = (N-1)/(1-r_a^2) - kappaA Ghat/rho*,  b = 4 Ghat/rho*,  De = 4/(rho*^2 beta_e)  (at N0; monotone in N),
  valid when r_a sqrt(N0) >= b/(2c) (then nu -> c nu^2 - b nu is increasing on nu >= r_a sqrt N).
w(N) = alpha N^2 + beta N - b r_a sqrt(N) + gamma is convex in N; its minimum over N >= N0 is w(N0) if w'(N0) >= 0,
and otherwise at least the minimum of the quadratic obtained from the tangent of sqrt at N1 = -beta'/(2 alpha).
"""
import sys, os
from fractions import Fraction as Fr
from mpmath import iv, mpf
from fc_core import lo, hi, G_of, G1_of, G2_of, Ecoef, rho_star, kappaA
import fc_check_B as B

iv.dps = 30
F = iv.mpf
HERE = os.path.dirname(os.path.abspath(__file__))
LOG = open(os.path.join(HERE, 'logs', 'fc_check_C.log'), 'w')
B.LOG = LOG
ITEMS = B.ITEMS


def P(*a):
    print(*a, file=LOG, flush=True)


def wing_cell(ta, tb, ra, rb, muW):
    t = F([ta, tb])
    ra = F(ra); rb = F(rb)
    M0 = F(lo(F(muW) * F(ta)))
    N0 = M0 + 2
    lam = F(5) / 2 * iv.log(t)
    G0 = G_of(iv, lam); G1 = G1_of(iv, lam); G2 = G2_of(iv, lam)
    # S on the cell: mean-value form (fc_spike.S_upper_neg gives an upper bound of (-S)_+)
    import fc_spike
    S = F([-fc_spike.S_upper_neg(ta, tb), hi(F(9) / 2 * (t - 1) ** 2 / t - 2 * G0)])
    kbar = F('3.85') + 10 / M0
    tau1 = 2 - 6 * G0 + 2 * F('3.55') * (-G1) - kbar ** 2 * G2 / (M0 + 3)
    Gh = F(max(hi(G0), hi(G_of(iv, lam + kbar / (M0 + 3)))))
    g1 = F(max(-lo(G1), mpf(0)))
    rs = rho_star(iv, N0, rb); kA = kappaA(iv, N0, rb)
    e2, e3, e4, e5 = Ecoef(iv, N0, rb)
    nm = F(min(hi(rb * iv.sqrt(N0)), mpf(6)))
    be = N0 - 1 - (2 / rs) * (e2 + e3 * nm + e4 * nm ** 2 + e5 * nm ** 3)
    assert lo(be) > 0 and lo(rs) > 0
    De = 4 / (rs ** 2 * be)
    kprime = kA * Gh / rs
    bb = 4 * Gh / rs
    c0 = (N0 - 1) / (1 - ra ** 2) - kprime
    cond = ra * iv.sqrt(N0) - bb / (2 * c0)
    if lo(c0) <= 0 or lo(cond) < 0:
        return None, 'nu-condition fails'
    # w(N) = alpha N^2 + beta N - bb ra sqrt(N) + gam
    alpha = ra ** 2 / (1 - ra ** 2)
    beta = S - ra ** 2 / (1 - ra ** 2) - kprime * ra ** 2
    gam = tau1 - 2 * S - g1 * De
    w0 = alpha * N0 ** 2 + beta * N0 - bb * ra * iv.sqrt(N0) + gam
    dw0 = 2 * alpha * N0 + beta - bb * ra / (2 * iv.sqrt(N0))
    if lo(dw0) >= 0:
        return lo(w0), 'min at N0 = %.2f' % float(lo(N0))
    # tangent of sqrt at N1: sqrt(N) <= sqrt(N1)/2 + N/(2 sqrt(N1))
    best = None
    for N1 in [lo(N0) * k for k in (1, 1.5, 2, 3, 4, 6, 8)]:
        N1 = F(N1)
        bp = beta - bb * ra / (2 * iv.sqrt(N1))
        gp = gam - bb * ra * iv.sqrt(N1) / 2
        v = gp - bp ** 2 / (4 * alpha)
        best = lo(v) if best is None else max(best, lo(v))
    return min(best, lo(w0)), 'interior minimum'


CLASSES = [
    # (name, r_a, r_b, tau, iotas, t-cell edges); r_a rounded down, r_b rounded up against the exact ends of fth_data
    ('Wa', Fr(566, 10000), Fr(741, 10000), '0.58', [31, 32], ['0.58', '0.59', '0.6']),
    ('Wb', Fr(740, 10000), Fr(1112, 10000), '0.55', [33, 34, 35, 36], ['0.55', '0.56', '0.57', '0.585', '0.6']),
    ('Wc', Fr(1111, 10000), Fr(1667, 10000), '0.52', [37, 38, 39], ['0.52', '0.53', '0.54', '0.555', '0.575', '0.6']),
]

B.PHI.extend(B.build_PHI(log=False))
for (name, ra, rb, tau, iotas, cedges) in CLASSES:
    raF = F(ra.numerator) / ra.denominator; rbF = F(rb.numerator) / rb.denominator
    # check the class contains the subintervals' r-ranges
    for R in B.ROWS:
        if R['iota'] in iotas:
            qa, qb, qbh, ell0, L, rhi, vmin, D = B.subint_data(R)
            assert min(lo(abs(2 * qa - 1)), lo(abs(2 * qb - 1))) >= hi(raF) and \
                max(hi(abs(2 * qa - 1)), hi(abs(2 * qb - 1))) <= lo(rbF), (R['iota'], name)   # member r-range in the class
    found = None
    for muW in [16, 17, 18, 19, 20, 22, 24, 26, 28, 30]:
        edges = [lo(F(x)) if i == 0 else (hi(F(x)) if i == len(cedges) - 1 else mpf(x)) for i, x in enumerate(cedges)]
        res = [wing_cell(a, b, raF, rbF, muW) for a, b in zip(edges[:-1], edges[1:])]
        if all(r[0] is not None and r[0] > 0 for r in res):
            found = (muW, edges, res)
            break
    if found is None:
        P('class %s: no mu_W <= 30' % name)
        continue
    muW, edges, res = found
    for (a, b), (v, how) in zip(zip(edges[:-1], edges[1:]), res):
        B.item('C1', 'wing class %s (r in [%s, %s]): min over N >= mu_W t + 2 of w(N) >= 0 (%s)' % (name, ra, rb, how),
               't in [%.3f, %.3f], mu >= %d' % (float(a), float(b), muW), 'interval in t (closed form in N)', v)
    for R in B.ROWS:
        if R['iota'] not in iotas:
            continue
        qa, qb, qbh, ell0, L, rhi, vmin, D = B.subint_data(R)
        ra_i = F(min(lo(abs(2 * qa - 1)), lo(abs(2 * qb - 1))))
        rb_i = F(max(hi(abs(2 * qa - 1)), hi(abs(2 * qb - 1))))
        assert lo(ra_i) >= hi(raF) and hi(rb_i) <= lo(rbF), (R['iota'], ra_i, rb_i)
        assert lo(ell0 / L) > hi(F(tau)), (R['iota'], ell0 / L)
        out = None
        for mu0 in B.SCAN:
            if mu0 < muW:
                continue
            o = B.row(R, R['theta'], mu0, tcut=mpf(tau))
            if o is not None and o[0] > 0:
                out = (mu0, o)
                break
        if out is None:
            P('iota %d: no mu0' % R['iota'])
            continue
        mu0, (m, Za, Zb, Zc, rhi) = out
        B.item('ROW-v21', 'iota %d (wing %s, spike t < %s): 1-theta-9D/(2mu0)-r^2/((1-r^2)mu0)-max(Za,Zb,Zc) > 0 '
               '(theta %s; Za %.3g Zb %.3g Zc %.3g)' % (R['iota'], name, tau, R['theta'], float(Za), float(Zb), float(Zc)),
               'mu >= mu0 = %d' % mu0, 'interval (one evaluation)', m)
        oo = None
        from fth_data import o2_cap
        for mu0 in B.SCAN:
            if mu0 < muW:
                continue
            o = B.row(R, o2_cap(R['lo'], R['hi']), mu0, tcut=mpf(tau))
            if o is not None and o[0] > 0:
                oo = (mu0, o)
                break
        if oo is not None:
            mu0, (m, Za, Zb, Zc, rhi) = oo
            B.item('ROW-o2', 'iota %d (wing %s): o2 cap %s' % (R['iota'], name, o2_cap(R['lo'], R['hi'])),
                   'mu >= mu0 = %d' % mu0, 'interval (one evaluation)', m)
        else:
            P('iota %d o2: no mu0 <= 70' % R['iota'])
n = len(ITEMS); nf = sum(1 for x in ITEMS if not x[5])
P('SUMMARY: %d items, %d FAIL' % (n, nf))
LOG.close()
print('done', n, nf)
